#include "compassmain.h"
#include "ui_compassmain.h"
#include <QtWidgets>
#include "QRect"	
#include "QDesktopWidget"
#include "globals.h"
CompassMain::CompassMain(QWidget *parent) :
	QMainWindow(parent),
	ui(new Ui::CompassMain)
{
    ui->setupUi(this);
    renderMainWidget();
}

CompassMain::~CompassMain()
{
	delete ui;
}

void CompassMain::renderMainWidget()
{
    cWidget = new centralWidgetClass(this);
    disconnect(cWidget);
    connect(cWidget, SIGNAL(label()), this, SLOT(renderLabel()));
    connect(cWidget, SIGNAL(analyze()), this, SLOT(renderAnalyze()));
    connect(cWidget, SIGNAL(assign()), this, SLOT(renderAssign()));
    connect(cWidget, SIGNAL(convert()), this, SLOT(renderConvert()));
    connect(cWidget, SIGNAL(about()), this, SLOT(renderAbout()));
    CompassMain::setCentralWidget(cWidget);
}

void CompassMain::renderLabel()
{
    winGss = new CompassSpinSystem(this);
    disconnect(winGss);
    connect(winGss, SIGNAL(goToMain()), this, SLOT(renderMainWidget()));
    CompassMain::setCentralWidget(winGss);
}

void CompassMain::renderAnalyze()
{
    winAnalyze = new CompassQuery(this);
    disconnect(winAnalyze);
    connect(winAnalyze, SIGNAL(goToMain()), this, SLOT(renderMainWidget()));
    CompassMain::setCentralWidget(winAnalyze);
}

void CompassMain::renderAssign()
{
    winRename = new CompassRename(this);
    disconnect(winRename);
    connect(winRename, SIGNAL(goToMain()), this, SLOT(renderMainWidget()));
    connect(winRename, SIGNAL(renderRename()), this, SLOT(renderRename()));
    CompassMain::setCentralWidget(winRename);
}

void CompassMain::renderRename()
{
    winIndex = new CompassIndex(this);
    disconnect(winIndex);
    connect(winIndex, SIGNAL(goToMain()), this, SLOT(renderMainWidget()));
    connect(winIndex, SIGNAL(renderManualMode()), this, SLOT(renderManualMode()));
    CompassMain::setCentralWidget(winIndex);
}

void CompassMain::renderManualMode()
{
    winManual= new CompassManualMode(this);
    disconnect(winManual);
    connect(winManual, SIGNAL(goToMain()), this, SLOT(renderMainWidget()));
    connect(winManual, SIGNAL(renderCompassMode()), this, SLOT(renderRename()));
    CompassMain::setCentralWidget(winManual);
}

void CompassMain::renderAbout()
{
	winAbout = new CompassAbout(this);
    disconnect(winAbout);
    connect(winAbout, SIGNAL(goToMain()), this, SLOT(renderMainWidget()));
    CompassMain::setCentralWidget(winAbout);
}

void CompassMain::renderConvert()
{
    winConvert = new CompassConvert(this);
    disconnect(winConvert);
    connect(winConvert, SIGNAL(goToMain()), this, SLOT(renderMainWidget()));
    CompassMain::setCentralWidget(winConvert);
}
