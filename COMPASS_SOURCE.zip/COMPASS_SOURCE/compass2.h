#ifndef COMPASS2_H
#define COMPASS2_H
#include <fstream>
#include <cmath>
#include <complex>
#include <iostream>
#include <iomanip>
#include <vector>
#include <limits>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>



void sortListsb(int match, std::string namefiles);
int compass_analyzeb(std::string cafile, std::string cbcafile, std::string cofile, std::string cafile2, std::string cbcafile2, std::string cofile2, std::string seq, std::string ss, std::string deutS, int match, int first, double dev, std::string namefiles, std::string resultfile, std::string indexfile, std::string hsqcfile, int maxFS);
#endif // COMPASS2_H
