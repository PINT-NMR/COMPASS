#ifndef COMPASSSPINSYSTEM_H
#define COMPASSSPINSYSTEM_H

#include <QWidget>
#include <QUrl>
#include "compasshelp5.h"

namespace Ui
{
	class CompassSpinSystem;
}

class CompassSpinSystem : public QWidget
{
	Q_OBJECT

public:
    explicit CompassSpinSystem(QWidget *parent = 0);
	~CompassSpinSystem();

private:
	Ui::CompassSpinSystem *ui;

private slots:
    std::vector < std::vector < std::string > > DefVec2(int x, int y);
    std::vector < std::string > DefVec(int x);
  //  bool removeDir(const QString & dirName);
    bool Check_CACB_Limits(std::string fname);
    void removeFiles(const QString & dirName);
	void on_menuButton_clicked();
	void on_SpinSystemButton_clicked();
	void on_HSQCButton_clicked();
	void on_HNCOButton_clicked();
	void on_HNCACOButton_clicked();
	void on_HNCACBButton_clicked();
	void on_HNCAButton_clicked();
	void on_HNCOCAButton_clicked();
	void on_HNCOCACBButton_clicked();
	void getDir();
	void on_folderButton_clicked();
    void load_project_parameters();
    void on_helpButton_clicked();
	void loadParam(QString path);
	void Show_CType(int state);
	void Fake_AssignHSQC();
	void Fake_AssignHSQCandHNCO();
	void Fake_AssignHNCOandHNCACO();
	void Fake_AssignnoHSQC();
	void Fake_AssignHNCACB();
	void Fake_AssignHNCACBandHNCOCACB();
	void Fake_AssignHNcaCBandHNcocaCB();
	void Fake_AssignHNcocaCB();
	void Fake_AssignHNcaCB();
    void Fake_AssignCBCACONH();
	void Fake_AssignHNCA();
	void Fake_AssignHNCAandHNCOCA();
	void Fake_AssignHNCACO();
	void Fake_AssignHNCO();
	void Fake_AssignHNCOCA();
	void Clear_HSQCarray();
	void Make_Warnings();
	int analysis();
	QString File_Format_Check2D(std::string infile);
	QString File_Format_Check3D(std::string infile, std::string Ctype);
	std::string ftoa1(double dub);
	bool Check_Duplicates(std::string infile);
	bool Check_UnAssigned(std::string infile);
    void setParam();
    void saveParam();
    void connectLines();
    void clear_form();
    void on_clearButton_clicked();
    void on_loadPriorButton_clicked();
    void on_quitButton_clicked();
    void showError();

signals:
    void goToMain();
};

#endif
