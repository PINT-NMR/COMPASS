#ifndef PARSER2_H
#define PARSER2_H
#include "compassvec.h"
#include "passdef.h"
#include "vector"
struct ResultType2 {
	double score;
	int resno;
    std::string res[MAX_RES];
    std::string ss[MAX_RES];
};
struct ParserType2
{
    double deuter;
    double pdeuter;
    std::string aa1;
    std::string aa2;
    std::vector<std::string> sequence;


    double ca[MAX_RES], cb[MAX_RES], co[MAX_RES];
	
    ParserType2() {
		   for (int i=0; i<MAX_RES; i++)
		           ca[i] = cb[i] = co[i] = 0.0;
		   deuter = 0.0;
		   pdeuter = 0.0;
	}

    void parse(int argc, char argv[][1000])
	{
		for (int i=0; i<MAX_RES; i++)
            ca[i] = cb[i] = co[i] = 0.0;

        for (int i = 1; i<argc;) {
		    if (!strcmp("-ca1", argv[i])) {
				ca[0] = atof(argv[i+1]);
				i += 2;
				continue;
			}
		    if (!strcmp("-ca2", argv[i])) {
				ca[1] = atof(argv[i+1]);
				i += 2;
		                continue;
			}
		    if (!strcmp("-cb1", argv[i])) {
				cb[0] = atof(argv[i+1]);
				i += 2;
				continue;
			}
		    if (!strcmp("-cb2", argv[i])) {
				cb[1] = atof(argv[i+1]);
				i += 2;
				continue;
			}
		    if (!strcmp("-co1", argv[i])) {
				co[0] = atof(argv[i+1]);
				i += 2;
				continue;
			}
		    if (!strcmp("-co2", argv[i])) {
				co[1] = atof(argv[i+1]);
				i += 2;
				continue;
			}
		    if (!strcmp("-seq", argv[i])) {
				aa1 = argv[i+1];
				aa2 = argv[i+2];
                std::stringstream ss(aa1);
                std::string s;
				while (ss >> s)
				{
					sequence.push_back(s);
					if(ss.peek() == ',')
						ss.ignore();
				}
                std::stringstream ss2(aa2);
                std::string s2;
				while (ss2 >> s2)
				{
					sequence.push_back(s2);
					if(ss.peek() == ',')
				ss.ignore();
				}
				i += 3;
				continue;
			}
		    if (!strcmp("-D", argv[i])) {
				deuter = 1.0;
				i++;
				continue;
			}
		    if (!strcmp("-pD", argv[i])) {
				pdeuter = 1.0;
				i++;
				continue;
			}
			else {
				i++;
			}
		}
    }
    std::vector<std::string> readSequence(std::string aa1, std::string aa2)
	{
        char s[5000];
        std::string s2 = aa1 + " " + aa2;
		int size2 = s2.size();
		for (int a=0; a<=size2; a++)
			s[a]=s2[a];
	    #define IS_PUNC(c) ((c) == ' ' || (c) == '\t')
            #define IS_END(c) ((c) == '\0' || (c) == '\n')
		int i =0;
        std::vector<std::string> word;
			word.resize(0);
    	    while (!IS_END(*s)) {
                int jj=0;
    			char t[MAX_LINE];
                std::string tt;
                while (IS_PUNC(s[i] !=0))  
					i++;
				if (!IS_END(*s))
					break;
	    	    while (!IS_PUNC(*s) && !IS_END(*s)) {
	    			t[jj++] = s[i++];
				}
	    	    t[jj] = '\0';
	    		word.push_back(t);
	    	}
    		#undef IS_PUNC
    		#undef IS_END
       		return word;
	}
};
#endif
