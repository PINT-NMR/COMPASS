#include "compasshelp2.h"
#include "ui_compasshelp2.h"
#include <QtWidgets>

CompassHelp2::CompassHelp2(QWidget *parent) :
    QDialog(parent),
	ui(new Ui::CompassHelp2)
{
	ui->setupUi(this);
}

CompassHelp2::~CompassHelp2()
{
	delete ui;
}

void CompassHelp2::on_closeButton_clicked()
{
    accept();
}
