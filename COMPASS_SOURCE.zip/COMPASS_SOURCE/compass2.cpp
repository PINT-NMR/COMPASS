#include "compass2.h"
#define MAX_LIN 100
#include <string.h>

#include "mfunc.h"

using namespace std;

void sortListsb(int match, string namefiles)
{

    ifstream Iresultfile2, Iresultfile3, Iresultfile4, Iresultfile5, Iresultfile6, Iresultfile7, Iresultfile8, Iresultfile9, Iresultfile10;
    ofstream resultfile2, resultfile3, resultfile4, resultfile5, resultfile6,resultfile7,resultfile8,resultfile9,resultfile10;
    ofstream resultfile2b, resultfile3b, resultfile4b, resultfile5b, resultfile6b,resultfile7b,resultfile8b,resultfile9b,resultfile10b;
    string filen2, filen3, filen4, filen5, filen6, filen7, filen8, filen9, filen10;

    namefiles+="Analysis/";

    string converted, line, sub;
    stringstream converted_out;
    converted_out << match;
    converted = converted_out.str();
    filen2=namefiles;
    filen2+="compass_result2_match";
    filen2+=converted;
    filen3=namefiles;
    filen3+="compass_result3_match";
    filen3+=converted;
    filen4=namefiles;
    filen4+="compass_result4_match";
    filen4+=converted;
    filen5=namefiles;
    filen5+="compass_result5_match";
    filen5+=converted;
    filen6=namefiles;
    filen6+="compass_result6_match";
    filen6+=converted;
    filen7=namefiles;
    filen7+="compass_result7_match";
    filen7+=converted;
    filen8=namefiles;
    filen8+="compass_result8_match";
    filen8+=converted;
    filen9=namefiles;
    filen9+="compass_result9_match";
    filen9+=converted;
    filen10=namefiles;
    filen10+="compass_result10_match";
    filen10+=converted;

    int lineC=0, least=0, tempL=0;
    string lineArr[1000][33];
    string tempA, tempFil;
    double tempF=0.0;
    Iresultfile2.open (filen2.c_str(), ios::in);
    while(Iresultfile2.good())
    {
        getline(Iresultfile2,line);
        lineC++;
    }
    Iresultfile2.clear();
    Iresultfile2.close();
    Iresultfile2.open (filen2.c_str(), ios::in);
    for(int i=0; i<(lineC-1)/31; i++)
    {
        for(int j=0; j<31; j++)
        {
            getline(Iresultfile2, lineArr[i][j]);
        }
        istringstream iss(lineArr[i][3]);
        iss >> sub;
        iss >> sub;
        iss >> sub;
        unsigned pos = sub.find("-");
        lineArr[i][31]=sub.substr(0,pos);
        iss >> sub;
        iss >> sub;
        lineArr[i][32]=sub;
    }
    Iresultfile2.clear();
    Iresultfile2.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempL=atoi(lineArr[i][31].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempL>atoi(lineArr[j][31].c_str()))
            {
                tempL=atoi(lineArr[j][31].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }

    filen2+="_sort";
    resultfile2.open (filen2.c_str(), ios::out);
    tempFil=filen2;
    tempFil+=".bak";
    resultfile2b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile2<<lineArr[i][j]<<endl;
            resultfile2b<<lineArr[i][j]<<endl;
        }
    resultfile2.clear();
    resultfile2.close();
    resultfile2b.clear();
    resultfile2b.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempF=atof(lineArr[i][32].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempF>atof(lineArr[j][32].c_str()))
            {
                tempF=atof(lineArr[j][32].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }
    filen2+="CHI";
    resultfile2.open (filen2.c_str(), ios::out);
    tempFil=filen2;
    tempFil+=".bak";
    resultfile2b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile2<<lineArr[i][j]<<endl;
            resultfile2b<<lineArr[i][j]<<endl;
        }
    resultfile2.clear();
    resultfile2.close();
    resultfile2b.clear();
    resultfile2b.close();
    lineC=0;

    Iresultfile3.open (filen3.c_str(), ios::in);
    while(Iresultfile3.good())
    {
        getline(Iresultfile3,line);
        lineC++;
    }
    Iresultfile3.clear();
    Iresultfile3.close();
    Iresultfile3.open (filen3.c_str(), ios::in);
    for(int i=0; i<(lineC-1)/31; i++)
    {
        for(int j=0; j<31; j++)
            getline(Iresultfile3, lineArr[i][j]);
        istringstream iss(lineArr[i][3]);
        iss >> sub;
        iss >> sub;
        iss >> sub;
        unsigned pos = sub.find("-");
        lineArr[i][31]=sub.substr(0,pos);
        iss >> sub;
        iss >> sub;
        lineArr[i][32]=sub;
    }
    Iresultfile3.clear();
    Iresultfile3.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempL=atoi(lineArr[i][31].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempL>atoi(lineArr[j][31].c_str()))
            {
                tempL=atoi(lineArr[j][31].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }

    filen3+="_sort";
    resultfile3.open (filen3.c_str(), ios::out);
    tempFil=filen3;
    tempFil+=".bak";
    resultfile3b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile3<<lineArr[i][j]<<endl;
            resultfile3b<<lineArr[i][j]<<endl;
        }
    resultfile3.clear();
    resultfile3.close();
    resultfile3b.clear();
    resultfile3b.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempF=atof(lineArr[i][32].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempF>atof(lineArr[j][32].c_str()))
            {
                tempF=atof(lineArr[j][32].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }
    filen3+="CHI";
    resultfile3.open (filen3.c_str(), ios::out);
    tempFil=filen3;
    tempFil+=".bak";
    resultfile3b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile3<<lineArr[i][j]<<endl;
            resultfile3b<<lineArr[i][j]<<endl;
        }
    resultfile3.clear();
    resultfile3.close();
    resultfile3b.clear();
    resultfile3b.close();
    lineC=0;


    Iresultfile4.open (filen4.c_str(), ios::in);
    while(Iresultfile4.good())
    {
        getline(Iresultfile4,line);
        lineC++;
    }
    Iresultfile4.clear();
    Iresultfile4.close();
    Iresultfile4.open (filen4.c_str(), ios::in);
    for(int i=0; i<(lineC-1)/31; i++)
    {
        for(int j=0; j<31; j++)
            getline(Iresultfile4, lineArr[i][j]);
        istringstream iss(lineArr[i][3]);
        iss >> sub;
        iss >> sub;
        iss >> sub;
        unsigned pos = sub.find("-");
        lineArr[i][31]=sub.substr(0,pos);
        iss >> sub;
        iss >> sub;
        lineArr[i][32]=sub;
    }
    Iresultfile4.clear();
    Iresultfile4.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempL=atoi(lineArr[i][31].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempL>atoi(lineArr[j][31].c_str()))
            {
                tempL=atoi(lineArr[j][31].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }

    filen4+="_sort";
    resultfile4.open (filen4.c_str(), ios::out);
    tempFil=filen4;
    tempFil+=".bak";
    resultfile4b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile4<<lineArr[i][j]<<endl;
            resultfile4b<<lineArr[i][j]<<endl;
        }
    resultfile4.clear();
    resultfile4.close();
    resultfile4b.clear();
    resultfile4b.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempF=atof(lineArr[i][32].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempF>atof(lineArr[j][32].c_str()))
            {
                tempF=atof(lineArr[j][32].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }
    filen4+="CHI";
    resultfile4.open (filen4.c_str(), ios::out);
    tempFil=filen4;
    tempFil+=".bak";
    resultfile4b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile4<<lineArr[i][j]<<endl;
            resultfile4b<<lineArr[i][j]<<endl;
        }
    resultfile4.clear();
    resultfile4.close();
    resultfile4b.clear();
    resultfile4b.close();
    lineC=0;


    Iresultfile5.open (filen5.c_str(), ios::in);
    while(Iresultfile5.good())
    {
        getline(Iresultfile5,line);
        lineC++;
    }
    Iresultfile5.clear();
    Iresultfile5.close();
    Iresultfile5.open (filen5.c_str(), ios::in);
    for(int i=0; i<(lineC-1)/31; i++)
    {
        for(int j=0; j<31; j++)
            getline(Iresultfile5, lineArr[i][j]);
        istringstream iss(lineArr[i][3]);
        iss >> sub;
        iss >> sub;
        iss >> sub;
        unsigned pos = sub.find("-");
        lineArr[i][31]=sub.substr(0,pos);
        iss >> sub;
        iss >> sub;
        lineArr[i][32]=sub;
    }
    Iresultfile5.clear();
    Iresultfile5.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempL=atoi(lineArr[i][31].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempL>atoi(lineArr[j][31].c_str()))
            {
                tempL=atoi(lineArr[j][31].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }

    filen5+="_sort";
    resultfile5.open (filen5.c_str(), ios::out);
    tempFil=filen5;
    tempFil+=".bak";
    resultfile5b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile5<<lineArr[i][j]<<endl;
            resultfile5b<<lineArr[i][j]<<endl;
        }
    resultfile5.clear();
    resultfile5.close();
    resultfile5b.clear();
    resultfile5b.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempF=atof(lineArr[i][32].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempF>atof(lineArr[j][32].c_str()))
            {
                tempF=atof(lineArr[j][32].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }
    filen5+="CHI";
    resultfile5.open (filen5.c_str(), ios::out);
    tempFil=filen5;
    tempFil+=".bak";
    resultfile5b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile5<<lineArr[i][j]<<endl;
            resultfile5b<<lineArr[i][j]<<endl;
        }
    resultfile5.clear();
    resultfile5.close();
    resultfile5b.clear();
    resultfile5b.close();
    lineC=0;

    Iresultfile6.open (filen6.c_str(), ios::in);
    while(Iresultfile6.good())
    {
        getline(Iresultfile6,line);
        lineC++;
    }
    Iresultfile6.clear();
    Iresultfile6.close();
    Iresultfile6.open (filen6.c_str(), ios::in);
    for(int i=0; i<(lineC-1)/31; i++)
    {
        for(int j=0; j<31; j++)
            getline(Iresultfile6, lineArr[i][j]);
        istringstream iss(lineArr[i][3]);
        iss >> sub;
        iss >> sub;
        iss >> sub;
        unsigned pos = sub.find("-");
        lineArr[i][31]=sub.substr(0,pos);
        iss >> sub;
        iss >> sub;
        lineArr[i][32]=sub;
    }
    Iresultfile6.clear();
    Iresultfile6.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempL=atoi(lineArr[i][31].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempL>atoi(lineArr[j][31].c_str()))
            {
                tempL=atoi(lineArr[j][31].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }

    filen6+="_sort";
    resultfile6.open (filen6.c_str(), ios::out);
    tempFil=filen6;
    tempFil+=".bak";
    resultfile6b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile6<<lineArr[i][j]<<endl;
            resultfile6b<<lineArr[i][j]<<endl;
        }
    resultfile6.clear();
    resultfile6.close();
    resultfile6b.clear();
    resultfile6b.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempF=atof(lineArr[i][32].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempF>atof(lineArr[j][32].c_str()))
            {
                tempF=atof(lineArr[j][32].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }
    filen6+="CHI";
    resultfile6.open (filen6.c_str(), ios::out);
    tempFil=filen6;
    tempFil+=".bak";
    resultfile6b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile6<<lineArr[i][j]<<endl;
            resultfile6b<<lineArr[i][j]<<endl;
        }
    resultfile6.clear();
    resultfile6.close();
    resultfile6b.clear();
    resultfile6b.close();
    lineC=0;


    Iresultfile7.open (filen7.c_str(), ios::in);
    while(Iresultfile7.good())
    {
        getline(Iresultfile7,line);
        lineC++;
    }
    Iresultfile7.clear();
    Iresultfile7.close();
    Iresultfile7.open (filen7.c_str(), ios::in);
    for(int i=0; i<(lineC-1)/31; i++)
    {
        for(int j=0; j<31; j++)
            getline(Iresultfile7, lineArr[i][j]);
        istringstream iss(lineArr[i][3]);
        iss >> sub;
        iss >> sub;
        iss >> sub;
        unsigned pos = sub.find("-");
        lineArr[i][31]=sub.substr(0,pos);
        iss >> sub;
        iss >> sub;
        lineArr[i][32]=sub;
    }
    Iresultfile7.clear();
    Iresultfile7.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempL=atoi(lineArr[i][31].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempL>atoi(lineArr[j][31].c_str()))
            {
                tempL=atoi(lineArr[j][31].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }

    filen7+="_sort";
    resultfile7.open (filen7.c_str(), ios::out);
    tempFil=filen7;
    tempFil+=".bak";
    resultfile7b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile7<<lineArr[i][j]<<endl;
            resultfile7b<<lineArr[i][j]<<endl;
        }
    resultfile7.clear();
    resultfile7.close();
    resultfile7b.clear();
    resultfile7b.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempF=atof(lineArr[i][32].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempF>atof(lineArr[j][32].c_str()))
            {
                tempF=atof(lineArr[j][32].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }
    filen7+="CHI";
    resultfile7.open (filen7.c_str(), ios::out);
    tempFil=filen7;
    tempFil+=".bak";
    resultfile7b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile7<<lineArr[i][j]<<endl;
            resultfile7b<<lineArr[i][j]<<endl;
        }
    resultfile7.clear();
    resultfile7.close();
    resultfile7b.clear();
    resultfile7b.close();
    lineC=0;


    Iresultfile8.open (filen8.c_str(), ios::in);
    while(Iresultfile8.good())
    {
        getline(Iresultfile8,line);
        lineC++;
    }
    Iresultfile8.clear();
    Iresultfile8.close();
    Iresultfile8.open (filen8.c_str(), ios::in);
    for(int i=0; i<(lineC-1)/31; i++)
    {
        for(int j=0; j<31; j++)
            getline(Iresultfile8, lineArr[i][j]);
        istringstream iss(lineArr[i][3]);
        iss >> sub;
        iss >> sub;
        iss >> sub;
        unsigned pos = sub.find("-");
        lineArr[i][31]=sub.substr(0,pos);
        iss >> sub;
        iss >> sub;
        lineArr[i][32]=sub;
    }
    Iresultfile8.clear();
    Iresultfile8.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempL=atoi(lineArr[i][31].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempL>atoi(lineArr[j][31].c_str()))
            {
                tempL=atoi(lineArr[j][31].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }

    filen8+="_sort";
    resultfile8.open (filen8.c_str(), ios::out);
    tempFil=filen8;
    tempFil+=".bak";
    resultfile8b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile8<<lineArr[i][j]<<endl;
            resultfile8b<<lineArr[i][j]<<endl;
        }
    resultfile8.clear();
    resultfile8.close();
    resultfile8b.clear();
    resultfile8b.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempF=atof(lineArr[i][32].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempF>atof(lineArr[j][32].c_str()))
            {
                tempF=atof(lineArr[j][32].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }
    filen8+="CHI";
    resultfile8.open (filen8.c_str(), ios::out);
    tempFil=filen8;
    tempFil+=".bak";
    resultfile8b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile8<<lineArr[i][j]<<endl;
            resultfile8b<<lineArr[i][j]<<endl;
        }
    resultfile8.clear();
    resultfile8.close();
    resultfile8b.clear();
    resultfile8b.close();
    lineC=0;
    Iresultfile9.open (filen9.c_str(), ios::in);
    while(Iresultfile9.good())
    {
        getline(Iresultfile9,line);
        lineC++;
    }
    Iresultfile9.clear();
    Iresultfile9.close();
    Iresultfile9.open (filen9.c_str(), ios::in);
    for(int i=0; i<(lineC-1)/31; i++)
    {
        for(int j=0; j<31; j++)
            getline(Iresultfile9, lineArr[i][j]);
        istringstream iss(lineArr[i][3]);
        iss >> sub;
        iss >> sub;
        iss >> sub;
        unsigned pos = sub.find("-");
        lineArr[i][31]=sub.substr(0,pos);
        iss >> sub;
        iss >> sub;
        lineArr[i][32]=sub;
    }
    Iresultfile9.clear();
    Iresultfile9.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempL=atoi(lineArr[i][31].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempL>atoi(lineArr[j][31].c_str()))
            {
                tempL=atoi(lineArr[j][31].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }

    filen9+="_sort";
    resultfile9.open (filen9.c_str(), ios::out);
    tempFil=filen9;
    tempFil+=".bak";
    resultfile9b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile9<<lineArr[i][j]<<endl;
            resultfile9b<<lineArr[i][j]<<endl;
        }
    resultfile9.clear();
    resultfile9.close();
    resultfile9b.clear();
    resultfile9b.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempF=atof(lineArr[i][32].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempF>atof(lineArr[j][32].c_str()))
            {
                tempF=atof(lineArr[j][32].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }
    filen9+="CHI";
    resultfile9.open (filen9.c_str(), ios::out);
    tempFil=filen9;
    tempFil+=".bak";
    resultfile9b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile9<<lineArr[i][j]<<endl;
            resultfile9b<<lineArr[i][j]<<endl;
        }
    resultfile9.clear();
    resultfile9.close();
    resultfile9b.clear();
    resultfile9b.close();
    lineC=0;

    Iresultfile10.open (filen10.c_str(), ios::in);
    while(Iresultfile10.good())
    {
        getline(Iresultfile10,line);
        lineC++;
    }
    Iresultfile10.clear();
    Iresultfile10.close();
    Iresultfile10.open (filen10.c_str(), ios::in);
    for(int i=0; i<(lineC-1)/31; i++)
    {
        for(int j=0; j<31; j++)
            getline(Iresultfile10, lineArr[i][j]);
        istringstream iss(lineArr[i][3]);
        iss >> sub;
        iss >> sub;
        iss >> sub;
        unsigned pos = sub.find("-");
        lineArr[i][31]=sub.substr(0,pos);
        iss >> sub;
        iss >> sub;
        lineArr[i][32]=sub;
    }
    Iresultfile10.clear();
    Iresultfile10.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempL=atoi(lineArr[i][31].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempL>atoi(lineArr[j][31].c_str()))
            {
                tempL=atoi(lineArr[j][31].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }

    filen10+="_sort";
    resultfile10.open (filen10.c_str(), ios::out);
    tempFil=filen10;
    tempFil+=".bak";
    resultfile10b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile10<<lineArr[i][j]<<endl;
            resultfile10b<<lineArr[i][j]<<endl;
        }
    resultfile10.clear();
    resultfile10.close();
    resultfile10b.clear();
    resultfile10b.close();

    for(int i=0; i<(lineC-1)/31; i++)
    {
        least=i;
        tempF=atof(lineArr[i][32].c_str());
        for(int j=i+1; j<(lineC-1)/31; j++)
        {
            if(tempF>atof(lineArr[j][32].c_str()))
            {
                tempF=atof(lineArr[j][32].c_str());
                least=j;
            }
        }
        if(least!=i)
            for(int k=0; k<33; k++)
            {
                tempA=lineArr[i][k];
                lineArr[i][k]=lineArr[least][k];
                lineArr[least][k]=tempA;
            }
    }
    filen10+="CHI";
    resultfile10.open (filen10.c_str(), ios::out);
    tempFil=filen10;
    tempFil+=".bak";
    resultfile10b.open (tempFil.c_str(), ios::out);
    for(int i=0; i<(lineC-1)/31; i++)
        for(int j=0; j<31; j++)
        {
            resultfile10<<lineArr[i][j]<<endl;
            resultfile10b<<lineArr[i][j]<<endl;
        }
    resultfile10.clear();
    resultfile10.close();
    resultfile10b.clear();
    resultfile10b.close();
    lineC=0;
}
int compass_analyzeb(string cafile, string cbcafile, string cofile, string cafile2, string cbcafile2, string cofile2, string seq, string ss, string deutS, int match, int first, double dev, string namefiles,string resultfile, string indexfile, string hsqcfile, int maxFS)
{
    if(resultfile=="" || deutS=="" || hsqcfile=="")
    {}
    int maxf=2;
    int res2no=0;
    string outname="";
    int lo=match;
    {
        bool errB=false;
        int sizei=0, sizei1=0, m=0, n=0;
        int counter=1, counter2=0, size=0;
        vector<double> ca_array, cb_array, co_array, ca, cb, co, cai, cbi, coi, cai1, cbi1, coi1; //3000
        vector<string> shifts2, names, ca_name_array, cb_name_array, co_name_array, name, namei, namei1;    //3000
        string line="", line2="", line3="", sub="", sub2="", sub3="", sub4="", sub5="";
        double doub=0.0, gly=0.0, gly2=0.0;

        string D="";
        bool is_gly = false;
        string pD="";
        if(deutS=="-D")
            D="-D";
        else if(deutS=="-pD")
            pD="-pD";
        int resultNO=0;
        ifstream file;
        fstream errors;
        vector<string> arr4, arr5, arr6, arr7, arr8, arr9, arr10, sarr4, sarr5, sarr6, sarr7, sarr8, sarr9, sarr10; //10000
        fstream output_file;
        int cc=0;
        string errors1 = namefiles;
        string MaxFrag = namefiles;
        MaxFrag += "Analysis/SetMaxFrag.txt";
        MaxFrag+="2";
        ofstream frag;
        frag.open(MaxFrag.c_str());
        errors1+="Temp/rename_errors.txt";

        errors.open(errors1.c_str(), ios::out);

        if(indexfile!="EMPTY")
        {
            file.open(indexfile.c_str());
            if(!file.is_open())
            {
                errors<<"Index file not found. Aborting."<<endl<<endl;
                errors.clear();
                errors.close();
                errB=true;
            }
            else
            {
            file.clear();
            file.close();
            }
        }

        vector <string> ss_sequence;
        string sub_temp;
        if(ss!="EMPTY")
        {
            file.open(ss.c_str(), ios::in);
            while(file>>sub_temp)
                ss_sequence.push_back(sub_temp);
            file.clear();
            file.close();
        }

        vector <string> seq_sequence;
        file.open(seq.c_str(), ios::in);
        while(file>>sub_temp)
            seq_sequence.push_back(sub_temp);
        file.clear();
        file.close();


        match = lo;
        if (errB== false)
        {
            int CA, CB, CO, CA2, CB2, CO2;
            CA=0;
            CB=0;
            CO=0;
            CA2=0;
            CB2=0;
            CO2=0;
            if(cbcafile2!="EMPTY")
            {
                file.open(cbcafile2.c_str(), ios::in);
                getline(file, line);
                getline(file, line);
                while(file.good())
                {
                    getline(file, line);
                    CB2++;
                }
                file.clear();
                file.close();
            }
            if(cbcafile!="EMPTY")
            {
                file.open(cbcafile.c_str(), ios::in);
                getline(file, line);
                getline(file, line);
                while(file.good())
                {
                    getline(file, line);
                    CB++;
                }
                file.clear();
                file.close();
            }
            if(cafile2!="EMPTY")
            {
                file.open(cafile2.c_str(), ios::in);
                getline(file, line);
                getline(file, line);
                while(file.good())
                {
                    getline(file, line);
                    CA2++;
                }
                file.clear();
                file.close();
            }
            if(cafile!="EMPTY")
            {
                file.open(cafile.c_str(), ios::in);
                getline(file, line);
                getline(file, line);
                while(file.good())
                {
                    getline(file, line);
                    CA++;
                }
                file.clear();
                file.close();
            }
            if(cofile2!="EMPTY")
            {
                file.open(cofile2.c_str(), ios::in);
                getline(file, line);
                getline(file, line);
                while(file.good())
                {
                    getline(file, line);
                    CO2++;
                }
                file.clear();
                file.close();
            }
            if(cofile!="EMPTY")
            {
                file.open(cofile.c_str(), ios::in);
                getline(file, line);
                getline(file, line);
                while(file.good())
                {
                    getline(file, line);
                    CO++;
                }
                file.clear();
                file.close();
            }

            int aArr=0;
            int bArr=0;
            int oArr=0;
            string named;
            if(cbcafile2!="EMPTY")
            {
                file.open(cbcafile2.c_str(), ios::in);
                getline(file, line);
                getline(file, line);
                for (int i=0; i<CB2;i++)
                {
                        getline (file, line);
                    istringstream iss(line);
                    iss >> sub;
                    unsigned Pos = sub.find_last_of("-");
                    if(sub.substr(Pos-2, 2)=="CB")
                    {
                        cb_name_array.push_back(sub);
                        iss >> sub;
                        iss >> sub;
                        cb_array.push_back(atof(sub.c_str()));
                        bArr++;
                    }
                    else if(sub.substr(Pos-2, 2)=="CA")
                    {
                        ca_name_array.push_back(sub);
                            iss >> sub;
                        iss >> sub;
                        ca_array.push_back(atof(sub.c_str()));
                        aArr++;
                    }
                }
                file.clear();
                file.close();
            }
            string temp;
        if(cbcafile!="EMPTY")
        {
            file.open(cbcafile.c_str(), ios::in);
            getline(file, line);
            getline(file, line);
            for (int i=0; i<CB;i++)
            {
                        getline (file, line);
                    istringstream iss(line);
                    iss >> sub;
                    named=sub;
                    unsigned pos = named.find_last_of("-");
                    iss >> sub;
                    iss >> sub;
                    doub = atof(sub.c_str());
                    temp=sub;
                    iss >> sub;
                    if(named.substr(pos-2, 2)=="CB")
                    {
                        cb_name_array.push_back(named);
                        cb_array.push_back(doub);
                        bArr++;
                    }
                    else if(named.substr(pos-2, 2)=="CA")
                    {
                        ca_name_array.push_back(named);
                        ca_array.push_back(doub);
                        aArr++;
                    }

            }
            file.clear();
            file.close();
        }
        if(cafile2!="EMPTY")
        {
            file.open(cafile2.c_str(), ios::in);
            getline(file, line);
            getline(file, line);
            for (int i=0; i<CA2;i++)
            {
                    getline (file, line);
                    istringstream iss(line);
                    iss >> sub;
		    bool found = false;
            for(uint j=0; j<ca_name_array.size(); j++)
			    if(sub==ca_name_array[j])
			    {
				    found = true;
				    break;
			    }
		    if(found==false)
	                    ca_name_array.push_back(sub);
                    iss >> sub;
                    iss >> sub;
		    if(found==false)
		    {
			    ca_array.push_back(atof(sub.c_str()));
	                    aArr++;
		    }
            }
            file.clear();
            file.close();
        }
        if(cafile!="EMPTY")
        {
            file.open(cafile.c_str(), ios::in);
            getline(file, line);
            getline(file, line);
            for (int i=0; i<CA;i++)
            {
                    getline (file, line);
                    istringstream iss(line);
                    iss >> sub;
		    bool found = false;
            for(uint j=0; j<ca_name_array.size(); j++)
			    if(sub==ca_name_array[j])
			    {
				    found = true;
				    break;
			    }
		    if(found==false)
	                    ca_name_array.push_back(sub);
                    iss >> sub;
                    iss >> sub;
		    if(found==false)
		    {
			    ca_array.push_back(atof(sub.c_str()));
	                    aArr++;
		    }
            }
            file.clear();
            file.close();
        }
        if(cofile2!="EMPTY")
        {
            file.open(cofile2.c_str(), ios::in);
            getline(file, line);
            getline(file, line);
            for (int i=0; i<CO2;i++)
            {
                    getline (file, line);
                    istringstream iss(line);
                    iss >> sub;
                    co_name_array.push_back(sub);
                    iss >> sub;
                    iss >> sub;
                    co_array.push_back(atof(sub.c_str()));
                    oArr++;
            }
            file.clear();
            file.close();
        }
        if(cofile!="EMPTY")
        {
            file.open(cofile.c_str(), ios::in);
            getline(file, line);
            getline(file, line);
            for (int i=0; i<CO;i++)
            {
                    getline (file, line);
                    istringstream iss(line);
                    iss >> sub;
                    co_name_array.push_back(sub);
                    iss >> sub;
                    iss >> sub;
                    co_array.push_back(atof(sub.c_str()));
                    oArr++;
            }
            file.clear();
            file.close();
        }

        for(int i=0; i<aArr;i++)
        {
            if(ca_name_array[i]=="EMPTY")
                continue;
            else
                for(int j=i+1; j<aArr;j++)
                {
                    if(ca_name_array[i]==ca_name_array[j] && ca_name_array[i]!="EMPTY")
                    {
                        ca_name_array[j]="EMPTY";
                        ca_array[j]=0;
                        break;
                    }
                }
        }
        for(int i=0; i<aArr;i++)
            if(ca_name_array[i]=="EMPTY")
            {
                for(int j=i+1; j<aArr;j++)
                    if(ca_name_array[j]!="EMPTY")
                    {
                        ca_name_array[i]=ca_name_array[j];
                        ca_array[i]=ca_array[j];
                        ca_name_array[j]="EMPTY";
                        ca_array[j]=0;
                        break;
                    }
            }
        for(int i=0; i<aArr; i++)
            if(ca_name_array[i]=="EMPTY")
            {
                aArr=i;
                break;
            }
        for(int i=0; i<bArr;i++)
        {
            if(cb_name_array[i]=="EMPTY")
                continue;
            else
                for(int j=i+1; j<bArr;j++)
                {
                    if(cb_name_array[i]==cb_name_array[j] && cb_name_array[i]!="EMPTY")
                    {
                        cb_name_array[j]="EMPTY";
                        cb_array[j]=0;
                        break;
                    }
                }
        }
        for(int i=0; i<bArr;i++)
            if(cb_name_array[i]=="EMPTY")
            {
                for(int j=i+1; j<bArr;j++)
                    if(cb_name_array[j]!="EMPTY")
                    {
                        cb_name_array[i]=cb_name_array[j];
                        cb_array[i]=cb_array[j];
                        cb_name_array[j]="EMPTY";
                        cb_array[j]=0;
                        break;
                    }
            }

        for(int i=0; i<bArr; i++)
            if(cb_name_array[i]=="EMPTY")
            {
                bArr=i;
                break;
            }

        for(int i=0; i<oArr;i++)
        {
            if(co_name_array[i]=="EMPTY")
                continue;
            else
                for(int j=i+1; j<oArr;j++)
                {
                    if(co_name_array[i]==co_name_array[j] && co_name_array[i]!="EMPTY")
                    {
                        co_name_array[j]="EMPTY";
                        co_array[j]=0;
                        break;
                    }
                }
        }
        for(int i=0; i<oArr;i++)
            if(co_name_array[i]=="EMPTY")
            {
                for(int j=i+1; j<oArr;j++)
                    if(co_name_array[j]!="EMPTY")
                    {
                        co_name_array[i]=co_name_array[j];
                        co_array[i]=co_array[j];
                        co_name_array[j]="EMPTY";
                        co_array[j]=0;
                        break;
                    }
            }
        for(int i=0; i<oArr; i++)
            if(co_name_array[i]=="EMPTY")
            {
                oArr=i;
                break;
            }

        bool found=false;
        int nArr=0;
        int nArr2;
        for(int a=0; a<aArr;a++)
        {
            name.push_back(ca_name_array[a]);
            ca.push_back(ca_array[a]);
            cb.push_back(0.0);
            co.push_back(0.0);
            nArr++;
        }
            nArr2=nArr;

        for(int b=0; b<bArr;b++)
        {
            found=false;
            for(int a=0;a<nArr2;a++)
            {
                unsigned pos = cb_name_array[b].find_last_of("-");
                unsigned pos2= name[a].find_last_of("-");
                sub=cb_name_array[b].substr(0,pos-2);
                sub2=name[a].substr(0,pos2-2);
                if(sub==sub2)
                {
                    cb[a]=cb_array[b];
                    found=true;
                    break;
                }
            }
            if(found==false)
            {
                unsigned pos = cb_name_array[b].find_last_of("-");
                sub=cb_name_array[b].substr(0,pos-2);
                sub+="CA";
                sub+=cb_name_array[b].substr(pos);
                name.push_back(sub);
                ca.push_back(0.0);
                cb.push_back(cb_array[b]);
                co.push_back(0.0);
                nArr++;
            }
        }
        nArr2=nArr;
        for(int o=0; o<oArr;o++)
        {
            found=false;
            for(int a=0;a<nArr2;a++)
            {
                unsigned pos = co_name_array[o].find_last_of("-");
                unsigned pos2= name[a].find_last_of("-");
                sub=co_name_array[o].substr(0,pos-2);
                sub2=name[a].substr(0,pos2-2);
                if(sub==sub2)
                {
                    co[a]=co_array[o];
                    found=true;
                    break;
                }
            }
            if(found==false)
            {
                unsigned pos = co_name_array[o].find_last_of("-");
                sub=co_name_array[o].substr(0,pos-2);
                sub+="CA";
                sub+=co_name_array[o].substr(pos);
                name.push_back(sub);
                ca.push_back(0.0);
                cb.push_back(0.0);
                co.push_back(co_array[o]);
                nArr++;
            }
        }
	

        size=nArr;
        int j=0;
        int k=0;
        for (int i=0; i<size; i++)
        {
            unsigned pos = name[i].find_last_of("-");
            if (name[i].substr(pos)=="-HN")
            {
                        namei.push_back(name[i]);
                        cai.push_back(ca[i]);
                        cbi.push_back(cb[i]);
                        coi.push_back(co[i]);
                        j++;
                sizei++;
            }
            else
            {
                    namei1.push_back(name[i]);
                        cai1.push_back(ca[i]);
                        cbi1.push_back(cb[i]);
                        coi1.push_back(co[i]);
                sizei1++;
                        k++;
            }
        }
        fstream dm_file;
        fstream dm_name_file;
        string dmname1, dmname2;

        dmname1=namefiles;
        dmname2=namefiles;
        dmname1+="Temp/dm_fileXXXXXX.txt";
        dmname2+="Temp/dm_name_fileXXXXXX.txt";
        dmname1+="2";
        dmname2+="2";
        dm_file.open (dmname1.c_str(), ios::out);
        dm_name_file.open (dmname2.c_str(), ios::out);
        if (match==3)
        {
            for (int i=0; i<sizei; i++)
            {
                for(int j=0; j<sizei1; j++)
                {
                    unsigned pos = namei[i].find ("N-");
                    unsigned pos2 = namei1[j].find ("N-");
                    sub2=namei[i].substr (0,pos);
                    sub3=namei1[j].substr (0, pos2);
                    if(sub2!=sub3)
                    {
                        int check_zeroa=0;
                        int check_zerob=0;
                        int check_zeroo=0;
                        int check_zeroes=0;
                        if(cai[i]==0)
                            check_zeroa++;
                        if(cai1[j]==0)
                            check_zeroa++;
                        if(cbi[i]==0 && cai[i]>48)
                                check_zerob++;
                        if(cbi[i]==0 && cai[i]==0)
                            check_zerob++;
                        if(cbi1[j]==0 && cai1[j]>48)
                            check_zerob++;
                        if(cbi1[j]==0 && cai1[j]==0)
                            check_zerob++;
                        if(coi[i]==0)
                            check_zeroo++;
                        if(coi1[j]==0)
                            check_zeroo++;
                        check_zeroes=check_zeroa+check_zerob+check_zeroo;
                        if(check_zeroes==0)
                        {
                            if(cai[i]+dev>=cai1[j] && cai[i]-dev<=cai1[j])
                            {
                                if(cbi[i]+dev>=cbi1[j] && cbi[i]-dev<=cbi1[j])
                                {
                                    if(coi[i]+dev>=coi1[j] && coi[i]-dev<=coi1[j])
                                    {
                                        for (int k=0; k<sizei1; k++)
                                        {
                                            unsigned pos =namei1[k].find ("N-");
                                            unsigned pos2=namei[i].find ("N-");
                                            sub2=namei1[k].substr (0,pos);
                                            sub3=namei[i].substr (0,pos2);
                                            m=-1;
                                            if (sub2==sub3)
                                            {
                                                m=k;
                                                break;
                                            }
                                        }
                                        for (int l=0; l<sizei; l++)
                                        {
                                            unsigned pos =namei[l].find ("N-");
                                            unsigned pos2=namei1[j].find ("N-");
                                            sub3=namei1[j].substr (0,pos2);
                                            sub2=namei[l].substr (0,pos);
                                            n=-1;
                                            if (sub2==sub3)
                                            {
                                                n=l;
                                                break;
                                            }
                                        }
                                        if(m!=-1 && n!=-1)
                                        {
                                            dm_file <<cai1[m]<<"\t"<<cbi1[m]<<"\t"<<coi1[m]<<"\t"<< (cai[i]+cai1[j])/2 << "\t" << (cbi[i]+cbi1[j])/2 << "\t" << (coi[i]+coi1[j])/2<<"\t"<<cai[n]<<"\t"<<cbi[n]<<"\t"<<coi[n]<<endl;
                                            dm_name_file <<namei1[m]<<"\t"<< namei[i] << "\t" << namei1[j]<<"\t"<< namei[n] <<endl;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        else if(match!=3)
        {
            for (int i=0; i<sizei; i++)
            {
                for(int j=0; j<sizei1; j++)
                {
                    unsigned pos = namei[i].find ("N-");
                    unsigned pos2 = namei1[j].find ("N-");
                    sub2=namei[i].substr (0,pos);
                    sub3=namei1[j].substr (0, pos2);
                    if(sub2!=sub3)
                    {
                        int check_zeroa=0;
                        int check_zerob=0;
                        int check_zeroo=0;
                        int check_zeroes=0;
                        if(cai[i]==0)
                                check_zeroa++;
                        if(cai1[j]==0)
                            check_zeroa++;
                        if(cbi[i]==0 && cai[i]>48)
                            check_zerob++;
                        if(cbi[i]==0 && cai[i]==0)
                            check_zerob++;
                        if(cbi1[j]==0 && cai1[j]>48)
                            check_zerob++;
                        if(cbi1[j]==0 && cai1[j]==0)
                            check_zerob++;
                        if(coi[i]==0)
                            check_zeroo++;
                        if(coi1[j]==0)
                            check_zeroo++;
                        check_zeroes=check_zeroa+check_zerob+check_zeroo;
                        if(match==1)
                            match=5;
                        if(check_zeroes<=match && check_zeroa<match && check_zerob<match && check_zeroo<match)
                        {
                            if(cai[i]+dev>=cai1[j] && cai[i]-dev<=cai1[j])
                            {
                                if(cbi[i]+dev>=cbi1[j] && cbi[i]-dev<=cbi1[j])
                                {
                                    if(coi[i]+dev>=coi1[j] && coi[i]-dev<=coi1[j])
                                    {
                                        for (int k=0; k<sizei1; k++)
                                        {
                                            unsigned pos =namei1[k].find ("N-");
                                            unsigned pos2=namei[i].find ("N-");
                                            sub2=namei1[k].substr (0,pos);
                                            sub3=namei[i].substr (0,pos2);
                                            m=-1;
                                            if (sub2==sub3)
                                            {
                                                m=k;
                                                break;
                                            }
                                        }
                                        for (int l=0; l<sizei; l++)
                                        {
                                            unsigned pos =namei[l].find ("N-");
                                            unsigned pos2=namei1[j].find ("N-");
                                            sub2=namei[l].substr (0,pos);
                                            sub3=namei1[j].substr (0,pos2);
                                            n=-1;
                                            if (sub2==sub3)
                                            {
                                                n=l;
                                                break;
                                            }
                                        }
                                        if(m!=-1 && n!=-1)
                                        {
                                            dm_file <<cai1[m]<<"\t"<<cbi1[m]<<"\t"<<coi1[m]<<"\t"<< (cai[i]+cai1[j])/2 << "\t" << (cbi[i]+cbi1[j])/2 << "\t" << (coi[i]+coi1[j])/2<<"\t"<<cai[n]<<"\t"<<cbi[n]<<"\t"<<coi[n]<<endl;
                                            dm_name_file <<namei1[m]<<"\t"<< namei[i] << "\t" << namei1[j]<<"\t"<< namei[n] <<endl;
                                        }
                                    }
                                    else if (coi[i]==0 || coi1[j]==0)
                                    {
                                        for (int k=0; k<sizei1; k++)
                                        {
                                            unsigned pos =namei1[k].find ("N-");
                                            unsigned pos2=namei[i].find ("N-");
                                            sub2=namei1[k].substr (0,pos);
                                            sub3=namei[i].substr (0,pos2);
                                            m=-1;
                                            if (sub2==sub3)
                                            {
                                                m=k;
                                                break;
                                            }
                                        }
                                        for (int l=0; l<sizei; l++)
                                        {
                                            unsigned pos =namei[l].find ("N-");
                                            unsigned pos2=namei1[j].find ("N-");
                                            sub2=namei[l].substr (0,pos);
                                            sub3=namei1[j].substr (0,pos2);
                                            n=-1;
                                            if (sub2==sub3)
                                            {
                                                n=l;
                                                break;
                                            }
                                        }
                                        if(m!=-1 && n!=-1)
                                        {
                                            dm_file <<cai1[m]<<"\t"<<cbi1[m]<<"\t"<<coi1[m]<<"\t"<< (cai[i]+cai1[j])/2 << "\t" << (cbi[i]+cbi1[j])/2 << "\t" << (2*coi[i]+2*coi1[j])/2<<"\t"<<cai[n]<<"\t"<<cbi[n]<<"\t"<<coi[n]<<endl;
                                            dm_name_file <<namei1[m]<<"\t"<< namei[i] << "\t" << namei1[j]<<"\t"<< namei[n] <<endl;
                                        }
                                    }
                                }
                                else if(cbi[i]==0 || cbi1[j]==0)
                                {
                                    if(coi[i]+dev>=coi1[j] && coi[i]-dev<=coi1[j])
                                    {
                                        for (int k=0; k<sizei1; k++)
                                        {
                                            unsigned pos =namei1[k].find ("N-");
                                            unsigned pos2=namei[i].find ("N-");
                                            sub2=namei1[k].substr (0,pos);
                                            sub3=namei[i].substr (0,pos2);
                                            m=-1;
                                            if (sub2==sub3)
                                            {
                                                m=k;
                                                break;
                                            }
                                        }
                                        for (int l=0; l<sizei; l++)
                                        {
                                            unsigned pos =namei[l].find ("N-");
                                            unsigned pos2=namei1[j].find ("N-");
                                            sub2=namei[l].substr (0,pos);
                                            sub3=namei1[j].substr (0,pos2);
                                            n=-1;
                                            if (sub2==sub3)
                                            {
                                                n=l;
                                                break;
                                            }
                                        }
                                        if(m!=-1 && n!=-1)
                                        {
                                            dm_file <<cai1[m]<<"\t"<<cbi1[m]<<"\t"<<coi1[m]<<"\t"<< (cai[i]+cai1[j])/2 << "\t" << (2*cbi[i]+2*cbi1[j])/2 << "\t" << (coi[i]+coi1[j])/2<<"\t"<<cai[n]<<"\t"<<cbi[n]<<"\t"<<coi[n]<<endl;
                                            dm_name_file <<namei1[m]<<"\t"<< namei[i] << "\t" << namei1[j]<<"\t"<< namei[n] <<endl;
                                        }
                                    }
                                }
                                else if(cai[i]==0 || cai1[j]==0)
                                {
                                    if(cbi[i]+dev>=cbi1[j] && cbi[i]-dev<=cbi1[j] && coi[i]+dev>=coi1[j] && coi[i]-dev<=coi1[j])
                                    {
                                        for (int k=0; k<sizei1; k++)
                                        {
                                            unsigned pos =namei1[k].find ("N-");
                                            unsigned pos2=namei[i].find ("N-");
                                            sub2=namei1[k].substr (0,pos);
                                            sub3=namei[i].substr (0,pos2);
                                            m=-1;
                                            if (sub2==sub3)
                                            {
                                                m=k;
                                                break;
                                            }
                                        }
                                        for (int l=0; l<sizei; l++)
                                        {
                                            unsigned pos =namei[l].find ("N-");
                                            unsigned pos2=namei1[j].find ("N-");
                                            sub2=namei[l].substr (0,pos);
                                            sub3=namei1[j].substr (0,pos2);
                                            n=-1;
                                            if (sub2==sub3)
                                            {
                                                n=l;
                                                break;
                                            }
                                        }
                                        if(m!=-1 && n!=-1)
                                        {
                                            dm_file <<cai1[m]<<"\t"<<cbi1[m]<<"\t"<<coi1[m]<<"\t"<< (2*cai[i]+2*cai1[j])/2 << "\t" << (cbi[i]+cbi1[j])/2 << "\t" << (coi[i]+coi1[j])/2<<"\t"<<cai[n]<<"\t"<<cbi[n]<<"\t"<<coi[n]<<endl;
                                            dm_name_file <<namei1[m]<<"\t"<< namei[i] << "\t" << namei1[j]<<"\t"<< namei[n] <<endl;
                                        }
                                    }
                                }
                            }
                        }
                        else if (check_zeroes==2)
                        {
                            if (check_zeroa==2)
                            {
                                if(cbi[i]+dev>=cbi1[j] && cbi[i]-dev<=cbi1[j] && coi[i]+dev>=coi1[j] && coi[i]-dev<=coi1[j])
                                {
                                    for (int k=0; k<sizei1; k++)
                                    {
                                        unsigned pos =namei1[k].find ("N-");
                                        unsigned pos2=namei[i].find ("N-");
                                        sub2=namei1[k].substr (0,pos);
                                        sub3=namei[i].substr (0,pos2);
                                        m=-1;
                                        if (sub2==sub3)
                                        {
                                            m=k;
                                            break;
                                        }
                                    }
                                    for (int l=0; l<sizei; l++)
                                    {
                                        unsigned pos =namei[l].find ("N-");
                                        unsigned pos2=namei1[j].find ("N-");
                                        sub2=namei[l].substr (0,pos);
                                        sub3=namei1[j].substr (0,pos2);
                                        n=-1;
                                        if (sub2==sub3)
                                        {
                                            n=l;
                                            break;
                                        }
                                    }
                                    if(m!=-1 && n!=-1)
                                    {
                                        dm_file <<cai1[m]<<"\t"<<cbi1[m]<<"\t"<<coi1[m]<<"\t"<< (2*cai[i]+2*cai1[j])/2 << "\t" << (cbi[i]+cbi1[j])/2 << "\t" << (coi[i]+coi1[j])/2<<"\t"<<cai[n]<<"\t"<<cbi[n]<<"\t"<<coi[n]<<endl;
                                        dm_name_file <<namei1[m]<<"\t"<< namei[i] << "\t" << namei1[j]<<"\t"<< namei[n] <<endl;
                                    }
                                }
                            }
                            if (check_zerob==2)
                            {
                                if(cai[i]+dev>=cai1[j] && cai[i]-dev<=cai1[j] && coi[i]+dev>=coi1[j] && coi[i]-dev<=coi1[j])
                                {
                                    for (int k=0; k<sizei1; k++)
                                    {
                                        unsigned pos =namei1[k].find ("N-");
                                        unsigned pos2=namei[i].find ("N-");
                                        sub2=namei1[k].substr (0,pos);
                                        sub3=namei[i].substr (0,pos2);
                                        m=-1;
                                        if (sub2==sub3)
                                        {
                                            m=k;
                                            break;
                                        }
                                    }
                                    for (int l=0; l<sizei; l++)
                                    {
                                        unsigned pos =namei[l].find ("N-");
                                        unsigned pos2=namei1[j].find ("N-");
                                        sub2=namei[l].substr (0,pos);
                                        sub3=namei1[j].substr (0,pos2);
                                        n=-1;
                                        if (sub2==sub3)
                                        {
                                            n=l;
                                            break;
                                        }
                                    }
                                    if (m!=-1 && n!=-1)
                                    {
                                        dm_file <<cai1[m]<<"\t"<<cbi1[m]<<"\t"<<coi1[m]<<"\t"<< (cai[i]+cai1[j])/2 << "\t" << (2*cbi[i]+2*cbi1[j])/2 << "\t" << (coi[i]+coi1[j])/2<<"\t"<<cai[n]<<"\t"<<cbi[n]<<"\t"<<coi[n]<<endl;
                                        dm_name_file <<namei1[m]<<"\t"<< namei[i] << "\t" << namei1[j]<<"\t"<< namei[n] <<endl;
                                    }
                                }
                            }
                            if (check_zeroo==2)
                            {
                                if(cai[i]+dev>=cai1[j] && cai[i]-dev<=cai1[j] && cbi[i]+dev>=cbi1[j] && cbi[i]-dev<=cbi1[j])
                                {
                                    for (int k=0; k<sizei1; k++)
                                    {
                                        unsigned pos =namei1[k].find ("N-");
                                        unsigned pos2=namei[i].find ("N-");
                                        sub2=namei1[k].substr (0,pos);
                                        sub3=namei[i].substr (0,pos2);
                                        m=-1;
                                        if (sub2==sub3)
                                        {
                                            m=k;
                                            break;
                                        }
                                    }
                                    for (int l=0; l<sizei; l++)
                                    {
                                        unsigned pos =namei[l].find ("N-");
                                        unsigned pos2=namei1[j].find ("N-");
                                        sub2=namei[l].substr (0,pos);
                                        sub3=namei1[j].substr (0,pos2);
                                        n=-1;
                                        if (sub2==sub3)
                                        {
                                            n=l;
                                            break;
                                        }
                                    }
                                    if(m!=-1 && n!=-1)
                                    {
                                        dm_file <<cai1[m]<<"\t"<<cbi1[m]<<"\t"<<coi1[m]<<"\t"<< (cai[i]+cai1[j])/2 << "\t" << (cbi[i]+cbi1[j])/2 << "\t" << (2*coi[i]+2*coi1[j])/2<<"\t"<<cai[n]<<"\t"<<cbi[n]<<"\t"<<coi[n]<<endl;
                                        dm_name_file <<namei1[m]<<"\t"<< namei[i] << "\t" << namei1[j]<<"\t"<< namei[n] <<endl;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        dm_file.clear();
        dm_name_file.clear();
        dm_file.close();
        dm_name_file.close();
        dm_file.open (dmname1.c_str(), ios::in);
        while (!dm_file.eof())
        {
            getline(dm_file, line2);
                counter2++;
        }
        dm_file.clear();
        dm_file.close();
        outname =namefiles;
        outname+="Temp/outputfileXXXXXX.txt";
        outname+="2";
        int countD=0;
        output_file.open (outname.c_str(), ios::out);
        res2no=0;
        for(int i=0; i<sizei; i++)
        {
            unsigned pos= namei[i].find_first_of("-");
            for(int j=0;j<sizei1;j++)
            {
                unsigned pos2= namei1[j].find_first_of("-");
                if(namei[i].substr(0,pos)==namei1[j].substr(0,pos2))
                {

                    output_file<<"-ca1 "<<cai1[j]<<" -cb1 "<<cbi1[j]<<" -co1 "<<coi1[j]<<" -ca2 "<<cai[i]<<" -cb2 "<<cbi[i]<<" -co2 "<<coi[i];
                    if(seq!="EMPTY" && ss!="EMPTY")
                        output_file << " -seq " << seq << " -first "<<first<<" "<< D << " " << pD << " -ss "<<ss<<" # "<< namei1[j]<<" "<<namei[i]<< endl;
                    else if(seq!="EMPTY" && ss=="EMPTY")
                        output_file << " -seq " << seq << " -first "<<first<<" "<< D << " " << pD <<" # "<< namei1[j]<<" "<< namei[i]<< endl;
                    res2no++;
                    countD++;
                    break;
                }
            }
        }
        for(int i=0; i<sizei; i++)
        {
            unsigned pos= namei[i].find_first_of("-");
            for(int j=0;j<sizei1;j++)
            {
                unsigned pos2= namei1[j].find_first_of("-");
                if(namei[i].substr(0,pos)==namei1[j].substr(0,pos2))
                {
                    break;
                }
                else if (j==sizei1-1)
                {
                    output_file<<"-ca1 0 -cb1 0 -co1 0 -ca2 "<<cai[i]<<" -cb2 "<<cbi[i]<<" -co2 "<<coi[i];
                    if(seq!="EMPTY" && ss!="EMPTY")
                        output_file << " -seq " << seq << " -first "<<first<<" "<< D << " " << pD << " -ss "<<ss<<" # xxx"<<namei[i]<<" "<<namei[i]<< endl;
                    else if(seq!="EMPTY" && ss=="EMPTY")
                        output_file << " -seq " << seq << " -first "<<first<<" "<< D << " " << pD <<" # xxx"<< namei[i]<<" "<< namei[i]<< endl;
                    res2no++;
                    countD++;
                }
            }
        }

        for(int j=0;j<sizei1;j++)
        {
            unsigned pos2= namei1[j].find_first_of("-");
            for(int i=0; i<sizei; i++)
            {
                unsigned pos= namei[i].find_first_of("-");
                if(namei[i].substr(0,pos)==namei1[j].substr(0,pos2))
                {
                    break;
                }
                else if (i==sizei-1)
                {
                    output_file<<"-ca1 "<<cai1[j]<<" -cb1 "<<cbi1[j]<<" -co1 "<<coi1[j]<<" -ca2 0 -cb2 0 -co2 0";
                    if(seq!="EMPTY" && ss!="EMPTY")
                        output_file << " -seq " << seq << " -first "<<first<<" "<< D << " " << pD << " -ss "<<ss<<" # "<< namei1[j]<<" xxx"<<namei1[j]<< endl;
                    else if(seq!="EMPTY" && ss=="EMPTY")
                        output_file << " -seq " << seq << " -first "<<first<<" "<< D << " " << pD <<" # "<< namei1[j]<<" xxx"<< namei1[j]<< endl;
                    res2no++;
                    countD++;
                }
            }
        }

        resultNO+=res2no;

        dm_file.open (dmname1.c_str(), ios::in);
        dm_name_file.open (dmname2.c_str(), ios::in);

        for (int i=0; i<counter2-1; i++)
        {
            maxf=3;
            getline (dm_file, line2);
                getline (dm_name_file, line3);
                istringstream iss(line2);
                counter=1;
            gly=0;
                do
            {
                    iss >> sub;
                        doub = atof( sub.c_str() );
                        if (doub!=0)
                {
                            if (counter==1)
                    {
                                    output_file << "-ca1 "<< doub<<" ";
                        gly=doub;
                    }
                                if (counter==2)
                    {
                        if (gly>40 && gly<50 && doub>40 && doub<50 && doub+5>gly && doub-5<gly)
                            is_gly=true;
                        else
                            is_gly=false;
                        if(is_gly==false)
                                            output_file << "-cb1 "<< doub<<" ";
                    }
                                if (counter==3)
                                        output_file << "-co1 "<< doub<<" ";
                                if (counter==4)
                    {
                                        output_file << "-ca2 "<< doub<<" ";
                        gly=doub;
                    }
                                if (counter==5)
                    {
                        if (gly>40 && gly<50 && doub>40 && doub<50 && doub+5>gly && doub-5<gly)
                            is_gly=true;
                        else
                            is_gly=false;
                        if(is_gly==false)
                                            output_file << "-cb2 "<< doub<<" ";
                    }
                                if (counter==6)
                                        output_file << "-co2 "<< doub<<" ";
                                if (counter==7)
                    {
                                        output_file << "-ca3 "<< doub<<" ";
                        gly=doub;
                    }
                                if (counter==8)
                    {
                        if (gly>40 && gly<50 && doub>40 && doub<50 && doub+5>gly && doub-5<gly)
                            is_gly=true;
                        else
                            is_gly=false;
                        if(is_gly==false)
                                            output_file << "-cb3 "<< doub<<" ";
                    }
                                if (counter==9)
                                        output_file << "-co3 "<< doub<<" ";
                }
                    counter++;
                        if (counter==11)
                            counter=1;
            }while (iss);
            if(seq!="EMPTY" && ss!="EMPTY")
                output_file << "-seq " << seq << " -first "<<first<<" "<< D << " " << pD << " -ss "<<ss<<" # "<< line3<< endl;
            else if(seq=="EMPTY" && ss!="EMPTY")
                output_file <<" -first "<<first<<" "<< D << " " << pD << " -ss "<<ss<<" # "<< line3<< endl;
            else if(seq!="EMPTY" && ss=="EMPTY")
                output_file << "-seq " << seq << " -first "<<first<<" "<< D << " " << pD <<" # "<< line3<< endl;
            else
                output_file << " -first "<<first<< D << " " << pD << " # "<< line3<< endl;
            resultNO++;
                    countD++;
        }
        dm_file.clear();
        dm_name_file.clear();
        dm_file.close();
        dm_name_file.close();
        dm_file.open (dmname1.c_str(), ios::in);
        dm_name_file.open (dmname2.c_str(), ios::in);
        for(int i=0; i<(counter2-1); i++)
        {
            shifts2.push_back("");
            names.push_back("");
            getline (dm_file, line2);
                getline (dm_name_file, line3);
                names[i]=line3;
                shifts2[i]=line2;
        }
        dm_file.clear();
        dm_name_file.clear();
        dm_file.close();
        dm_name_file.close();
        remove(dmname1.c_str());
        remove(dmname2.c_str());
        cc=0;
        for(int i=0; i<(counter2-1); i++)
        {
            for(int j=0; j<(counter2-1); j++)
            {
                string tV="";
                istringstream iss(names[i]);
                istringstream iss2(names[j]);
                    string comp1,name2,name3,name4;
		    iss>>sub;
                    iss>>sub;
                    comp1=sub;
		    iss>>sub;
                    iss>>sub;
                    iss2>>sub2;
                    iss2>>sub2;
		    name2=sub2;
                    iss2>>sub2;
		    name3=sub2;
                    iss2>>sub2;
		    name4=sub2;
                    if (sub==name2 && comp1!=name4)
                {
                    maxf=4;
                        istringstream iss3(shifts2[i]);
                        iss3>>sub3;
                    if(atof( sub3.c_str())!=0)
                    {
                            output_file<<"-ca1 "<<sub3<<" ";
                        tV="-ca1 "+sub3+" ";
                        gly=atof(sub3.c_str());
                    }
                        iss3>>sub3;
                    gly2= atof(sub3.c_str());
                    if(gly>40 && gly<50 && gly2>40 && gly2<50 && gly2+5>gly && gly2-5<gly)
                        is_gly =true;
                    else
                        is_gly = false;
                        if(atof( sub3.c_str())!=0 && is_gly==false)
                    {
                        tV+="-cb1 "+sub3+" ";
                            output_file<<"-cb1 "<<sub3<<" ";
                    }
                        iss3>>sub3;
                        if(atof( sub3.c_str())!=0)
                    {
                        tV+="-co1 "+sub3+" ";
                        output_file<<"-co1 "<<sub3<<" ";
                    }
                        iss3>>sub3;
                        if(atof( sub3.c_str())!=0)
                    {
                        tV+="-ca2 "+sub3+" ";
                            output_file<<"-ca2 "<<sub3<<" ";
                        gly=atof(sub3.c_str());
                    }
                        iss3>>sub3;
                    gly2= atof(sub3.c_str());
                    if(gly>40 && gly<50 && gly2>40 && gly2<50 && gly2+5>gly && gly2-5<gly)
                        is_gly =true;
                    else
                        is_gly = false;
                        if(atof( sub3.c_str())!=0 && is_gly==false)
                    {
                        tV+="-cb2 "+sub3+" ";
                            output_file<<"-cb2 "<<sub3<<" ";
                    }
                        iss3>>sub3;
                        if(atof( sub3.c_str())!=0)
                    {
                        tV+="-co2 "+sub3+" ";
                            output_file<<"-co2 "<<sub3<<" ";
                    }
                        istringstream iss4(shifts2[j]);
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-ca3 "+sub4+" ";
                            output_file<<"-ca3 "<<sub4<<" ";
                        gly=atof(sub4.c_str());
                    }
                        iss4>>sub4;
                    gly2= atof(sub4.c_str());
                        if(gly>40 && gly<50 && gly2>40 && gly2<50 && gly2+5>gly && gly2-5<gly)
                        is_gly =true;
                    else
                        is_gly = false;
                    if(atof( sub4.c_str())!=0 && is_gly==false)
                    {
                        tV+="-cb3 "+sub4+" ";
                            output_file<<"-cb3 "<<sub4<<" ";
                    }
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-co3 "+sub4+" ";
                            output_file<<"-co3 "<<sub4<<" ";
                    }
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-ca4 "+sub4+" ";
                            output_file<<"-ca4 "<<sub4<<" ";
                        gly=atof(sub4.c_str());
                    }
                        iss4>>sub4;
                    gly2= atof(sub4.c_str());
                    if(gly>40 && gly<50 && gly2>40 && gly2<50 && gly2+5>gly && gly2-5<gly)
                        is_gly =true;
                    else
                        is_gly = false;
                        if(atof( sub4.c_str())!=0 && is_gly==false)
                    {
                        tV+="-cb4 "+sub4+" ";
                            output_file<<"-cb4 "<<sub4<<" ";
                    }
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-co4 "+sub4+" ";
                            output_file<<"-co4 "<<sub4<<" ";
                    }
                        sarr4.push_back(tV);
                    resultNO++;
                    tV=names[i]+" "+name3;
                    if(seq!="EMPTY" && ss!="EMPTY")
                        output_file << "-seq " << seq << " -first "<<first<<" "<< D << " " << pD << " -ss "<< ss <<" # "<<names[i]<<"\t"<<name3<<"\t";
                    else if(seq=="EMPTY" && ss!="EMPTY")
                        output_file <<" -first "<<first<<" "<< D << " "<< pD << " -ss "<< ss <<" # "<<names[i]<<"\t"<<name3<<"\t";
                    else if(seq!="EMPTY" && ss=="EMPTY")
                            output_file << "-seq " << seq << " -first "<<first<<" "<< D <<" "<< pD << " # "<<names[i]<<"\t"<<name3<<"\t";
                        else
                            output_file << " -first "<<first<<" "<< D << " " << pD <<" # "<< names[i]<<"\t"<<name3<<"\t";
                    tV+="\t"+name4;
                    arr4.push_back(tV);
                        output_file<<name4<<endl;
                    cc++;
                    countD++;
                }
            }
        }
if(match>3)
    match=1;
{
    if(maxFS>4)
    {
        int ccc=cc;
        cc=0;
        for(int i=0; i<(ccc-1); i++)
        {
            for(int j=0; j<(counter2-1); j++)
            {
                string tV="";
                string n1, n2, ncheck0, ncheck, ncheck2;
                istringstream iss(arr4[i]);
                istringstream iss2(names[j]);
                    iss>>sub;
                    iss>>sub;
                n1=sub;
                    iss>>sub;
                    iss>>sub;
                n2=sub;
                iss>>sub;
                iss>>sub;
                    iss2>>sub2;
                iss2>>sub2;
                ncheck0=sub2;
                iss2>>sub2;
                ncheck=sub2;
                iss2>>sub2;
                ncheck2=sub2;
                    if (sub==ncheck0 && ncheck2!=n1 && ncheck2!=n2)
                {
                    maxf=5;
                        output_file<<sarr4[i];
                    tV=sarr4[i];
                    istringstream iss4(shifts2[j]);
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-ca5 "+sub4+" ";
                            output_file<<"-ca5 "<<sub4<<" ";
                        gly=atof(sub4.c_str());
                    }
                        iss4>>sub4;
                    gly2= atof(sub4.c_str());
                    if(gly>40 && gly<50 && gly2>40 && gly2<50 && gly2+5>gly && gly2-5<gly)
                        is_gly =true;
                    else
                        is_gly = false;
                        if(atof( sub4.c_str())!=0 && is_gly==false)
                    {
                        tV+="-cb5 "+sub4+" ";
                            output_file<<"-cb5 "<<sub4<<" ";
                    }
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-co5 "+sub4+" ";
                            output_file<<"-co5 "<<sub4<<" ";
                    }
                        sarr5.push_back(tV);
                        resultNO++;
                    if(seq!="EMPTY" && ss!="EMPTY")
                        output_file << "-seq " << seq << " -first "<<first<<" "<< D << " " << pD << " -ss "<< ss <<" # "<<arr4[i]<<"\t"<<ncheck<<"\t";
                    else if(seq=="EMPTY" && ss!="EMPTY")
                        output_file <<" -first "<<first<<" "<< D << " "<< pD << " -ss "<< ss <<" # "<<arr4[i]<<"\t"<<ncheck<<"\t";
                    else if(seq!="EMPTY" && ss=="EMPTY")
                            output_file << "-seq " << seq << " -first "<<first<<" "<< D <<" "<< pD << " # "<<arr4[i]<<"\t"<<ncheck<<"\t";
                        else
                            output_file << " -first "<<first<<" "<< D << " " << pD <<" # "<< arr4[i]<<"\t"<<ncheck<<"\t";
                    output_file<<ncheck2<<endl;
                    arr5.push_back(arr4[i]+"\t"+ncheck+"\t"+ncheck2);
                    cc++;
                    countD++;
                }
            }
        }
    if(maxFS>5)
    {
        ccc=cc;
        cc=0;
        for(int i=0; i<(ccc-1); i++)
        {
            for(int j=0; j<(counter2-1); j++)
            {
                string tV="";
                string n1, n2, n3, ncheck0, ncheck, ncheck2;
                istringstream iss(arr5[i]);
                istringstream iss2(names[j]);
                    iss>>sub;
                    iss>>sub;
                n1=sub;
                    iss>>sub;
                    iss>>sub;
                n2=sub;
                iss>>sub;
                iss>>sub;
                n3=sub;
                iss>>sub;
                iss>>sub;
                    iss2>>sub2;
                iss2>>sub2;
                ncheck0=sub2;
                iss2>>sub2;
                ncheck=sub2;
                iss2>>sub2;
                ncheck2=sub2;
                    if (sub==ncheck0 && ncheck2!=n1 && ncheck2!=n2 && ncheck2!=n3)
                {
                    maxf=6;
                        output_file<<sarr5[i];
                    tV=sarr5[i];
                    istringstream iss4(shifts2[j]);
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-ca6 "+sub4+" ";
                            output_file<<"-ca6 "<<sub4<<" ";
                        gly=atof(sub4.c_str());
                    }
                        iss4>>sub4;
                    gly2= atof(sub4.c_str());
                    if(gly>40 && gly<50 && gly2>40 && gly2<50 && gly2+5>gly && gly2-5<gly)
                        is_gly =true;
                    else
                        is_gly = false;
                        if(atof( sub4.c_str())!=0 && is_gly==false)
                    {
                        tV+="-cb6 "+sub4+" ";
                            output_file<<"-cb6 "<<sub4<<" ";
                    }
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-co6 "+sub4+" ";
                            output_file<<"-co6 "<<sub4<<" ";
                    }
                        sarr6.push_back(tV);
                        resultNO++;
                    if(seq!="EMPTY" && ss!="EMPTY")
                        output_file << "-seq " << seq << " -first "<<first<<" "<< D << " " << pD << " -ss "<< ss <<" # "<<arr5[i]<<"\t"<<ncheck<<"\t";
                    else if(seq=="EMPTY" && ss!="EMPTY")
                        output_file <<" -first "<<first<<" "<< D << " "<< pD << " -ss "<< ss <<" # "<<arr5[i]<<"\t"<<ncheck<<"\t";
                    else if(seq!="EMPTY" && ss=="EMPTY")
                            output_file << "-seq " << seq << " -first "<<first<<" "<< D <<" "<< pD << " # "<<arr5[i]<<"\t"<<ncheck<<"\t";
                        else
                            output_file << " -first "<<first<<" "<< D << " " << pD <<" # "<< arr5[i]<<"\t"<<ncheck<<"\t";
                    output_file<<ncheck2<<endl;
                    arr6.push_back(arr5[i]+"\t"+ncheck+"\t"+ncheck2);
                    cc++;
                    countD++;
                }
            }
        }
    if(maxFS>6)
    {
        ccc=cc;
        cc=0;
        for(int i=0; i<(ccc-1); i++)
        {
            for(int j=0; j<(counter2-1); j++)
            {
                string tV="";
                string n1, n2, n3, n4, ncheck0, ncheck, ncheck2;
                istringstream iss(arr6[i]);
                istringstream iss2(names[j]);
                    iss>>sub;
                    iss>>sub;
                n1=sub;
                    iss>>sub;
                    iss>>sub;
                n2=sub;
                iss>>sub;
                iss>>sub;
                n3=sub;
                iss>>sub;
                iss>>sub;
                n4=sub;
                iss>>sub;
                iss>>sub;
                    iss2>>sub2;
                iss2>>sub2;
                ncheck0=sub2;
                iss2>>sub2;
                ncheck=sub2;
                iss2>>sub2;
                ncheck2=sub2;
                    if (sub==ncheck0 && ncheck2!=n1 && ncheck2!=n2 && ncheck2!=n3 && ncheck2!=n4)
                {
                    maxf=7;
                        output_file<<sarr6[i];
                    tV=sarr6[i];
                    istringstream iss4(shifts2[j]);
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-ca7 "+sub4+" ";
                            output_file<<"-ca7 "<<sub4<<" ";
                        gly=atof(sub4.c_str());
                    }
                        iss4>>sub4;
                    gly2= atof(sub4.c_str());
                    if(gly>40 && gly<50 && gly2>40 && gly2<50 && gly2+5>gly && gly2-5<gly)
                        is_gly =true;
                    else
                        is_gly = false;
                        if(atof( sub4.c_str())!=0 && is_gly==false)
                    {
                        tV+="-cb7 "+sub4+" ";
                            output_file<<"-cb7 "<<sub4<<" ";
                    }
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-co7 "+sub4+" ";
                            output_file<<"-co7 "<<sub4<<" ";
                    }
                        sarr7.push_back(tV);
                        resultNO++;
                    if(seq!="EMPTY" && ss!="EMPTY")
                        output_file << "-seq " << seq << " -first "<<first<<" "<< D << " " << pD << " -ss "<< ss <<" # "<<arr6[i]<<"\t"<<ncheck<<"\t";
                    else if(seq=="EMPTY" && ss!="EMPTY")
                        output_file <<" -first "<<first<<" "<< D << " "<< pD << " -ss "<< ss <<" # "<<arr6[i]<<"\t"<<ncheck<<"\t";
                    else if(seq!="EMPTY" && ss=="EMPTY")
                            output_file << "-seq " << seq << " -first "<<first<<" "<< D <<" "<< pD << " # "<<arr6[i]<<"\t"<<ncheck<<"\t";
                        else
                            output_file << " -first "<<first<<" "<< D << " " << pD <<" # "<< arr6[i]<<"\t"<<ncheck<<"\t";
                    output_file<<ncheck2<<endl;
                    arr7.push_back(arr6[i]+"\t"+ncheck+"\t"+ncheck2);
                    cc++;
                    countD++;
                }
            }
        }
    if(maxFS>7)
    {
        ccc=cc;
        cc=0;
        for(int i=0; i<(ccc-1); i++)
        {
            for(int j=0; j<(counter2-1); j++)
            {
                string tV="";
                string n1, n2, n3, n4, n5, ncheck0, ncheck, ncheck2;
                istringstream iss(arr7[i]);
                istringstream iss2(names[j]);
                    iss>>sub;
                    iss>>sub;
                n1=sub;
                    iss>>sub;
                    iss>>sub;
                n2=sub;
                iss>>sub;
                iss>>sub;
                n3=sub;
                iss>>sub;
                iss>>sub;
                n4=sub;
                iss>>sub;
                iss>>sub;
                n5=sub;
                iss>>sub;
                iss>>sub;
                    iss2>>sub2;
                iss2>>sub2;
                ncheck0=sub2;
                iss2>>sub2;
                ncheck=sub2;
                iss2>>sub2;
                ncheck2=sub2;
                    if (sub==ncheck0 && ncheck2!=n1 && ncheck2!=n2 && ncheck2!=n3 && ncheck2!=n4 && ncheck2!=n5)
                {
                    maxf=8;
                        output_file<<sarr7[i];
                    tV=sarr7[i];
                    istringstream iss4(shifts2[j]);
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-ca8 "+sub4+" ";
                            output_file<<"-ca8 "<<sub4<<" ";
                        gly=atof(sub4.c_str());
                    }
                        iss4>>sub4;
                    gly2= atof(sub4.c_str());
                    if(gly>40 && gly<50 && gly2>40 && gly2<50 && gly2+5>gly && gly2-5<gly)
                        is_gly =true;
                    else
                        is_gly = false;
                        if(atof( sub4.c_str())!=0 && is_gly==false)
                    {
                        tV+="-cb8 "+sub4+" ";
                            output_file<<"-cb8 "<<sub4<<" ";
                    }
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-co8 "+sub4+" ";
                            output_file<<"-co8 "<<sub4<<" ";
                    }
                        sarr8.push_back(tV);
                        resultNO++;
                    if(seq!="EMPTY" && ss!="EMPTY")
                        output_file << "-seq " << seq << " -first "<<first<<" "<< D << " " << pD << " -ss "<< ss <<" # "<<arr7[i]<<"\t"<<ncheck<<"\t";
                    else if(seq=="EMPTY" && ss!="EMPTY")
                        output_file <<" -first "<<first<<" "<< D << " "<< pD << " -ss "<< ss <<" # "<<arr7[i]<<"\t"<<ncheck<<"\t";
                    else if(seq!="EMPTY" && ss=="EMPTY")
                            output_file << "-seq " << seq << " -first "<<first<<" "<< D <<" "<< pD << " # "<<arr7[i]<<"\t"<<ncheck<<"\t";
                        else
                            output_file << " -first "<<first<<" "<< D << " " << pD <<" # "<< arr7[i]<<"\t"<<ncheck<<"\t";
                    output_file<<ncheck2<<endl;
                    arr8.push_back(arr7[i]+"\t"+ncheck+"\t"+ncheck2);
                    cc++;
                    countD++;
                }
            }
        }
    if(maxFS>8)
    {
        ccc=cc;
        cc=0;
        for(int i=0; i<(ccc-1); i++)
        {
            for(int j=0; j<(counter2-1); j++)
            {
                string tV="";
                string n1, n2, n3, n4, n5, n6, ncheck0, ncheck, ncheck2;
                istringstream iss(arr8[i]);
                istringstream iss2(names[j]);
                    iss>>sub;
                    iss>>sub;
                n1=sub;
                    iss>>sub;
                    iss>>sub;
                n2=sub;
                iss>>sub;
                iss>>sub;
                n3=sub;
                iss>>sub;
                iss>>sub;
                n4=sub;
                iss>>sub;
                iss>>sub;
                n5=sub;
                iss>>sub;
                iss>>sub;
                n6=sub;
                iss>>sub;
                iss>>sub;
                    iss2>>sub2;
                iss2>>sub2;
                ncheck0=sub2;
                iss2>>sub2;
                ncheck=sub2;
                iss2>>sub2;
                ncheck2=sub2;
                    if (sub==ncheck0 && ncheck2!=n1 && ncheck2!=n2 && ncheck2!=n3 && ncheck2!=n4 && ncheck2!=n5 && ncheck2!=n6)
                {
                    maxf=9;
                        output_file<<sarr8[i];
                    tV=sarr8[i];
                    istringstream iss4(shifts2[j]);
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-ca9 "+sub4+" ";
                            output_file<<"-ca9 "<<sub4<<" ";
                        gly=atof(sub4.c_str());
                    }
                        iss4>>sub4;
                    gly2= atof(sub4.c_str());
                    if(gly>40 && gly<50 && gly2>40 && gly2<50 && gly2+5>gly && gly2-5<gly)
                        is_gly =true;
                    else
                        is_gly = false;
                        if(atof( sub4.c_str())!=0 && is_gly==false)
                    {
                        tV+="-cb9 "+sub4+" ";
                            output_file<<"-cb9 "<<sub4<<" ";
                    }
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-co9 "+sub4+" ";
                            output_file<<"-co9 "<<sub4<<" ";
                    }
                        sarr9.push_back(tV);
                        resultNO++;
                    if(seq!="EMPTY" && ss!="EMPTY")
                        output_file << "-seq " << seq << " -first "<<first<<" "<< D << " " << pD << " -ss "<< ss <<" # "<<arr8[i]<<"\t"<<ncheck<<"\t";
                    else if(seq=="EMPTY" && ss!="EMPTY")
                        output_file <<" -first "<<first<<" "<< D << " "<< pD << " -ss "<< ss <<" # "<<arr8[i]<<"\t"<<ncheck<<"\t";
                    else if(seq!="EMPTY" && ss=="EMPTY")
                            output_file << "-seq " << seq << " -first "<<first<<" "<< D <<" "<< pD << " # "<<arr8[i]<<"\t"<<ncheck<<"\t";
                        else
                            output_file << " -first "<<first<<" "<< D << " " << pD <<" # "<< arr8[i]<<"\t"<<ncheck<<"\t";
                    output_file<<ncheck2<<endl;
                    arr9.push_back(arr8[i]+"\t"+ncheck+"\t"+ncheck2);
                    cc++;
                    countD++;
                }
            }
        }
    if(maxFS>9)
    {
        ccc=cc;
        cc=0;
        for(int i=0; i<(ccc-1); i++)
        {
            for(int j=0; j<(counter2-1); j++)
            {
                string tV="";
                string n1, n2, n3, n4, n5, n6, n7, ncheck0, ncheck, ncheck2;
                istringstream iss(arr9[i]);
                istringstream iss2(names[j]);
                    iss>>sub;
                    iss>>sub;
                n1=sub;
                    iss>>sub;
                    iss>>sub;
                n2=sub;
                iss>>sub;
                iss>>sub;
                n3=sub;
                iss>>sub;
                iss>>sub;
                n4=sub;
                iss>>sub;
                iss>>sub;
                n5=sub;
                iss>>sub;
                iss>>sub;
                n6=sub;
                iss>>sub;
                iss>>sub;
                n7=sub;
                iss>>sub;
                iss>>sub;
                    iss2>>sub2;
                iss2>>sub2;
                ncheck0=sub2;
                iss2>>sub2;
                ncheck=sub2;
                iss2>>sub2;
                ncheck2=sub2;
                    if (sub==ncheck0 && ncheck2!=n1 && ncheck2!=n2 && ncheck2!=n3 && ncheck2!=n4 && ncheck2!=n5 && ncheck2!=n6 && ncheck2!=n7)
                {
                    maxf=10;
                        output_file<<sarr9[i];
                    tV=sarr9[i];
                    istringstream iss4(shifts2[j]);
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-ca10 "+sub4+" ";
                            output_file<<"-ca10 "<<sub4<<" ";
                        gly=atof(sub4.c_str());
                    }
                        iss4>>sub4;
                    gly2= atof(sub4.c_str());
                    if(gly>40 && gly<50 && gly2>40 && gly2<50 && gly2+5>gly && gly2-5<gly)
                        is_gly =true;
                    else
                        is_gly = false;
                        if(atof( sub4.c_str())!=0 && is_gly==false)
                    {
                        tV+="-cb10 "+sub4+" ";
                            output_file<<"-cb10 "<<sub4<<" ";
                    }
                        iss4>>sub4;
                        if(atof( sub4.c_str())!=0)
                    {
                        tV+="-co10 "+sub4+" ";
                            output_file<<"-co10 "<<sub4<<" ";
                    }
                        sarr10.push_back(tV);
                        resultNO++;
                    if(seq!="EMPTY" && ss!="EMPTY")
                        output_file << "-seq " << seq << " -first "<<first<<" "<< D << " " << pD << " -ss "<< ss <<" # "<<arr9[i]<<"\t"<<ncheck<<"\t";
                    else if(seq=="EMPTY" && ss!="EMPTY")
                        output_file <<" -first "<<first<<" "<< D << " "<< pD << " -ss "<< ss <<" # "<<arr9[i]<<"\t"<<ncheck<<"\t";
                    else if(seq!="EMPTY" && ss=="EMPTY")
                            output_file << "-seq " << seq << " -first "<<first<<" "<< D <<" "<< pD << " # "<<arr9[i]<<"\t"<<ncheck<<"\t";
                        else
                            output_file << " -first "<<first<<" "<< D << " " << pD <<" # "<< arr9[i]<<"\t"<<ncheck<<"\t";
                    output_file<<ncheck2<<endl;
                    arr10.push_back(arr9[i]+"\t"+ncheck+"\t"+ncheck2);
                    cc++;
                    countD++;
                }
            }
        }
    }
    }
    }
    }
    }
    }
}
        output_file.clear();
        output_file.close();
frag<<match<<maxf;
frag.clear();
frag.close();

if(countD>999)
{
        errors.clear();
        errors.close();
    return 0;
}
else if (countD==0)
{
    errors.clear();
    errors.close();
    return 2;
}
else if (countD<=999 && countD>0)
{
    return 1;
}
    }

    }
return 1;
}

