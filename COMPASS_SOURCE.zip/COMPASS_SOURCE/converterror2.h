#ifndef CONVERTERROR2_H
#define CONVERTERROR2_H

#include <QDialog>

namespace Ui
{
	class ConvertError2;
}

class ConvertError2 : public QDialog
{
	Q_OBJECT

public:
	ConvertError2(QWidget *parent = 0);
	~ConvertError2();

private:
	Ui::ConvertError2 *ui;

private slots:
	void errorSet();

    void on_closeButton_clicked();
};

#endif
