#ifndef COMPASSMAIN_H
#define COMPASSMAIN_H
#include <QMainWindow>
#include <compassquery.h>	
#include <compassrename.h>
#include <compassabout.h>
#include <compassconvert.h>
#include <compassspinsystem.h>
#include "centralwidgetclass.h"
#include "compassindex.h"
#include "compassmanualmode.h"

namespace Ui
{
	class CompassMain;
}

class CompassMain : public QMainWindow
{
	Q_OBJECT

public:
	CompassMain(QWidget *parent = 0);
	~CompassMain(); 


private:
	Ui::CompassMain *ui;		
	CompassRename *winRename;
	CompassAbout *winAbout;
	CompassConvert *winConvert;
    CompassIndex *winIndex;
    CompassManualMode *winManual;
    centralWidgetClass *cWidget;
    CompassSpinSystem *winGss;
    CompassQuery *winAnalyze;

private slots:
    void renderMainWidget();
    void renderManualMode();
    void renderLabel();
    void renderAnalyze();
    void renderAssign();
    void renderRename();
    void renderConvert();
    void renderAbout();
};
 
#endif
