#ifndef HTMLFILE2_H
#define HTMLFILE2_H
#include "compassvec.h"
using namespace std;

void htmlfile2(string namefiles, int matchI, bool ss);

#endif // HTMLFILE2_H
