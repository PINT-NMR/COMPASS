#ifndef INDEXERROR2_H
#define INDEXERROR2_H

#include <QMainWindow>

namespace Ui
{
	class IndexError2;
}

class IndexError2 : public QMainWindow
{
	Q_OBJECT

public:
	IndexError2(QWidget *parent = 0);
	~IndexError2();

protected:
	void changeEvent(QEvent *e);

private:
	Ui::IndexError2 *ui;

private slots:
	void readerrfile2();
};

#endif
