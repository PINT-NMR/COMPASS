#include "centralwidgetclass.h"
#include "ui_centralwidgetclass.h"
#include "QDesktopServices"
#include <QUrl>


centralWidgetClass::centralWidgetClass(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::centralWidgetClass)
{
    ui->setupUi(this);
}

centralWidgetClass::~centralWidgetClass()
{
    delete ui;
}

void centralWidgetClass::on_gssButton_clicked()
{
    //Label
    emit label();
}

void centralWidgetClass::on_peak_menuButton_clicked()
{
    //Analyze
    emit analyze();
}


void centralWidgetClass::on_rename_menuButton_clicked()
{
    //Assign
    emit assign();
}


void centralWidgetClass::on_convertButton_clicked()
{
    //Convert
    emit convert();
}

void centralWidgetClass::on_about_menuButton_clicked()
{
    //About
    emit about();
}

void centralWidgetClass::on_quit_menuButton_clicked()
{
    //Exit
    QApplication::quit();
}

void centralWidgetClass::on_checkGitHubButton_clicked()
{
    QDesktopServices::openUrl(QUrl("https://github.com/PINT-NMR/COMPASS"));
}
