#include <QApplication>
#include "compassmain.h"

int main(int argc, char *argv[])
{
	QApplication app(argc, argv);
	CompassMain w;
    w.showMaximized();
	return app.exec();
}
