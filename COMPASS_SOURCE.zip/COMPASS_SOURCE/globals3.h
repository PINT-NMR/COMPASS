#include <QtWidgets>
#include <cstdlib>
#include <vector>
namespace Ui
{
extern int total;
extern int progress;
extern QString capar;
extern QString capar2;
extern QString cbcapar;
extern QString cbcapar2;
extern QString copar;
extern QString copar2;
extern QString hsqcpar;
extern QString seqpar;
extern QString sspar;
extern QString savepar;
extern QString propar;
extern int firstpar;
extern int trosypar;
extern int sampar;
extern double d1par;
extern double d2par;
extern double d3par;
extern int i1par;
extern int i2par;
extern int i3par;
extern QString parca ;
extern QString parca2;
extern QString parcbca;
extern QString parcbca2;
extern QString parco;
extern QString parco2;
extern QString parhsqc;
extern QString parsave;
extern QString parpro;
extern int Refpar ;
extern double pard1 ;
extern double pard2;
extern double pard3 ;
extern bool CACheck;
extern bool CAB;
extern bool CBB;
extern bool b1;
extern bool b2;
extern bool b3;
extern QString devErr;
extern bool abortBool;
extern int abortInt;
extern bool running;
}
