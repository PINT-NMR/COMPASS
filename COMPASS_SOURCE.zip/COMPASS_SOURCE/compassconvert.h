#ifndef COMPASSCONVERT_H
#define COMPASSCONVERT_H

#include <QWidget>
#include "compasshelp3.h"
#include "converterror.h"
#include "converterror2.h"
#include "convertcomplete.h"

namespace Ui
{
	class CompassConvert;
}

class CompassConvert : public QWidget
{
	Q_OBJECT

public:
	CompassConvert(QWidget *parent = 0);
	~CompassConvert();

private:
	Ui::CompassConvert *ui;

private slots:
    QString fileCheck();
    bool alphaCheck(QString word);
	void on_menuButton_clicked();
	void on_convButton_clicked();
	void on_helpButton_clicked();
	void on_fileButton_clicked();
	void on_folderButton_clicked();
	void handleIndex(int index);
	void convert2d();
	void convert3d();
	void convertSeq();
	void hide3d();
	void hide2d();
	void hideSeq();
	void show3d();
	void show2d();
	void showSeq();
	void hidePeak();
	void showPeak3d();
	void showPeak2d();
	void handleState(int state);
	void handleState2d(int state);
	void handleState3d(int state);
	void unassignhide();
	void formatSeq(int state);
	void formatSeq2(bool click);
	void toggleVol2d(int state);
	void toggleVol3d(int state);
	void formatPeak(int state);
	void handleFormat(QString state);
	void handleFormat2(int state);
	void convert2dtoCustom();
	void convert3dtoCustom();
	void convertseqtoCustom();
	void convert2dtoCompass();
	void convert3dtoCompass();
	void convertseqtoCompass();
	bool legalcheck(std::string sub, std::string type);
	bool legalcheckChar(char sub, std::string type);
	std::string convert(std::string fasta, bool delimiter);
	std::string convert3(std::string fasta, bool delimiter, std::string caps);
	std::string convert2(char c, bool delimiter, std::string caps);
	void threetothree(std::string seq, bool delimiter, std::string caps);
	void threetwoone(std::string seq, bool delimiter);
	void onetwothree(std::string seq, bool delimiter, std::string caps);
	void handleConv(bool state);
    void convertOS();
    void convertOSui();
    void on_quitButton_clicked();
    void disconnectAll();
    void connectAll();
    void toggleCustom();
    void toggleCompass();
    void toggleUpper();
    void toggleMixed();
    void toggleOne();
    void toggleThree();

signals:
    void goToMain();
};

#endif
