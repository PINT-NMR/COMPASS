#ifndef INDEXERROR_H
#define INDEXERROR_H

#include <QMainWindow>

namespace Ui
{
	class IndexError;
}

class IndexError : public QMainWindow
{
	Q_OBJECT

public:
	IndexError(QWidget *parent = 0);
	~IndexError();

protected:
	void changeEvent(QEvent *e);

private:
	Ui::IndexError *ui;

private slots:
	void readerrfile();
};

#endif
