#include "compassmanualmode.h"
#include "ui_compassmanualmode.h"
#include <QtWidgets>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <cmath>
#include <QUrl>
#include "compass_analyze3.h"
#include "indexerror2.h"
#include "ssp2.h"
#include "compasshtml2.h"
#include "compassvec.h"
#include "shifts.h"
#include "globals.h"
#include "passdef.h"
#include "parser2.h"
#include "calcscore2.h"
#include "QFile"
#include "mfunc.h"
#include "csedit.h"


CompassManualMode::CompassManualMode(QWidget *parent) :
    QWidget(parent),
	ui(new Ui::CompassManualMode)
{
	ui->setupUi(this);
    ui->fileBrowser->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

	ui->errorLabel->hide();
	ui->errorBrowser->setText("");
	connect(ui->seqBrowser, SIGNAL(anchorClicked(const QUrl &)), this, SLOT(anchorClicked(const QUrl &)));
	setResbox();
	readfile();
	ssp();
	extern QString profile;
	std::string findName;
	findName=profile.toStdString();
	unsigned posL = findName.find_last_of("/");
	unsigned posL2 = findName.find_last_of(".");
	findName = findName.substr(posL+1,posL2-posL-1);

	QString titleName = QString::fromUtf8(findName.c_str());

	std::string fname, line;
	fname=profile.toStdString();
	std::ifstream file;
	file.open(fname.c_str(), std::ios::in);
	getline(file, line);
	findName=line;
	getline(file, line);
	getline(file, line);
	getline(file, line);
	getline(file, line);
	std::string seqF =line;
	getline(file, line);
	file.clear();
	file.close();
	int first = atoi(line.c_str());
	DisplayInfo(line);
	QTextCursor cursor = ui->seqBrowser->textCursor();
	cursor.setPosition(0);
	ui->seqBrowser->setTextCursor(cursor);
	QTextCursor cursor2 = ui->fileBrowser->textCursor();
	cursor2.setPosition(0);
	ui->fileBrowser->setTextCursor(cursor2);

	std::string line2, sub;
	file.open(seqF.c_str(), std::ios::in);
	getline(file, line2);
	file.clear();
	file.close();
	int last=0;
	std::istringstream iss(line2);
	while(iss >> sub)
		last++;
	last= first+last-1;
	extern int xAxisFirst;
	xAxisFirst= first;
	extern int xAxisLast;
	xAxisLast = last;
    ui->customPlot->clearGraphs();
	resetPlot();
	ui->customPlot->plotLayout()->insertRow(0);
	ui->customPlot->plotLayout()->addElement(0, 0, new QCPPlotTitle(ui->customPlot, titleName));
	ui->customPlot->addLayer("below", ui->customPlot->layer("main"), QCustomPlot::limBelow);
    //Toolbar
    menuBar = new QMenuBar(this);
    QMenu *fileMenu = new QMenu("File");
    QAction *actionMainMenu = new QAction("Main menu");
    QAction *actionSaveSSP= new QAction("Save SSP");
    QAction *actionQuit= new QAction("Quit");
    QAction *actionCOMPASS= new QAction("COMPASS mode");
    QAction *actionManual= new QAction("Manual assignment mode");
    QAction *actionHelp= new QAction("COMPASS Help");
    fileMenu->addAction(actionMainMenu);
    fileMenu->addAction(actionSaveSSP);
    fileMenu->addAction(actionQuit);
    QMenu *modeMenu = new QMenu("Mode");
    modeMenu->addAction(actionCOMPASS);
    modeMenu->addAction(actionManual);
    QMenu *helpMenu = new QMenu("Help");
    helpMenu->addAction(actionHelp);
    menuBar->addMenu(fileMenu);
    menuBar->addMenu(modeMenu);
    menuBar->addMenu(helpMenu);
    this->layout()->setMenuBar(menuBar);
    connect(actionMainMenu, SIGNAL(triggered(bool)), this, SLOT(goToMainSig()));
    connect(actionSaveSSP, SIGNAL(triggered(bool)), this, SLOT(saveSsp()));
    connect(actionQuit, SIGNAL(triggered(bool)), this, SLOT(quitApp()));
    connect(actionHelp, SIGNAL(triggered(bool)), this, SLOT(displayHelp()));
    connect(actionCOMPASS, SIGNAL(triggered(bool)), this, SLOT(compassMode()));
}

void CompassManualMode::goToMainSig()
{
    emit goToMain();
}

void CompassManualMode::compassMode()
{
    emit renderCompassMode();
}
void CompassManualMode::quitApp()
{
    QMessageBox dlg;
    dlg.setText("Do you want to quit?");
    dlg.setStandardButtons(QMessageBox::Yes | QMessageBox::Cancel);
    dlg.setDefaultButton(QMessageBox::Yes);
    dlg.setWindowTitle("COMPASS");
    int ret = dlg.exec();
    switch (ret)
    {
    case QMessageBox::Yes:
    {
        QApplication::quit();
    }
    default:
        break;
    }
}
void CompassManualMode::editChemicalShifts()
{
    CSedit winEdit;
    winEdit.setWindowModality(Qt::ApplicationModal);
    if(winEdit.exec())
        return;
}
void CompassManualMode::resetPlot()
{
	ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectAxes |
                                  QCP::iSelectLegend);
	setAxis();
	ui->customPlot->axisRect()->setupFullAxesBox();
	
	ui->customPlot->xAxis->setLabel("Residue Number");
	ui->customPlot->yAxis->setLabel("Secondary Structure Propensity (SSP)");
	ui->customPlot->legend->setVisible(false);
	QFont legendFont = font();
	connect(ui->customPlot, SIGNAL(selectionChangedByUser()), this, SLOT(selectionChanged()));
	connect(ui->customPlot, SIGNAL(mousePress(QMouseEvent*)), this, SLOT(mousePress()));
	connect(ui->customPlot, SIGNAL(mouseWheel(QWheelEvent*)), this, SLOT(mouseWheel()));
	connect(ui->customPlot->xAxis, SIGNAL(rangeChanged(QCPRange)), ui->customPlot->xAxis2, SLOT(setRange(QCPRange)));
	connect(ui->customPlot->yAxis, SIGNAL(rangeChanged(QCPRange)), ui->customPlot->yAxis2, SLOT(setRange(QCPRange)));
	ssp();

}
void CompassManualMode::on_ResetButton_clicked()
{
	ui->customPlot->clearGraphs();
	resetPlot();
}
void CompassManualMode::setAxis()
{
	extern int xAxisFirst;
	extern int xAxisLast;
	ui->customPlot->xAxis->setRange(xAxisFirst, xAxisLast);
	ui->customPlot->yAxis->setRange(-1, 1);
	ui->customPlot->rescaleAxes();


}
void CompassManualMode::selectionChanged()
{
  if (ui->customPlot->xAxis->selectedParts().testFlag(QCPAxis::spAxis) || ui->customPlot->xAxis->selectedParts().testFlag(QCPAxis::spTickLabels) ||
      ui->customPlot->xAxis2->selectedParts().testFlag(QCPAxis::spAxis) || ui->customPlot->xAxis2->selectedParts().testFlag(QCPAxis::spTickLabels))
  {
    ui->customPlot->xAxis2->setSelectedParts(QCPAxis::spAxis|QCPAxis::spTickLabels);
    ui->customPlot->xAxis->setSelectedParts(QCPAxis::spAxis|QCPAxis::spTickLabels);
  }
  if (ui->customPlot->yAxis->selectedParts().testFlag(QCPAxis::spAxis) || ui->customPlot->yAxis->selectedParts().testFlag(QCPAxis::spTickLabels) ||
      ui->customPlot->yAxis2->selectedParts().testFlag(QCPAxis::spAxis) || ui->customPlot->yAxis2->selectedParts().testFlag(QCPAxis::spTickLabels))
  {
    ui->customPlot->yAxis2->setSelectedParts(QCPAxis::spAxis|QCPAxis::spTickLabels);
    ui->customPlot->yAxis->setSelectedParts(QCPAxis::spAxis|QCPAxis::spTickLabels);
  }
}

void CompassManualMode::mousePress()
{
  if (ui->customPlot->xAxis->selectedParts().testFlag(QCPAxis::spAxis))
    ui->customPlot->axisRect()->setRangeDrag(ui->customPlot->xAxis->orientation());
  else if (ui->customPlot->yAxis->selectedParts().testFlag(QCPAxis::spAxis))
    ui->customPlot->axisRect()->setRangeDrag(ui->customPlot->yAxis->orientation());
  else
    ui->customPlot->axisRect()->setRangeDrag(Qt::Horizontal|Qt::Vertical);
}

void CompassManualMode::mouseWheel()
{
  if (ui->customPlot->xAxis->selectedParts().testFlag(QCPAxis::spAxis))
    ui->customPlot->axisRect()->setRangeZoom(ui->customPlot->xAxis->orientation());
  else if (ui->customPlot->yAxis->selectedParts().testFlag(QCPAxis::spAxis))
    ui->customPlot->axisRect()->setRangeZoom(ui->customPlot->yAxis->orientation());
  else
    ui->customPlot->axisRect()->setRangeZoom(Qt::Horizontal|Qt::Vertical);
}
void CompassManualMode::saveSsp()
{ 
    QString fileName = QFileDialog::getSaveFileName(this, "Save SSP graph", qApp->applicationDirPath(), "*.png");
    if (!fileName.isEmpty())
    {
        if (!fileName.endsWith(".png"))
            fileName += ".png";
        ui->ResetButton->hide();
        QPixmap originalPixmap = QPixmap::grabWidget(ui->customPlot);
        originalPixmap.save(fileName, "png");
        ui->ResetButton->show();
    }
}
void CompassManualMode::addGraph()
{
	extern int xAxisFirst;
	extern int xAxisLast;
	int n = xAxisLast-xAxisFirst-1;
    QVector<double> x, y;
    QVector<double> x2, y2;
	double fVec = (double)xAxisFirst;
	for (int i=0; i<=n; i++)
	{
        x.push_back(fVec);
        y.push_back(0.0);
        x2.push_back(fVec);
        y2.push_back(0.0);
		fVec+= 1.0;
	}
	
	extern QString profile;
	std::string fname, line, line2, line3;
	fname=profile.toStdString();
	std::ifstream file;
	file.open(fname.c_str(), std::ios::in);
	getline(file,line);
	for(int j=0; j<12; j++)
		getline(file,line3);
	file.clear();
	file.close();
	std::string ssPath = line + "Analysis/sspSeq.s2";
	line+="Analysis/inSSP.ssp";
	

	file.open(line.c_str(), std::ios::in);
	int lC=0;
	if(file.is_open())
	{
		while(file.good())
		{
			getline(file, line2);
			lC++;
		}
		lC--;
	}
	file.clear();
	file.close();
	file.open(line.c_str(), std::ios::in);
	if(file.is_open())
	{
		int val=0;
		for(int j=0; j<lC; j++)
		{
			getline(file, line2);
			std::istringstream iss(line2);
			std::string sub, sub2;
			iss >> sub;
			iss >> sub2;
			x[val] = atof(sub.c_str());
			y[val] = atof(sub2.c_str());
			val++;

		}
	}
	file.clear();
	file.close();
	{
	ui->customPlot->addGraph();
	ui->customPlot->graph(0)->setName(QString("SSP"));
	ui->customPlot->graph(0)->setData(x, y);
	ui->customPlot->graph(0)->setLineStyle((QCPGraph::LineStyle)(5));
	QPen graphPen;
	graphPen.setColor(QColor(255, 0, 0));
	graphPen.setWidthF(3);
	ui->customPlot->graph(0)->setPen(graphPen);
	}

	if(line3!="EMPTY" && ui->overlayButton->isChecked()) 
	{
		file.open(ssPath.c_str(), std::ios::in);
		lC=0;
		if(file.is_open())
		{
			while(file.good())
			{
				getline(file, line2);
				lC++;
			}
			lC--;
		}
		file.clear();
		file.close();
		file.open(ssPath.c_str(), std::ios::in);
		if(file.is_open())
		{
			int val=0;
			for(int j=0; j<lC; j++)
			{
				getline(file, line2);
				std::istringstream iss(line2);
				std::string sub, sub2;
				iss >> sub;
				iss >> sub2;
				x2[val] = atof(sub.c_str());
				y2[val] = atof(sub2.c_str());
				val++;
		}
		}
		file.clear();
		file.close();

		ui->customPlot->addGraph();
		ui->customPlot->graph(1)->setName(QString("SSP_ref"));
		ui->customPlot->graph(1)->setData(x2, y2);
		ui->customPlot->graph(1)->setLineStyle((QCPGraph::LineStyle)(5));
		QPen graphPen;
		graphPen.setColor(QColor(210, 210, 210));
		graphPen.setWidthF(10);
		ui->customPlot->graph(1)->setPen(graphPen);
		ui->customPlot->graph(1)->setLayer("below");
	}
	ui->customPlot->replot();
}


void CompassManualMode::on_calculateButton_clicked()
{
	QString peakName = ui->peakEdit->toPlainText();
	QByteArray nByte = peakName.toUtf8();
	std::string peak = nByte.data();
	int resNO = ui->resBox->value();
	std::string ca1, cb1, co1, ca2, cb2, co2;
	ca1=ca2=cb1=cb2=co1=co2="0";
	
	extern QString profile;
	std::string fname, line;
	fname=profile.toStdString();
	std::ifstream file;
	file.open(fname.c_str(), std::ios::in);
	getline(file, line);
	std::string dir = line;
	std::string resFile = dir + "Analysis/compass_result2_match1_sortCHI.bak";
	getline(file, line);
	getline(file, line);
	getline(file, line);
	getline(file, line);
	std::string seq = line;
	getline(file, line);
	int first = atoi(line.c_str());
	getline(file, line);
	getline(file, line);
	getline(file, line);
	getline(file, line);
	getline(file, line);
	std::string deut = line;
	double deuter = 0, pdeuter = 0;
	if(line == "pD")
		pdeuter = 1;
	else if(line == "D")
		deuter = 1;

	file.clear();
	file.close();
	file.open(resFile.c_str(), std::ios::in);
	int iC=0;
	while(file.good())
	{
		getline(file, line);
		iC++;
	}
	iC--;
	file.clear();
	file.close();
	file.open(resFile.c_str(), std::ios::in);
	bool found =false;
	for(int j=0; j<iC/31; j++)
	{
		for(int i=0; i<31; i++)
		{
			getline(file, line);
			if(i==24)
			{
				std::istringstream iss(line);
				std::string sub;
				iss >> sub;
				iss >> sub;
				iss >> sub;
				unsigned pos = sub.find("N-");
				std::string temp_peak;
				if(sub.substr(0,3)=="xxx")
					temp_peak= sub.substr(3,pos-3);
				else
					temp_peak= sub.substr(0,pos);
				if(peak==temp_peak)
				{
					found=true;
				}
			}
			if(i==27 && found==true) 
			{
				std::istringstream iss(line);
				std::string sub;
				iss >> sub;
				iss >> sub;
				iss >> sub;
				iss >> sub;
				ca1=sub;
				iss >> sub;
				ca2=sub;
			}
			else if(i==28 && found==true) 
			{
				std::istringstream iss(line);
				std::string sub;
				iss >> sub;
				iss >> sub;
				iss >> sub;
				iss >> sub;
				cb1=sub;
				iss >> sub;
				cb2=sub;
			}
			else if(i==29 && found==true) 
			{
				std::istringstream iss(line);
				std::string sub;
				iss >> sub;
				iss >> sub;
				iss >> sub;
				iss >> sub;
				co1=sub;
				iss >> sub;
				co2=sub;
			}
		}
		if(found==true)
			break;
		else
			found=false;
	}
	file.clear();
	file.close();
	if(found==true)
	{
		int zeroes=0;
		if(ca1=="0")
			zeroes++;
		if(ca2=="0")
			zeroes++;
		if(cb1=="0")
			zeroes++;
		if(cb2=="0")
			zeroes++;
		if(co1=="0")
			zeroes++;
		if(co2=="0")
			zeroes++;
		file.open(seq.c_str(), std::ios::in);
		getline(file, line);
		std::string line_temp = line;
		file.clear();
		file.close();
		std::istringstream iss(line_temp);
		std::istringstream iss2(line);
		std::string sub, aa1, aa2, sub2;
		bool invalid= false;
		for(int i=0; i<resNO-first+1; i++)
		{
			iss >> sub;
			if(i==resNO-first-1)
			{
				aa1 = sub;
				break;
			}
		}

		for(int i=0; i<resNO-first+1; i++)
		{
			iss2 >> sub2;
			if(i==resNO-first)
			{
				aa2 = sub2;
				if(sub2=="PRO")
					invalid=true;
				break;
			}
		}


		ui->errorLabel->hide();
		ui->errorBrowser->setText("");
		char s[2000];
		ParserType2 parser2;
		ShiftType shifts2;
		if(invalid!=true)
		{
			std::string pass;
			if(deuter>0)
				pass = "-ca1 " + ca1 + " -ca2 " + ca2 + " -cb1 " + cb1 + " -cb2 " + cb2 + " -co1 " + co1 + " -co2 " + co2 + " -D " + "-seq " +aa1 + " " + aa2;
			else if (pdeuter>0)
				pass = "-ca1 " + ca1 + " -ca2 " + ca2 + " -cb1 " + cb1 + " -cb2 " + cb2 + " -co1 " + co1 + " -co2 " + co2 + " -pD " + "-seq " +aa1 + " " + aa2;
			else
				pass = "-ca1 " + ca1 + " -ca2 " + ca2 + " -cb1 " + cb1 + " -cb2 " + cb2 + " -co1 " + co1 + " -co2 " + co2 + " -seq " +aa1 + " " + aa2;

            for (unsigned int i=0; i<pass.length(); i++)
				s[i]=pass[i];

            char a[1000][1000];
			int wc = 1;
		        int j = 0;
            for(unsigned int i=0; i<strlen(s); i++)
				if (s[i] != ' ' && s[i] != '\n')
				{
					a[wc][j++] = s[i];
				}
				else  
				{
					a[wc][j] = '\0';
					wc++;
					j = 0;
				}
			parser2.parse(wc, a);
			CalcScoreType2 score(parser2);
			shifts2.setShifts();
			score.calcScore(shifts2, wc, a, aa1, aa2, 1);
			extern std::string chiValq;

			QString chiVal = QString::fromUtf8(chiValq.c_str());
			
			ui->chiBrowser->setText(chiVal);
		}
		else
		{
			ui->errorLabel->show();
			ui->errorBrowser->setText("Cannot assign spin system to prolines.");
		}

	}
	else
	{
		ui->errorLabel->show();
        ui->errorBrowser->setText("The specified spin system is invalid.");
	}
	
}
CompassManualMode::~CompassManualMode()
{
	delete ui;
}

void CompassManualMode::anchorClicked(const QUrl &url)
{
	std::string str = url.toEncoded().data();
	DisplayInfo(str);
}
void CompassManualMode::setResbox()
{
	extern QString profile;
	std::string fname, line, seq, sub;
	fname=profile.toStdString();
	std::ifstream file;
	file.open(fname.c_str(), std::ios::in);
	if(file.is_open())
	{
		getline(file, line);
		getline(file, line);
		getline(file, line);
		getline(file, line);
		getline(file, line);
		seq = line;
		getline(file, line);
		int first = atoi(line.c_str());
		file.clear();
		file.close();
		file.open(seq.c_str(), std::ios::in);
		getline(file, line);
		file.clear();
		file.close();
		std::istringstream iss(line);
		int count=0;
		while(iss>>sub)
			count++;
		int max = count-1+first;
		first++;
		ui->resBox->setMinimum(first);
		ui->resBox->setMaximum(max);
	}
}
void CompassManualMode::on_overlayButton_clicked()
{
	ui->customPlot->clearGraphs();
	resetPlot();

}
void CompassManualMode::on_deleteButton_clicked()
{
	qint32 posBar = ui->seqBrowser->verticalScrollBar()->value();
	qint32 posBar2 = ui->fileBrowser->verticalScrollBar()->value();
	ui->errorLabel->hide();
	ui->errorBrowser->setText("");
	bool deleteI;
	QString csText = ui->csBrowser->toPlainText();
	QByteArray nByte;
	nByte=csText.toUtf8();
	std::string cstext = nByte.data();
	std::istringstream iss(cstext);
	std::string sub;
	std::string target;
	if(ui->iButton->isChecked())
		deleteI=true;
	else
		deleteI=false;
	while(sub!="residue:")
		iss >> sub;
	iss >>sub;
	std::string resno="";
	if(sub!="-")
		resno=sub.substr(1);
	if(deleteI==true)
	{
		while(sub!="'i':")
			iss >> sub;
		iss >> sub;
		target=sub;
	}
	else
	{
		while(sub!="'i-1':")
			iss >> sub;
		iss >> sub;
		target=sub;
	}
	if(target!="-")
	{
	extern QString profile;
	std::string fname, line;
	fname=profile.toStdString();
	std::ifstream file;
	file.open(fname.c_str(), std::ios::in);
	getline(file, line);
	file.clear();
	file.close();
	std::string fname2=line;
	line+="Analysis/indice.idx";
	fname=line;
	file.open(fname.c_str(), std::ios::in);
	getline(file, line);
	file.clear();
	file.close();
	std::string idxArr[2000];
	std::istringstream iss2(line);
	int iC=0;
	while(iss2>>idxArr[iC])
		iC++;
	std::ofstream fileO, fileO2;
	fileO.open(fname.c_str(), std::ios::out);
	std::string lineI="";
	for(int i=0; i<iC; i++)
	{
		bool printIdx=true;
		std::string fname3=fname2;
		std::string fnamem=fname2;
		std::string fnamem2=fname2;
		fnamem+="Analysis/manualmode.bak";
		fnamem2+="Analysis/manualmode";
		fname3+="Analysis/COMPASSresult_match";
		fname3+=idxArr[i].substr(0,1);
		if(idxArr[i].substr(0,1) == "4")
		{
			fname3 = "";
			fname3 = fnamem;
		}
		file.open(fname3.c_str(), std::ios::in);
		while(file.good())
		{
			std::string line2, line3, sub2, sub3;
			getline(file, line2);
			std::istringstream iss3(line2);
			iss3 >> sub2;
			if(idxArr[i]==sub2)
			{
				unsigned pos= idxArr[i].find(".");
				int loopNo = 20-atoi(idxArr[i].substr(pos+1).c_str())+2;
				for(int j=0; j<loopNo; j++)
					getline(file, line3);
				std::istringstream iss4(line3);
				while(iss4>>sub3)
					if(sub3.length()>=target.length() && target==sub3.substr(0,target.length()))
					{
						printIdx=false;
						break;
					}
					else if (sub3.substr(0,3)=="xxx" && sub3.length()-3>=target.length() && target==sub3.substr(3,target.length()))
					{
						printIdx=false;
						break;
					}

				break;
			}
		}
		file.clear();
		file.close();
		if(printIdx==true)
		{
			fileO<<idxArr[i]<<" ";
			lineI+=idxArr[i];
			lineI+=" ";
		}
		else if(printIdx==false && idxArr[i].substr(0,1) == "4")
		{
			std::ofstream fileO2;
            fileO2.open(fnamem2.c_str(), std::ios::out);
			file.open(fnamem.c_str(), std::ios::in);
			std::string l;
			int lC=0;
			while(file.good())
			{
				getline(file, l);
				lC++;
			}
			lC--;
			file.clear();
			file.close();
			file.open(fnamem.c_str(), std::ios::in);
			std::string tempArr[31];
			for(int j=0; j<lC/31; j++)
			{
				for(int k=0; k<31; k++)
				{
					getline(file, l);
					tempArr[k] = l;
				}
				if(tempArr[3].substr(0,6)!=idxArr[i])
				{
					for(int k=0; k<31; k++)
						fileO2<<tempArr[k]<<"\n";
				}
			}
            file.clear();
            file.close();
			fileO2.clear();
			fileO2.close();
            QString cp1 = QString::fromUtf8(fnamem2.c_str());
            QString cp2 = QString::fromUtf8(fnamem.c_str());
            if(QFile::exists(cp2))
                QFile::remove(cp2);
            QFile::copy(cp1, cp2);
		}
	}
	fileO.clear();
	fileO.close();
	QString qLine=QString::fromUtf8(lineI.c_str());
	ui->indexBrowser->setText(qLine);
	DisplayInfo(resno);
	createBak(0);
	readfile();
	CompassManualMode::rename(2); 
	CompassManualMode::ssp(); 
	}
	if(posBar >= 0)
		ui->seqBrowser->verticalScrollBar()->setValue(posBar);
	if(posBar2 >= 0)
		ui->fileBrowser->verticalScrollBar()->setValue(posBar2);
}
void CompassManualMode::DisplayInfo(std::string resno)
{
	extern QString profile;
    std::string cafile, cbcafile, cofile, csfile,cafile2, cbcafile2, cofile2, hsqcfile, compassfile, line2, seqfile, indexfile, indexfile2;
	double cadev=0.00, cbdev=0.00, codev=0.00;
    std::string typeI1cs="";

	std::ifstream file;
	std::string line;
	int resNo =atoi(resno.c_str());
	file.open (profile.toStdString().c_str(), std::ios::in);
	getline(file, line);
	compassfile=line; 
	indexfile=line;
    csfile=line+"Analysis/csedit";
	indexfile+="Analysis/indice.idx";
	indexfile2=line;
	std::string manualfile = line;
	manualfile += "Analysis/manualmode.bak";
	indexfile2+="Analysis/COMPASSresult_match";
	getline(file, line);
	cafile= line;
	getline(file, line);
	cbcafile= line;
	getline(file, line);
	cofile= line;
	getline(file, line);
	seqfile= line;
	getline(file, line);
	int first=atoi(line.c_str());
	getline(file, line);
	cafile2= line;
	getline(file, line);
	cbcafile2= line;
	getline(file, line);
	cofile2= line;
	getline(file, line);
	hsqcfile= line;
	file.clear();
	file.close();

	file.open(seqfile.c_str(), std::ios::in);
	getline(file, line);
	file.clear();
	file.close();
	std::istringstream iss(line);
	std::string sub;
	for(int i=first; i<=atoi(resno.c_str()); i++)
		iss >> sub;
	std::string info;
	ui->csBrowser->clear();
	QString Info;
	info="<font size=\"4\">";
	info+="Inspecting residue: ";
	info+=aa3to1(sub);
	info+=resno;
	info+="<br></font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="\t\t\t\t";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertPlainText(Info);
    info="<font size=\"4\"><sup>13</sup>C<sup>&alpha;</sup></font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="\t\t";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertPlainText(Info);
    info="<font size=\"4\"><sup>13</sup>C<sup>&beta;</sup></font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="\t\t";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertPlainText(Info);
	info="<font size=\"4\"><sup>13</sup>C<sup>O</sup><br>Type '<i>i</i>':</font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="\t";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertPlainText(Info);

	
	std::string idxArr[2500];
	int ic=0;
	file.open(indexfile.c_str(), std::ios::in);
	while(file>>sub)
	{
		idxArr[ic]=sub;
		ic++;
	}
	file.clear();
	file.close();

	std::string typeI="-", typeI1="-";
	for(int i=0; i<ic; i++)
	{
		bool done=false;
		std::string indexfile3=indexfile2;
		indexfile3+=idxArr[i].substr(0,1);
		std::string temp;
		if(idxArr[i].substr(0,1)=="4")
		{
			indexfile3 = "";
			indexfile3 = manualfile;
		}
		file.open(indexfile3.c_str(), std::ios::in);
		while(file.good())
		{
			getline(file, line);
			std::istringstream iss2(line);
			iss2>>sub;
			temp=sub;
			if(sub==idxArr[i])
			{
				iss2>>sub;
				iss2>>sub;
				unsigned pos2 = sub.find("-");
				int number =atoi(sub.substr(0,pos2).c_str());
				int number2 =atoi(sub.substr(pos2+1).c_str());
				if(resNo>=number && resNo<=number2)
				{
					int loopno= (number2-number+1)+2*(number2-number+1-2);
					int loopno2=(resNo-number)*2;
					unsigned pos = temp.find(".");
					for(int j=atoi(temp.substr(pos+1).c_str()); j<22; j++)
						getline(file, line);
					std::istringstream iss3(line);
					if(resNo==number2)
					{
						for(int k=0; k<=loopno; k++)
							iss3 >> sub;
						typeI=sub;
					}
					else if(resNo==number)
					{
						iss3 >> sub; 
						iss3 >> sub;
						typeI1=sub;
					}
					else
					{
						iss3 >> sub;
						for(int k=0; k<loopno2; k++)
							iss3 >> sub;
						typeI=sub;
						iss3 >> sub;
						typeI1=sub;
					}
					done=true;
				}
			}
		}
		file.clear();
		file.close();
		if(typeI!="-" && typeI1!="-" && done==true)
			break;
	}
	std::string typeI1o="-";
	if(typeI!="-")
	{
		unsigned posT=typeI.find("N-");
		typeI=typeI.substr(0,posT);
	}
	if(typeI1!="-")
	{
        unsigned posC=typeI1.find_first_of("-");
        typeI1cs = typeI1.substr(0,posC-1);
		unsigned posT=typeI1.find("N-");
		unsigned posT2=typeI1.find("CA-");
		typeI1o=typeI1.substr(0,posT);
		if(typeI1.substr(0,3)!="xxx")
			typeI1=typeI1.substr(posT+2,posT2-posT-2);
		else
			typeI1="xxx";
	}
	std::string ca="-", cb="-", co="-", ca1="-", cb1="-", co1="-";
	if(cafile!="EMPTY" && (typeI!="-" || typeI1!="-"))
	{
		file.open(cafile.c_str(), std::ios::in);
		getline(file, line);
		getline(file, line);
		while(file.good())
		{
			getline(file, line);
			std::istringstream iss4(line);
			iss4 >> sub;
			unsigned pos = sub.find("N-");
			if(typeI==sub.substr(0,pos) && sub.substr(pos,3)=="N-C" && sub.substr(pos+3,1)=="A")
			{
				iss4 >> sub;
				iss4 >> sub;
				ca=sub;
			}
			else if (typeI1==sub.substr(pos+2,typeI1.length()) && sub.substr(pos+2+typeI1.length(), 1)=="C")
			{
				iss4 >> sub;
				iss4 >> sub;
				ca1=sub;
			}
			if((ca!="-" && typeI1=="-") || (ca1!="-" && typeI=="-") || (ca!="-" && ca1!="-") )
				break;
		}
		file.clear();
		file.close();
	}
	if(cafile2!="EMPTY" && typeI1!="-")
	{
		file.open(cafile2.c_str(), std::ios::in);
		getline(file, line);
		getline(file, line);
		while(file.good())
		{
			bool done=false;
			getline(file, line);
			std::istringstream iss4(line);
			iss4 >> sub;
			unsigned pos = sub.find("N-");
			if (typeI1==sub.substr(pos+2,typeI1.length()) && sub.substr(pos+2+typeI1.length(), 1)=="C")
			{
				iss4 >> sub;
				iss4 >> sub;
				if(ca1!="-")
				{
					double doub =(atof(ca1.c_str())+atof(sub.c_str()))/2.0;
					cadev= abs((atof(ca1.c_str())-atof(sub.c_str()))/2.0);
					std::ostringstream oss;
					oss << doub;
					ca1=oss.str();
				}
				else
					ca1=sub;
				done=true;
			}
			if(done==true)
				break;
		}
		file.clear();
		file.close();
	}
	if(cbcafile!="EMPTY" && (typeI!="-" || typeI1!="-"))
	{
		file.open(cbcafile.c_str(), std::ios::in);
		getline(file, line);
		getline(file, line);
		bool isca=true;
		while(file.good())
		{
			getline(file, line);
			std::istringstream iss4(line);
			iss4 >> sub;
			unsigned pos = sub.find("N-");
            if(typeI==sub.substr(0,pos) && sub.substr(pos,3)=="N-C" && (sub.substr(pos+3,1)=="A" || sub.substr(pos+3,1)=="B"))
			{
				if(sub.substr(pos+2,2)=="CA")
					isca=true;
				else
					isca=false;
				iss4 >> sub;
				iss4 >> sub;
				if(isca==true && ca=="-")
					ca=sub;
				else if (isca==false)
					cb=sub;
			}
			else if (typeI1==sub.substr(pos+2,typeI1.length()) && sub.substr(pos+2+typeI1.length(), 1)=="C")
			{
				if(sub.substr(typeI1.length()+pos+2,2)=="CA")
					isca=true;
				else
					isca=false;
				iss4 >> sub;
				iss4 >> sub;
				if(isca==true && ca1=="-")
					ca1=sub;
				else if (isca==false)
					cb1=sub;
			}
			if((ca!="-" && cb!="-" && typeI1=="-") || (ca1!="-" && cb1!="-" && typeI=="-") || (ca!="-" && ca1!="-" && cb!="-" && cb1!="-") )
				break;
		}
		file.clear();

		file.close();
	}
	if(cbcafile2!="EMPTY" && typeI1!="-")
	{
		file.open(cbcafile2.c_str(), std::ios::in);
		getline(file, line);
		getline(file, line);
		bool isca=true;
		while(file.good())
		{
			getline(file, line);
			std::istringstream iss4(line);
			iss4 >> sub;
			bool done=false, done2=false;
			unsigned pos = sub.find("N-");
			if (typeI1==sub.substr(pos+2,typeI1.length()) && sub.substr(pos+2+typeI1.length(), 1)=="C")
			{
				if(sub.substr(typeI1.length()+pos+2,2)=="CA")
					isca=true;
				else
					isca=false;
				iss4 >> sub;
				iss4 >> sub;
				if(isca==true && ca1=="-")
				{
					ca1=sub;
					done=true;
				}
				else if (isca==false && cb1=="-")
				{
					cb1=sub;
					done2=true;
				}
				else if (isca==false && cb1!="-")
				{
					double doub =(atof(cb1.c_str())+atof(sub.c_str()))/2.0;
					cbdev= abs((atof(cb1.c_str())-atof(sub.c_str()))/2.0);
					std::ostringstream oss;
					oss << doub;
					cb1=sub;
					done2=true;
				}
			}
			if (done==true && done2==true)
				break;
		}
		file.clear();
		file.close();
	}
	if(cofile!="EMPTY" && (typeI!="-" || typeI1!="-"))
	{
		file.open(cofile.c_str(), std::ios::in);
		getline(file, line);
		getline(file, line);
		while(file.good())
		{
			getline(file, line);
			std::istringstream iss4(line);
			iss4 >> sub;
			unsigned pos = sub.find("N-");
			if(typeI==sub.substr(0,pos) && sub.substr(pos,3)=="N-C" && sub.substr(pos+3,1)=="O")
			{
				iss4 >> sub;
				iss4 >> sub;
				co=sub;
			}
			else if (typeI1==sub.substr(pos+2,typeI1.length()) && sub.substr(pos+2+typeI1.length(), 1)=="C")
			{
				iss4 >> sub;
				iss4 >> sub;
				co1=sub;
			}
			if((co!="-" && typeI1=="-") || (co1!="-" && typeI=="-") || (co!="-" && co1!="-") )
				break;
		}
		file.clear();
		file.close();
	}
	if(cofile2!="EMPTY" && typeI1!="-")
	{
		file.open(cofile2.c_str(), std::ios::in);
		getline(file, line);
		getline(file, line);
		while(file.good())
		{
			getline(file, line);
			std::istringstream iss4(line);
			iss4 >> sub;
			bool done =false;
			unsigned pos = sub.find("N-");
			if (typeI1==sub.substr(pos+2,typeI1.length()) && sub.substr(pos+2+typeI1.length(), 1)=="C")
			{
				iss4 >> sub;
				iss4 >> sub;
				if(co1!="-")
				{
					double doub =(atof(co1.c_str())+atof(sub.c_str()))/2.0;
					codev= abs((atof(co1.c_str())-atof(sub.c_str()))/2.0);
					std::ostringstream oss;
					oss << doub;
					co1=oss.str();
				}
				else
					co1=sub;
				done=true;
			}
			if(done==true)
				break;
		}
		file.clear();
		file.close();
	}

    std::ifstream fileCS;
    fileCS.open(csfile.c_str(), std::ios::in);
    while(getline(fileCS, line))
    {
        std::istringstream issCS(line);
        issCS>>sub;
        if(sub==typeI)
        {
            issCS>>sub;
            issCS>>sub;
            issCS>>sub;
            if(sub=="0")
                ca="-";
            else
                ca=sub;
            issCS>>sub;
            issCS>>sub;
            if(sub=="0")
                cb="-";
            else
                cb=sub;
            issCS>>sub;
            issCS>>sub;
            if(sub=="0")
                co="-";
            else
                co=sub;
        }
        else if(sub==typeI1cs)
        {
            issCS>>sub;
            issCS>>sub;
            issCS>>sub;
            issCS>>sub;
            if(sub=="0")
                ca1="-";
            else
                ca1=sub;
            issCS>>sub;
            issCS>>sub;
            if(sub=="0")
                cb1="-";
            else
                cb1=sub;
            issCS>>sub;
            issCS>>sub;
            if(sub=="0")
                co1="-";
            else
                co1=sub;
        }
    }
    fileCS.clear();
    fileCS.close();
	extern double warnCA;
	extern double warnCB;
	extern double warnCO;
	extern double warnDev;
	bool warnca=false;
	bool warncb=false;
	bool warnco=false;
	bool warndevca=false;
	bool warndevcb=false;
	bool warndevco=false;
	double CA, CB, CO, Dev;
	CA=warnCA;
	CB=warnCB;
	CO=warnCO;
	Dev=warnDev;

	if(abs(atof(ca.c_str())-atof(ca1.c_str()))>=CA && ca!="-" && ca1!="-")
		warnca=true;
	if(abs(atof(cb.c_str())-atof(cb1.c_str()))>=CB && cb!="-" && cb1!="-")
		warncb=true;
	if(abs(atof(co.c_str())-atof(co1.c_str()))>=CO && co!="-" && co1!="-")
		warnco=true;
	if(cadev>=Dev)
		warndevca=true;
	if(cbdev>=Dev)
		warndevcb=true;
	if(codev>=Dev)
		warndevco=true;

	if(typeI!="-" && typeI.substr(0,3)=="xxx")
	{
		typeI=typeI.substr(3);
	}
	if(typeI1o!="-" && typeI1o.substr(0,3)=="xxx")
	{
		typeI1o=typeI1o.substr(3);
	}
	std::ostringstream ss, ss2, ss3;
	ss << cadev;
	std::string cadevS(ss.str());
	ss2 << cbdev;
	std::string cbdevS(ss2.str());
	ss3 << codev;
	std::string codevS(ss3.str());
	info="<font size=\"4\">";
	info+=typeI; 
	info+="</font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="\t\t";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertPlainText(Info);
	info="<font size=\"4\" ";
	if(warnca==true)
		info+=" style=\"BACKGROUND-COLOR: #FA5858\"";
	info+=">";
    if(ca.length()>6)
        info+=mconvert(std::floor(1000.0*atof(ca.c_str())+0.5)/1000);
    else
        info+=ca;
    info+="</font><font style=\"BACKGROUND-COLOR: #F2F2F2\"> </font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="\t\t";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertPlainText(Info);
	info="<font size=\"4\"";
	if(warncb==true)
		info+=" style=\"BACKGROUND-COLOR: #FA5858\"";
	info+=">";
    if(cb.length()>6)
        info+=mconvert(std::floor(1000.0*atof(cb.c_str())+0.5)/1000);
    else
        info+=cb;
    info+="</font><font style=\"BACKGROUND-COLOR: #F2F2F2\"> </font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="\t\t";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertPlainText(Info);
	info="<font size=\"4\"";
	if(warnco==true)
		info+=" style=\"BACKGROUND-COLOR: #FA5858\"";
	info+=">";
    if(co.length()>6)
        info+=mconvert(std::floor(100.0*atof(co.c_str())+0.5)/100);
    else
        info+=co;
	info+="</font><font size=\"4\" font style=\"BACKGROUND-COLOR: #F2F2F2\"> </font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="<font size=\"4\"><br>Type '<i>i-1</i>':</font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="\t";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertPlainText(Info);
	info="<font size=\"4\">";
	info+=typeI1o; 
	info+="</font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="\t\t";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertPlainText(Info);
	info="<font size=\"4\"";
	if(warnca==true)
		info+="  style=\"BACKGROUND-COLOR: #FA5858\"";
	info+=">";
    if(ca1.length()>6)
        info+=mconvert(std::floor(1000.0*atof(ca1.c_str())+0.5)/1000);
    else
        info+=ca1;
    info+="</font><font style=\"BACKGROUND-COLOR: #F2F2F2\"> </font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="<font size=\"4\"";
	if(warndevca==true)
		info+=" style=\"BACKGROUND-COLOR: #FA5858\"";
	info+="> (";
	if(cadevS.length()==1)
	{
		info+=cadevS;
		info+=".00";
	}
	else if(cadevS.length()==3)
	{
		info+=cadevS;
		info+="0";
	}
	else if (cadevS.length()>4)
	{
		std::string info_tmp =mconvert(std::floor(100.0*atof(cadevS.c_str())+0.5)/100);
		if (info_tmp.length()==1)
			info += info_tmp+".00";
		else if (info_tmp.length()==3)
			info += info_tmp+"0";
		else
			info += info_tmp;
	}
	else 
		info += cadevS;
	info+=")</font><font style=\"BACKGROUND-COLOR: #F2F2F2\"> </font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="\t";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertPlainText(Info);
	info="<font size=\"4\"";
	if(warncb==true)
		info+=" style=\"BACKGROUND-COLOR: #FA5858\"";
	info+=">";
    if(cb1.length()>6)
        info+=mconvert(std::floor(1000.0*atof(cb1.c_str())+0.5)/1000);
    else
        info+=cb1;
    info+="</font><font style=\"BACKGROUND-COLOR: #F2F2F2\"> </font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="<font size=\"4\"";
	if(warndevcb==true)
		info+=" style=\"BACKGROUND-COLOR: #FA5858\"";
	info+="> (";
	if(cbdevS.length()==1)
	{
		info+=cbdevS;
		info+=".00";
	}
	else if(cbdevS.length()==3)
	{
		info+=cbdevS;
		info+="0";
	}
	else if (cbdevS.length()>4)
	{
		std::string info_tmp =mconvert(std::floor(100.0*atof(cbdevS.c_str())+0.5)/100);
		if (info_tmp.length()==1)
			info += info_tmp+".00";
		else if (info_tmp.length()==3)
			info += info_tmp+"0";
		else
			info += info_tmp;
	}
	else 
		info += cbdevS;
	info+=")</font><font style=\"BACKGROUND-COLOR: #F2F2F2\"> </font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="\t";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertPlainText(Info);
	info="<font size=\"4\"";
	if(warnco==true)
		info+=" style=\"BACKGROUND-COLOR: #FA5858\"";
	info+=">";
    if(co1.length()>6)
        info+=mconvert(std::floor(100.0*atof(co1.c_str())+0.5)/100);
    else
        info+=co1;
    info+="</font><font style=\"BACKGROUND-COLOR: #F2F2F2\"> </font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
	info="<font size=\"4\"";
	if(warndevco==true)
		info+=" style=\"BACKGROUND-COLOR: #FA5858\"";
	info+="> (";
	if(codevS.length()==1)
	{
		info+=codevS;
		info+=".00";
	}
	else if(codevS.length()==3)
	{
		info+=codevS;
		info+="0";
	}
	else if (codevS.length()>4)
	{
		std::string info_tmp =mconvert(std::floor(100.0*atof(codevS.c_str())+0.5)/100);
		if (info_tmp.length()==1)
			info += info_tmp+".00";
		else if (info_tmp.length()==3)
			info += info_tmp+"0";
		else
			info += info_tmp;
	}
	else 
		info += codevS;
	info+=")</font><font style=\"BACKGROUND-COLOR: #F2F2F2\"> </font>";
	Info= QString::fromUtf8(info.c_str());
	ui->csBrowser->insertHtml(Info);
}
void CompassManualMode::stat(std::string file)
{
	QString fname = QString::fromUtf8(file.c_str());
	QFile resfile(fname);
	resfile.open(QFile::ReadOnly | QFile::Text);
	QTextStream ReadFile(&resfile);
	ui->statBrowser->setText(ReadFile.readAll());
	resfile.close();
}
void CompassManualMode::rename(int save)
{
    if(save==0)
    {}
	QByteArray nByte; 
	extern QString profile;
	std::string lineA;
	std::ifstream fileA;
	std::string stringA = profile.toStdString().c_str();
	fileA.open(stringA.c_str(), std::ios::in);
	getline(fileA, lineA);
	fileA.clear();
	fileA.close();
	QString filenames=QString::fromUtf8(lineA.c_str());
    QString rmcmd= filenames;
    rmcmd+= "Analysis/indice.idx";
    QFile::remove(rmcmd);

	std::fstream index_file;
	
	rmcmd= filenames;
	rmcmd+= "Analysis/indice.idx";
	nByte=rmcmd.toUtf8();
	std::string str1 =nByte.data();
	index_file.open (str1.c_str(), std::ios::out);
	QString GetText;
	GetText = ui->indexBrowser->toPlainText();
	if (GetText!="")
	{
	QByteArray qstr = GetText.toUtf8();
	index_file<<qstr.data();;
	index_file.clear();
	index_file.close();

	extern QString profile;
	QString cafile, cbcafile, cofile, cafile2, cbcafile2, cofile2, hsqcfile, compassfile, line2;
	std::string cafileS, cbcafileS, cofileS, cafile2S, cbcafile2S, cofile2S, hsqcfileS;

	std::ifstream file;
	std::string line;
	file.open (profile.toStdString().c_str(), std::ios::in);
	getline(file, line);
	line2=QString::fromUtf8(line.c_str());
	std::string resultfile= line;
	resultfile+="Analysis/COMPASSresult_match";
	compassfile=line2;
	std::string compassfiles=line;
	compassfile+="Analysis/COMPASSresult_match";
	getline(file, line);
	cafile= QString::fromUtf8(line.c_str());
	cafileS=line;
	getline(file, line);
	cbcafile= QString::fromUtf8(line.c_str());
	cbcafileS=line;
	getline(file, line);
	cofile= QString::fromUtf8(line.c_str());
	cofileS=line;
	getline(file, line);
	getline(file, line);
	getline(file, line);
	cafile2= QString::fromUtf8(line.c_str());
	cafile2S=line;
	getline(file, line);
	cbcafile2= QString::fromUtf8(line.c_str());
	cbcafile2S=line;
	getline(file, line);
	cofile2= QString::fromUtf8(line.c_str());
	cofile2S=line;
	getline(file, line);
	hsqcfile= QString::fromUtf8(line.c_str());
	hsqcfileS=line;
	file.clear();
	file.close();
	
	QString cmd_line;
	std::string indexfile, filenameS;
	indexfile=compassfiles;
	indexfile+= "Analysis/indice.idx";
	QByteArray nByte = line2.toUtf8();
	filenameS= nByte.data();
	
	compass_analyze3(cafileS, cbcafileS, cofileS, cafile2S, cbcafile2S, cofile2S, "EMPTY", "EMPTY", "EMPTY",1,1,0.1,filenameS,resultfile,indexfile,hsqcfileS);

	std::ifstream errorFile;
	
	rmcmd= filenames;
	rmcmd+="Temp/rename_errors.txt";
	nByte=rmcmd.toUtf8();
	str1=nByte.data();
	errorFile.open(str1.c_str(), std::ios::in);
	std::string lineErr;
	getline (errorFile, lineErr);
	if (lineErr != "")
	{
		IndexError2 *winIE2;
		winIE2 = new IndexError2(this);
		winIE2->show();
	}
	errorFile.clear();
	errorFile.close();
	}
}

std::string CompassManualMode::aa3to1(std::string aa)
{
	if(aa=="ALA")
		return "A";
	else if(aa=="ARG")
		return "R";
	else if(aa=="ASN")
		return "N";
	else if(aa=="ASP")
		return "D";
	else if(aa=="CYS")
		return "C";
	else if(aa=="GLU")
		return "E";
	else if(aa=="GLN")
		return "Q";
	else if(aa=="GLY")
		return "G";
	else if(aa=="PRO")
		return "P";
	else if(aa=="SER")
		return "S";
	else if(aa=="TYR")
		return "Y";
	else if(aa=="HIS")
		return "H";
	else if(aa=="ILE")
		return "I";
	else if(aa=="LEU")
		return "L";
	else if(aa=="LYS")
		return "K";
	else if(aa=="MET")
		return "M";
	else if(aa=="PHE")
		return "F";
	else if(aa=="THR")
		return "T";
	else if(aa=="TRP")
		return "W";
	else 
		return "V";
}
void CompassManualMode::ssp()
{
	extern QString profile;
	std::string fname, line, seqfile, cafile, cbcafile, cofile, cafile2, cbcafile2, cofile2, hsqcfile, trosy, ssp_deut, seqRead, seqFile, firstSsp, ss;
	fname=profile.toStdString();
	std::ifstream file;
	file.open(fname.c_str(), std::ios::in);
	getline(file, line);
	std::string dir=line;
	seqfile= line;
	seqfile+="Analysis/seqfile.seq";
	seqFile=seqfile;
	seqFile+="2";
	getline(file, line);
	unsigned pos;
	if(line=="EMPTY")
		cafile=line;
	else
	{
		cafile=dir;
		cafile+="Results/";
		pos=line.find_last_of("/");
		cafile+=line.substr(pos+1);
		cafile+=".compass";
	}

	getline(file, line);
	if(line=="EMPTY")
		cbcafile=line;
	else
	{
		cbcafile=dir;
		cbcafile+="Results/";
		pos=line.find_last_of("/");
		cbcafile+=line.substr(pos+1);
		cbcafile+=".compass";
	}

	getline(file, line);
	if(line=="EMPTY")
		cofile=line;
	else
	{
		cofile=dir;
		cofile+="Results/";
		pos=line.find_last_of("/");
		cofile+=line.substr(pos+1);
		cofile+=".compass";
	}

	getline(file, line);
	seqRead=line;
	getline(file, line);
	firstSsp=line;
	getline(file, line);
	if(line=="EMPTY")
		cafile2=line;
	else
	{
		cafile2=dir;
		cafile2+="Results/";
		pos=line.find_last_of("/");
		cafile2+=line.substr(pos+1);
		cafile2+=".compass";
	}

	getline(file, line);
	if(line=="EMPTY")
		cbcafile2=line;
	else
	{
		cbcafile2=dir;
		cbcafile2+="Results/";
		pos=line.find_last_of("/");
		cbcafile2+=line.substr(pos+1);
		cbcafile2+=".compass";
	}

	getline(file, line);
	if(line=="EMPTY")
		cofile2=line;
	else
	{
		cofile2=dir;
		cofile2+="Results/";
		pos=line.find_last_of("/");
		cofile2+=line.substr(pos+1);
		cofile2+=".compass";
	}

	getline(file, line);
	if(line=="EMPTY")
		hsqcfile=line;
	else
	{
		hsqcfile=dir;
		hsqcfile+="Results/";
		pos=line.find_last_of("/");
		hsqcfile+=line.substr(pos+1);
		hsqcfile+=".compass";
	}

	getline(file, line);
	ssp_deut=line;	
	getline(file, line);
	trosy=line;
	getline(file, line);
	ss=line;
	if(ss=="EMPTY")
		ui->overlayButton->hide();
	file.clear();
	file.close();	

	file.open(seqfile.c_str(), std::ios::in);
	std::string subE;
    std::string emArr[1500][3], doneArr[1500];
	int dC=0;
	int em=0;
	while(file.good())
	{
		getline(file, line);
		std::istringstream iss(line);
		iss >> subE;
		emArr[em][0]=subE;
		iss >> subE;
		emArr[em][1]=subE;
		em++;
	}
	file.clear();
	file.close();
	for(int e=0; e<em; e++)
		for (int f=e+1; f<em; f++)
	{
		if(atoi(emArr[e][1].c_str())> atoi(emArr[f][1].c_str()))
		{
			std::string tempEm = emArr[e][1];
			std::string tempEm2= emArr[e][2];
			emArr[e][1]=emArr[f][1];
			emArr[e][2]=emArr[f][2];
			emArr[f][1]=tempEm;
			emArr[f][2]=tempEm2;
		}
	}
	std::ofstream fileE;
	fileE.open(seqFile.c_str(), std::ios::out);
	{
		bool foundI=false;
		for(int i=0; i<em-1; i++)
			if(emArr[i][1]=="m")
			{
				for(int j=0; j<dC; j++)
					if(emArr[i][0]==doneArr[j])
					{
						foundI=true;
						break;
					}
				if(foundI==false)
				{
					fileE << emArr[i][0].c_str();
					fileE << " ";
					doneArr[dC]=emArr[i][0];
					dC++;
				}
				else
					foundI=false;

			}
		for(int i=0; i<em-1; i++)
		{
			bool in_loop=false;
			foundI=false;
			if(emArr[i][1]=="e")
			{
				in_loop=true;
				for(int j=0; j<dC; j++)
				{
					if(emArr[i][0]==doneArr[j])
					{
						foundI=true;
						break;
					}
				}
				if(foundI==false && in_loop==true)
				{
					fileE << emArr[i][0].c_str();
					fileE << " ";
					in_loop=false;
				}
			}
		}
	}
	fileE.clear();
	fileE.close();

std::string sspArr[1500][6], Nshift, HNshift, Cshift, name; 
bool minus1=false;
std::string pro;
char str[1];
bool found=false;
int cCa=0, cCa2=0, cCb=0, cCb2=0, cCo=0, cCo2=0, cHsqc=0, cSsp=0, cSspF=0;

for(int j=0; j<6; j++)
	for(int i=0; i<1500; i++)
		sspArr[i][j]="0";

if(cafile!="EMPTY") 
{
	file.open(cafile.c_str(), std::ios::in);
	getline(file, line);
	getline(file, line);
	while(file.good())
	{
		getline(file, line);
		cCa++;
	}
	file.clear();
	file.close();
	file.open(cafile.c_str(), std::ios::in);
	getline(file, line);
	getline(file, line);
	for(int i=0; i<cCa-2; i++)
	{
		minus1=false;
		found=false;
		getline(file, line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		name=sub;
		iss >> sub;
		Nshift=sub;
		iss >> sub;
		Cshift=sub;
		iss >> sub;
		HNshift=sub;
		
		str[0]=name[0];
		if(!isalpha(str[0]))
			continue;
		unsigned pos=name.find("CA");
		if(name.substr(pos-1,1)=="-")
		{
			pro=name.substr(0,1); 
			for(int j=0; j<cSsp; j++)
			{
				if(sspArr[j][0]==name.substr(1,pos-3))
				{
					found=true;
					cSspF=j;
					break;
				}					
			}
			if(found==false)
				sspArr[cSsp][0]=name.substr(1,pos-3); 
		}
		else	
		{
			minus1=true;
			unsigned pos2=name.find_first_of("-");	
			pro=name.substr(pos2+1,1);
			for(int j=0; j<cSsp; j++)
			{
				if(sspArr[j][0]==name.substr(pos2+2,pos-2-pos2))
				{
					found=true;
					cSspF=j;
					break;
				}					
			}		
			if(found==false)
				sspArr[cSsp][0]=name.substr(pos2+2, pos-2-pos2); 
		}

		if(minus1==false)
		{
			if(found==false)
				sspArr[cSsp][5]=Nshift;
			else if(sspArr[cSspF][5]!="0")
				sspArr[cSspF][5]=ftoa((atof(sspArr[cSspF][5].c_str())+atof(Nshift.c_str()))/2);
			else
				sspArr[cSspF][5]=Nshift;
		}
		if(found==false)
			sspArr[cSsp][1]=Cshift; 
		else if(sspArr[cSspF][1]!="0")
			sspArr[cSspF][1]=ftoa((atof(sspArr[cSspF][1].c_str())+atof(Cshift.c_str()))/2);	
		else
			sspArr[cSspF][1]=Cshift;
		if(minus1==false)
		{
			if(found==false && pro!="P")
				sspArr[cSsp][4]=HNshift; 
			else if(sspArr[cSspF][4]!="0" && pro!="P")
				sspArr[cSspF][4]= ftoa((atof(sspArr[cSspF][4].c_str())+atof(HNshift.c_str()))/2);
			else if(pro!="P")
				sspArr[cSspF][4]=HNshift;
		}
		if(found==false)
			cSsp++;
	}	
	file.clear();
	file.close();
}
if(cafile2!="EMPTY") 
{
	file.open(cafile2.c_str(), std::ios::in);
	getline(file, line);
	getline(file, line);
	while(file.good())
	{
		getline(file, line);
		cCa2++;
	}
	file.clear();
	file.close();
	file.open(cafile2.c_str(), std::ios::in);
	getline(file, line);
	getline(file, line);
	for(int i=0; i<cCa2-2; i++)
	{
		found=false;
		getline(file, line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		name=sub;
		iss >> sub;
		Nshift=sub;
		iss >> sub;
		Cshift=sub;
		iss >> sub;
		HNshift=sub;

		str[0]=name[0];
		if(!isalpha(str[0]))
			continue;
		unsigned pos=name.find("CA");
		unsigned pos2=name.find_first_of("-");
		pro=name.substr(pos2+1,1);
		for(int j=0; j<cSsp; j++)
		{
			if(sspArr[j][0]==name.substr(pos2+2,pos-2-pos2))
			{
				found=true;
				cSspF=j;
				break;
			}					
		}
		if(found==false)
			sspArr[cSsp][0]=name.substr(pos2+2,pos-2-pos2); 

		if(found==false)
			sspArr[cSsp][1]=Cshift; 
		else if(sspArr[cSspF][1]!="0")
			sspArr[cSspF][1]= ftoa((atof(sspArr[cSspF][1].c_str())+atof(Cshift.c_str()))/2);	
		else
			sspArr[cSspF][1]=Cshift;

		if(found==false)
			cSsp++;
	}	
	file.clear();
	file.close();
}
if(cofile!="EMPTY")
{
	file.open(cofile.c_str(), std::ios::in);
	getline(file, line);
	getline(file, line);
	while(file.good())
	{
		getline(file, line);
		cCo++;
	}
	file.clear();
	file.close();
	file.open(cofile.c_str(), std::ios::in);
	getline(file, line);
	getline(file, line);
	for(int i=0; i<cCo-2; i++)
	{
		found=false;
		getline(file, line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		name=sub;
		iss >> sub;
		Nshift=sub;
		iss >> sub;
		Cshift=sub;
		iss >> sub;
		HNshift=sub;

		str[0]=name[0];
		if(!isalpha(str[0]))
			continue;
		unsigned pos=name.find("CO");
		if(name.substr(pos-1,1)=="-")
		{
			minus1=false;
			pro=name.substr(0,1); 
			for(int j=0; j<cSsp; j++)
			{
				if(sspArr[j][0]==name.substr(1,pos-3))
				{
					found=true;
					cSspF=j;
					break;
				}					
			}

			if(found==false)
				sspArr[cSsp][0]=name.substr(1,pos-3); 
		}
		else
		{
			minus1=true;
			unsigned pos2=name.find_first_of("-");
			pro=name.substr(pos2+1,1);
			for(int j=0; j<cSsp; j++)
			{
				if(sspArr[j][0]==name.substr(pos2+2,pos-2-pos2))
				{
					found=true;
					cSspF=j;
					break;
				}					
			}		
			if(found==false)
				sspArr[cSsp][0]=name.substr(pos2+2,pos-2-pos2); 
		}
		if(minus1==false)
		{
			if(found==false)
				sspArr[cSsp][5]=Nshift; 
			else if(sspArr[cSspF][5]!="0")
				sspArr[cSspF][5]= ftoa((atof(sspArr[cSspF][5].c_str())+atof(Nshift.c_str()))/2);
			else
				sspArr[cSspF][5]=Nshift;
		}
		if(found==false)
			sspArr[cSsp][3]=Cshift; 
		else if(sspArr[cSspF][3]!="0")
			sspArr[cSspF][3]= ftoa((atof(sspArr[cSspF][3].c_str())+atof(Cshift.c_str()))/2);	
		else
			sspArr[cSspF][3]=Cshift;
		if(minus1==false)
		{
			if(found==false && pro!="P")
				sspArr[cSsp][4]=HNshift; 
			else if(sspArr[cSspF][4]!="0" && pro!="P")
				sspArr[cSspF][4]= ftoa((atof(sspArr[cSspF][4].c_str())+atof(HNshift.c_str()))/2);
			else if(pro!="P")
				sspArr[cSspF][4]=HNshift;
		}
		if(found==false)
			cSsp++;
	}	
	file.clear();
	file.close();
}		

if(cofile2!="EMPTY")
{
	file.open(cofile2.c_str(), std::ios::in);
	getline(file, line);
	getline(file, line);
	while(file.good())
	{
		getline(file, line);
		cCo2++;
	}
	file.clear();
	file.close();
	file.open(cofile2.c_str(), std::ios::in);
	getline(file, line);
	getline(file, line);
	for(int i=0; i<cCo2-2; i++)
	{
		found=false;
		getline(file, line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		name=sub;
		iss >> sub;
		Nshift=sub;
		iss >> sub;
		Cshift=sub;
		iss >> sub;
		HNshift=sub;

		str[0]=name[0];
		if(!isalpha(str[0]))
			continue;
		unsigned pos=name.find("CO");
		unsigned pos2=name.find_first_of("-");
		pro=name.substr(pos2+1,1);	
		for(int j=0; j<cSsp; j++)
		{
			if(sspArr[j][0]==name.substr(pos2+2,pos-2-pos2))
			{
				found=true;
				cSspF=j;
				break;
			}					
		}		
		if(found==false)
			sspArr[cSsp][0]=name.substr(pos2+2,pos-2-pos2); 
		
		if(found==false)
			sspArr[cSsp][3]=Cshift; 
		else if(sspArr[cSspF][3]!="0")
			sspArr[cSspF][3]= ftoa((atof(sspArr[cSspF][3].c_str())+atof(Cshift.c_str()))/2);
		else
			sspArr[cSspF][3]=Cshift;

		if(found==false)
			cSsp++;
	}	
	file.clear();
	file.close();
}
std::string caorcb;
if(cbcafile!="EMPTY") 
{
	file.open(cbcafile.c_str(), std::ios::in);
	getline(file, line);
	getline(file, line);
	while(file.good())
	{
		getline(file, line);
		cCb++;
	}
	file.clear();
	file.close();
	file.open(cbcafile.c_str(), std::ios::in);
	getline(file, line);
	getline(file, line);
	for(int i=0; i<cCb-2; i++)
	{
		found=false;
		getline(file, line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		name=sub;
		iss >> sub;
		Nshift=sub;
		iss >> sub;
		Cshift=sub;
		iss >> sub;
		HNshift=sub;

		str[0]=name[0];
		if(!isalpha(str[0]))
			continue;
		unsigned pos=name.find_last_of("-");		
		caorcb=name.substr(pos-2,2); 
		if(name.substr(pos-3,1)=="-")
		{
			minus1=false;
			pro=name.substr(0,1); 
			for(int j=0; j<cSsp; j++)
			{
				if(sspArr[j][0]==name.substr(1,pos-5))
				{
					found=true;
					cSspF=j;
					break;
				}					
			}
			if(found==false)
			{
				sspArr[cSsp][0]=name.substr(1,pos-5); 
			}
		}
		else
		{
			minus1=true;
			unsigned pos2=name.find_first_of("-");	
			pro=name.substr(pos2+1,1);	
			for(int j=0; j<cSsp; j++)
			{
				if(sspArr[j][0]==name.substr(pos2+2,pos-4-pos2))
				{
					found=true;
					cSspF=j;
					break;
				}					
			}		
			if(found==false)
			{
				sspArr[cSsp][0]=name.substr(pos2+2,pos-4-pos2); 
			}
		}
		if(minus1==false)
		{
			if(found==false)
				sspArr[cSsp][5]=Nshift; 
			else if(found==true && sspArr[cSspF][5]!="0")
				sspArr[cSspF][5]= ftoa((atof(sspArr[cSspF][5].c_str())+atof(Nshift.c_str()))/2);
			else
				sspArr[cSspF][5]=Nshift;
		}
		if(found==false && caorcb=="CB")
		{
			sspArr[cSsp][2]=Cshift; 
		}
		else if(found==true && sspArr[cSspF][2]!="0" && caorcb=="CB")
		{
			sspArr[cSspF][2]= ftoa((atof(sspArr[cSspF][2].c_str())+atof(Cshift.c_str()))/2);
		}
		else if (caorcb=="CB")
		{
			sspArr[cSspF][2]=Cshift;
		}
		if(found==false && caorcb=="CA")
			sspArr[cSsp][1]=Cshift; 
		else if(found==true && sspArr[cSspF][1]!="0" && caorcb=="CA")
			sspArr[cSspF][1]= ftoa((atof(sspArr[cSspF][1].c_str())+atof(Cshift.c_str()))/2);
		else if (caorcb=="CA")
			sspArr[cSspF][1]=Cshift;		
		if(minus1==false)
		{
			if(found==false && pro!="P")
				sspArr[cSsp][4]=HNshift; 
			else if(found==true && sspArr[cSspF][4]!="0" && pro!="P")
				sspArr[cSspF][4]= ftoa((atof(sspArr[cSspF][4].c_str())+atof(HNshift.c_str()))/2);
			else if(pro!="P")
				sspArr[cSspF][4]=HNshift;
		}
		if(found==false)
			cSsp++;
	}	
	file.clear();
	file.close();
}

if(cbcafile2!="EMPTY") 
{
	file.open(cbcafile2.c_str(), std::ios::in);
	getline(file, line);
	getline(file, line);
	while(file.good())
	{
		getline(file, line);
		cCb2++;
	}
	file.clear();
	file.close();
	file.open(cbcafile2.c_str(), std::ios::in);
	getline(file, line);
	getline(file, line);
	for(int i=0; i<cCb2-2; i++)
	{
		found=false;
		getline(file, line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		name=sub;
		iss >> sub;
		Nshift=sub;
		iss >> sub;
		Cshift=sub;
		iss >> sub;
		HNshift=sub;

		str[0]=name[0];
		if(!isalpha(str[0]))
			continue;
		unsigned pos=name.find_last_of("-");	
		caorcb=name.substr(pos-2,2);
		unsigned pos2=name.find_first_of("-");
		pro=name.substr(pos2+1,1);	
		for(int j=0; j<cSsp; j++)
		{
			if(sspArr[j][0]==name.substr(pos2+2,pos-4-pos2))
			{
				found=true;
				cSspF=j;
				break;
			}					
		}	

		if(found==false)
			sspArr[cSsp][0]=name.substr(pos2+2,pos-4-pos2); 

		if(found==false && caorcb=="CB")
			sspArr[cSsp][2]=Cshift; 
		else if(sspArr[cSspF][2]!="0" && caorcb=="CB")
			sspArr[cSspF][2]= ftoa((atof(sspArr[cSspF][2].c_str())+atof(Cshift.c_str()))/2);
		else if (caorcb=="CB")
			sspArr[cSspF][2]=Cshift;
		if(found==false && caorcb=="CA")
			sspArr[cSsp][1]=Cshift; 
		else if(sspArr[cSspF][1]!="0" && caorcb=="CA")
			sspArr[cSspF][1]= ftoa((atof(sspArr[cSspF][1].c_str())+atof(Cshift.c_str()))/2);
		else if (caorcb=="CA")
			sspArr[cSspF][1]=Cshift;			
		if(found==false)
			cSsp++;
	}	
	file.clear();
	file.close();
}
if(hsqcfile!="EMPTY") 
{
	file.open(hsqcfile.c_str(), std::ios::in);
	getline(file, line);
	getline(file, line);
	while(file.good())
	{
		getline(file, line);
		cHsqc++;
	}
	file.clear();
	file.close();
	file.open(hsqcfile.c_str(), std::ios::in);
	getline(file, line);
	getline(file, line);
	for(int i=0; i<cHsqc-2; i++)
	{
		found=false;
		getline(file, line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		name=sub;
		iss >> sub;
		Nshift=sub;
		iss >> sub;
		HNshift=sub;

		str[0]=name[0];
		if(!isalpha(str[0]))
			continue;
		unsigned pos=name.find("N-");		
		for(int j=0; j<cSsp; j++)
		{
			if(sspArr[j][0]==name.substr(1,pos-1))
			{
				found=true;
				cSspF=j;
				break;
			}					
		}		
		if(found==false)
			sspArr[cSsp][0]=name.substr(1,pos-1);
		if(found==false)
			sspArr[cSsp][5]=Nshift; 
		else if(sspArr[cSspF][5]!="0")
			sspArr[cSspF][5]= ftoa((atof(sspArr[cSspF][5].c_str())+atof(Nshift.c_str()))/2);
		else
			sspArr[cSspF][5]=Nshift;
		if(found==false)
			sspArr[cSsp][4]=HNshift; 
		else if(sspArr[cSspF][4]!="0")
			sspArr[cSspF][4]= ftoa((atof(sspArr[cSspF][4].c_str())+atof(HNshift.c_str()))/2);
		else
			sspArr[cSspF][4]=HNshift;
		if(found==false)
			cSsp++;
	}	
	file.clear();
	file.close();
}

file.open(seqFile.c_str(), std::ios::in); 
getline(file, line);					
std::istringstream iss(line);
std::string sub2, sub_last;
std::string resnoArr[1500];
int cRes=0;
sub_last="0";
do{
	iss >> sub2;
	if(sub2!=sub_last)
	{
		resnoArr[cRes]=sub2;
		cRes++;
	}
	sub_last=sub2;
}while(iss);
file.clear();
file.close();

std::string caSSPfile, cbSSPfile, coSSPfile, hnSSPfile, nSSPfile, sspcmd, inSSPfile, manualPlotFile;
file.open(profile.toStdString().c_str(), std::ios::in);
getline(file, line);
file.clear();
file.close();
caSSPfile=line;
caSSPfile+="Analysis/ca.ca";
cbSSPfile=line;
cbSSPfile+="Analysis/cb.cb";
coSSPfile=line;
coSSPfile+="Analysis/co.co";
hnSSPfile=line;
hnSSPfile+="Analysis/hn.hn";
nSSPfile=line;
nSSPfile+="Analysis/n.n";
QString rmQ = QString::fromUtf8(caSSPfile.c_str());
QFile::remove(rmQ);
rmQ = QString::fromUtf8(cbSSPfile.c_str());
QFile::remove(rmQ);
rmQ= QString::fromUtf8(coSSPfile.c_str());
QFile::remove(rmQ);
rmQ= QString::fromUtf8(hnSSPfile.c_str());
QFile::remove(rmQ);
rmQ= QString::fromUtf8(nSSPfile.c_str());
QFile::remove(rmQ);

std::ofstream fileO;
std::string nucl;


fileO.open(caSSPfile.c_str(), std::ios::out);
nucl="CA";
for(int i=0; i<cSsp; i++)
	for(int j=0; j<cRes; j++)
		if(sspArr[i][1]!="0" && sspArr[i][0]==resnoArr[j])
		{
			fileO<<sspArr[i][0]<<"\t"<<Compensate(sspArr[i][1], sspArr[i][0], seqRead, firstSsp, ssp_deut, nucl)<<"\n";
			break;
		}
fileO.clear();
fileO.close();

nucl="CB";
fileO.open(cbSSPfile.c_str(), std::ios::out);
for(int i=0; i<cSsp; i++)
{
	for(int j=0; j<cRes; j++)
	{
		if(sspArr[i][2]!="0" && sspArr[i][0]==resnoArr[j])
		{
			fileO<<sspArr[i][0]<<"\t"<<Compensate(sspArr[i][2], sspArr[i][0], seqRead, firstSsp, ssp_deut, nucl)<<"\n";
			break;
		}
	}
}
fileO.clear();
fileO.close();
fileO.open(coSSPfile.c_str(), std::ios::out);
for(int i=0; i<cSsp; i++)
	for(int j=0; j<cRes; j++)
		if(sspArr[i][3]!="0" && sspArr[i][0]==resnoArr[j])
		{
			fileO<<sspArr[i][0]<<"\t"<<sspArr[i][3]<<"\n";
		}
fileO.clear();
fileO.close();
nucl="HN";
fileO.open(hnSSPfile.c_str(), std::ios::out);
for(int i=0; i<cSsp; i++)
	for(int j=0; j<cRes; j++)
		if(sspArr[i][4]!="0" && sspArr[i][0]==resnoArr[j])
		{
			fileO<<sspArr[i][0]<<"\t"<<Trosy(sspArr[i][4], trosy, nucl)<<"\n";
		}
fileO.clear();
fileO.close();
nucl="N";
fileO.open(nSSPfile.c_str(), std::ios::out);
for(int i=0; i<cSsp; i++)
	for(int j=0; j<cRes; j++)
		if(sspArr[i][5]!="0" && sspArr[i][0]==resnoArr[j])
			fileO<<sspArr[i][0]<<"\t"<<Trosy(sspArr[i][5], trosy, nucl)<<"\n";
fileO.clear();
fileO.close();

std::string seqSSPfile;
seqSSPfile=line;
seqSSPfile+="Analysis/sspSeq.s";
inSSPfile=line;
manualPlotFile = inSSPfile + "Results/SSP_plot.txt";
inSSPfile+="Analysis/inSSP.ssp";


std::string imageDir;
imageDir=line;
imageDir+="Results/";

std::string line_aa, sub_aa;
std::string aaArr[1500];
int cAA=0;


file.open(seqRead.c_str(), std::ios::in);
getline(file, line_aa);
file.clear();
file.close();
std::istringstream issa(line_aa);
do{
	issa >> sub_aa;
	aaArr[cAA]=aa3to1(sub_aa);
	cAA++;	
}while(issa);


fileO.open(seqSSPfile.c_str(), std::ios::out);
for(int i=0; i<(atoi(firstSsp.c_str())-1); i++)
	fileO<<"X ";
for(int i=0; i<cAA-1; i++)
	fileO<<aaArr[i]<<" ";
fileO.clear();
fileO.close();

sspCalc2(caSSPfile, cbSSPfile, coSSPfile, hnSSPfile, nSSPfile, seqSSPfile, inSSPfile);
if(ss!="EMPTY")
{
	std::ifstream fileSS;
	std::ofstream fileSSo;
	std::string ssFileo = seqSSPfile.c_str();
	ssFileo+="2";
	fileSS.open(ss.c_str(), std::ios::in);
	fileSSo.open(ssFileo.c_str(), std::ios::out);
	std::string subSS, element;
	int fS = atoi(firstSsp.c_str());
	while(fileSS>>subSS)
	{
		if(subSS=="helx")
			fileSSo<<fS<<"\t"<<"1"<<"\n";			
		else if(subSS=="loop")
			fileSSo<<fS<<"\t"<<"0"<<"\n";			
		else if(subSS=="strd")
			fileSSo<<fS<<"\t"<<"-1"<<"\n";			
		fS++;
	}
	fileSS.clear();
	fileSS.close();
	fileSSo.clear();
	fileSSo.close();
}	
	addGraph();


}
std::string CompassManualMode::ftoa(double doub)
{
	std::ostringstream ss;
	ss << doub;
	return ss.str();
}
double CompassManualMode::Compensate(std::string cs, std::string resno, std::string seqRead, std::string first, std::string ssp_deut, std::string nucl)
{
	std::ifstream Sfile;
	double c;
	c=atof(cs.c_str());
	std::string line, aa;
	Sfile.open(seqRead.c_str(), std::ios::in);
	getline(Sfile, line);
	std::istringstream iss(line);
	for(int i=atoi(first.c_str()); i<=atoi(resno.c_str()); i++)
		iss >> aa;
	Sfile.clear();
	Sfile.close();
	if(ssp_deut=="pD" && c!=0.0)
	{
		if(nucl=="CA")
		{
			if(aa=="ALA")
				return (c+0.394526);
			else if(aa=="ARG")
				return (c+0.403);
			else if(aa=="ASN")
				return (c+0.2765);
			else if(aa=="ASP")
				return (c+0.186);
			else if(aa=="CYS")
				return (c+0.393);
			else if(aa=="GLU")
				return (c+0.4305);
			else if(aa=="GLN")
				return (c+0.41875);
			else if(aa=="GLY")
				return (c+0.4412);
			else if(aa=="PRO")
				return (c+0.3034);
			else if(aa=="SER")
				return (c+0.427);
			else if(aa=="TYR")
				return (c+0.267);
			else if(aa=="HIS")
				return (c+0.4295);
			else if(aa=="ILE")
				return (c+0.459);
			else if(aa=="LEU")
				return (c+0.432636);
			else if(aa=="LYS")
				return (c+0.420556);
			else if(aa=="MET")
				return (c+0.4645);
			else if(aa=="PHE")
				return (c+0.333);
			else if(aa=="THR")
				return (c+0.302);
			else if(aa=="TRP")
				return (c+0.2765);
			else 
				return (c+0.421167);
		}
		else
		{
			if(aa=="ALA")
				return (c+0.781056);
			else if(aa=="ARG")
				return (c+0.921);
			else if(aa=="ASN")
				return (c+0.4585);
			else if(aa=="ASP")
				return (c+0.4215);
			else if(aa=="CYS")
				return (c+0.328889); 	
			else if(aa=="GLU")
				return (c+0.882714);
			else if(aa=="GLN")
				return (c+0.84325);
			else if(aa=="GLY")
				return (c+0.0);
			else if(aa=="PRO")
				return (c+0.9472);
			else if(aa=="SER")
				return (c+0.328889);
			else if(aa=="TYR")
				return (c+0.628);
			else if(aa=="HIS")
				return (c+0.9055);
			else if(aa=="ILE")
				return (c+0.9035);
			else if(aa=="LEU")
				return (c+1.10318);
			else if(aa=="LYS")
				return (c+0.834889);
			else if(aa=="MET")
				return (c+0.917);
			else if(aa=="PHE")
				return (c+0.711667);
			else if(aa=="THR")
				return (c+0.3685);
			else if(aa=="TRP")
				return (c+0.4105);
			else 
				return (c+0.904917);
		}
	}
	else if(ssp_deut=="D" && c!=0.0)
	{
		if(nucl=="CA")
		{
			if(aa=="ALA")
				return (c+0.68);
			else if(aa=="ARG")
				return (c+0.69);
			else if(aa=="ASN")
				return (c+0.55);
			else if(aa=="ASP")
				return (c+0.55);
			else if(aa=="CYS")
				return (c+0.55);
			else if(aa=="GLU")
				return (c+0.69);
			else if(aa=="GLN")
				return (c+0.69);
			else if(aa=="GLY")
				return (c+0.78);
			else if(aa=="PRO")
				return (c+0.69);
			else if(aa=="SER")
				return (c+0.55);
			else if(aa=="TYR")
				return (c+0.55);
			else if(aa=="HIS")
				return (c+0.55);
			else if(aa=="ILE")
				return (c+0.77);
			else if(aa=="LEU")
				return (c+0.62);
			else if(aa=="LYS")
				return (c+0.69);
			else if(aa=="MET")
				return (c+0.69);
			else if(aa=="PHE")
				return (c+0.55);
			else if(aa=="THR")
				return (c+0.63);
			else if(aa=="TRP")
				return (c+0.63);
			else 
				return (c+0.84);
		}
		else if (nucl=="CB")
		{
			if(aa=="ALA")
				return (c+1);
			else if(aa=="ARG")
				return (c+1.11);
			else if(aa=="ASN")
				return (c+0.71);
			else if(aa=="ASP")
				return (c+0.71);
			else if(aa=="CYS")
				return (c+0.71);
			else if(aa=="GLU")
				return (c+0.97);
			else if(aa=="GLN")
				return (c+0.97);
			else if(aa=="GLY")
				return (c+0.78);
			else if(aa=="PRO")
				return (c+1.11);
			else if(aa=="SER")
				return (c+0.71);
			else if(aa=="TYR")
				return (c+0.71);
			else if(aa=="HIS")
				return (c+0.71);
			else if(aa=="ILE")
				return (c+1.28);
			else if(aa=="LEU")
				return (c+1.26);
			else if(aa=="LYS")
				return (c+1.11);
			else if(aa=="MET")
				return (c+0.97);
			else if(aa=="PHE")
				return (c+0.71);
			else if(aa=="THR")
				return (c+0.81);
			else if(aa=="TRP")
				return (c+0.71);
			else 
				return (c+1.2);
		}
		else
		{
			if(aa=="ALA")
				return (c+0.41);
			else if(aa=="ARG")
				return (c+0.34);
			else if(aa=="ASN")
				return (c+0.34);
			else if(aa=="ASP")
				return (c+0.34);
			else if(aa=="CYS")
				return (c+0.34);
			else if(aa=="GLU")
				return (c+0.34);
			else if(aa=="GLN")
				return (c+0.34);
			else if(aa=="GLY")
				return (c+0.33);
			else if(aa=="PRO")
				return (c+0.34);
			else if(aa=="SER")
				return (c+0.34);
			else if(aa=="TYR")
				return (c+0.34);
			else if(aa=="HIS")
				return (c+0.34);
			else if(aa=="ILE")
				return (c+0.34);
			else if(aa=="LEU")
				return (c+0.34);
			else if(aa=="LYS")
				return (c+0.34);
			else if(aa=="MET")
				return (c+0.34);
			else if(aa=="PHE")
				return (c+0.34);
			else if(aa=="THR")
				return (c+0.27);
			else if(aa=="TRP")
				return (c+0.34);
			else 
				return (c+0.27);
		}

	}
	else
		return c;
}
double CompassManualMode::Trosy(std::string cs, std::string trosy, std::string nucl)
{
	if(nucl=="HN")
	{
		if(trosy=="Yes")
			return (atof(cs.c_str())+(46/600));
		else
			return atof(cs.c_str());
	}
	else
	{
		if(trosy=="Yes")
			return (atof(cs.c_str())-(46/600));
		else
			return atof(cs.c_str());
	}
}
int CompassManualMode::saveIdx()
{
	std::ofstream idxfile_new;
	extern QString profile;
	QString idxtext;
	std::string fname2, line;

	fname2=profile.toStdString().c_str();	
	std::ifstream idxgetfile;
	idxgetfile.open(fname2.c_str(), std::ios::in);
	getline(idxgetfile, line);
	idxgetfile.clear();
	idxgetfile.close();

	fname2 = line;
	fname2+="Analysis/indice.idx";
	idxgetfile.open(fname2.c_str(), std::ios::in);
	getline(idxgetfile, line);
	idxgetfile.clear();
	idxgetfile.close();
	std::istringstream iss(line);
	std::string sub;
	std::string idxArr[1000];
	int iC=0;
	while(iss >> sub)
	{
		if(sub.substr(0,1)=="4")
		{
			idxArr[iC++]=sub;
		}
	}
	int idx = 4000;
	for (int i=0; i<iC; i++)
	{
		std::string temp;
		temp = idxArr[i].substr(0,4);
		if(atoi(temp.c_str())==idx)
		{
			idx++;
			i=-1;
		}
	}
	
	idxfile_new.open (fname2.c_str(), std::ios::out);
	idxtext = ui->indexBrowser->toPlainText();
	idxfile_new<<idxtext.toStdString();
	idxfile_new<<" "<<idx<<".1";
	idxfile_new.clear();
	idxfile_new.close();
	return idx;
}
void CompassManualMode::undoFunc()
{
	std::ofstream idxfile_new;
	extern QString profile;
	QString idxtext;
	std::string fname2, line;
	fname2=profile.toStdString().c_str();	
	std::ifstream idxgetfile;
	idxgetfile.open(fname2.c_str(), std::ios::in);
	getline(idxgetfile, line);
	idxgetfile.clear();
	idxgetfile.close();
	fname2 = line;
    QString cp1 = QString::fromUtf8(line.c_str());
    cp1+= "Analysis/manualmode";
    QString cp2 = cp1;
    cp2+=".bak";
    if(QFile::exists(cp2))
    {
        QFile::remove(cp2);
    }
    QFile::copy(cp1, cp2);

	std::string fname3 = line;
	fname2+="Analysis/indice.idx";
	idxfile_new.open (fname2.c_str(), std::ios::out);
	idxtext = ui->indexBrowser->toPlainText();
	idxfile_new<<idxtext.toStdString();
	idxfile_new.clear();
	idxfile_new.close();
}
void CompassManualMode::on_undoButton_clicked()
{
	ui->errorLabel->hide();
	ui->errorBrowser->setText("");
	QString text = ui->indexBrowser->toPlainText();
	QByteArray nByte = text.toUtf8();
	std::string line, line2, sub;
	line= nByte.data();
	line2=line;
	std::istringstream iss(line);
	while(iss >> sub)
    {}
	int length = sub.length();
	int length2= line2.length();
	std::string manual = sub;
	qint32 posBar = ui->seqBrowser->verticalScrollBar()->value();
	qint32 posBar2= ui->fileBrowser->verticalScrollBar()->value();
	if(length2==length && length>0)
	{
		ui->indexBrowser->setText("");
		std::ofstream idxfile_new;
		extern QString profile;
		QString idxtext;
		std::string fname2, line;
	
		fname2=profile.toStdString().c_str();	
		std::ifstream idxgetfile;
		idxgetfile.open(fname2.c_str(), std::ios::in);
		getline(idxgetfile, line);
		idxgetfile.clear();
		idxgetfile.close();

        std::string mname = line;
        mname += "Analysis/manualmode";
        std::string mname2 = mname;
        mname2 += ".bak";
        std::ofstream file;
        file.open(mname2.c_str(), std::ios::out);
        file<<"";
        file.clear();
        file.close();
        file.open(mname.c_str(), std::ios::out);
        file<<"";
        file.clear();
        file.close();
	
		fname2 = line;
		std::string fname3 = line;
		fname2+="Analysis/indice.idx";
		idxfile_new.open (fname2.c_str(), std::ios::out);
		idxtext = ui->indexBrowser->toPlainText();
		idxfile_new<<idxtext.toStdString();
		idxfile_new.clear();
		idxfile_new.close();
		createBak(0);
		readfile();
		rename(2);
		ssp();

	}
	else if(length2>0)
	{
		line2=line2.substr(0,length2-length-1);
		text=QString::fromUtf8(line2.c_str());
		ui->indexBrowser->setText(text);
		std::ofstream idxfile_new;
		extern QString profile;
		QString idxtext;
		std::string fname2, line;
	
		fname2=profile.toStdString().c_str();	
		std::ifstream idxgetfile;
		idxgetfile.open(fname2.c_str(), std::ios::in);
		getline(idxgetfile, line);
		idxgetfile.clear();
		idxgetfile.close();
	
		fname2 = line;
		std::string fname3 = line;
		fname2+="Analysis/indice.idx";
		idxfile_new.open (fname2.c_str(), std::ios::out);
		idxtext = ui->indexBrowser->toPlainText();
		idxfile_new<<idxtext.toStdString();
		idxfile_new.clear();
		idxfile_new.close();

		if(manual.substr(0,1)=="4")
		{
			std::string mname = line;
			mname += "Analysis/manualmode";
			std::string mname2 = mname;
			mname2 += ".bak";
			std::ifstream file;
			file.open(mname2.c_str(), std::ios::in);
			std::string tempArr[31], l;
			int lC = 0;
			while(file.good())
			{
				getline(file, l);
				lC++;
			}
			lC--;
			file.clear();
			file.close();
			file.open(mname2.c_str(), std::ios::in);
			std::ofstream fileO;
			fileO.open(mname.c_str(), std::ios::out);
	
			for(int i=0; i<lC/31; i++)
			{
				for(int j=0; j<31; j++)
				{
					getline(file, l);
					tempArr[j]=l;
				}
				if(tempArr[3].substr(0,6) != manual)
				{
					for(int k=0; k<31; k++)
                    {
						fileO << tempArr[k]<<"\n";
                    }
				}
			}
            file.clear();
            file.close();
			fileO.clear();
			fileO.close();
            QString cp1 = QString::fromUtf8(mname.c_str());
            QString cp2 = QString::fromUtf8(mname2.c_str());
            if(QFile::exists(cp2))
            {
                QFile::remove(cp2);
            }
            QFile::copy(cp1, cp2);
		}
        createBak(0);
        readfile();
        rename(2);
        ssp();
	}
	if(posBar >= 0)
		ui->seqBrowser->verticalScrollBar()->setValue(posBar);
	if(posBar2 >= 0)
		ui->fileBrowser->verticalScrollBar()->setValue(posBar2);
}
void CompassManualMode::on_previewButton_clicked()
{
	extern QString profile;
	QString idxtext;
	std::string fname2, line;
	fname2=profile.toStdString().c_str();	
	int resNO = ui->resBox->value();
	std::string temp_peak, temp_peaki, temp_peaki1, ca1, cb1, co1, ca2, cb2, co2;
	ca1=ca2=cb1=cb2=co1=co2="0";
	QString peakName = ui->peakEdit->toPlainText();
	QByteArray nByte = peakName.toUtf8();
	std::string peak = nByte.data();

	std::ifstream file;
	file.open(fname2.c_str(), std::ios::in);
	getline(file, line);
	fname2 = line;
	std::string idFile = line + "Analysis/manualmode"; 
	std::string idFile2 = line + "Analysis/manualmode.bak"; 
	fname2 += "Analysis/compass_result2_match1_sortCHI.bak";
	getline(file, line);
	getline(file, line);
	getline(file, line);
	getline(file, line);
	std::string seq = line;
	getline(file, line);
	file.clear();
	file.close();
	int first = atoi(line.c_str());

	
	file.open(seq.c_str(), std::ios::in);
	getline(file, line);
	file.clear();
	file.close();
	std::istringstream iss2(line);
	std::string sub2, aa1, aa2;
	bool invalid= false;
	for(int i=0; i<resNO-first+1; i++)
	{
		iss2 >> sub2;
		if(i==resNO-first-1)
			aa1 = sub2;
		else if(i==resNO-first)
		{
			aa2 = sub2;
			if(sub2=="PRO")
				invalid=true;
		}
	}
	if(invalid==false)
	{
		file.open(fname2.c_str(), std::ios::in);
		int iC=0;
		while(file.good())
		{
			getline(file, line);
			iC++;
		}
		iC--;
		file.clear();
		file.close();
		file.open(fname2.c_str(), std::ios::in);
		bool found =false;
		for(int j=0; j<iC/31; j++)
		{
			for(int i=0; i<31; i++)
			{
				getline(file, line);
				if(i==24)
				{
					std::istringstream iss(line);
					std::string sub;
					iss >> sub;
					iss >> sub;
					temp_peaki1 = sub;
					iss >> sub;
					temp_peaki= sub;
					unsigned pos = sub.find("N-");
					if(sub.substr(0,3)=="xxx")
						temp_peak= sub.substr(3,pos-3);
					else
						temp_peak= sub.substr(0,pos);
					if(peak==temp_peak)
					{
						found=true;
					}
				}
				if(i==27 && found==true) 
				{
					std::istringstream iss(line);
					std::string sub;
					iss >> sub;
					iss >> sub;
					iss >> sub;
					iss >> sub;
					ca1=sub;
					iss >> sub;
					ca2=sub;
				}
				else if(i==28 && found==true) 
				{
					std::istringstream iss(line);
					std::string sub;
					iss >> sub;
					iss >> sub;
					iss >> sub;
					iss >> sub;
					cb1=sub;
					iss >> sub;
					cb2=sub;
				}
				else if(i==29 && found==true)
				{
					std::istringstream iss(line);
					std::string sub;
						iss >> sub;
					iss >> sub;
					iss >> sub;
					iss >> sub;
					co1=sub;
					iss >> sub;
					co2=sub;
				}
			}
			if(found==true)
				break;
			else
				found=false;
		}
		file.clear();
		file.close();
		if(found==true)
		{
			ui->errorLabel->hide();
			ui->errorBrowser->setText("");

			int idNo = saveIdx();
			std::ofstream fileO;
			fileO.open(idFile2.c_str(), std::ios::app);
			fileO << "*\nIndex\n*\n"<<idNo<<".1 "<<aa1<<"-"<<aa2<<"\t"<<resNO-1<<"-"<<resNO<<"\tstrd-strd\t1.000\n";
			for(int j=0; j<19; j++)
				fileO << "4XXX.X\n";
			fileO << "#\n# "<<temp_peaki1<<" "<<temp_peaki<<"\n#\n#\n#| CA |\t"<<ca1<<"\t"<<ca2<<"\n#| CB |\t"<<cb1<<"\t"<<cb2<<"\n#| CO |\t"<<co1<<"\t"<<co2<<"\n#\n";
			fileO.clear();
			fileO.close();
	
			qint32 posBar2= ui->fileBrowser->verticalScrollBar()->value();
			{
				createBak(1);
				readfile();
				CompassManualMode::rename(1); 
				CompassManualMode::ssp(); 
			}
			if(posBar2 >= 0)
				ui->fileBrowser->verticalScrollBar()->setValue(posBar2);
		}
		else
		{
			ui->errorLabel->show();
            ui->errorBrowser->setText("The specified spin system is invalid.");
		}
	}
	else
	{
		ui->errorLabel->show();
		ui->errorBrowser->setText("Cannot assign spin system to prolines.");
	}
}
void CompassManualMode::hideWarnings()
{
	readfile();
}
void CompassManualMode::warn()
{
	Warnings2 *winWarn2;
	winWarn2 =new Warnings2(this);
	winWarn2->show();
}
void CompassManualMode::warn2()
{
	extern QString profile;
    std::string cafile, cbcafile, cofile, csfile, cafile2, cbcafile2, cofile2, hsqcfile, compassfile, line2, seqfile, indexfile, indexfile2;
	std::ifstream file;
    std::string typeI1cs="";
	std::string line;
	file.open (profile.toStdString().c_str(), std::ios::in);
	getline(file, line);
	compassfile=line; 
	indexfile=line;
    csfile=line+"Analysis/csedit";
	indexfile+="Analysis/indice.idx";
	indexfile2=line;
	std::string manual = line;
	manual+= "Analysis/manualmode.bak";
	indexfile2+="Analysis/COMPASSresult_match";
	getline(file, line);
	cafile= line;
	getline(file, line);
	cbcafile= line;
	getline(file, line);
	cofile= line;
	getline(file, line);
	seqfile= line;
	getline(file, line);
	int first=atoi(line.c_str());
	getline(file, line);
	cafile2= line;
	getline(file, line);
	cbcafile2= line;
	getline(file, line);
	cofile2= line;
	getline(file, line);
	hsqcfile= line;
	file.clear();
	file.close();

	file.open(seqfile.c_str(), std::ios::in);
	getline(file, line);
	file.clear();
	file.close();
	std::istringstream iss(line);
	std::string sub;
	int resno=first;
	while(iss>>sub)
		resno++;
	
	std::string idxArr[2500];
	int ic=0;
	file.open(indexfile.c_str(), std::ios::in);
	while(file>>sub)
	{
		idxArr[ic]=sub;
		ic++;
	}
	file.clear();
	file.close();

	std::string fnameO=compassfile;
	fnameO+="Analysis/warnings.txt";
	std::ofstream fileO;
	fileO.open(fnameO.c_str(), std::ios::out);
	for(int resNo =first; resNo<resno; resNo++)
	{
	double cadev=0.00, cbdev=0.00, codev=0.00;
	std::string typeI="-", typeI1="-";
	for(int i=0; i<ic; i++)
	{
		bool done=false;
		std::string indexfile3=indexfile2;
		indexfile3+=idxArr[i].substr(0,1);
		if(idxArr[i].substr(0,1)=="4")
			indexfile3 = manual;
		std::string temp;
		file.open(indexfile3.c_str(), std::ios::in);
		while(file.good())
		{
			getline(file, line);
			std::istringstream iss2(line);
			iss2>>sub;
			temp=sub;
			if(sub==idxArr[i])
			{
				iss2>>sub;
				iss2>>sub;
				unsigned pos2 = sub.find("-");
				int number =atoi(sub.substr(0,pos2).c_str());
				int number2 =atoi(sub.substr(pos2+1).c_str());
				if(resNo>=number && resNo<=number2)
				{
					int loopno= (number2-number+1)+2*(number2-number+1-2);
					int loopno2=(resNo-number)*2;
					unsigned pos = temp.find(".");
					for(int j=atoi(temp.substr(pos+1).c_str()); j<22; j++)
						getline(file, line);
					std::istringstream iss3(line);
					if(resNo==number2)
					{
						for(int k=0; k<=loopno; k++)
							iss3 >> sub;
						typeI=sub;
					}
					else if(resNo==number)
					{
						iss3 >> sub; 
						iss3 >> sub;
						typeI1=sub;
					}
					else
					{
						iss3 >> sub;
						for(int k=0; k<loopno2; k++)
							iss3 >> sub;
						typeI=sub;
						iss3 >> sub;
						typeI1=sub;
					}
					done=true;
				}
			}
		}
		file.clear();
		file.close();
		if(typeI!="-" && typeI1!="-" && done==true)
			break;
	}
	std::string typeI1o="-";
	if(typeI!="-")
	{
		unsigned posT=typeI.find("N-");
		typeI=typeI.substr(0,posT);
	}
	if(typeI1!="-")
	{
        unsigned posC=typeI1.find_first_of("-");
        typeI1cs = typeI1.substr(0,posC-1);
		unsigned posT=typeI1.find("N-");
		unsigned posT2=typeI1.find("CA-");
		typeI1o=typeI1.substr(0,posT);
		if(typeI1.substr(0,3)!="xxx")
			typeI1=typeI1.substr(posT+2,posT2-posT-2);
		else 
			typeI1="xxx";
	}
	std::string ca="-", cb="-", co="-", ca1="-", cb1="-", co1="-";
	if(cafile!="EMPTY" && (typeI!="-" || typeI1!="-"))
	{
		file.open(cafile.c_str(), std::ios::in);
		getline(file, line);
		getline(file, line);
		while(file.good())
		{
			getline(file, line);
			std::istringstream iss4(line);
			iss4 >> sub;
			unsigned pos = sub.find("N-");
			if(typeI==sub.substr(0,pos) && sub.substr(pos,3)=="N-C" && sub.substr(pos+3,1)=="A")
			{
				iss4 >> sub;
				iss4 >> sub;
				ca=sub;
			}
			else if (typeI1==sub.substr(pos+2,typeI1.length()) && sub.substr(pos+2+typeI1.length(), 1)=="C")
			{
				iss4 >> sub;
				iss4 >> sub;
				ca1=sub;
			}
			if((ca!="-" && typeI1=="-") || (ca1!="-" && typeI=="-") || (ca!="-" && ca1!="-") )
				break;
		}
		file.clear();
		file.close();
	}
	if(cafile2!="EMPTY" && typeI1!="-")
	{
		file.open(cafile2.c_str(), std::ios::in);
		getline(file, line);
		getline(file, line);
		while(file.good())
		{
			bool done=false;
			getline(file, line);
			std::istringstream iss4(line);
			iss4 >> sub;
			unsigned pos = sub.find("N-");
			if (typeI1==sub.substr(pos+2,typeI1.length()) && sub.substr(pos+2+typeI1.length(), 1)=="C")
			{
				iss4 >> sub;
				iss4 >> sub;
				if(ca1!="-")
				{
					double doub =(atof(ca1.c_str())+atof(sub.c_str()))/2.0;
					cadev= abs((atof(ca1.c_str())-atof(sub.c_str()))/2.0);
					std::ostringstream oss;
					oss << doub;
					ca1=oss.str();
				}
				else
					ca1=sub;
				done=true;
			}
			if(done==true)
				break;
		}
		file.clear();
		file.close();
	}
	if(cbcafile!="EMPTY" && (typeI!="-" || typeI1!="-"))
	{
		file.open(cbcafile.c_str(), std::ios::in);
		getline(file, line);
		getline(file, line);
		bool isca=true;
		while(file.good())
		{
			getline(file, line);
			std::istringstream iss4(line);
			iss4 >> sub;
			unsigned pos = sub.find("N-");
            if(typeI==sub.substr(0,pos) && sub.substr(pos,3)=="N-C" && (sub.substr(pos+3,1)=="A" || sub.substr(pos+3,1)=="B"))
			{
				if(sub.substr(pos+2,2)=="CA")
					isca=true;
				else
					isca=false;
				iss4 >> sub;
				iss4 >> sub;
				if(isca==true && ca=="-")
					ca=sub;
				else if (isca==false)
					cb=sub;
			}
			else if (typeI1==sub.substr(pos+2,typeI1.length()) && sub.substr(pos+2+typeI1.length(), 1)=="C")
			{
				if(sub.substr(typeI1.length()+pos+2,2)=="CA")
					isca=true;
				else
					isca=false;
				iss4 >> sub;
				iss4 >> sub;
				if(isca==true && ca1=="-")
					ca1=sub;
				else if (isca==false)
					cb1=sub;
			}
			if((ca!="-" && cb!="-" && typeI1=="-") || (ca1!="-" && ca1!="-" && typeI=="-") || (ca!="-" && ca1!="-" && cb!="-" && cb1!="-") )
				break;
		}
		file.clear();

		file.close();
	}
	if(cbcafile2!="EMPTY" && typeI1!="-")
	{
		file.open(cbcafile2.c_str(), std::ios::in);
		getline(file, line);
		getline(file, line);
		bool isca=true;
		while(file.good())
		{
			getline(file, line);
			std::istringstream iss4(line);
			iss4 >> sub;
			bool done=false, done2=false;
			unsigned pos = sub.find("N-");
			if (typeI1==sub.substr(pos+2,typeI1.length()) && sub.substr(pos+2+typeI1.length(), 1)=="C")
			{
				if(sub.substr(typeI1.length()+pos+2,2)=="CA")
					isca=true;
				else
					isca=false;
				iss4 >> sub;
				iss4 >> sub;
				if(isca==true && ca1=="-")
				{
					ca1=sub;
					done=true;
				}
				else if (isca==false && cb1=="-")
				{
					cb1=sub;
					done2=true;
				}
				else if (isca==false && cb1!="-")
				{
					double doub =(atof(cb1.c_str())+atof(sub.c_str()))/2.0;
					cbdev= abs((atof(cb1.c_str())-atof(sub.c_str()))/2.0);
					std::ostringstream oss;
					oss << doub;
					cb1=sub;
					done2=true;
				}
			}
			if (done==true && done2==true)
				break;
		}
		file.clear();
		file.close();
	}
	if(cofile!="EMPTY" && (typeI!="-" || typeI1!="-"))
	{
		file.open(cofile.c_str(), std::ios::in);
		getline(file, line);
		getline(file, line);
		while(file.good())
		{
			getline(file, line);
			std::istringstream iss4(line);
			iss4 >> sub;
			unsigned pos = sub.find("N-");
			if(typeI==sub.substr(0,pos) && sub.substr(pos,3)=="N-C" && sub.substr(pos+3,1)=="O")
			{
				iss4 >> sub;
				iss4 >> sub;
				co=sub;
			}
			else if (typeI1==sub.substr(pos+2,typeI1.length()) && sub.substr(pos+2+typeI1.length(), 1)=="C")
			{
				iss4 >> sub;
				iss4 >> sub;
				co1=sub;
			}
			if((co!="-" && typeI1=="-") || (co1!="-" && typeI=="-") || (co!="-" && co1!="-") )
				break;
		}
		file.clear();
		file.close();
	}
	if(cofile2!="EMPTY" && typeI1!="-")
	{
		file.open(cofile2.c_str(), std::ios::in);
		getline(file, line);
		getline(file, line);
		while(file.good())
		{
			getline(file, line);
			std::istringstream iss4(line);
			iss4 >> sub;
			bool done =false;
			unsigned pos = sub.find("N-");
			if (typeI1==sub.substr(pos+2,typeI1.length()) && sub.substr(pos+2+typeI1.length(), 1)=="C")
			{
				iss4 >> sub;
				iss4 >> sub;
				if(co1!="-")
				{
					double doub =(atof(co1.c_str())+atof(sub.c_str()))/2.0;
					codev= abs((atof(co1.c_str())-atof(sub.c_str()))/2.0);
					std::ostringstream oss;
					oss << doub;
					co1=oss.str();
				}
				else
					co1=sub;
				done=true;
			}
			if(done==true)
				break;
		}
		file.clear();
		file.close();
	}
    std::ifstream fileCS;
    fileCS.open(csfile.c_str(), std::ios::in);
    while(getline(fileCS, line))
    {
        std::istringstream issCS(line);
        issCS>>sub;
        if(sub==typeI)
        {
            issCS>>sub;
            issCS>>sub;
            issCS>>sub;
            if(sub=="0")
                ca="-";
            else
                ca=sub;
            issCS>>sub;
            issCS>>sub;
            if(sub=="0")
                cb="-";
            else
                cb=sub;
            issCS>>sub;
            issCS>>sub;
            if(sub=="0")
                co="-";
            else
                co=sub;
        }
        else if(sub==typeI1cs)
        {
            issCS>>sub;
            issCS>>sub;
            issCS>>sub;
            issCS>>sub;
            if(sub=="0")
                ca1="-";
            else
                ca1=sub;
            issCS>>sub;
            issCS>>sub;
            if(sub=="0")
                cb1="-";
            else
                cb1=sub;
            issCS>>sub;
            issCS>>sub;
            if(sub=="0")
                co1="-";
            else
                co1=sub;
        }
    }
    fileCS.clear();
    fileCS.close();
	extern double warnCA;
	extern double warnCB;
	extern double warnCO;
	extern double warnDev;
	double CA, CB, CO, Dev;
	CA=warnCA;
	CB=warnCB;
	CO=warnCO;
	Dev=warnDev;

	if(cadev>=Dev || cbdev>=Dev || codev>=Dev || (ca!="-" && ca1!="-" && abs(atof(ca.c_str()) - atof(ca1.c_str()))>=CA) || (cb!="-" && cb1!="-" && abs(atof(cb.c_str()) - atof(cb1.c_str()))>=CB) || ( co!="-" && co1!="-" && abs(atof(co.c_str()) - atof(co1.c_str()))>=CO))
		fileO<<resNo<<" ";

	}
	fileO.clear();
	fileO.close();

	file.open(fnameO.c_str(), std::ios::in);
	std::string wArr[2000];
	int wArrC=0;
	while(file>>wArr[wArrC])
		wArrC++;
	file.clear();
	file.close();

	QTextCursor cursor = ui->seqBrowser->textCursor();
	QString fname;
	extern QString profile;
	std::string profileC, pname;
	profileC = profile.toStdString().c_str();
	std::ifstream fileC;
	
	fileC.open (profileC.c_str(), std::ios::in);
	getline(fileC, line);
	pname=line;
	pname+="Analysis/seqfile.seq";
	getline(fileC, line);
	getline(fileC, line);
	getline(fileC, line);
	getline(fileC, line);

	getline(fileC,line2);
	fileC.clear();
	fileC.close();
	
	int first2, wC;
	first= atoi(line2.c_str());
	first2=first;
	wC=first;
	
	fileC.open(line.c_str(), std::ios::in);
	getline(fileC, line);
	fileC.clear();
	fileC.close();
	std::stringstream issA(line);
	std::string seqArr[1500];
	QString lineout;
	int cs=0;
	int cf=0;
	do{
		issA >> sub;
		seqArr[cs]=sub;
		cs++;
	}while(issA);
	cs--;
	
	
	std::string merArr[3000][3];
	fileC.open(pname.c_str(), std::ios::in);
	int Arrc=0;
	while(fileC.good())
	{
		getline(fileC, line);
		std::stringstream iss2(line);
		iss2 >> sub;
		merArr[Arrc][0]=sub; 
		iss2 >> sub;
		merArr[Arrc][1]=sub; 
		Arrc++;
	}
	Arrc--;

	ui->seqBrowser->setText("");
	bool nowarn=true;

int noout=first;
	if(first%5!=0)
	{
		lineout="<FONT style=\"BACKGROUND-COLOR: #F2F2F2\">";
		lineout+=QString::number(first);
		lineout+="</FONT>";
		ui->seqBrowser->insertHtml(lineout);
		lineout="\n";
		cursor.movePosition(QTextCursor::End);
		ui->seqBrowser->setTextCursor(cursor);
		ui->seqBrowser->insertPlainText(lineout);
		while(first%5!=0)
		{
			cursor.movePosition(QTextCursor::End);
			ui->seqBrowser->setTextCursor(cursor);
			if(Arrc>0)
			{
				for(int c=0; c<Arrc;c++)
				{
					if(atoi(merArr[c][0].c_str())==first2)
					{ 
						nowarn=true;
						for(int w=0; w<wArrC; w++)
						{
							if(atoi(wArr[w].c_str())==wC)
							{
								lineout="<FONT style=\"BACKGROUND-COLOR: #FA5858\">";
								nowarn=false;
								break;
							}
						}
						if(nowarn==true)
						{
							if(merArr[c][1]=="m")
								lineout="<FONT style=\"BACKGROUND-COLOR: #81F781\">";
							else if(merArr[c][1]=="e")
								lineout="<FONT style=\"BACKGROUND-COLOR: #F3F781\">";
						}
						break;
					}
					else if(c==Arrc-1)
						lineout="<FONT style=\"BACKGROUND-COLOR: #F2F2F2\">";
				
				}
				lineout+="<a href=\"";
				std::stringstream ssO;
				ssO<<noout;
				std::string noout2 = ssO.str();
				lineout+=noout2.c_str();
				noout++;
				lineout+="\" style=\"color:#000000\" style=\"text-decoration:none;\">";
				lineout+= QString::fromUtf8(seqArr[cf].c_str());
				lineout+="</a>";

				lineout+= "</FONT>";
			}
			else
				lineout= QString::fromUtf8(seqArr[cf].c_str());
			ui->seqBrowser->insertHtml(lineout);
			ui->seqBrowser->insertPlainText(" ");
			first++;
			first2++;
			wC++;
			cf++;
		}
		cursor.movePosition(QTextCursor::End);
		ui->seqBrowser->setTextCursor(cursor);
		lineout="\n";
		ui->seqBrowser->insertPlainText(lineout);
	}
	
int check_times= cs-cf;
int temp_check = check_times;

while(temp_check%20!=0)
{
	temp_check--;
}
int times= temp_check/20;
int remain= check_times-temp_check;
	
	for(int i=0; i<times;i++)
	{
		for(int j=0; j<4; j++)
		{
			cursor.movePosition(QTextCursor::End);
			ui->seqBrowser->setTextCursor(cursor);
			lineout="<FONT style=\"BACKGROUND-COLOR: #F2F2F2\">";
			lineout+=QString::number(first);
			lineout+="</FONT>";
			ui->seqBrowser->insertHtml(lineout);
			first+=5;
			if(j!=3)
			{
				lineout="\t";
				cursor.movePosition(QTextCursor::End);
				ui->seqBrowser->setTextCursor(cursor);
				ui->seqBrowser->insertPlainText(lineout);
			}
			else
				lineout="\n";
				cursor.movePosition(QTextCursor::End);
				ui->seqBrowser->setTextCursor(cursor);
				ui->seqBrowser->insertPlainText(lineout);			
		}
		for(int j=1; j<21; j++)
		{
			cursor.movePosition(QTextCursor::End);
			ui->seqBrowser->setTextCursor(cursor);

			if(Arrc>0)
			{
				for(int c=0; c<Arrc;c++)
				{
					if(atoi(merArr[c][0].c_str())==first2)
					{ 
						nowarn=true;
						for(int w=0; w<wArrC; w++)
						{
							if(atoi(wArr[w].c_str())==wC)
							{
								lineout="<FONT style=\"BACKGROUND-COLOR: #FA5858\">";
								nowarn=false;
								break;
							}
						}
						if(nowarn==true)
						{
							if(merArr[c][1]=="m")
								lineout="<FONT style=\"BACKGROUND-COLOR: #81F781\">";
							else if(merArr[c][1]=="e")
								lineout="<FONT style=\"BACKGROUND-COLOR: #F3F781\">";
						}
						break;
						
					}
					else if(c==Arrc-1)
					{
						lineout="<FONT style=\"BACKGROUND-COLOR: #F2F2F2\">";
					}
				}
				lineout+="<a href=\"";
				std::stringstream ssO;
				ssO<<noout;
				std::string noout2 = ssO.str();
				lineout+=noout2.c_str();
				noout++;
				lineout+="\" style=\"color:#000000\" style=\"text-decoration:none;\">";
				lineout+= QString::fromUtf8(seqArr[cf].c_str());
				lineout+="</a>";

				lineout+= "</FONT>";
			}
			else
				lineout= QString::fromUtf8(seqArr[cf].c_str());
			cf++;
			ui->seqBrowser->insertHtml(lineout);	
			if(j%5==0 && j!=20)
				lineout="\t";
			else
				lineout=" ";
			cursor.movePosition(QTextCursor::End);
			ui->seqBrowser->setTextCursor(cursor);		
			ui->seqBrowser->insertPlainText(lineout);	
			first2++;
			wC++;
		}
		lineout="\n";
		cursor.movePosition(QTextCursor::End);
		ui->seqBrowser->setTextCursor(cursor);
		ui->seqBrowser->insertPlainText(lineout);
	}
int remain_check=remain;
	if(remain_check%5==0)
	{
		remain_check=remain_check/5-1;
	}
	else{
		while(remain_check%5!=0)
			remain_check--;
		remain_check=remain_check/5;
	}
	for(int i=0; i<remain_check+1; i++)
	{
		cursor.movePosition(QTextCursor::End);
		ui->seqBrowser->setTextCursor(cursor);
			lineout="<FONT style=\"BACKGROUND-COLOR: #F2F2F2\">";
			lineout+=QString::number(first);
			lineout+="</FONT>";
			ui->seqBrowser->insertHtml(lineout);
		lineout="\t\t";
		ui->seqBrowser->insertPlainText(lineout);
		first+=5;
	}
	cursor.movePosition(QTextCursor::End);
	ui->seqBrowser->setTextCursor(cursor);
	lineout="\n";
	ui->seqBrowser->insertPlainText(lineout);
	
	for(int i=1; i<=remain; i++)
	{
		cursor.movePosition(QTextCursor::End);
		ui->seqBrowser->setTextCursor(cursor);
			if(Arrc>0)
			{
				for(int c=0; c<Arrc;c++)
				{
					if(atoi(merArr[c][0].c_str())==first2)
					{ 
						nowarn=true;
						for(int w=0; w<wArrC; w++)
						{
							if(atoi(wArr[w].c_str())==wC)
							{
								lineout="<FONT style=\"BACKGROUND-COLOR: #FA5858\">";
								nowarn=false;
								break;
							}
						}
						if(nowarn==true)
						{
							if(merArr[c][1]=="m")
								lineout="<FONT style=\"BACKGROUND-COLOR: #81F781\">";
							else if(merArr[c][1]=="e")
								lineout="<FONT style=\"BACKGROUND-COLOR: #F3F781\">";
						}
						
						break;
					}
					else if(c==Arrc-1)
						lineout="<FONT style=\"BACKGROUND-COLOR: #F2F2F2\">";
				}
				lineout+="<a href=\"";
				std::stringstream ssO;
				ssO<<noout;
				std::string noout2 = ssO.str();
				lineout+=noout2.c_str();
				noout++;
				lineout+="\" style=\"color:#000000\" style=\"text-decoration:none;\">";
				lineout+= QString::fromUtf8(seqArr[cf].c_str());
				lineout+="</a>";

				lineout+= "</FONT>";
			}
			else
				lineout= QString::fromUtf8(seqArr[cf].c_str());
			cf++;
			ui->seqBrowser->insertHtml(lineout);	
		if(i%5==0)
			lineout="\t";
		else
			lineout=" ";			
		ui->seqBrowser->insertPlainText(lineout);	
		first2++;	
		wC++;
	}
}
void CompassManualMode::displayHelp()
{
    CompassHelp4 winHelp4;
    winHelp4.setWindowModality(Qt::ApplicationModal);
    if(winHelp4.exec())
        return;
}

void CompassManualMode::readfile()
{
	QString fname;
	extern QString profile;
	std::string profileC, line, line2, lineDir;
	profileC = profile.toStdString().c_str();
	std::ifstream fileC;
	fileC.open (profileC.c_str(), std::ios::in);
	getline(fileC, line);
	
	line2+= line;
	std::string fnam=line2;
	fnam+="Analysis/statistics.txt";
	lineDir=line2;
	fname = "Analysis/compass_result";
	fname+= "2";
	fname += "_match";
    fname+= "1";
	fname += "_sort";
	fname += "CHI";
	fname+="_html";
	fname+= ".bak";
	line2 += fname.toStdString().c_str();

    ui->fileBrowser->setFont (QFont ("Consolas", 8)); //Windows Version
    ui->seqBrowser->setFont (QFont ("Consolas", 9)); //Windows Version
    ui->csBrowser->setFont (QFont ("Consolas", 9)); //Windows Version
    ui->statBrowser->setFont (QFont ("Consolas", 9)); //Windows Version
	
	fname = QString::fromUtf8(line2.c_str()); 
	QFile resfile(fname);
	resfile.open(QFile::ReadOnly | QFile::Text);
	QTextStream ReadFile(&resfile);
	ui->fileBrowser->setText("");
	ui->fileBrowser->insertHtml(ReadFile.readAll());
	resfile.close();
	fname= QString::fromUtf8(lineDir.c_str());
	fname+="Analysis/indice.idx";
	std::ifstream fileI;
	fileI.open(fname.toStdString().c_str(), std::ios::in);	
	std::string lineI;
	QString qlineI;
	qlineI = "";
	while (fileI.good())
	{
		getline (fileI, lineI);
		qlineI += QString::fromUtf8(lineI.c_str());
	}
	ui->indexBrowser->setText(qlineI);
	fileI.clear();
	fileI.close();
	
	getline(fileC, line);
	getline(fileC, line);
	getline(fileC, line);
	getline(fileC, line);
	fileC.clear();
	fileC.close();
	fileC.open(line.c_str(), std::ios::in);
	std::string subS="";
	int resSeq=0, noPro=0;
	while(fileC>>subS)
	{
		if(subS=="PRO")
			noPro++;
		resSeq++;	
	}
	fileC.clear();
	fileC.close();
	readfile_seq(fnam, resSeq, noPro);
	stat(fnam);
}
void CompassManualMode::readfile_seq(std::string fnam, int resSeq, int noPro)
{
	qint32 posBar = ui->seqBrowser->verticalScrollBar()->value();
	qint32 posBar2= ui->fileBrowser->verticalScrollBar()->value();

	QTextCursor cursor = ui->seqBrowser->textCursor();
	QString fname;
	extern QString profile;
	std::string profileC, line, line2, pname;
	profileC = profile.toStdString().c_str();
	std::ifstream fileC;
	
	fileC.open (profileC.c_str(), std::ios::in);
	getline(fileC, line);
	pname=line;
	pname+="Analysis/seqfile.seq";
	getline(fileC, line);
	getline(fileC, line);
	getline(fileC, line);
	getline(fileC, line);

	getline(fileC,line2);
	fileC.clear();
	fileC.close();
	
	int first, first2;
	first= atoi(line2.c_str());
	first2=first;
	fileC.open(line.c_str(), std::ios::in);
	getline(fileC, line);
	fileC.clear();
	fileC.close();
	std::stringstream iss(line);
	std::string sub;
	std::string seqArr[1500];
	QString lineout;
	int cs=0;
	int cf=0;
	do{
		iss >> sub;
		seqArr[cs]=sub;
		cs++;
	}while(iss);
	cs--;
	
	
	std::string merArr[3000][3];
	fileC.open(pname.c_str(), std::ios::in);
	int Arrc=0;
	while(fileC.good())
	{
		getline(fileC, line);
		std::stringstream iss2(line);
		iss2 >> sub;
		merArr[Arrc][0]=sub; 
		iss2 >> sub;
		merArr[Arrc][1]=sub; 
		Arrc++;
	}
	Arrc--;

	std::ofstream ofile;
	ofile.open(fnam.c_str(), std::ios::out);
	int noAss=0, noAsstemp=0;
	double perAss=0.;
	for(int q=0; q<Arrc; q++)
	{
		if(merArr[q][1]=="m")
			noAsstemp++;
		else if(merArr[q][1]=="e")
		{
			for(int qq=0; qq<Arrc; qq++)
			{
				if((atoi(merArr[q][0].c_str())-1==atoi(merArr[qq][0].c_str()) && merArr[qq][1]=="m"))
				{
					noAss++;
					break;
				}
				else if((atoi(merArr[q][0].c_str())-1==atoi(merArr[qq][0].c_str()) && merArr[qq][1]=="e"))
				{
					for(int qqq=0; qqq<Arrc; qqq++)
					{
						if(atoi(merArr[q][0].c_str())-2==atoi(merArr[qqq][0].c_str()) && merArr[qqq][1]=="m")
							break;
						else if(atoi(merArr[q][0].c_str())-2==atoi(merArr[qqq][0].c_str()) && merArr[qqq][1]=="e")
						{
							for(int qqqq=0; qqqq<Arrc; qqqq++)
							{
								if(atoi(merArr[q][0].c_str())+1==atoi(merArr[qqqq][0].c_str()) && merArr[qqqq][1]=="m")
									break;
								else if(atoi(merArr[q][0].c_str())+1==atoi(merArr[qqqq][0].c_str()) && merArr[qqqq][1]=="e")
								{
									noAss++;
									break;
								}
								else if (qqqq==Arrc-1)
									noAss++;
							}
							break;
						}
						else if(qqq==Arrc-1)
							noAss++;
					}
				}

			}
		}
	}

    noAss+=noAsstemp/2;
    perAss=(double)noAss/(double)resSeq;
    ofile << 100*std::floor(perAss*10000 + 0.5)/10000;
    ofile << "\% assigned.\n";
    ofile << noAss;
    ofile << "/";
    ofile << resSeq;
    ofile<<" residues assigned.\nNumber of prolines: ";
    ofile << noPro;
    ofile << " (";
    ofile << 100*std::floor((double)noPro/(double)resSeq*10000 + 0.5)/10000;
    ofile << "\%)";

	ofile.clear();
	ofile.close();
	
	ui->seqBrowser->setText("");

int noout=first;
	if(first%5!=0)
	{
		lineout="<FONT style=\"BACKGROUND-COLOR: #F2F2F2\">";
		lineout+=QString::number(first);
		lineout+="</FONT>";
		ui->seqBrowser->insertHtml(lineout);
		lineout="\n";
		cursor.movePosition(QTextCursor::End);
		ui->seqBrowser->setTextCursor(cursor);
		ui->seqBrowser->insertPlainText(lineout);
		while(first%5!=0)
		{
			cursor.movePosition(QTextCursor::End);
			ui->seqBrowser->setTextCursor(cursor);
			if(Arrc>0)
			{
				for(int c=0; c<Arrc;c++)
				{
					if(atoi(merArr[c][0].c_str())==first2)
					{ 
						if(merArr[c][1]=="m")
							lineout="<FONT style=\"BACKGROUND-COLOR: #81F781\">";
						else if(merArr[c][1]=="e")
							lineout="<FONT style=\"BACKGROUND-COLOR: #F3F781\">";
						break;
					}
					else if(c==Arrc-1)
						lineout="<FONT style=\"BACKGROUND-COLOR: #F2F2F2\">";
				
				}
				lineout+="<a href=\"";
				std::stringstream ssO;
				ssO<<noout;
				std::string noout2 = ssO.str();
				lineout+=noout2.c_str();
				noout++;
				lineout+="\" style=\"color:#000000\" style=\"text-decoration:none;\">";
				lineout+= QString::fromUtf8(seqArr[cf].c_str());
				lineout+="</a>";

				lineout+= "</FONT>";
			}
			else
				lineout= QString::fromUtf8(seqArr[cf].c_str());
			ui->seqBrowser->insertHtml(lineout);
			ui->seqBrowser->insertPlainText(" ");
			
			first++;
			first2++;
			cf++;
		}
		cursor.movePosition(QTextCursor::End);
		ui->seqBrowser->setTextCursor(cursor);
		lineout="\n";
		ui->seqBrowser->insertPlainText(lineout);
	}
	
int check_times= cs-cf;
int temp_check = check_times;

while(temp_check%20!=0)
{
	temp_check--;
}
int times= temp_check/20;
int remain= check_times-temp_check;
	
	for(int i=0; i<times;i++)
	{
		for(int j=0; j<4; j++)
		{
			cursor.movePosition(QTextCursor::End);
			ui->seqBrowser->setTextCursor(cursor);
			lineout="<FONT style=\"BACKGROUND-COLOR: #F2F2F2\">";
			lineout+=QString::number(first);
			lineout+="</FONT>";
			ui->seqBrowser->insertHtml(lineout);
			first+=5;
			if(j!=3)
			{
				lineout="\t";
				cursor.movePosition(QTextCursor::End);
				ui->seqBrowser->setTextCursor(cursor);
				ui->seqBrowser->insertPlainText(lineout);
			}
			else
				lineout="\n";
				cursor.movePosition(QTextCursor::End);
				ui->seqBrowser->setTextCursor(cursor);
				ui->seqBrowser->insertPlainText(lineout);			
		}
		for(int j=1; j<21; j++)
		{
			cursor.movePosition(QTextCursor::End);
			ui->seqBrowser->setTextCursor(cursor);

			if(Arrc>0)
			{
				for(int c=0; c<Arrc;c++)
				{
					if(atoi(merArr[c][0].c_str())==first2)
					{ 
						if(merArr[c][1]=="m")
							lineout="<FONT style=\"BACKGROUND-COLOR: #81F781\">";
						else if(merArr[c][1]=="e")
							lineout="<FONT style=\"BACKGROUND-COLOR: #F3F781\">";
						break;
					}
					else if(c==Arrc-1)
					{
						lineout="<FONT style=\"BACKGROUND-COLOR: #F2F2F2\">";
					}
				}
				lineout+="<a href=\"";
				std::stringstream ssO;
				ssO<<noout;
				std::string noout2 = ssO.str();
				lineout+=noout2.c_str();
				noout++;
				lineout+="\" style=\"color:#000000\" style=\"text-decoration:none;\">";
				lineout+= QString::fromUtf8(seqArr[cf].c_str());
				lineout+="</a>";

				lineout+= "</FONT>";
			}
			else
				lineout= QString::fromUtf8(seqArr[cf].c_str());
			cf++;
			ui->seqBrowser->insertHtml(lineout);	
			if(j%5==0 && j!=20)
				lineout="\t";
			else
				lineout=" ";
			cursor.movePosition(QTextCursor::End);
			ui->seqBrowser->setTextCursor(cursor);		
			ui->seqBrowser->insertPlainText(lineout);	
			first2++;
		}
		lineout="\n";
		cursor.movePosition(QTextCursor::End);
		ui->seqBrowser->setTextCursor(cursor);
		ui->seqBrowser->insertPlainText(lineout);
	}
int remain_check=remain;
	if(remain_check%5==0)
	{
		remain_check=remain_check/5-1;
	}
	else{
		while(remain_check%5!=0)
			remain_check--;
		remain_check=remain_check/5;
	}
	for(int i=0; i<remain_check+1; i++)
	{
		cursor.movePosition(QTextCursor::End);
		ui->seqBrowser->setTextCursor(cursor);
			lineout="<FONT style=\"BACKGROUND-COLOR: #F2F2F2\">";
			lineout+=QString::number(first);
			lineout+="</FONT>";
			ui->seqBrowser->insertHtml(lineout);
		lineout="\t\t";
		ui->seqBrowser->insertPlainText(lineout);
		first+=5;
	}
	cursor.movePosition(QTextCursor::End);
	ui->seqBrowser->setTextCursor(cursor);
	lineout="\n";
	ui->seqBrowser->insertPlainText(lineout);
	
	for(int i=1; i<=remain; i++)
	{
		cursor.movePosition(QTextCursor::End);
		ui->seqBrowser->setTextCursor(cursor);
			if(Arrc>0)
			{
				for(int c=0; c<Arrc;c++)
				{
					if(atoi(merArr[c][0].c_str())==first2)
					{ 
						if(merArr[c][1]=="m")
							lineout="<FONT style=\"BACKGROUND-COLOR: #81F781\">";
						else if(merArr[c][1]=="e")
							lineout="<FONT style=\"BACKGROUND-COLOR: #F3F781\">";
						break;
					}
					else if(c==Arrc-1)
						lineout="<FONT style=\"BACKGROUND-COLOR: #F2F2F2\">";
				}
				lineout+="<a href=\"";
				std::stringstream ssO;
				ssO<<noout;
				std::string noout2 = ssO.str();
				lineout+=noout2.c_str();
				noout++;
				lineout+="\" style=\"color:#000000\" style=\"text-decoration:none;\">";
				lineout+= QString::fromUtf8(seqArr[cf].c_str());
				lineout+="</a>";

				lineout+= "</FONT>";
			}
			else
				lineout= QString::fromUtf8(seqArr[cf].c_str());
			cf++;
			ui->seqBrowser->insertHtml(lineout);	
		if(i%5==0)
			lineout="\t";
		else
			lineout=" ";			
		ui->seqBrowser->insertPlainText(lineout);	
		first2++;	
	}
	if(posBar >= 0)
		ui->seqBrowser->verticalScrollBar()->setValue(posBar);
	if(posBar2 >= 0)
		ui->fileBrowser->verticalScrollBar()->setValue(posBar2);
}
void CompassManualMode::createBak(int bakI)
{
	bool mismatch =false;
	std::ifstream fileN;
	std::ofstream fileHtml;
	std::string line, line2, matchno, lineF;
	extern QString profile;
	fileN.open(profile.toStdString().c_str(), std::ios::in);
	getline(fileN, line);
	getline(fileN, lineF);
	getline(fileN, lineF);
	getline(fileN, lineF);
	getline(fileN, lineF);
	std::string seqF = lineF;
	getline(fileN, lineF);
	int first = atoi(lineF.c_str());
	fileN.clear();
	fileN.close();

	fileN.open(seqF.c_str(), std::ios::in);
	getline(fileN, lineF);
	std::istringstream issF(lineF);
	std::string subF;
	int lC=0;
	while(issF>>subF)
		lC++;
	int last = first + lC -1;
	fileN.clear();
	fileN.close();
	
	std::string file=line;
	std::string dir2 =line;
	std::string htmlfile=line+"Analysis/htmlindex.idx";
	file+="Analysis/indice.idx";
	std::ifstream fileI;
	fileI.open(file.c_str(), std::ios::in);
	std::string lineI, Iline;
	while (fileI.good())
	{
		getline (fileI, lineI);
		Iline += lineI;
		Iline += " ";
	}
	fileI.clear();
	fileI.close();
	
	std::string sub;
	std::istringstream iss(Iline);
	int subC = 0;
	std::string idxArr[1000];
	std::string storeArr[1000][3]; 
	std::string peakArr[1000][21]; 
	std::string endArr[2000][4]; 
	std::string midArr[2000][4]; 
	for (int i=0; i<1000;i++)
	{	
		idxArr[i]="EMPTY";
		for(int k=0; k<3; k++)
			storeArr[i][k]="EMPTY";
		for(int j=0; j<18; j++)
			peakArr[i][j]="EMPTY";
	}
	for (int i=0; i<2000; i++)
	{
		endArr[i][1]="EMPTY";
		midArr[i][1]="EMPTY";
		endArr[i][0]="EMPTY";
		midArr[i][0]="EMPTY";
		midArr[i][2]="EMPTY";
		midArr[i][3]="EMPTY";
		endArr[i][2]="EMPTY";
		endArr[i][3]="EMPTY";
	}

	do
	{
		iss >> sub;
		idxArr[subC]=sub;
		subC++;
	} while (iss);
	idxArr[subC-1]="EMPTY";
	subC--;
	std::string same1, same2;
	bool sameIdx = false;
	for(int i=0; i<subC; i++)
	{
		for(int j=i+1; j<subC;j++)
		{
			std::string t1, t2;
			unsigned posi = idxArr[i].find(".");
			unsigned posj = idxArr[j].find(".");
			t1=idxArr[i].substr(0,posi);
			t2=idxArr[j].substr(0,posj);
			if (t1==t2)
			{
				sameIdx = true;
				same1 = idxArr[i];
				same2 = idxArr[j];
				break;
			}
		}
		if (sameIdx==true)
			break;
	}

	std::string lo;
	fileHtml.open(htmlfile.c_str(), std::ios::out);
	if (sameIdx==false)
	{
		std::ifstream fileC;
		std::string sub2, line3;
		int si=0;
		int ci=0;
		for (int i=0; i<subC; i++)
		{
			line2= line;
			line2+= "Analysis/COMPASSresult_match";
			unsigned pos = idxArr[i].find(".");
			sub2 = idxArr[i].substr(0,pos);
			std::string subtemp;
			int getthis = 0;
			if(atoi(sub2.c_str())>=2000 && atoi(sub2.c_str())<3000)
				line2+="2";
			else if (atoi(sub2.c_str())>=3000 && atoi(sub2.c_str()) < 4000)
				line2+="3";		
			else if (atoi(sub2.c_str())>=4000)
			{
				line2=line + "Analysis/manualmode.bak";
			}
			else
				line2+="1";
			fileC.open(line2.c_str(), std::ios::in);
			bool foundIdx =false;
			while(fileC.good())
			{
				getline(fileC, line3);
				if(i==subC-1)
					lo = line3;
				std::istringstream iss2(line3);
				iss2 >> sub2;
				if(sub2==idxArr[i])
				{
					if(i==subC-1 && bakI==1)
					{
						std::istringstream isso(lo);
						std::string subo;
						isso >> subo;
						isso >> subo;
						isso >> subo;
						QString qlo = "Residues ";
						qlo += QString::fromUtf8(subo.c_str());
						qlo += " were assigned.";
						ui->errorBrowser->setText(qlo);
					}
					foundIdx =true;
					unsigned pos2 = sub2.find(".");
					subtemp = sub2.substr(pos2+1,2);
					if(subtemp=="1")
						getthis = 21;
					else if (subtemp=="2")
						getthis = 20;
					else if (subtemp=="3")
						getthis = 19;
					else if (subtemp=="4")
						getthis = 18;
					else if (subtemp=="5")
						getthis = 17;
					else if (subtemp=="6")
						getthis =16;
					else if (subtemp=="7")
						getthis = 15;
					else if (subtemp=="8")
						getthis = 14;
					else if (subtemp=="9")
						getthis = 13;
					else if (subtemp=="10")
						getthis = 12;
					else if (subtemp=="11")
						getthis = 11;
					else if (subtemp=="12")
						getthis = 10;
					else if (subtemp=="13")
						getthis = 9;
					else if (subtemp=="14")
						getthis = 8;
					else if (subtemp=="15")
						getthis = 7;
					else if (subtemp=="16")
						getthis = 6;
					else if (subtemp=="17")
						getthis = 5;
					else if (subtemp=="18")
						getthis = 4;
					else if (subtemp=="19")
						getthis = 3;
					else if (subtemp=="20")
						getthis = 2;

					storeArr[ci][0] = sub2;
					iss2 >>sub2;
					iss2 >>sub2;
					storeArr[ci][1] = sub2;
					
					for(int j=0;j<getthis;j++)
					{
						getline(fileC, line3);
					}
					storeArr[ci][2] = line3;
					ci++;
				}
			}
			if (foundIdx==false)
				si++;

			fileC.clear();
			fileC.close();
		}
		subC=ci;
		int emptyC=0;
		for(int t=0; t<subC; t++)
		{
			for(int u=t+1; u<subC; u++)
				if(storeArr[t][2]==storeArr[u][2] && storeArr[t][2]!="EMPTY")
				{
					storeArr[u][0]="EMPTY";
					storeArr[u][1]="EMPTY";
					storeArr[u][2]="EMPTY";
					emptyC++;
				}
		}
		for(int t=0; t<subC; t++)
		{
			for(int u=t+1; u<subC; u++)
				if(storeArr[t][2]=="EMPTY" && storeArr[u][2]!="EMPTY")
				{
					storeArr[t][0]=storeArr[u][0];
					storeArr[t][1]=storeArr[u][1];
					storeArr[t][2]=storeArr[u][2];
					storeArr[u][0]="EMPTY";
					storeArr[u][1]="EMPTY";
					storeArr[u][2]="EMPTY";
				}
		}
		subC-=emptyC;


		for (int j=0; j<subC; j++)
		{
			int count=0;
			std::string sub3, line4;
			line4 = storeArr[j][2];
			std::istringstream iss3(line4);
			iss3 >> sub3;
			do
			{
				iss3 >> sub3;
				peakArr[j][count]=sub3;
				count++;
			}while (iss3);
			peakArr[j][19] = storeArr[j][1];
			peakArr[j][20] = storeArr[j][0];
		}
		
		int countEnd=0;
		int countMid=0;
		int resno;
		
		for (int l=0; l<subC; l++)
		{
			endArr[countEnd][0]=peakArr[l][0];
			unsigned posr = peakArr[l][19].find("-");
			endArr[countEnd][1]=peakArr[l][19].substr(0,posr);
			endArr[countEnd][2]=peakArr[l][20];
			endArr[countEnd][3]="1";
			resno = atoi(peakArr[l][19].substr(0,posr).c_str());
			resno++;
			countEnd++;
			for (int k=1; k<19;k++)
			{
				if(peakArr[l][k+1]!="EMPTY" && k<18)
				{
					midArr[countMid][0]=peakArr[l][k];
					std::stringstream ss;
					ss << resno;
					midArr[countMid][1]=ss.str();
					midArr[countMid][2]=peakArr[l][20];
					if(k%2==0)
						midArr[countMid][3]="1";
					else
						midArr[countMid][3]="2";
					countMid++;
					if (k%2==0)
						resno++;
				}
				else
				{
					countMid--;
					endArr[countEnd][0]=midArr[countMid][0];
					endArr[countEnd][1]=midArr[countMid][1];
					endArr[countEnd][2]=midArr[countMid][2];
					endArr[countEnd][3]=midArr[countMid][3];


					countEnd++;
					midArr[countMid][0]="EMPTY";
					midArr[countMid][1]="EMPTY";
					midArr[countMid][2]="EMPTY";
					midArr[countMid][3]="EMPTY";

					break;
				}
			}
		}
		mismatch = false;
		for (int l=0; l<countEnd; l++)
			for (int k=l+1; k<countEnd; k++)
			{
				if(endArr[l][0]==endArr[k][0] && endArr[l][1]==endArr[k][1] && endArr[l][3]==endArr[k][3] && l!=k)
				{
					endArr[k][0] = "EMPTY";
					endArr[k][1] = "EMPTY";	
					endArr[k][2] = "EMPTY";
					endArr[k][3] = "EMPTY";
				}
				else if (endArr[l][0]==endArr[k][0] && endArr[l][1]!=endArr[k][1] && l!=k)
				{
					mismatch = true;
					same1 = endArr[l][2];
					same2 = endArr[k][2];
				}
				else if(endArr[l][0]!=endArr[k][0] && endArr[l][1]==endArr[k][1] && endArr[l][3]==endArr[k][3] && l!=k)
				{
					mismatch = true;
					same1 = endArr[l][2];
					same2 = endArr[k][2];
				}
			}
			
				
		for (int l=0; l<countEnd; l++)
			for (int k=1; k<countMid; k++)
				if(endArr[l][0]!=midArr[k][0] && endArr[l][1]==midArr[k][1] && endArr[l][3]==midArr[k][3] && l!=k)
				{
					mismatch = true;
					same1 = endArr[l][2];
					same2 = endArr[k][2];
				}
		
		for (int l=0; l<countEnd; l++)	
			for (int k=l+1; k<countEnd; k++)
			{
				if(endArr[l][0]=="EMPTY" && endArr[k][0]!="EMPTY" && l!=k)
				{
					endArr[l][0]=endArr[k][0];
					endArr[l][1]=endArr[k][1];
					endArr[l][2]=endArr[k][2];
					endArr[l][3]=endArr[k][3];
					endArr[k][0]="EMPTY";
					endArr[k][1]="EMPTY";
					endArr[k][2]="EMPTY";
					endArr[k][3]="EMPTY";
					break;
				}
			}
		
		for (int l=0; l<countMid; l++)
			for (int k=l+1; k<countMid; k++)
			{
				if(midArr[l][0]==midArr[k][0] && midArr[l][1]==midArr[k][1] && midArr[l][3]==midArr[k][3] && l!=k)
				{
					midArr[k][0] = "EMPTY";
					midArr[k][1] = "EMPTY";
					midArr[k][2] = "EMPTY";
					midArr[k][3] = "EMPTY";
				}
				else if (midArr[l][0]==midArr[k][0] && midArr[l][1]!=midArr[k][1] && l!=k)
				{
					mismatch = true;
					same1 = midArr[l][2];
					same2 = midArr[k][2];
				}
			}
		
		for (int l=0; l<countMid; l++)
			for (int k=l+1; k<countMid; k++)
			{
				if (midArr[l][0]!=midArr[k][0] && midArr[l][1]==midArr[k][1] && midArr[l][3]==midArr[k][3] && l!=k)
				{
					mismatch = true;
					same1 = midArr[l][2];
					same2 = midArr[k][2];
				}
			}

		
		for (int l=0; l<countMid; l++)	
			for (int k=l+1; k<countMid; k++)
			{
				if(midArr[l][0]=="EMPTY" && midArr[k][0]!="EMPTY" && l!=k)
				{
					midArr[l][0]=midArr[k][0];
					midArr[l][1]=midArr[k][1];
					midArr[l][2]=midArr[k][2];
					midArr[l][3]=midArr[k][3];
					midArr[k][0]="EMPTY";
					midArr[k][1]="EMPTY";
					midArr[k][2]="EMPTY";
					midArr[k][3]="EMPTY";
					break;
				}
			}
		if(mismatch==false)
		{
			for (int l=0; l<countEnd; l++)
			{
				{
					for (int k=0; k<countMid; k++)
					{
						if (endArr[l][0]==midArr[k][0] && endArr[l][1]==midArr[k][1] )
						{
							endArr[l][0]="EMPTY";
							endArr[l][1]="EMPTY";
							endArr[l][2]="EMPTY";
							endArr[l][3]="EMPTY";
							break;
						}
						else if (endArr[l][0]==midArr[k][0] && endArr[l][1]!=midArr[k][1] )
						{
							mismatch =true;
							same1 = endArr[l][2];
							same2 = midArr[k][2];
							break;
						}
					}
				}		
			}
			if(mismatch==false)
			{
				for (int l=0; l<countEnd; l++)	
					for (int k=l+1; k<countEnd; k++)
						if(endArr[l][0]=="EMPTY" && endArr[k][0]!="EMPTY" && l!=k)
						{
							endArr[l][0]=endArr[k][0];
							endArr[l][1]=endArr[k][1];
							endArr[l][2]=endArr[k][2];
							endArr[l][3]=endArr[k][3];
							endArr[k][0]="EMPTY";
							endArr[k][1]="EMPTY";
							endArr[k][2]="EMPTY";
							endArr[k][3]="EMPTY";
							break;
						}
		
			for(int hh=0;hh<countMid;hh++)
				if(midArr[hh][0]=="EMPTY")
				{
					countMid=hh;
					break;
				}
			for(int hh=0;hh<countEnd;hh++)
				if(endArr[hh][0]=="EMPTY")
				{
					countEnd=hh;
					break;
				}
				for(int l=0; l<countEnd; l++)
					for (int k=0; k<countMid; k++)
					{
						if (endArr[l][0]!=midArr[k][0] && endArr[l][1]==midArr[k][1] && endArr[l][3]==midArr[k][3])
						{
							mismatch =true;
							same1 = endArr[l][2];
							same2 = midArr[k][2];
							break;
						}
					}





		if(mismatch==false)
		{
			for(int u=0; u<countEnd; u++)
			{
				for(int v=u+1;v<countEnd; v++)
				{
					if(v!=u && endArr[u][1]==endArr[v][1] && endArr[u][1]!="EMPTY" && endArr[u][3]!=endArr[v][3])
					{
						midArr[countMid][0]=endArr[u][0];
						midArr[countMid][1]=endArr[u][1];
						midArr[countMid][2]=endArr[u][2];
						midArr[countMid][3]=endArr[u][3];
						countMid++;
						midArr[countMid][0]=endArr[v][0];
						midArr[countMid][1]=endArr[v][1];
						midArr[countMid][2]=endArr[v][2];
						midArr[countMid][3]=endArr[v][3];
						countMid++;
						endArr[u][0]="EMPTY";
						endArr[u][1]="EMPTY";
						endArr[u][2]="EMPTY";
						endArr[u][3]="EMPTY";

						endArr[v][0]="EMPTY";
						endArr[v][1]="EMPTY";
						endArr[v][2]="EMPTY";
						endArr[v][3]="EMPTY";
					}				
				}
			}
		}
			
			if(mismatch==false)
			{
				for (int l=0; l<countEnd; l++)	
					for (int k=l+1; k<countEnd; k++)
						if(endArr[l][0]=="EMPTY" && endArr[k][0]!="EMPTY" && l!=k)
						{
							endArr[l][0]=endArr[k][0];
							endArr[l][1]=endArr[k][1];
							endArr[l][2]=endArr[k][2];
							endArr[l][3]=endArr[k][3];
							endArr[k][0]="EMPTY";
							endArr[k][1]="EMPTY";
							endArr[k][2]="EMPTY";
							endArr[k][3]="EMPTY";
							break;
						}

			}
			if(mismatch==false)
			{
				for (int l=0; l<countEnd; l++)	
				{
					for (int k=l+1; k<countEnd; k++)
					{
						if(endArr[l][1]==endArr[k][1] && endArr[l][3]==endArr[k][3] && (endArr[l][0]!=endArr[k][0]))
							mismatch=true;
					}
					for (int k=0; k<countMid; k++)
					{
						if(endArr[l][1]==midArr[k][1] && endArr[l][3]==midArr[k][3] && (endArr[l][0]!=midArr[k][0]))
							mismatch=true;
					}
				for (int l=0; l<countMid; l++)	
				{
					for (int k=l+1; k<countEnd; k++)
					{
						if(midArr[l][1]==endArr[k][1] && midArr[l][3]==endArr[k][3] && (midArr[l][0]!=endArr[k][0]))
							mismatch=true;
					}
					for (int k=0; k<countMid; k++)
					{
						if(midArr[l][1]==midArr[k][1] && midArr[l][3]==midArr[k][3] && (midArr[l][0]!=midArr[k][0]))
							mismatch=true;
					}
				}			
				}
			}
			if(mismatch==false)
			{
			for(int hh=0;hh<countEnd;hh++)
				if(endArr[hh][0]=="EMPTY")
				{
					countEnd=hh;
					break;
				}
				std::ifstream resultfile2, resultfile3, resultfile4, resultfile5, resultfile6,resultfile7,resultfile8,resultfile9,resultfile10;
					std::ofstream resultfile2b, resultfile3b, resultfile4b, resultfile5b, resultfile6b,resultfile7b,resultfile8b,resultfile9b,resultfile10b;
					std::string filen2, filen3, filen4, filen5, filen6, filen7, filen8, filen9, filen10;
				for(int list=0; list<3; list++)
				{
				for(int i=0;i<3;i++)
				{
					std::string matchno;
					if (i==0)
						matchno="1";
					else if (i==1)
						matchno="2";
					else
						matchno="3";
					
					filen2=line;
					filen2+="Analysis/compass_result2_match";
					filen2+=matchno;

					filen3=line;
					filen3+="Analysis/compass_result3_match";
					filen3+=matchno;
					filen4=line;
					filen4+="Analysis/compass_result4_match";
					filen4+=matchno;
					{
						filen5=line;
						filen5+="Analysis/compass_result5_match";
						filen5+=matchno;
						filen6=line;
						filen6+="Analysis/compass_result6_match";
						filen6+=matchno;
						filen7=line;
						filen7+="Analysis/compass_result7_match";
						filen7+=matchno;
						filen8=line;
						filen8+="Analysis/compass_result8_match";
						filen8+=matchno;
						filen9=line;
						filen9+="Analysis/compass_result9_match";
						filen9+=matchno;
						filen10=line;
						filen10+="Analysis/compass_result10_match";
						filen10+=matchno;
					}
					if(list==1)
					{
						filen2+="_sort";
						filen3+="_sort";
						filen4+="_sort";
						{
							filen5+="_sort";
							filen6+="_sort";
							filen7+="_sort";
							filen8+="_sort";
							filen9+="_sort";
							filen10+="_sort";
						}
					}
					else if (list==2)
					{
						filen2+="_sortCHI";
						filen3+="_sortCHI";
						filen4+="_sortCHI";
						{
							filen5+="_sortCHI";
							filen6+="_sortCHI";
							filen7+="_sortCHI";
							filen8+="_sortCHI";
							filen9+="_sortCHI";
							filen10+="_sortCHI";
						}
					}
					resultfile2.open (filen2.c_str(), std::ios::in);
					resultfile3.open (filen3.c_str(), std::ios::in);
					resultfile4.open (filen4.c_str(), std::ios::in);
					{
						resultfile5.open (filen5.c_str(), std::ios::in);
						resultfile6.open (filen6.c_str(), std::ios::in);
						resultfile7.open (filen7.c_str(), std::ios::in);
						resultfile8.open (filen8.c_str(), std::ios::in);
						resultfile9.open (filen9.c_str(), std::ios::in);
						resultfile10.open (filen10.c_str(), std::ios::in);
					}
					
					filen2+=".bak";
					filen3+=".bak";
					filen4+=".bak";
					{
						filen5+=".bak";
						filen6+=".bak";
						filen7+=".bak";
						filen8+=".bak";
						filen9+=".bak";
						filen10+=".bak";
					}
			
					resultfile2b.open (filen2.c_str(), std::ios::out);
					resultfile3b.open (filen3.c_str(), std::ios::out);
					resultfile4b.open (filen4.c_str(), std::ios::out);
					{
						resultfile5b.open (filen5.c_str(), std::ios::out);
						resultfile6b.open (filen6.c_str(), std::ios::out);
						resultfile7b.open (filen7.c_str(), std::ios::out);
						resultfile8b.open (filen8.c_str(), std::ios::out);
						resultfile9b.open (filen9.c_str(), std::ios::out);
						resultfile10b.open (filen10.c_str(), std::ios::out);
					}


					std::string temp_rows2;
					std::string temp_rows[31];
					std::string temp_peaks[18];
					std::string merArr[3000][5];
					for(int fill=0;fill<3000;fill++)
						for(int fill2=0; fill2<5;fill2++)
							merArr[fill][fill2]="EMPTY";

					int countMer=0;
					for(int fill=0; fill<countMid; fill++)
					{
						for(int fill2=0; fill2<5; fill2++)
						{
							if(fill2!=4)
								merArr[countMer][fill2]=midArr[fill][fill2];
							else
								merArr[countMer][fill2]="m";
						}
						countMer++;
					}
					for(int fill=0; fill<countEnd; fill++)
					{
						for(int fill2=0; fill2<5; fill2++)
						{
							if(fill2!=4)
								merArr[countMer][fill2]=endArr[fill][fill2];
							else
								merArr[countMer][fill2]="e";
						}
						countMer++;
					}
std::string fileS;

fileS=line;
fileS+="Analysis/seqfile.seq";
std::ofstream fileSf;

for (int q=0; q<countMer; q++)
{
	for(int qq=q+1; qq< countMer; qq++)
	{
		if(merArr[q][1]!="EMPTY" && merArr[q][1]==merArr[qq][1] && merArr[q][4]!=merArr[qq][4])
		{
			if(merArr[q][4]=="e")
			{
				for(int qqq=0; qqq<5; qqq++)
					merArr[q][qqq]="EMPTY";
			}
			else
			{
				for(int qqq=0; qqq<5; qqq++)
					merArr[qq][qqq]="EMPTY";
			}
		}
	}
}

for (int q=0; q<countMer; q++)
{
	if(merArr[q][0]=="EMPTY")
	{
		for(int qq=q+1; qq< countMer; qq++)
		{
			if(merArr[qq][0]!="EMPTY")
			{
				for (int qqq=0; qqq<5; qqq++)
				{
					merArr[q][qqq]=merArr[qq][qqq];
					merArr[qq][qqq]="EMPTY";
					break;
				}
				break;
			}
		}
	}
}


fileSf.open(fileS.c_str(), std::ios::out);
for(int ff=0;ff<countMer;ff++){
	fileSf<<merArr[ff][1]<<"\t"<<merArr[ff][4]<<"\n";
}
fileSf.clear();
fileSf.close();				
						while(resultfile3.good())
						{	
							bool del=true;
							bool not_new=false;
							bool found=false;
							int mind =0;
							int pind =0;
							bool illegal=false;
							bool in_loop=false;
							std::string subP;
							int counterP=0;
							for(int in=0;in<18;in++)
								temp_peaks[in]="EMPTY";						
							for(int j=0; j<31; j++)
								getline(resultfile3, temp_rows[j]);
							std::istringstream iss5(temp_rows[24]);
							iss5 >> subP; 
							do
							{
								iss5 >> subP;
								if (counterP <4)
								{	
									temp_peaks[counterP] = subP;
									counterP++;
								}
							}while(iss5);
							for(int p=0; p<4; p+=2)
							{
								for(int m=0; m<countMer; m++)
								{
									if(temp_peaks[p]==merArr[m][0])
									{
										in_loop=true;
										found=true;
										mind=m;
										pind=p;
										break;
									}
								}
								if(found==true)
								break;
							}
						 	int psub=1;
							bool passed=true;
							if(pind>0 && atoi(merArr[mind][1].c_str())-pind/2<first) 
								passed=false;
							if(pind<2 && atoi(merArr[mind][1].c_str())+(2-pind)/2>last) 
								passed=false;

							if(pind>0 && passed==true)
								for(int p=pind; p>=0; p-=2)
								{
									for(int m=0; m<countMer;m++)
										if(atoi(merArr[m][1].c_str())+psub==atoi(merArr[mind][1].c_str()))
										{
											passed=false;
											break;
										}
									psub++;
									if(passed==false)
										break;
								}
						if(passed==true && found==true)
						{
							int var=1;
							int legal=1;
							int fig;
							fig=atoi(merArr[mind][1].c_str());
							for(int p=pind+2;p<4;p+=2)
							{
								for(int m=0; m<countMer;m++)
								{
									if(temp_peaks[p]==merArr[m][0] && (fig+var)!=atoi(merArr[m][1].c_str()))
									{
										illegal=true;
									}
									else if(merArr[m][3]=="1" && (fig+var)==atoi(merArr[m][1].c_str()) && temp_peaks[p]!=merArr[m][0])
										illegal=true;
									if(pind==0 && temp_peaks[p]==merArr[m][0] && fig+var==atoi(merArr[m][1].c_str()))
										legal++;
									if(illegal==true)
										break;
								}
								if(illegal==true)
									break;
								var++;
							}

							if(illegal==false)
							{
								if(legal==2)
									del=true;
								else
									del=false;
							}
							else
							{
								del=true;
							}
						}
						else if (in_loop==true && passed==false)
							del=true;						
						else if(in_loop==false) 
						{
							for(int m=0;m<countMer;m++)
								if(merArr[m][0]==temp_peaks[0] || merArr[m][0]==temp_peaks[1] || merArr[m][0]==temp_peaks[2] || merArr[m][0]==temp_peaks[3])
									not_new=true;
							if(not_new==false)
								del=false;
						}								
							if(del==false && temp_rows[24]!=temp_rows2)
							{
								temp_rows2=temp_rows[24]; 
								for(int p=0; p<31; p++)
									resultfile3b<<temp_rows[p]<<"\n";
							}
							else if (list==2 && temp_rows[24]!=temp_rows2)
							{
								std::istringstream issH(temp_rows[3]);
								std::string subH;
								issH >> subH;
								fileHtml <<subH.substr(0,4)<<" ";
							}
						}

						while(resultfile4.good())
						{	
							bool del=true;
							bool not_new=false;
							bool found=false;
							int mind =0;
							int pind =0;
							bool illegal=false;
							bool in_loop=false;
							std::string subP;
							int counterP=0;
							for(int in=0;in<18;in++)
								temp_peaks[in]="EMPTY";						
							for(int j=0; j<31; j++)
								getline(resultfile4, temp_rows[j]);
							std::istringstream iss5(temp_rows[24]);
							iss5 >> subP; 
							do
							{
								iss5 >> subP;
								if (counterP <6)
								{	
									temp_peaks[counterP] = subP;
									counterP++;
								}
							}while(iss5);
							for(int p=0; p<6; p+=2)
							{
								for(int m=0; m<countMer; m++)
								{
									if(temp_peaks[p]==merArr[m][0])
									{
										in_loop=true;
										found=true;
										mind=m;
										pind=p;
										break;
									}
								}
								if(found==true)
								break;
							}
						 	int psub=1;
							bool passed=true;
							if(pind>0 && atoi(merArr[mind][1].c_str())-pind/2<first) 
								passed=false;
							if(pind<4 && atoi(merArr[mind][1].c_str())+(4-pind)/2>last)
								passed=false;

							if(pind>0 && passed==true)
								for(int p=pind; p>=0; p-=2)
								{
									for(int m=0; m<countMer;m++)
										if(atoi(merArr[m][1].c_str())+psub==atoi(merArr[mind][1].c_str()))
										{
											passed=false;
											break;
										}
									psub++;
									if(passed==false)
										break;
								}
						if(passed==true && found==true)
						{
							int var=1;
							int legal=1;
							int fig;
							fig=atoi(merArr[mind][1].c_str());
							for(int p=pind+2;p<6;p+=2)
							{
								for(int m=0; m<countMer;m++)
								{
									if(temp_peaks[p]==merArr[m][0] && (fig+var)!=atoi(merArr[m][1].c_str()))
									{
										illegal=true;
									}
									else if(merArr[m][3]=="1" && (fig+var)==atoi(merArr[m][1].c_str()) && temp_peaks[p]!=merArr[m][0])
										illegal=true;
									if(pind==0 && temp_peaks[p]==merArr[m][0] && fig+var==atoi(merArr[m][1].c_str()))
										legal++;
									if(illegal==true)
										break;
								}
								if(illegal==true)
									break;
								var++;
							}
							if(illegal==false)
							{
								if(legal==3)
									del=true;
								else
									del=false;
							}
							else
							{
								del=true;
							}
						}
						else if (in_loop==true && passed==false)
							del=true;						
						else if(in_loop==false) 
							{
								for(int m=0;m<countMer;m++)
									if(merArr[m][0]==temp_peaks[0] || merArr[m][0]==temp_peaks[1] || merArr[m][0]==temp_peaks[2] || merArr[m][0]==temp_peaks[3] || merArr[m][0]==temp_peaks[4] || merArr[m][0]==temp_peaks[5])
										not_new=true;
								if(not_new==false)
									del=false;
							}								
							if(del==false && temp_rows[24]!=temp_rows2) 
							{
								temp_rows2=temp_rows[24]; 
								for(int p=0; p<31; p++)
									resultfile4b<<temp_rows[p]<<"\n";
							}
							else if (list==2 && temp_rows[24]!=temp_rows2)
							{
								std::istringstream issH(temp_rows[3]);
								std::string subH;
								issH >> subH;
								fileHtml <<subH.substr(0,4)<<" ";
							}
						}
						while(resultfile5.good())
						{	
							bool del=true;
							bool not_new=false;
							bool found=false;
							int mind =0;
							int pind =0;
							bool illegal=false;
							bool in_loop=false;
							std::string subP;
							int counterP=0;
							for(int in=0;in<18;in++)
								temp_peaks[in]="EMPTY";						
							for(int j=0; j<31; j++)
								getline(resultfile5, temp_rows[j]);
							std::istringstream iss5(temp_rows[24]);
							iss5 >> subP; 
							do
							{
								iss5 >> subP;
								if (counterP <18)
								{	
									temp_peaks[counterP] = subP;
									counterP++;
								}
							}while(iss5);
							for(int p=0; p<8; p+=2)
							{
								for(int m=0; m<countMer; m++)
								{
									if(temp_peaks[p]==merArr[m][0])
									{
										in_loop=true;
										found=true;
										mind=m;
										pind=p;
										break;
									}
								}
								if(found==true)
								break;
							}
						 	int psub=1;
							bool passed=true;
							if(pind>0 && atoi(merArr[mind][1].c_str())-pind/2<first) 
							{
								passed=false;
							}
							if(pind<6 && atoi(merArr[mind][1].c_str())+(6-pind)/2>last) 
							{
								passed=false;
							}

							if(pind>0 && passed==true)
								for(int p=pind; p>=0; p-=2)
								{
									for(int m=0; m<countMer;m++)
										if(atoi(merArr[m][1].c_str())+psub==atoi(merArr[mind][1].c_str()))
										{
											passed=false;
											break;
										}
									psub++;
									if(passed==false)
										break;
								}
							int var=1;
							int fig;
						if(passed==true && found==true)
						{
							int legal=1;
							fig=atoi(merArr[mind][1].c_str());
							for(int p=pind+2;p<8;p+=2)
							{
								for(int m=0; m<countMer;m++)
								{
									if(temp_peaks[p]==merArr[m][0] && (fig+var)!=atoi(merArr[m][1].c_str()))
									{
										illegal=true;
									}
									else if(merArr[m][3]=="1" && (fig+var)==atoi(merArr[m][1].c_str()) && temp_peaks[p]!=merArr[m][0])
										illegal=true;
									if(pind==0 && temp_peaks[p]==merArr[m][0] && fig+var==atoi(merArr[m][1].c_str()))
										legal++;
									if(illegal==true)
										break;
								}
								if(illegal==true)
									break;
								var++;
							}
							if(illegal==false)
							{
								if(legal==4)
									del=true;
								else
									del=false;
							}
							else
							{
								del=true;
							}
						}
						else if (in_loop==true && passed==false)
							del=true;						
						else if(in_loop==false) 
							{
								for(int m=0;m<countMer;m++)
									if(merArr[m][0]==temp_peaks[0] || merArr[m][0]==temp_peaks[1] || merArr[m][0]==temp_peaks[2] || merArr[m][0]==temp_peaks[3] || merArr[m][0]==temp_peaks[4] || merArr[m][0]==temp_peaks[5] || merArr[m][0]==temp_peaks[6] || merArr[m][0]==temp_peaks[7])
										not_new=true;
								if(not_new==false)
									del=false;
							}								
							
							if(del==false && temp_rows[24]!=temp_rows2) 
							{
								temp_rows2=temp_rows[24]; 
								for(int p=0; p<31; p++)
									resultfile5b<<temp_rows[p]<<"\n";
							}
							else if (list==2 && temp_rows[24]!=temp_rows2)
							{
								std::istringstream issH(temp_rows[3]);
								std::string subH;
								issH >> subH;
								fileHtml <<subH.substr(0,4)<<" ";
							}
						}
						while(resultfile6.good())
						{	
							bool del=true;
							bool not_new=false;
							bool found=false;
							int mind =0;
							int pind =0;
							bool illegal=false;
							bool in_loop=false;
							std::string subP;
							int counterP=0;
							for(int in=0;in<18;in++)
								temp_peaks[in]="EMPTY";						
							for(int j=0; j<31; j++)
								getline(resultfile6, temp_rows[j]);
							std::istringstream iss5(temp_rows[24]);
							iss5 >> subP; 
							do
							{
								iss5 >> subP;
								if (counterP <10)
								{	
									temp_peaks[counterP] = subP;
									counterP++;
								}
							}while(iss5);
							for(int p=0; p<10; p+=2)
							{
								for(int m=0; m<countMer; m++)
								{
									if(temp_peaks[p]==merArr[m][0])
									{
										in_loop=true;
										found=true;
										mind=m;
										pind=p;
										break;
									}
								}
								if(found==true)
								break;
							}
						 	int psub=1;
							bool passed=true;
							if(pind>0 && atoi(merArr[mind][1].c_str())-pind/2<first) 
								passed=false;
							if(pind<8 && atoi(merArr[mind][1].c_str())+(8-pind)/2>last) 
								passed=false;

							if(pind>0 && passed==true)
								for(int p=pind; p>=0; p-=2)
								{
									for(int m=0; m<countMer;m++)
										if(atoi(merArr[m][1].c_str())+psub==atoi(merArr[mind][1].c_str()))
										{
											passed=false;
											break;
										}
									psub++;
									if(passed==false)
										break;
								}
						if(passed==true && found==true)
						{
							int var=1;
							int legal=1;
							int fig;
							fig=atoi(merArr[mind][1].c_str());
							for(int p=pind+2;p<10;p+=2)
							{
								for(int m=0; m<countMer;m++)
								{
									if(temp_peaks[p]==merArr[m][0] && (fig+var)!=atoi(merArr[m][1].c_str()))
									{
										illegal=true;
									}
									else if(merArr[m][3]=="1" && (fig+var)==atoi(merArr[m][1].c_str()) && temp_peaks[p]!=merArr[m][0])
										illegal=true;
									if(pind==0 && temp_peaks[p]==merArr[m][0] && fig+var==atoi(merArr[m][1].c_str()))
										legal++;
									if(illegal==true)
										break;
								}
								if(illegal==true)
									break;
								var++;
							}
							if(illegal==false)
							{
								if(legal==5)
									del=true;
								else
									del=false;
							}
							else
							{
								del=true;
							}
						}
						else if (in_loop==true && passed==false)
							del=true;						
						else if(in_loop==false) 
							{
								for(int m=0;m<countMer;m++)
									if(merArr[m][0]==temp_peaks[0] || merArr[m][0]==temp_peaks[1] || merArr[m][0]==temp_peaks[2] || merArr[m][0]==temp_peaks[3] || merArr[m][0]==temp_peaks[4] || merArr[m][0]==temp_peaks[5] || merArr[m][0]==temp_peaks[6] || merArr[m][0]==temp_peaks[7] || merArr[m][0]==temp_peaks[8] || merArr[m][0]==temp_peaks[9])
										not_new=true;
								if(not_new==false)
									del=false;
							}								
							
							if(del==false && temp_rows[24]!=temp_rows2) 
							{
								temp_rows2=temp_rows[24]; 
								for(int p=0; p<31; p++)
									resultfile6b<<temp_rows[p]<<"\n";
							}
							else if (list==2 && temp_rows[24]!=temp_rows2)
							{
								std::istringstream issH(temp_rows[3]);
								std::string subH;
								issH >> subH;
								fileHtml <<subH.substr(0,4)<<" ";
							}
						}

						while(resultfile7.good())
						{	
							bool del=true;
							bool not_new=false;
							bool found=false;
							int mind =0;
							int pind =0;
							bool illegal=false;
							bool in_loop=false;
							std::string subP;
							int counterP=0;
							for(int in=0;in<18;in++)
								temp_peaks[in]="EMPTY";						
							for(int j=0; j<31; j++)
								getline(resultfile7, temp_rows[j]);
							std::istringstream iss5(temp_rows[24]);
							iss5 >> subP; 
							do
							{
								iss5 >> subP;
								if (counterP <12)
								{	
									temp_peaks[counterP] = subP;
									counterP++;
								}
							}while(iss5);
							for(int p=0; p<12; p+=2)
							{
								for(int m=0; m<countMer; m++)
								{
									if(temp_peaks[p]==merArr[m][0])
									{
										in_loop=true;
										found=true;
										mind=m;
										pind=p;
										break;
									}
								}
								if(found==true)
								break;
							}
						 	int psub=1;
							bool passed=true;
							if(pind>0 && atoi(merArr[mind][1].c_str())-pind/2<first) 
								passed=false;
							if(pind<10 && atoi(merArr[mind][1].c_str())+(10-pind)/2>last) 
								passed=false;

							if(pind>0 && passed==true)
								for(int p=pind; p>=0; p-=2)
								{
									for(int m=0; m<countMer;m++)
										if(atoi(merArr[m][1].c_str())+psub==atoi(merArr[mind][1].c_str()))
										{
											passed=false;
											break;
										}
									psub++;
									if(passed==false)
										break;
								}
						if(passed==true && found==true)
						{
							int var=1;
							int legal=1;
							int fig;
							fig=atoi(merArr[mind][1].c_str());
							for(int p=pind+2;p<12;p+=2)
							{
								for(int m=0; m<countMer;m++)
								{
									if(temp_peaks[p]==merArr[m][0] && (fig+var)!=atoi(merArr[m][1].c_str()))
									{
										illegal=true;
									}
									else if(merArr[m][3]=="1" && (fig+var)==atoi(merArr[m][1].c_str()) && temp_peaks[p]!=merArr[m][0])
										illegal=true;
									if(pind==0 && temp_peaks[p]==merArr[m][0] && fig+var==atoi(merArr[m][1].c_str()))
										legal++;
									if(illegal==true)
										break;
								}
								if(illegal==true)
									break;
								var++;
							}
							if(illegal==false)
							{
								if(legal==6)
									del=true;
								else
									del=false;
							}
							else
							{
								del=true;
							}
						}
						else if (in_loop==true && passed==false)
							del=true;						
						else if(in_loop==false) 
							{
								for(int m=0;m<countMer;m++)
									if(merArr[m][0]==temp_peaks[0] || merArr[m][0]==temp_peaks[1] || merArr[m][0]==temp_peaks[2] || merArr[m][0]==temp_peaks[3] || merArr[m][0]==temp_peaks[4] || merArr[m][0]==temp_peaks[5] || merArr[m][0]==temp_peaks[6] || merArr[m][0]==temp_peaks[7] || merArr[m][0]==temp_peaks[8] || merArr[m][0]==temp_peaks[9] || merArr[m][0]==temp_peaks[10] || merArr[m][0]==temp_peaks[11])
										not_new=true;
								if(not_new==false)
									del=false;
							}								
							
							if(del==false && temp_rows[24]!=temp_rows2) 
							{
								temp_rows2=temp_rows[24]; 
								for(int p=0; p<31; p++)
									resultfile7b<<temp_rows[p]<<"\n";
							}
							else if (list==2 && temp_rows[24]!=temp_rows2)
							{
								std::istringstream issH(temp_rows[3]);
								std::string subH;
								issH >> subH;
								fileHtml <<subH.substr(0,4)<<" ";
							}
						}

						while(resultfile8.good())
						{	
							bool del=true;
							bool not_new=false;
							bool found=false;
							int mind =0;
							int pind =0;
							bool illegal=false;
							bool in_loop=false;
							std::string subP;
							int counterP=0;
							for(int in=0;in<18;in++)
								temp_peaks[in]="EMPTY";						
							for(int j=0; j<31; j++)
								getline(resultfile8, temp_rows[j]);
							std::istringstream iss5(temp_rows[24]);
							iss5 >> subP; 
							do
							{
								iss5 >> subP;
								if (counterP <14)
								{	
									temp_peaks[counterP] = subP;
									counterP++;
								}
							}while(iss5);
							for(int p=0; p<14; p+=2)
							{
								for(int m=0; m<countMer; m++)
								{
									if(temp_peaks[p]==merArr[m][0])
									{
										in_loop=true;
										found=true;
										mind=m;
										pind=p;
										break;
									}
								}
								if(found==true)
								break;
							}
						 	int psub=1;
							bool passed=true;
							if(pind>0 && atoi(merArr[mind][1].c_str())-pind/2<first) 
								passed=false;
							if(pind<12 && atoi(merArr[mind][1].c_str())+(12-pind)/2>last) 
								passed=false;

							if(pind>0 && passed==true)
								for(int p=pind; p>=0; p-=2)
								{
									for(int m=0; m<countMer;m++)
										if(atoi(merArr[m][1].c_str())+psub==atoi(merArr[mind][1].c_str()))
										{
											passed=false;
											break;
										}
									psub++;
									if(passed==false)
										break;
								}
						if(passed==true && found==true)
						{
							int var=1;
							int legal=1;
							int fig;
							fig=atoi(merArr[mind][1].c_str());
							for(int p=pind+2;p<14;p+=2)
							{
								for(int m=0; m<countMer;m++)
								{
									if(temp_peaks[p]==merArr[m][0] && (fig+var)!=atoi(merArr[m][1].c_str()))
									{
										illegal=true;
									}
									else if(merArr[m][3]=="1" && (fig+var)==atoi(merArr[m][1].c_str()) && temp_peaks[p]!=merArr[m][0])
										illegal=true;
									if(pind==0 && temp_peaks[p]==merArr[m][0] && fig+var==atoi(merArr[m][1].c_str()))
										legal++;
									if(illegal==true)
										break;
								}
								if(illegal==true)
									break;
								var++;
							}
							if(illegal==false)
							{
								if(legal==7)
									del=true;
								else
									del=false;
							}
							else
							{
								del=true;
							}
						}
						else if (in_loop==true && passed==false)
							del=true;						
						else if(in_loop==false) 
							{
								for(int m=0;m<countMer;m++)
									if(merArr[m][0]==temp_peaks[0] || merArr[m][0]==temp_peaks[1] || merArr[m][0]==temp_peaks[2] || merArr[m][0]==temp_peaks[3] || merArr[m][0]==temp_peaks[4] || merArr[m][0]==temp_peaks[5] || merArr[m][0]==temp_peaks[6] || merArr[m][0]==temp_peaks[7] || merArr[m][0]==temp_peaks[8] || merArr[m][0]==temp_peaks[9] || merArr[m][0]==temp_peaks[10] || merArr[m][0]==temp_peaks[11] || merArr[m][0]==temp_peaks[12] || merArr[m][0]==temp_peaks[13])
										not_new=true;
								if(not_new==false)
									del=false;
							}								
							if(del==false && temp_rows[24]!=temp_rows2) 
							{
								temp_rows2=temp_rows[24]; 
								for(int p=0; p<31; p++)
									resultfile8b<<temp_rows[p]<<"\n";
							}
							else if (list==2 && temp_rows[24]!=temp_rows2)
							{
								std::istringstream issH(temp_rows[3]);
								std::string subH;
								issH >> subH;
								fileHtml <<subH.substr(0,4)<<" ";
							}
						}
						while(resultfile9.good())
						{	
							bool del=true;
							bool not_new=false;
							bool found=false;
							int mind =0;
							int pind =0;
							bool illegal=false;
							bool in_loop=false;
							std::string subP;
							int counterP=0;
							for(int in=0;in<18;in++)
								temp_peaks[in]="EMPTY";						
							for(int j=0; j<31; j++)
								getline(resultfile9, temp_rows[j]);
							std::istringstream iss5(temp_rows[24]);
							iss5 >> subP; 
							do
							{
								iss5 >> subP;
								if (counterP <16)
								{	
									temp_peaks[counterP] = subP;
									counterP++;
								}
							}while(iss5);
							for(int p=0; p<16; p+=2)
							{
								for(int m=0; m<countMer; m++)
								{
									if(temp_peaks[p]==merArr[m][0])
									{
										in_loop=true;
										found=true;
										mind=m;
										pind=p;
										break;
									}
								}
								if(found==true)
								break;
							}
						 	int psub=1;
							bool passed=true;
							if(pind>0 && atoi(merArr[mind][1].c_str())-pind/2<first) 
								passed=false;
							if(pind<14 && atoi(merArr[mind][1].c_str())+(14-pind)/2>last) 
								passed=false;

							if(pind>0 && passed==true)
								for(int p=pind; p>=0; p-=2)
								{
									for(int m=0; m<countMer;m++)
										if(atoi(merArr[m][1].c_str())+psub==atoi(merArr[mind][1].c_str()))
										{
											passed=false;
											break;
										}
									psub++;
									if(passed==false)
										break;
								}
						if(passed==true && found==true)
						{
							int var=1;
							int legal=1;
							int fig;
							fig=atoi(merArr[mind][1].c_str());
							for(int p=pind+2;p<16;p+=2)
							{
								for(int m=0; m<countMer;m++)
								{
									if(temp_peaks[p]==merArr[m][0] && (fig+var)!=atoi(merArr[m][1].c_str()))
										illegal=true;
									else if(merArr[m][3]=="1" && (fig+var)==atoi(merArr[m][1].c_str()) && temp_peaks[p]!=merArr[m][0])
										illegal=true;

									if(pind==0 && temp_peaks[p]==merArr[m][0] && fig+var==atoi(merArr[m][1].c_str()))
										legal++;
									if(illegal==true)
										break;
								}
								if(illegal==true)
									break;
								var++;
							}
							if(illegal==false)
							{
								if(legal==8)
									del=true;
								else
									del=false;
							}
							else
							{
								del=true;
							}
						}
						
						else if (in_loop==true && passed==false)
							del=true;
						else if(in_loop==false) 
							{
								for(int m=0;m<countMer;m++)
									if(merArr[m][0]==temp_peaks[0] || merArr[m][0]==temp_peaks[1] || merArr[m][0]==temp_peaks[2] || merArr[m][0]==temp_peaks[3] || merArr[m][0]==temp_peaks[4] || merArr[m][0]==temp_peaks[5] || merArr[m][0]==temp_peaks[6] || merArr[m][0]==temp_peaks[7] || merArr[m][0]==temp_peaks[8] || merArr[m][0]==temp_peaks[9] || merArr[m][0]==temp_peaks[10] || merArr[m][0]==temp_peaks[11] || merArr[m][0]==temp_peaks[12] || merArr[m][0]==temp_peaks[13] || merArr[m][0]==temp_peaks[14] || merArr[m][0]==temp_peaks[15])
										not_new=true;
								if(not_new==false)
									del=false;
							}								
							if(del==false && temp_rows[24]!=temp_rows2) 
							{
								temp_rows2=temp_rows[24]; 
								for(int p=0; p<31; p++)
									resultfile9b<<temp_rows[p]<<"\n";
							}
							else if (list==2 && temp_rows[24]!=temp_rows2)
							{
								std::istringstream issH(temp_rows[3]);
								std::string subH;
								issH >> subH;
								fileHtml <<subH.substr(0,4)<<" ";
							}
						}
						while(resultfile10.good())
						{								
							bool del=true;
							bool not_new=false;
							bool found=false;
							int mind =0;
							int pind =0;
							bool illegal=false;
							bool in_loop=false;
							std::string subP;
							int counterP=0;
							for(int in=0;in<18;in++)
								temp_peaks[in]="EMPTY";						
							for(int j=0; j<31; j++)
								getline(resultfile10, temp_rows[j]);
							std::istringstream iss5(temp_rows[24]);
							iss5 >> subP; 
							do
							{
								iss5 >> subP;
								if (counterP <18)
								{	
									temp_peaks[counterP] = subP;
									counterP++;
								}
							}while(iss5);
							for(int p=0; p<18; p+=2)
							{
								for(int m=0; m<countMer; m++)
								{
									if(temp_peaks[p]==merArr[m][0])
									{
										in_loop=true;
										found=true;
										mind=m;
										pind=p;
										break;
									}
								}
								if(found==true)
								break;
							}
						 	int psub=1;
							bool passed=true;
							if(pind>0 && atoi(merArr[mind][1].c_str())-pind/2<first) 
								passed=false;
							if(pind<16 && atoi(merArr[mind][1].c_str())+(16-pind)/2>last) 
								passed=false;

							if(pind>0 && passed==true)
								for(int p=pind; p>=0; p-=2)
								{
									for(int m=0; m<countMer;m++)
										if(atoi(merArr[m][1].c_str())+psub==atoi(merArr[mind][1].c_str()))
										{
											passed=false;
											break;
										}
									psub++;
									if(passed==false)
										break;
								}
						if(passed==true && found==true)
						{
							int var=1;
							int legal=1;
							int fig;
							fig=atoi(merArr[mind][1].c_str());
							for(int p=pind+2;p<18;p+=2)
							{
								for(int m=0; m<countMer;m++)
								{
									if(temp_peaks[p]==merArr[m][0] && (fig+var)!=atoi(merArr[m][1].c_str()))
									{
										illegal=true;
									}
									else if(merArr[m][3]=="1" && (fig+var)==atoi(merArr[m][1].c_str()) && temp_peaks[p]!=merArr[m][0])
										illegal=true;
									if(pind==0 && temp_peaks[p]==merArr[m][0] && fig+var==atoi(merArr[m][1].c_str()))
										legal++;
									if(illegal==true)
										break;
								}
								if(illegal==true)
									break;
								var++;
							}
							if(illegal==false)
							{
								if(legal==9)
									del=true;
								else
									del=false;
							}
							else
							{
								del=true;
							}
						}
						else if (in_loop==true && passed==false)
							del=true;
						else if (in_loop==false) 
							{
								for(int m=0;m<countMer;m++)
									if(merArr[m][0]==temp_peaks[0] || merArr[m][0]==temp_peaks[1] || merArr[m][0]==temp_peaks[2] || merArr[m][0]==temp_peaks[3] || merArr[m][0]==temp_peaks[4] || merArr[m][0]==temp_peaks[5] || merArr[m][0]==temp_peaks[6] || merArr[m][0]==temp_peaks[7] || merArr[m][0]==temp_peaks[8] || merArr[m][0]==temp_peaks[9] || merArr[m][0]==temp_peaks[10] || merArr[m][0]==temp_peaks[11] || merArr[m][0]==temp_peaks[12] || merArr[m][0]==temp_peaks[13] || merArr[m][0]==temp_peaks[14] || merArr[m][0]==temp_peaks[15] || merArr[m][0]==temp_peaks[16] || merArr[m][0]==temp_peaks[17])
										not_new=true;
								if(not_new==false)
									del=false;
							}								
							if(del==false && temp_rows[24]!=temp_rows2) 
							{
								temp_rows2=temp_rows[24]; 
								for(int p=0; p<31; p++)
									resultfile10b<<temp_rows[p]<<"\n";
							}
							else if (list==2 && temp_rows[24]!=temp_rows2)
							{
								std::istringstream issH(temp_rows[3]);
								std::string subH;
								issH >> subH;
								fileHtml <<subH.substr(0,4)<<" ";
							}
						}
						while(resultfile2.good())
						{			
							bool del=true;
							bool not_new=false;
							std::string subP;
							int counterP=0;
							for(int in=0;in<18;in++)
								temp_peaks[in]="EMPTY";						
							for(int j=0; j<31; j++)
								getline(resultfile2, temp_rows[j]);
							std::istringstream iss5(temp_rows[24]);
							iss5 >> subP; 
							do
							{
								iss5 >> subP;
								if (counterP <2)
								{	
									temp_peaks[counterP] = subP;
									counterP++;
								}
							}while(iss5);

							for(int m=0;m<countMer;m++)
							{
								if(merArr[m][0]==temp_peaks[0] || merArr[m][0]==temp_peaks[1])
									not_new=true;
							}
							if(not_new==false)
								del=false;
							
							if(del==false && temp_rows[24]!=temp_rows2) 
							{
								temp_rows2=temp_rows[24]; 
								for(int p=0; p<31; p++)
									resultfile2b<<temp_rows[p]<<"\n";
							}
							else if (list==2 && temp_rows[24]!=temp_rows2)
							{
								std::istringstream issH(temp_rows[3]);
								std::string subH;
								issH >> subH;
								fileHtml <<subH.substr(0,4)<<" ";
							}
						}


			
				resultfile2.clear();
				resultfile2.close();
				resultfile3.clear();
				resultfile3.close();
				resultfile4.clear();
				resultfile4.close();
				resultfile5.clear();
				resultfile5.close();
				resultfile6.clear();
				resultfile6.close();
				resultfile7.clear();
				resultfile7.close();
				resultfile8.clear();
				resultfile8.close();
				resultfile9.clear();
				resultfile9.close();
				resultfile10.clear();
				resultfile10.close();
				resultfile2b.clear();
				resultfile2b.close();
				resultfile3b.clear();
				resultfile3b.close();
				resultfile4b.clear();
				resultfile4b.close();
				resultfile5b.clear();
				resultfile5b.close();
				resultfile6b.clear();
				resultfile6b.close();
				resultfile7b.clear();
				resultfile7b.close();
				resultfile8b.clear();
				resultfile8b.close();
				resultfile9b.clear();
				resultfile9b.close();
				resultfile10b.clear();
				resultfile10b.close();
				} 
}
            QString cp1 = QString::fromUtf8(dir2.c_str());
            cp1+="Analysis/manualmode.bak";
            QString cp2 = QString::fromUtf8(dir2.c_str());
            cp2+="Analysis/manualmode";
            if(QFile::exists(cp2))
                QFile::remove(cp2);
            QFile::copy(cp1, cp2);
			}
			else
			{
				ui->errorLabel->show();
                ui->errorBrowser->setText("The submitted index conflicts with a prior assignment.\nIndex is omitted.");
				undoFunc();
			}
		}
		else
			{
				ui->errorLabel->show();
                ui->errorBrowser->setText("The submitted index conflicts with a prior assignment.\nIndex is omitted.");
				undoFunc();
			}

	}
	else
			{
				ui->errorLabel->show();
                ui->errorBrowser->setText("The submitted index conflicts with a prior assignment.\nIndex is omitted.");
				undoFunc();
			}
	}
	else
			{
				ui->errorLabel->show();
                ui->errorBrowser->setText("The submitted index conflicts with a prior assignment.\nIndex is omitted.");
				undoFunc();
			}
				if(mismatch==false){
				fileHtml.clear();
				fileHtml.close();
				compasshtml2();}
	
}
