#include "compassspinsystem.h"
#include "ui_compassspinsystem.h"
#include <QtWidgets>
#include <cstdlib>
#include "QRect"		//Used for centering windows
#include "QDesktopWidget"	//Used for centering windows
#include "compassvec.h"
#include "globals2.h"
#include "globals.h"
#include "queryerror5.h"
#include "queryerror6.h"
#include "queryerror7.h"
#include "compassssresults.h"
#include "math.h"
#include <QFileDialog>
#include <QFile>
#include <vector>
#include "compassfunctions.h"


std::vector < std::string > CompassSpinSystem::DefVec(int x)
{
   std::vector < std::string > Arr;

   for (int j=0;j<x;j++)
       Arr.push_back("");

   return Arr;
}
std::vector< std::vector < std::string > > CompassSpinSystem::DefVec2(int x, int y)
{
   std::vector< std::vector < std::string > > Arr2;
   std::vector < std::string > Arr;

   for (int j=0;j<y;j++)
       Arr.push_back("");
   for (int i=0;i<x;i++)
       Arr2.push_back(Arr);
   return Arr2;
}


CompassSpinSystem::CompassSpinSystem(QWidget *parent) :
    QWidget(parent),
	ui(new Ui::CompassSpinSystem)
{
	ui->setupUi(this);
    setParam();
    connectLines();
    ui->CAinCBCheck->isChecked() == true ? Show_CType(1) : Show_CType(0);
    connect(ui->CAinCBCheck, SIGNAL(stateChanged(int)), this,SLOT(Show_CType(int)));
	getDir();
}
void CompassSpinSystem::setParam()
{
    extern QString parca, parca2, parcbca, parcbca2, parco, parco2, parhsqc, parsave, parpro;
    extern int Refpar;
    extern bool CAcheck, CAB, CBB;
    extern double pard1, pard2, pard3;

    ui->HNCALine->setText(parca);
    ui->HNCOCALine->setText(parca2);
    ui->HNCACBLine->setText(parcbca);
    ui->HNCOCACBLine->setText(parcbca2);
    ui->HNCOLine->setText(parco);
    ui->HNCACOLine->setText(parco2);
    ui->HSQCLine->setText(parhsqc);
    ui->folderLine->setText(parsave);
    ui->projectLine->setText(parpro);
    ui->RefBox->setCurrentIndex(Refpar);
    ui->devNBox->setValue(pard1);
    ui->devCBox->setValue(pard2);
    ui->devHBox->setValue(pard3);
    ui->CAButton->setChecked(CAB);
    ui->CBButton->setChecked(CBB);
    ui->CAinCBCheck->setChecked(CAcheck);

}
void CompassSpinSystem::saveParam()
{
    extern QString parca, parca2, parcbca, parcbca2, parco, parco2, parhsqc, parsave, parpro;
    extern int Refpar;
    extern bool CAcheck, CAB, CBB;
    extern double pard1, pard2, pard3;

    parca = ui->HNCALine->text();
    parca2 = ui->HNCOCALine->text();
    parcbca = ui->HNCACBLine->text();
    parcbca2 = ui->HNCOCACBLine->text();
    parco = ui->HNCOLine->text();
    parco2 = ui->HNCACOLine->text();
    parhsqc = ui->HSQCLine->text();
    parsave = ui->folderLine->text();
    parpro = ui->projectLine->text();
    Refpar = ui->RefBox->currentIndex();
    pard1 = ui->devNBox->value();
    pard2 = ui->devCBox->value();
    pard3 = ui->devHBox->value();
    CAcheck = ui->CAinCBCheck->isChecked();
    CAB = ui->CAButton->isChecked();
    CBB = ui->CBButton->isChecked();
    ui->CBButton->setChecked(CBB);
    ui->CAinCBCheck->setChecked(CAcheck);


}void CompassSpinSystem::connectLines()
{
    connect(ui->HNCALine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->HNCOCALine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->HNCACBLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->HNCOCACBLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->HNCOLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->HNCACOLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->HSQCLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->projectLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->folderLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->RefBox, SIGNAL(currentIndexChanged(int)), this, SLOT(saveParam()));
    connect(ui->devNBox, SIGNAL(valueChanged(double)), this, SLOT(saveParam()));
    connect(ui->devCBox, SIGNAL(valueChanged(double)), this, SLOT(saveParam()));
    connect(ui->devHBox, SIGNAL(valueChanged(double)), this, SLOT(saveParam()));
    connect(ui->CAinCBCheck, SIGNAL(toggled(bool)), this, SLOT(saveParam()));
    connect(ui->CAButton, SIGNAL(toggled(bool)), this, SLOT(saveParam()));
    connect(ui->CBButton, SIGNAL(toggled(bool)), this, SLOT(saveParam()));
}
void CompassSpinSystem::clear_form()
{
    ui->HNCALine->setText("");
    ui->HNCOCALine->setText("");
    ui->HNCACBLine->setText("");
    ui->HNCOCACBLine->setText("");
    ui->HNCOLine->setText("");
    ui->HNCACOLine->setText("");
    ui->HSQCLine->setText("");
    ui->folderLine->setText("");
    getDir();
    ui->RefBox->setCurrentIndex(0);
    ui->devNBox->setValue(0.2);
    ui->devCBox->setValue(0.2);
    ui->devHBox->setValue(0.02);
    ui->CAinCBCheck->setChecked(true);
    ui->CBButton->setChecked(true);
    ui->projectLine->setText("");
}
void CompassSpinSystem::on_helpButton_clicked()
{
    CompassHelp5 winHelp5;
    winHelp5.setWindowModality(Qt::ApplicationModal);
    if(winHelp5.exec())
        return;

}

void CompassSpinSystem::removeFiles(const QString & dirName)
{

    QDir dir(dirName);

           Q_FOREACH(QFileInfo info, dir.entryInfoList(QDir::NoDotAndDotDot | QDir::System | QDir::Hidden  | QDir::AllDirs | QDir::Files, QDir::DirsFirst))
            {
               if (info.suffix()=="compass" || info.fileName()=="spinsystems.list" || info.fileName()=="warning.txt" || info.fileName()=="label.cpar")
                QFile::remove(info.absoluteFilePath());
            }
    return;
}
CompassSpinSystem::~CompassSpinSystem()
{
	delete ui;
}

void CompassSpinSystem::on_menuButton_clicked()
{
    emit goToMain();
}

void CompassSpinSystem::on_HSQCButton_clicked()
{
    QString path;
    path = QFileDialog::getOpenFileName(
	this,
    "Choose an HSQC file",
	QString::null,
	QString::null);
    if(path!="")
    ui->HSQCLine->setText(convSlash(path));
}
void CompassSpinSystem::on_HNCOButton_clicked()
{
	QString path;				
	path = QFileDialog::getOpenFileName(
	this,
    "Choose an HNCO (i-1) file",
	QString::null,
	QString::null);
	if(path!="")			
    ui->HNCOLine->setText(convSlash(path));
				
}
void CompassSpinSystem::on_HNCACOButton_clicked()
{
	QString path;				
	path = QFileDialog::getOpenFileName(
	this,
    "Choose an HNCO (i)(i-1) file",
	QString::null,
	QString::null);
	if(path!="")		
    ui->HNCACOLine->setText(convSlash(path));
					
}
void CompassSpinSystem::on_HNCACBButton_clicked()
{
	QString path;			
	path = QFileDialog::getOpenFileName(		
	this,
    "Choose an HNCB (i)(i-1) file",
	QString::null,
	QString::null);
	if(path!="")			
    ui->HNCACBLine->setText(convSlash(path));
				
}
void CompassSpinSystem::on_HNCAButton_clicked()
{
	QString path;			
	path = QFileDialog::getOpenFileName(		
	this,
    "Choose an HNCA (i)(i-1) file",
	QString::null,
	QString::null);
	if(path!="")			
    ui->HNCALine->setText(convSlash(path));
				
}
void CompassSpinSystem::on_HNCOCAButton_clicked()
{
	QString path;			
	path = QFileDialog::getOpenFileName(		
	this,
    "Choose an HNCA (i-1) file",
	QString::null,
	QString::null);
	if(path!="")			
    ui->HNCOCALine->setText(convSlash(path));
				
}
void CompassSpinSystem::on_HNCOCACBButton_clicked()
{
	QString path;			
	path = QFileDialog::getOpenFileName(		
	this,
    "Choose an HNCB (i-1) file",
	QString::null,
	QString::null);
	if(path!="")			
    ui->HNCOCACBLine->setText(convSlash(path));
}
void CompassSpinSystem::getDir()
{
    //char cwd[1024];
    //getcwd(cwd, sizeof(cwd));
    //std::stringstream ss;
    //std::string s;
    //ss << cwd;
    //ss >> s;
    //QString Qcwd = QString::fromUtf8(s.c_str());
    QString Qcwd = QDir::currentPath();
	Qcwd += "/";
    ui->folderLine->setText(convSlash(Qcwd));
}
void CompassSpinSystem::on_folderButton_clicked()
{
	QString path;
	QFileDialog dialog(this);
	dialog.setFileMode(QFileDialog::Directory);
	path = QFileDialog::getExistingDirectory(
	this,
	"Choose a directory",
	QString::null, QFileDialog::ShowDirsOnly);
	if(path.isNull() == false)
	{
		path+="/";
        ui->folderLine->setText(convSlash(path));
	}
}
void CompassSpinSystem::Show_CType(int state)
{
	if (state==0)
	{
		ui->labelNeg->setDisabled(true);
		ui->CAButton->setDisabled(true);
		ui->CBButton->setDisabled(true);
	}
	else
	{
		ui->labelNeg->setEnabled(true);
		ui->CAButton->setEnabled(true);
		ui->CBButton->setEnabled(true);
	}
}
void CompassSpinSystem::on_SpinSystemButton_clicked()
{
    bool exist1=false, exist2=false;
    extern QString qDir;
    extern std::string Dir;

    QString qfolder = ui->folderLine->text();
    QString qproject = ui->projectLine->text();
    QString qError;
    qfolder=makeSlashLast(qfolder);

	exist1=QDir(qfolder).exists();
    checkProjectName(qproject);
    qError=checkProjectName(qproject);

    QString HNCO=ui->HNCOLine->text();
    QString HSQC=ui->HSQCLine->text();
    QString HNCACO=ui->HNCACOLine->text();
    QString HNCACB=ui->HNCACBLine->text();
    QString HNCOCACB=ui->HNCOCACBLine->text();
    QString HNCA=ui->HNCALine->text();
    QString HNCOCA=ui->HNCOCALine->text();
    if (HNCO=="" && HSQC=="" && HNCACO=="" && HNCACB=="" && HNCA=="" && HNCOCACB=="" && HNCOCA=="")
    {
        qError = "Please submit at least one input file.";
    }
    if (qError!="")
    {
            extern QString errorMessage2;
            errorMessage2="Error!";
            extern QString errorMessage;
            errorMessage=qError;
            showError();
            return;
    }
    else if(ui->projectLine->text()=="")
    {
        extern QString errorMessage2;
        errorMessage2="Error!";
        extern QString errorMessage;
        errorMessage="Please submit a project name.";
        showError();
        return;
    }
    else
    {
		qfolder+= ui->projectLine->text();
        qfolder = makeSlashLast(qfolder);
        qDir=qfolder;
        Dir=qfolder.toUtf8().data();
    }

    exist2=QDir(qfolder).exists();
	if(exist1==false)
	{
        QueryError6 winQE6;
        winQE6.setWindowModality(Qt::ApplicationModal);
        if(winQE6.exec())
            analysis();
        else
            return;
	}
	else if(exist2==true)
	{
        QueryError5 winQE5;
        winQE5.setWindowModality(Qt::ApplicationModal);
        if(winQE5.exec())
            return;
	}
	else if(exist2==false && exist1==true)
                analysis();

}
int CompassSpinSystem::analysis()
{
	Clear_HSQCarray();

    extern QString qDir;
    extern std::string Dir;

	QString path=ui->HNCOLine->text(); 
	std::string HNCOfile;
	QByteArray nByte= path.toUtf8();
	HNCOfile=nByte.data();
	
	path=ui->HSQCLine->text(); 
	std::string HSQCfile;
	nByte= path.toUtf8();
	HSQCfile=nByte.data();

	path=ui->HNCACOLine->text(); 
	std::string HNCACOfile;
	nByte= path.toUtf8();
	HNCACOfile=nByte.data();
	
	path=ui->HNCACBLine->text(); 
	std::string HNCACBfile;
	nByte= path.toUtf8();
	HNCACBfile=nByte.data();
	
	path=ui->HNCOCACBLine->text(); 
	std::string HNCOCACBfile;
	nByte= path.toUtf8();
	HNCOCACBfile=nByte.data();
	
	path=ui->HNCALine->text(); 
	std::string HNCAfile;
	nByte= path.toUtf8();
	HNCAfile=nByte.data();

	path=ui->HNCOCALine->text(); 
	std::string HNCOCAfile;
	nByte= path.toUtf8();
	HNCOCAfile=nByte.data();
	
	path=ui->RefBox->currentText(); 
	std::string RefBox;
	nByte= path.toUtf8();
	RefBox=nByte.data();


	QString filesOK="";
	if (HSQCfile!="")
		filesOK=File_Format_Check2D(HSQCfile);
	if (HNCOfile!="" && filesOK=="")
		filesOK=File_Format_Check3D(HNCOfile,"CO");
	if (HNCACOfile!="" && filesOK=="")
		filesOK=File_Format_Check3D(HNCACOfile,"CO");
	if (HNCACBfile!="" && filesOK=="")
		filesOK=File_Format_Check3D(HNCACBfile,"CB");
	if (HNCOCACBfile!="" && filesOK=="")
		filesOK=File_Format_Check3D(HNCOCACBfile,"CB");
	if (HNCAfile!="" && filesOK=="")
		filesOK=File_Format_Check3D(HNCAfile,"CA");
	if (HNCOCAfile!="" && filesOK=="")
		filesOK=File_Format_Check3D(HNCOCAfile,"CA");

	bool CACB=false;
	if (ui -> CAinCBCheck -> isChecked())
		CACB=true;

    bool error=false;
	if(HNCOfile=="" && HSQCfile=="")
	{
		error=true;
	}
    if(error==false && filesOK=="")
	{

        if(QDir(qDir).exists()==false)
        {
           QDir dir=QDir::root();
           dir.mkpath(qDir);
        }
        else
        {
           removeFiles(qDir);
        }
		
		double Ndev, Cdev, Hdev;
		
		Ndev = ui->devNBox->value();
		Cdev = ui->devCBox->value();
		Hdev = ui->devHBox->value();
	
		std::string paramin;
        paramin=Dir+"label.cpar";
		std::ofstream fileo;
        std::string fileout;
		fileo.open(paramin.c_str(), std::ios::out);

        if (HNCAfile!="")
        {
            unsigned found=HNCAfile.find_last_of("/");
            fileout=Dir+HNCAfile.substr(found+1)+".compass";
            fileo<<fileout<<"\n";
        }
        else
            fileo<<"EMPTY\n";
        if (HNCOCAfile!="")
        {
            unsigned found=HNCOCAfile.find_last_of("/");
            fileout=Dir+HNCOCAfile.substr(found+1)+".compass";
            fileo<<fileout<<"\n";
        }
        else
            fileo<<"EMPTY\n";
        if (HNCACBfile!="")
        {
            unsigned found=HNCACBfile.find_last_of("/");
            fileout=Dir+HNCACBfile.substr(found+1)+".compass";
            fileo<<fileout<<"\n";
        }
        else
            fileo<<"EMPTY\n";
        if (HNCOCACBfile!="")
        {
            unsigned found=HNCOCACBfile.find_last_of("/");
            fileout=Dir+HNCOCACBfile.substr(found+1)+".compass";
            fileo<<fileout<<"\n";
        }
        else
            fileo<<"EMPTY\n";
        if (HNCACOfile!="")
        {
            unsigned found=HNCACOfile.find_last_of("/");
            fileout=Dir+HNCACOfile.substr(found+1)+".compass";
            fileo<<fileout<<"\n";
        }
        else
            fileo<<"EMPTY\n";
        if (HNCOfile!="")
        {
            unsigned found=HNCOfile.find_last_of("/");
            fileout=Dir+HNCOfile.substr(found+1)+".compass";
            fileo<<fileout<<"\n";
        }
        else
            fileo<<"EMPTY\n";
        if (HSQCfile!="")
        {
            unsigned found=HSQCfile.find_last_of("/");
            fileout=Dir+HSQCfile.substr(found+1)+".compass";
            fileo<<fileout<<"\n";
        }
        else
        {
            unsigned found=HNCOfile.find_last_of("/");
            fileout=Dir+HNCOfile.substr(found+1)+".hsqc.compass";
            fileo<<fileout<<"\n";
        }

        fileo<<"EMPTY"<<"\n"<<"EMPTY"<<"\n";
        fileo<<"NO"<<"\n"<<"1"<<"\n"<<"Double labeled"<<"\n"<<"0.2"<<"\n"<<"0.2"<<"\n"<<"0.2"<<"\n"<<"10"<<"\n"<<"10"<<"\n"<<"10"<<"\n";
		if (HSQCfile!="")
			fileo<<HSQCfile<<"\n";
		else
			fileo<<"EMPTY\n";
		if (HNCACOfile!="")
			fileo<<HNCACOfile<<"\n";
		else
			fileo<<"EMPTY\n";
		if (HNCOfile!="")
			fileo<<HNCOfile<<"\n";
		else
			fileo<<"EMPTY\n";
		if (HNCACBfile!="")
			fileo<<HNCACBfile<<"\n";
		else
			fileo<<"EMPTY\n";
		if (HNCOCACBfile!="")
			fileo<<HNCOCACBfile<<"\n";
		else
			fileo<<"EMPTY\n";
		if (HNCAfile!="")
			fileo<<HNCAfile<<"\n";
		else
			fileo<<"EMPTY\n";
		if (HNCOCAfile!="")
			fileo<<HNCOCAfile<<"\n";
		else
			fileo<<"EMPTY\n";
		fileo<<Ndev<<"\n"<<Cdev<<"\n"<<Hdev<<"\n";
		if(ui->CAinCBCheck->isChecked())
			fileo<<"YES\n";
		else
			fileo<<"NO\n";
		if(ui->CAButton->isChecked())
			fileo<<"CA\n";
		else
			fileo<<"CB\n";
        fileo<<RefBox<<"\n";
        fileo<<makeSlashLast(ui->folderLine->text()).toUtf8().data()<<"\n";
        fileo<<ui->projectLine->text().toUtf8().data()<<"\n";
		fileo.clear();
		fileo.close();
	
        if(HSQCfile!="" && HNCOfile=="" && (ui->RefBox->currentText()=="HSQC" || ui->RefBox->currentText()=="All lists"))
			Fake_AssignHSQC();
        else if(HNCOfile=="" && HSQCfile!="" && (ui->RefBox->currentText()=="HNCO (i-1)" || ui->RefBox->currentText()=="HNCO (i-1) and HSQC"))
		{
				extern QString errorMessage,errorMessage2;
                errorMessage="Choose 'HSQC' or 'All Lists' as 'Spin system reference' if no HNCO (i-1) is submitted.";
				errorMessage2="Error!";
                showError();
				return 0;
		}
		else if(HNCOfile!="" && HSQCfile=="")
		{
			if( ui->RefBox->currentText()=="HNCO (i-1)" ||  ui->RefBox->currentText()=="All lists" )
				Fake_AssignnoHSQC();
			else
			{
				extern QString errorMessage,errorMessage2;
                errorMessage="Choose 'HNCO (i-1)' or 'All Lists' as 'Spin system reference' if no HSQC is submitted.";
				errorMessage2="Error!";
                showError();
				return 0;
			}
		}
        else if(HNCOfile!="" && HSQCfile!="" && ui->RefBox->currentText()!="HSQC")
			Fake_AssignHSQCandHNCO();
        else
            Fake_AssignHSQC();

		if(HNCOfile!="" && HNCACOfile!="")
			Fake_AssignHNCOandHNCACO();
		else if(HNCOfile=="" && HNCACOfile!="")
			Fake_AssignHNCACO();
		else if(HNCOfile!="" && HNCACOfile=="")
			Fake_AssignHNCO();
	
		if(HNCACBfile!="" && HNCOCACBfile!="" && CACB==true)
			Fake_AssignHNCACBandHNCOCACB();
        else if(HNCACBfile!="" && HNCOCACBfile=="" && CACB==true)
			Fake_AssignHNCACB();
        else if(HNCACBfile=="" && HNCOCACBfile!="" && CACB==true)
            Fake_AssignCBCACONH();

		if(HNCACBfile!="" && HNCOCACBfile!="" && CACB==false)
			Fake_AssignHNcaCBandHNcocaCB();
		else if(HNCACBfile!="" && HNCOCACBfile=="" && CACB==false)
			Fake_AssignHNcaCB();
		else if(HNCACBfile=="" && HNCOCACBfile!="" && CACB==false)
			Fake_AssignHNcocaCB();
	
		if(HNCAfile!="" && HNCOCAfile!="")
			Fake_AssignHNCAandHNCOCA();
		else if(HNCAfile!="" && HNCOCAfile=="")
			Fake_AssignHNCA();
		else if(HNCAfile=="" && HNCOCAfile!="")
			Fake_AssignHNCOCA();
	}
    else if(error==true)
	{
		extern QString errorMessage,errorMessage2;
        errorMessage="Please include either HNCO (i-1) file or HSQC";
		errorMessage2="Error!";
        showError();
		return 0;
	}
    else if(filesOK!="")//
	{
		extern QString errorMessage,errorMessage2;
		errorMessage2="Error!";
		errorMessage=filesOK;
        showError();
		return 0;
	}
	std::string HSQCfileout;
	if (HSQCfile=="")
	{
		unsigned found=HNCOfile.find_last_of("/");
        HSQCfileout=Dir+HNCOfile.substr(found+1)+".hsqc.compass";
	}
	else
	{
		unsigned found=HSQCfile.find_last_of("/");
        HSQCfileout=Dir+HSQCfile.substr(found+1)+".compass";
	}
	std::ofstream fileo;
    extern int counterhsqc;
    extern std::vector< std::vector< std::string > > HSQCarray;

    fileo.open(HSQCfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2"<<std::endl;

    for(int i=0;i<counterhsqc-2;i++)
    {
        if(HSQCarray[i][0]=="?")
            fileo<<std::endl<<HSQCarray[i][0]<<"-?  "<<HSQCarray[i][2]<<"  "<<HSQCarray[i][4];
        else
            fileo<<std::endl<<HSQCarray[i][0]<<"N-HN  "<<HSQCarray[i][2]<<"  "<<HSQCarray[i][4];
    }
    fileo.clear();
	fileo.close();

    Make_Warnings();
    return 1;
}
QString CompassSpinSystem::File_Format_Check2D(std::string infile)
{
	std::ifstream file;
	std::string line, sub,sub1,sub2;
	file.open(infile.c_str(), std::ios::in);
	int counter=0;
	while(file.good())
	{
		getline(file,line);
		counter++;
	}
	file.clear();
	file.close();
	if (counter==0)
        return "The HSQC file does not exist or is empty. Please check your input file.";
    else if (counter<2)
        return "The HSQC file does not have a valid format. Please check your input file.";
    file.open(infile.c_str(), std::ios::in);
    getline(file,line);
    getline(file,line);
	if (line!="")
	{
		file.clear();
		file.close();
        return "The submitted HSQC file does not have a valid format. Line 2 must be empty. Please check your input file.";
	}
	QString retstr="";
    for (int k=0;k<counter-3;k++)
	{
		getline(file,line);
		std::string shift1,shift2,data,linetemp;
		linetemp=line;
		std::istringstream iss(line);
		int lc=0;
		while (iss>>sub)
			lc++;
        if (lc==0)
        {
            retstr= "The HSQC file contains an empty line that is illegal for non-header lines. (Line:" % QString::number(k+3)% ") Please check you input file.";
            break;
        }
        else if (lc!=4)
        {
            retstr= "The number of columns in the HSQC file is not correct. Please check your input file.";
			break;
		}
		else
		{
			std::istringstream iss2(linetemp);
			iss2>>shift1;
			iss2>>shift1;
			iss2>>shift2;
			iss2>>data; 
			int num = shift1.length();
			for (int i=0;i<num;i++)
			{
				if (!isdigit(shift1[i]) && shift1[i]!='.')
				{
                    retstr= "Column 2 in the submitted HSQC file contains a non-numerical symbol. (Line:" % QString::number(k+3)% ") Please check your input file.";
					break;
				}
			}
			if (retstr!="")
				break;
			num = shift2.length();
			for (int i=0;i<num;i++)
			{
				if (!isdigit(shift2[i]) && shift2[i]!='.')
				{
                    retstr= "Column 3 in the submitted HSQC file contains a non-numerical symbol. (Line:" % QString::number(k+3)% ") Please check your input file.";
					break;
				}
			}
			if (retstr!="")
				break;
			if (atof(shift1.c_str())<=90.0 || atof(shift1.c_str())>145.0)
			{
                retstr= "Column 2 in the submitted HSQC file does not contain nitrogen chemical shifts. (Line:" % QString::number(k+3)% ") Please check your input file.";
				break;
			}
			if (atof(shift2.c_str())<=2.0 || atof(shift2.c_str())>14.0)
			{
                retstr= "Column 3 in the submitted HSQC file does not contain hydrogen chemical shifts. (Line:" % QString::number(k+3)% ") Please check your input file.";
				break;
			}
			num = data.length();
			for (int i=0;i<num;i++)
			{
				if (!isdigit(data[i]) && data[0]!='-')
				{
                    retstr= "Column 4 in the submitted HSQC file contains a non-numerical symbol. (Line:" % QString::number(k+3)% ") Please check your input file.";
					break;
				}
			}
			if (retstr!="")
				break;
		}
	}
	file.clear();
	file.close();
	return retstr;
}
QString CompassSpinSystem::File_Format_Check3D(std::string infile, std::string Ctype)
{
	std::ifstream file;
	std::string line, sub,sub1,sub2;
	QString retstr="";
	file.open(infile.c_str(), std::ios::in);
	int counter=0;
	while(file.good())
	{
		getline(file,line);
		counter++;
	}
	file.clear();
	file.close();
	if (counter==0)
	{
		retstr= QString::fromUtf8(infile.c_str());
        retstr += " is empty or does not exist. Please check your input file.";
		return retstr; 
	}
    else if (counter<2)
    {
        retstr= QString::fromUtf8(infile.c_str());
        retstr += " does not have a valid format. Please check your input file.";
        return retstr;
    }
	file.open(infile.c_str(), std::ios::in);
	getline(file,line);
	getline(file,line);
	if (line!="")
	{
		file.clear();
		file.close();
		retstr= QString::fromUtf8(infile.c_str());
        retstr += " does not have a valid format. Line 2 must be empty. Please check your input file.";
	}
    for (int k=0;k<counter-3;k++)
	{
		getline(file,line);
		std::string shift1,shift2,shiftC,data,linetemp;
		linetemp=line;
		std::istringstream iss(line);
		int lc=0;
		while (iss>>sub)
			lc++;
        if (lc==0)
        {
            retstr= QString::fromUtf8(infile.c_str());
            retstr += " contains an empty line that is illegal for non-header lines. (Line:" % QString::number(k+3)% ") Please check you input file.";
        }
        else if (lc!=5)
		{
			retstr= QString::fromUtf8(infile.c_str());
            retstr += " does not have the correct number of columns. Please check your input file.";
			break;
		}
		else
		{
			std::istringstream iss2(linetemp);
			iss2>>shift1;
			iss2>>shift1;
			iss2>>shiftC;
			iss2>>shift2;
			iss2>>data; 
			int num = shift1.length();
			for (int i=0;i<num;i++)
			{
				if (!isdigit(shift1[i]) && shift1[i]!='.')
				{
					retstr = "Column 2 in ";
					retstr += QString::fromUtf8(infile.c_str());
                    retstr += " contains a non-numerical symbol. (Line:" % QString::number(k+3)% ") Please check your input file.";
					break;
				}
			}
			if (retstr!="")
				break;
			num = shift2.length();
			for (int i=0;i<num;i++)
			{
				if (!isdigit(shift2[i]) && shift2[i]!='.')
				{
					retstr = "Column 4 in ";
					retstr += QString::fromUtf8(infile.c_str());
                    retstr += " contains a non-numerical symbol. (Line:" % QString::number(k+3)% ") Please check your input file.";
					break;
				}
			}
			if (retstr!="")
				break;
			for (int i=0;i<num;i++)
			{
				if (!isdigit(shiftC[i]) && shiftC[i]!='.')
				{
					retstr = "Column 3 in ";
					retstr += QString::fromUtf8(infile.c_str());
                    retstr += " contains a non-numerical symbol. (Line:" % QString::number(k+3)% ") Please check your input file.";
					break;
				}
			}
			if (retstr!="")
				break;
			if (atof(shift1.c_str())<=90.0 || atof(shift1.c_str())>145.0)
			{
				retstr = "Column 2 in ";
				retstr += QString::fromUtf8(infile.c_str());
                retstr += " does not contain nitrogen chemical shifts. (Line:" % QString::number(k+3)% ") Please check your input file.";
				break;
			}
			if (atof(shift2.c_str())<=2.0 || atof(shift2.c_str())>14.0)
			{
				retstr = "Column 4 in ";
				retstr += QString::fromUtf8(infile.c_str());
                retstr += " does not contain hydrogen chemical shifts. (Line:" % QString::number(k+3)% ") Please check your input file.";
				break;
			}
			num = data.length();
			for (int i=0;i<num;i++)
			{
				if (!isdigit(data[i]) && data[0]!='-')
				{
					retstr = "Column 5 in ";
					retstr += QString::fromUtf8(infile.c_str());
                    retstr += " contains a non-numerical symbol. (Line:" % QString::number(k+3)% ") Please check your input file.";
					break;
				}
			}
			if (retstr!="")
				break;
			if (Ctype=="CA")
			{
				if (atof(shiftC.c_str())<=30.0 || atof(shiftC.c_str())>75.0)
				{
                    retstr = "Column 3 in ";
					retstr += QString::fromUtf8(infile.c_str());
                    retstr += " does not contain CA chemical shifts. (Line:" % QString::number(k+3)% ") Please check your input file.";
					break;
				}
			}
			else if(Ctype=="CB" )
			{
				if (atof(shiftC.c_str())<=0.0 || atof(shiftC.c_str())>90.0)
				{
                    retstr = "Column 3 in ";
					retstr += QString::fromUtf8(infile.c_str());
                    retstr += " does not contain valid chemical shifts. (Line:" % QString::number(k+3)% ") Please check your input file.";
					break;
				}
			}
			else
			{
				if (atof(shiftC.c_str())<=150.0 || atof(shiftC.c_str())>200.0)
				{
                    retstr = "Column 3 in ";
					retstr += QString::fromUtf8(infile.c_str());
                    retstr += " does not contain CO chemical shifts. (Line:" % QString::number(k+3)% ") Please check your input file.";
					break;
				}
			}

		}
	}
	file.clear();
	file.close();
	return retstr;
}
void CompassSpinSystem::load_project_parameters()
{
    QString path;
    path = QFileDialog::getOpenFileName(
	this,
    "Choose a parameter file",
	QString::null,
	tr("Parameter files (*.cpar)"));
    if(path!="")
		loadParam(path);
}
void CompassSpinSystem::loadParam(QString path)
{
	QByteArray qByte = path.toUtf8();
	std::string fname = qByte.data();
	std::ifstream file;
	std::string line;
	file.open(fname.c_str(), std::ios::in);
	for(int i=0;i<18;i++)
		getline(file, line);

    getline(file, line);
	QString qline = QString::fromUtf8(line.c_str());
    if (qline!="EMPTY" && !QFile::exists(qline))
    {
        extern QString errorMessage,errorMessage2;
        errorMessage="The parameter file refers to an HSQC file that does not exist.";
        errorMessage2="Error!";
        showError();
        return;
    }
    else if(qline!="EMPTY")
        ui->HSQCLine->setText(convSlash(qline));
	else 
		ui->HSQCLine->setText("");

    getline(file, line);
    qline = QString::fromUtf8(line.c_str());
    if (qline!="EMPTY" && !QFile::exists(qline))
    {
        extern QString errorMessage,errorMessage2;
        errorMessage="The parameter file refers to an HNCO (i)(i-1) file that does not exist.";
        errorMessage2="Error!";
        showError();
        return;
    }
    else if(qline!="EMPTY")
        ui->HNCACOLine->setText(convSlash(qline));
	else 
		ui->HNCACOLine->setText("");

    getline(file, line);
	qline = QString::fromUtf8(line.c_str());
    if (qline!="EMPTY" && !QFile::exists(qline))
    {
        extern QString errorMessage,errorMessage2;
        errorMessage="The parameter file refers to an HNCO (i-1) file that does not exist.";
        errorMessage2="Error!";
        showError();
        return;
    }
    else if(qline!="EMPTY")
        ui->HNCOLine->setText(convSlash(qline));
	else 
		ui->HNCOLine->setText("");

    getline(file, line);
    qline = QString::fromUtf8(line.c_str());
    if (qline!="EMPTY" && !QFile::exists(qline))
    {
        extern QString errorMessage,errorMessage2;
        errorMessage="The parameter file refers to an HNCB (i)(i-1) file that does not exist.";
        errorMessage2="Error!";
        showError();
        return;
    }
    else if(qline!="EMPTY")
        ui->HNCACBLine->setText(convSlash(qline));
	else 
		ui->HNCACBLine->setText("");

    getline(file, line);
	qline = QString::fromUtf8(line.c_str());
    if (qline!="EMPTY" && !QFile::exists(qline))
    {
        extern QString errorMessage,errorMessage2;
        errorMessage="The parameter file refers to an HNCB (i-1) file that does not exist.";
        errorMessage2="Error!";
        showError();
        return;
    }
    else if(qline!="EMPTY")
        ui->HNCOCACBLine->setText(convSlash(qline));
	else
		ui->HNCOCACBLine->setText("");

    getline(file, line);
	qline = QString::fromUtf8(line.c_str());
    if (qline!="EMPTY" && !QFile::exists(qline))
    {
        extern QString errorMessage,errorMessage2;
        errorMessage="The parameter file refers to an HNCA (i)(i-1) file that does not exist.";
        errorMessage2="Error!";
        showError();
        return;
    }
    else if(qline!="EMPTY")
        ui->HNCALine->setText(convSlash(qline));
	else if(qline=="EMPTY")
		ui->HNCALine->setText("");

    getline(file, line);
	qline = QString::fromUtf8(line.c_str());
    if (qline!="EMPTY" && !QFile::exists(qline))
    {
        extern QString errorMessage,errorMessage2;
        errorMessage="The parameter file refers to an HNCA (i-1) file that does not exist.";
        errorMessage2="Error!";
        showError();
        return;
    }
    else if(qline!="EMPTY")
        ui->HNCOCALine->setText(convSlash(qline));
	else if(qline=="EMPTY")
		ui->HNCOCALine->setText("");

    getline(file, line);
    int num = line.length();
    for (int i=0;i<num;i++)
        if (!isdigit(line[i]) && !line[i]=='.')
        {
            extern QString errorMessage,errorMessage2;
            errorMessage="The parameter file does not have the correct format.\n Please submit a valid parameter file.";
            errorMessage2="Error!";
            showError();
            return;
        }
	double m1 = atof(line.c_str());

    getline(file, line);
    num = line.length();
    for (int i=0;i<num;i++)
        if (!isdigit(line[i]) && !line[i]=='.')
        {
            extern QString errorMessage,errorMessage2;
            errorMessage="The parameter file does not have the correct format.\n Please submit a valid parameter file.";
            errorMessage2="Error!";
            showError();
            return;
        }
	double m2 = atof(line.c_str());

    getline(file, line);
    num = line.length();
    for (int i=0;i<num;i++)
        if (!isdigit(line[i]) && !line[i]=='.')
        {
            extern QString errorMessage,errorMessage2;
            errorMessage="The parameter file does not have the correct format.\n Please submit a valid parameter file.";
            errorMessage2="Error!";
            showError();
            return;
        }
	double m3 = atof(line.c_str());

    getline(file, line);
    if (line!="NO" && line!="YES")
    {
        extern QString errorMessage,errorMessage2;
        errorMessage="The parameter file does not have the correct format.";
        errorMessage2="Error!";
        showError();
        return;
    }
    else if(line=="NO")
		ui->CAinCBCheck->setChecked(false);
	else if(line=="YES")
		ui->CAinCBCheck->setChecked(true);

    getline(file, line);
    if (line!="CA" && line!="CB")
    {
        extern QString errorMessage,errorMessage2;
        errorMessage="Negative signals are either denoted 'CA' or 'CB'. \n Please submit a parameter file with correct format.";
        errorMessage2="Error!";
        showError();
        return;
    }
    else if(line=="CA")
		ui->CAButton->setChecked(true);
	else if(line=="CB")
		ui->CBButton->setChecked(true);

    getline(file, line);
    if (line!="HSQC" && line!="HNCO (i-1)" && line!="HNCO (i-1) and HSQC" && line!="All lists")
    {
        extern QString errorMessage,errorMessage2;
        errorMessage="Allowed spin system references are 'HSQC', 'HNCO (i-1)', 'HNCO (i-1) and HSQC' and 'All lists'. \n Please submit a parameter file with correct format.";
        errorMessage2="Error!";
        showError();
        return;
    }
    else if(line=="HSQC")
	{
		int index = ui->RefBox->findText("HSQC");
		ui->RefBox->setCurrentIndex(index);
	}
    else if(line=="HNCO (i-1)")
	{
		int index = ui->RefBox->findText("HNCO (i-1)");
		ui->RefBox->setCurrentIndex(index);
	}
    else if(line=="HNCO (i-1) and HSQC")
	{
		int index = ui->RefBox->findText("HNCO (i-1) and HSQC");
		ui->RefBox->setCurrentIndex(index);
	}
    else if(line=="All lists")
	{
		int index = ui->RefBox->findText("All lists");
		ui->RefBox->setCurrentIndex(index);
	}
    getline(file,line);
    QDir fold(QString::fromUtf8(line.c_str()));
    if (fold.exists())
        ui->folderLine->setText(QString::fromUtf8(line.c_str()));
    getline(file,line);
    ui->projectLine->setText(QString::fromUtf8(line.c_str()));
    file.clear();
	file.close();
	ui->devNBox->setValue(m1);
	ui->devCBox->setValue(m2);
	ui->devHBox->setValue(m3);
}
void CompassSpinSystem::Clear_HSQCarray()
{
    extern int counterhsqc;
    extern int counternum;
    counterhsqc=0;
    counternum=10;

    extern std::vector<std::string> HSQCsub;
    extern std::vector<double> Spinsub;
    extern std::vector< std::vector< std::string > > HSQCarray;
    extern std::vector< std::vector< double > > SpinSysarray;
    HSQCarray.erase(HSQCarray.begin(), HSQCarray.end());
    SpinSysarray.erase(SpinSysarray.begin(), SpinSysarray.end());
    Spinsub.erase(Spinsub.begin(), Spinsub.end());
    HSQCsub.erase(HSQCsub.begin(), HSQCsub.end());

}
bool CompassSpinSystem::Check_CACB_Limits(std::string fname)
{
    std::ifstream file;
    std::ofstream wfile;
    file.open(fname.c_str(), std::ios::in);
    std::string line, str;
    std::vector<std::string> out;
    str="In the file "+fname;
    out.push_back(str);
    int count=0;
    while(getline(file, line))
    {
        if(count>1)
        {
         std::istringstream iss(line);
         std::string pname, shift1, shift2, shift3;
         iss>>pname;
         iss>>shift1;
         iss>>shift2;
         iss>>shift3;
         if(atof(shift2.c_str())>45 && atof(shift2.c_str())<62 && pname.substr(pname.find_last_of("-")-1,1)=="B")
         {
             str="Peak "+pname;
             for(uint j=0; j<20-pname.length();j++)
                 str+=" ";
             str+=shift1+"  "+shift2+"  "+shift3+"  might be a CA resonance.";
             out.push_back(str);
         }
         if((atof(shift2.c_str())<42 || atof(shift2.c_str())>65) && pname.substr(pname.find_last_of("-")-1,1)=="A") //CA som är döpt som CB
         {
             str="Peak "+pname;
             for(uint j=0; j<20-pname.length();j++)
                 str+=" ";
             str+=shift1+"  "+shift2+"  "+shift3+"  might be a CB resonance.";
             out.push_back(str);
         }
        }
        count++;
    }
    file.clear();
    file.close();
    if(out.size()>1)
    {
        wfile.open("warning.txt", std::ios::app);
        for(unsigned int i=0; i<out.size(); i++)
            wfile<<out[i]<<"\n";
        wfile.clear();
        wfile.close();
        return true;
    }
    return false;
}
void CompassSpinSystem::Make_Warnings()
{
	QString path=ui->HNCOLine->text(); 
	std::string HNCOfile;
	QByteArray nByte= path.toUtf8();
	HNCOfile=nByte.data();
	
	path=ui->HSQCLine->text(); 
	std::string HSQCfile;
	nByte= path.toUtf8();
	HSQCfile=nByte.data();

	path=ui->HNCACOLine->text(); 
	std::string HNCACOfile;
	nByte= path.toUtf8();
	HNCACOfile=nByte.data();
	
	path=ui->HNCACBLine->text(); 
	std::string HNCACBfile;
	nByte= path.toUtf8();
	HNCACBfile=nByte.data();
	
	path=ui->HNCOCACBLine->text(); 
	std::string HNCOCACBfile;
	nByte= path.toUtf8();
	HNCOCACBfile=nByte.data();
	
	path=ui->HNCALine->text(); 
	std::string HNCAfile;
	nByte= path.toUtf8();
	HNCAfile=nByte.data();

	path=ui->HNCOCALine->text(); 
	std::string HNCOCAfile;
	nByte= path.toUtf8();
	HNCOCAfile=nByte.data();

    extern std::string Dir;
    extern QString qDir;

    std::string line,warfile,HSQCfileout,HNCOfileout,HNCACOfileout,HNCACBfileout,HNCOCACBfileout,HNCAfileout,HNCOCAfileout;
	std::ofstream fileo;
	std::ofstream fileo2;
    fileo.open("warning.txt",std::ios::out);
	fileo.clear();
	fileo.close();
	bool warnings=false,check=false;
    if (HSQCfile=="")
	{
		unsigned found=HNCOfile.find_last_of("/");
        HSQCfileout=Dir+HNCOfile.substr(found+1)+".hsqc.compass";
		check=Check_Duplicates(HSQCfileout);
		if (check==true)
			warnings=true;
		check=Check_UnAssigned(HSQCfileout);
		if (check==true)
			warnings=true;
	}
	else
	{
		unsigned found=HSQCfile.find_last_of("/");
        HSQCfileout=Dir+HSQCfile.substr(found+1)+".compass";
		check=Check_Duplicates(HSQCfileout);
		if (check==true)
			warnings=true;
		check=Check_UnAssigned(HSQCfileout);
		if (check==true)
			warnings=true;
	}
	if (HNCOfile!="")
	{
		unsigned found=HNCOfile.find_last_of("/");
        HNCOfileout=Dir+HNCOfile.substr(found+1)+".compass";
		check=Check_Duplicates(HNCOfileout);
		if (check==true)
			warnings=true;
		check=Check_UnAssigned(HNCOfileout);
		if (check==true)
			warnings=true;
	}
	if (HNCACOfile!="")
	{
		unsigned found=HNCACOfile.find_last_of("/");
        HNCACOfileout=Dir+HNCACOfile.substr(found+1)+".compass";
		check=Check_Duplicates(HNCACOfileout);
		if (check==true)
			warnings=true;
		check=Check_UnAssigned(HNCACOfileout);
		if (check==true)
			warnings=true;
	}
	if (HNCACBfile!="")
	{
		unsigned found=HNCACBfile.find_last_of("/");
        HNCACBfileout=Dir+HNCACBfile.substr(found+1)+".compass";
		check=Check_Duplicates(HNCACBfileout);
		if (check==true)
			warnings=true;
		check=Check_UnAssigned(HNCACBfileout);
		if (check==true)
			warnings=true;
        if(ui->CAinCBCheck->isChecked())
        {
            check=Check_CACB_Limits(HNCACBfileout);
        }
        if (check==true)
            warnings=true;
	}
	if (HNCOCACBfile!="")
	{
		unsigned found=HNCOCACBfile.find_last_of("/");
        HNCOCACBfileout=Dir+HNCOCACBfile.substr(found+1)+".compass";
		check=Check_Duplicates(HNCOCACBfileout);
		if (check==true)
			warnings=true;
		check=Check_UnAssigned(HNCOCACBfileout);
		if (check==true)
			warnings=true;
        if(ui->CAinCBCheck->isChecked())
        {
            check=Check_CACB_Limits(HNCOCACBfileout);
        }
        if (check==true)
            warnings=true;
	}
	if (HNCAfile!="")
	{
		unsigned found=HNCAfile.find_last_of("/");
        HNCAfileout=Dir+HNCAfile.substr(found+1)+".compass";
		check=Check_Duplicates(HNCAfileout);
		if (check==true)
			warnings=true;
		check=Check_UnAssigned(HNCAfileout);
		if (check==true)
			warnings=true;
	}
	if (HNCOCAfile!="")
	{
		unsigned found=HNCOCAfile.find_last_of("/");
        HNCOCAfileout=Dir+HNCOCAfile.substr(found+1)+".compass";
		check=Check_Duplicates(HNCOCAfileout);
		if (check==true)
			warnings=true;
		check=Check_UnAssigned(HNCOCAfileout);
		if (check==true)
			warnings=true;
	}
    FILE * fileo1;
	fileo1 = fopen ("spinsystems.list","w");

    {
        extern std::vector< std::vector <double> > SpinSysarray;
        extern std::vector<double> Spinsub;

        extern int counterhsqc;

        for (int i=1;i<counterhsqc-1;i++)
        {
            if (SpinSysarray[i][0]!=0.0)
            {
                for (int j=0;j<9;j++)
                {
                    if (j==0)
                            fprintf (fileo1, "%6.0f ", SpinSysarray[i][j]);
                    else if (j==1)
                            fprintf (fileo1, "%11.3f ", SpinSysarray[i][j]);
                    else if (j==2)
                            fprintf (fileo1, "%6.3f ", SpinSysarray[i][j]);
                    else if ( j==3)
                    {
                        if (SpinSysarray[i][j]==0.0)
                            fprintf (fileo1, "%7.0f ", SpinSysarray[i][j]);
                        else
                            fprintf (fileo1, "%5.3f ", SpinSysarray[i][j]);
                    }
                    else if (j==4)
                    {
                        if (SpinSysarray[i][j]==0.0)
                            fprintf (fileo1, "%8.0f +/- 0.00 ", SpinSysarray[i][j]);
                        else
                        {
                            fprintf (fileo1, "%8.3f", SpinSysarray[i][j]);
                            fprintf (fileo1, " +/-%5.2f ", SpinSysarray[i][9]);//
                        }
                    }
                    else if (j==6)
                    {
                        if (SpinSysarray[i][j]==0.0)
                            fprintf (fileo1, "%7.0f +/- 0.00 ", SpinSysarray[i][j]);
                        else
                        {
                            fprintf (fileo1, "%7.3f", SpinSysarray[i][j]);
                            fprintf (fileo1, " +/-%5.2f ", SpinSysarray[i][10]);//
                        }
                    }
                    else if (j==8)
                    {
                        if (SpinSysarray[i][j]==0.0)
                            fprintf (fileo1, "%7.0f +/- 0.00\n", SpinSysarray[i][j]);
                        else
                        {
                            fprintf (fileo1, "%7.3f", SpinSysarray[i][j]);
                            fprintf (fileo1, " +/-%5.2f\n", SpinSysarray[i][11]);//
                        }
                    }
                    else
                    {
                        if (SpinSysarray[i][j]==0.0)
                            fprintf (fileo1, "%7.0f ", SpinSysarray[i][j]);
                        else
                            fprintf (fileo1, "%7.3f ", SpinSysarray[i][j]);
                    }
                }
            }
		}
	}
	fclose (fileo1);

	if(warnings==false)
        remove("warning.txt");

{
        extern QString fileRes,fileWarn;

        fileRes="spinsystems.list";
        fileWarn="warning.txt";
        CompassSSResults *winResults;
        winResults = new CompassSSResults(this);
        winResults->show();
        hide();

        QString file1, file2;

        file1= "warning.txt";
        file2= qDir;
        file2+="warning.txt";

        QFile::copy(file1, file2);

        remove(file1.toStdString().c_str());
}
    QString file1, file2;
    file1= "spinsystems.list";
    file2+=qDir;
    file2+="spinsystems.list";

    QFile::copy(file1, file2);

    remove(file1.toStdString().c_str());

}
void CompassSSResults::on_closeButton_clicked()
{
    CompassSpinSystem *winSS;
    winSS = new CompassSpinSystem(this);
    winSS->show();
    hide();
}
bool CompassSpinSystem::Check_Duplicates(std::string infile)
{
	int counter=0,counter2=1;
	std::ofstream wfile;
	std::ifstream file;
	std::string line; 
    wfile.open("warning.txt", std::ios::app);
	file.open(infile.c_str(), std::ios::in);
	while(file.good())
	{
		getline(file,line);
		counter++;
	}
	counter--;

	file.clear();
	file.close();


    std::vector < std::string > array2;
    std::vector < std::string > array=DefVec(counter);
    array2.push_back("In the file "+infile);


    file.open(infile.c_str(), std::ios::in);

    getline(file,line);
    getline(file,line);

    for (int i=0;i<counter-1;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
        array[i]=sub;
	}
    for (int i=0;i<counter-1;i++)
	{
		for (int j=i+1;j<counter-1;j++)
        {
			if (array[i].substr(0,1)!="?" && array[i].substr(0,2)!="N-" && array[i]==array[j])
			{
                array2.push_back(array[i]);
				counter2++;

			}
		}
	}
	file.clear();
	file.close();

    if (counter2>1)
	{
		for(int i=0;i<counter2;i++)
		{
			if (i>0)
                wfile<<"Non-unique peak:   "<<array2[i]<<"\n";
			else
				wfile<<array2[i]<<"\n";
		}
		wfile<<"\n";
	}
    wfile.clear();
	wfile.close();

	if (counter2>1)
		return true;
	else
		return false;
}
bool CompassSpinSystem::Check_UnAssigned(std::string infile)
{
	int counter=0,counter2=1;
	std::ofstream wfile;
	std::ifstream file;
	std::string line; 
    wfile.open("warning.txt", std::ios::app);
	file.open(infile.c_str(), std::ios::in);
	while(file.good())
	{
		getline(file,line);
		counter++;
	}
	counter--;
	file.clear();
	file.close();
	file.open(infile.c_str(), std::ios::in);

	getline(file,line);
	getline(file,line);

    std::vector < std::string > array=DefVec(counter+3);
	array[0]="In the file "+infile;
	for (int i=0;i<counter-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;

		iss >> sub;
		unsigned pos=sub.find_last_of("-");
		std::string sub1=sub.substr(pos-1,1);
		if ((sub.substr(0,1)=="?" || sub.substr(0,2)=="N-" ) || ( sub1!="A" && sub1!="B" && sub1!="O" && sub1!="N"  ))
		{
					array[counter2]=line;
					counter2++;
		}
	}
	file.close();
	if (counter2>1)
	{
		for(int i=0;i<counter2;i++)
		{
			if (i>0)
                wfile<<"Not properly labeled peak:   "<<array[i]<<"\n";
			else	
				wfile<<array[i]<<"\n";
		}
		wfile<<"\n";
	}
	wfile.clear();
	wfile.close();
	if (counter2>1)
		return true;
	else
		return false;
}
void CompassSpinSystem::Fake_AssignHSQCandHNCO()
{
	QString path=ui->HSQCLine->text(); 
	std::string HSQCfile;
	QByteArray nByte= path.toUtf8();
	HSQCfile=nByte.data();

	path=ui->HNCOLine->text(); 
	std::string HNCOfile;
	nByte= path.toUtf8();
	HNCOfile=nByte.data();

	std::string line;

	double Ndev, Hdev;
	
	Ndev = ui->devNBox->value();
	Hdev = ui->devHBox->value();

	std::ifstream file;
	std::ofstream fileo;
	file.open(HSQCfile.c_str(), std::ios::in);
    extern int counterhsqc;
	while(file.good())
	{
		getline(file,line);
		counterhsqc++;
	}
	counterhsqc--;
	file.clear();
	file.close();
	file.open(HSQCfile.c_str(), std::ios::in);
	getline(file,line);
	getline(file,line);
    extern int counternum;
    extern std::vector< std::vector < std::string > > HSQCarray;
    extern std::vector<std::string> HSQCsub;

	for(int i=0;i<counterhsqc-2;i++)
	{
        HSQCsub.erase(HSQCsub.begin(), HSQCsub.end());
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		std::stringstream ss,ss2;
		ss << counternum;
		std::string sub2,sub3;
		ss >> sub2;
        HSQCsub.push_back(sub2);

		counternum--;
		ss2 << counternum;
		ss2 >> sub3;
        HSQCsub.push_back(sub3);

		counternum++;
		iss >> sub;
		iss >> sub;
        HSQCsub.push_back(sub);
        HSQCsub.push_back("0");
		iss >> sub;
        HSQCsub.push_back(sub);

		iss >> sub;
        HSQCsub.push_back(sub);

		counternum += 10;
        HSQCarray.push_back(HSQCsub);
	}
	file.clear();
	file.close();

	int countertemp=counterhsqc;

	file.open(HNCOfile.c_str(), std::ios::in);
    int counterhnco=0;
	while(file.good())
	{
		getline(file,line);
		counterhnco++;
	}
	counterhnco--;
	file.clear();
	file.close();
	file.open(HNCOfile.c_str(), std::ios::in);
    std::vector < std::vector < std::string > > HNCOarray=DefVec2(counterhnco-2,6);
	getline(file,line);
	getline(file,line);
	for(int i=0;i<counterhnco-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNCOarray[i][2]=sub;
		iss >> sub;
		HNCOarray[i][3]=sub;
		iss >> sub;
		HNCOarray[i][4]=sub;
		iss >> sub;
		HNCOarray[i][5]=sub;
	}
	file.clear();
	file.close();


	for(int j=0;j<counterhnco-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(HNCOarray[j][2].c_str()) >= (atof(HSQCarray[i][2].c_str()) - Ndev) &&  atof(HNCOarray[j][2].c_str()) <= (atof(HSQCarray[i][2].c_str()) + Ndev) && atof(HNCOarray[j][4].c_str()) >= (atof(HSQCarray[i][4].c_str()) - Hdev) &&  atof(HNCOarray[j][4].c_str()) <= (atof(HSQCarray[i][4].c_str()) + Hdev ))
			{
				HNCOarray[j][0]=HSQCarray[i][0];
				HNCOarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
			else if(i==counterhsqc-3 && ui->RefBox->currentText()!="HSQC" )
			{
				std::stringstream ss,ss2;
				std::string sub;
				ss << counternum;
				ss >> sub;
				HNCOarray[j][0]=sub;
                HSQCsub.erase(HSQCsub.begin(), HSQCsub.end());
                HSQCsub.push_back(sub);
				counternum--;
				ss2 << counternum;
				ss2 >> sub;
				HNCOarray[j][1]=sub;
                HSQCsub.push_back(sub);

                HSQCsub.push_back(HNCOarray[j][2]);

                HSQCsub.push_back("0");
                HSQCsub.push_back(HNCOarray[j][4]);

                HSQCarray.push_back(HSQCsub);
				counternum++;
				countertemp++;
				counternum += 10;
			}
			else if(i==counterhsqc-3 && ui->RefBox->currentText()=="HSQC" )
				HNCOarray[j][0]="?";
		}
	}

	counterhsqc=countertemp;

	if(ui->RefBox->currentText()=="HNCO (i-1)")
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			for(int j=0;j<counterhnco-2;j++)
			{
				if(atof(HNCOarray[j][0].c_str()) == atof(HSQCarray[i][0].c_str()))
                    break;
				else if(j==counterhnco-3)
                    HSQCarray[i][0]="?";
            }
		}
    }

	{
        extern std::vector< std::vector < double > > SpinSysarray; //[5000][12]
        extern std::vector<double> Spinsub;
        for(int i=0; i<counterhsqc-1; i++)
        {
            Spinsub.erase(Spinsub.begin(), Spinsub.end());
            for(int j=0; j<12; j++)
                Spinsub.push_back(0.0);
            SpinSysarray.push_back(Spinsub);
        }

    int num=0;
	for(int i=0;i<counterhsqc-2;i++)
	{
		num=(atoi(HSQCarray[i][0].c_str()))/10;
		SpinSysarray[num][0]=atof(HSQCarray[i][0].c_str());
		SpinSysarray[num][1]=atof(HSQCarray[i][2].c_str());
		SpinSysarray[num][2]=atof(HSQCarray[i][4].c_str());
	}
	}
}
void CompassSpinSystem::Fake_AssignHSQC()
{
	QString path=ui->HSQCLine->text(); 
	std::string HSQCfile;
	QByteArray nByte= path.toUtf8();
	HSQCfile=nByte.data();

	std::string line;
	
	std::ifstream file;
	std::ofstream fileo;
	file.open(HSQCfile.c_str(), std::ios::in);
    extern int counterhsqc;
	while(file.good())
	{
		getline(file,line);
		counterhsqc++;
	}
	counterhsqc--;
	file.clear();
	file.close();
	file.open(HSQCfile.c_str(), std::ios::in);
	getline(file,line);
	getline(file,line);
    extern int counternum;


    extern std::vector< std::vector < std::string > > HSQCarray;
    extern std::vector<std::string> HSQCsub;

	for(int i=0;i<counterhsqc-2;i++)
	{
        HSQCsub.erase(HSQCsub.begin(), HSQCsub.end());
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		std::stringstream ss,ss2;
		ss << counternum;
		std::string sub2,sub3;
		ss >> sub2;
        HSQCsub.push_back(sub2);
		counternum--;
		ss2 << counternum;
		ss2 >> sub3;
        HSQCsub.push_back(sub3);
		counternum++;
		iss >> sub;
		iss >> sub;
        HSQCsub.push_back(sub);
        HSQCsub.push_back("0");
		iss >> sub;
        HSQCsub.push_back(sub);
		iss >> sub;
        HSQCsub.push_back(sub);
		counternum += 10;
        HSQCarray.push_back(HSQCsub);
	}

	file.clear();
	file.close();
	{
        extern std::vector< std::vector < double > > SpinSysarray;
        extern std::vector<double> Spinsub;
        Spinsub.erase(Spinsub.begin(), Spinsub.end());
        for(int j=0; j<12; j++)
            Spinsub.push_back(0.0);

        for(int i=0; i<counterhsqc-1; i++)          
            SpinSysarray.push_back(Spinsub);

        int num=0;
    for(int i=0;i<counterhsqc-2;i++)
	{
		num=(atoi(HSQCarray[i][0].c_str()))/10;
		SpinSysarray[num][0]=atof(HSQCarray[i][0].c_str());
		SpinSysarray[num][1]=atof(HSQCarray[i][2].c_str());
		SpinSysarray[num][2]=atof(HSQCarray[i][4].c_str());
	}
	}
}
void CompassSpinSystem::Fake_AssignnoHSQC()
{
	QString path=ui->HNCOLine->text(); 
	std::string HNCOfile;
	QByteArray nByte= path.toUtf8();
	HNCOfile=nByte.data();

	std::string line;
	std::ifstream file;
	std::ofstream fileo;
	file.open(HNCOfile.c_str(), std::ios::in);
	extern int counterhsqc;
    int counterhnco=0;
	while(file.good())
	{
		getline(file,line);
		counterhnco++;
	}
	counterhnco--;
	file.clear();
	file.close();
	file.open(HNCOfile.c_str(), std::ios::in);
	getline(file,line);
	getline(file,line);
    extern int counternum;
    std::vector< std::vector< std::string > > HNCOarray=DefVec2(counterhnco-2,6);
    extern std::vector<std::string> HSQCsub;
    extern std::vector< std::vector< std::string > > HSQCarray;
	for(int i=0;i<counterhnco-2;i++)
	{
        HSQCsub.erase(HSQCsub.begin(), HSQCsub.end());
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		std::stringstream ss,ss2;
		ss << counternum;
		std::string sub2,sub3;
		ss >> sub2;
        HSQCsub.push_back(sub2);
		HNCOarray[i][0]=sub2;
		counternum--;
		ss2 << counternum;
		ss2 >> sub3;
        HSQCsub.push_back(sub3);
		HNCOarray[i][1]=sub3;
		counternum++;
		iss >> sub;
		iss >> sub;
        HSQCsub.push_back(sub);
        HSQCsub.push_back("0");
		HNCOarray[i][2]=sub;
		iss >> sub;
		HNCOarray[i][3]=sub;
		iss >> sub;
        HSQCsub.push_back(sub);
		HNCOarray[i][4]=sub;
		iss >> sub;
        HSQCsub.push_back(sub);
		HNCOarray[i][5]=sub;
		counternum += 10;
        HSQCarray.push_back(HSQCsub);
	}
	counterhsqc=counterhnco;
	file.clear();
	file.close();
	{
        extern std::vector< std::vector < double > > SpinSysarray;
        extern std::vector<double> Spinsub;
        for(int i=0; i<counterhsqc-1; i++)
        {
            Spinsub.erase(Spinsub.begin(), Spinsub.end());
            for(int j=0; j<12; j++)
                Spinsub.push_back(0.0);
            SpinSysarray.push_back(Spinsub);
        }
	int num=0;
	for(int i=0;i<counterhsqc-2;i++)
	{
		num=atoi(HSQCarray[i][0].c_str())/10;
		SpinSysarray[num][0]=atof(HSQCarray[i][0].c_str());
		SpinSysarray[num][1]=atof(HSQCarray[i][2].c_str());
		SpinSysarray[num][2]=atof(HSQCarray[i][4].c_str());
	}
	}
}
void CompassSpinSystem::Fake_AssignHNCOandHNCACO()
{
	QString path=ui->HNCOLine->text(); 
	std::string HNCOfile;
	QByteArray nByte= path.toUtf8();
	HNCOfile=nByte.data();

	path=ui->HNCACOLine->text(); 
	std::string HNCACOfile;
	nByte= path.toUtf8();
	HNCACOfile=nByte.data();

    extern std::string Dir;
	
	std::string line,HNCOfileout,HNCACOfileout;
	unsigned found=HNCACOfile.find_last_of("/");
	unsigned found1=HNCOfile.find_last_of("/");
    HNCACOfileout=Dir+HNCACOfile.substr(found+1)+".compass";
    HNCOfileout=Dir+HNCOfile.substr(found1+1)+".compass";

	double Ndev, Cdev, Hdev;
	
	Ndev = ui->devNBox->value();
	Cdev = ui->devCBox->value();
	Hdev = ui->devHBox->value();
	std::ifstream file;
	std::ofstream fileo;
	file.open(HNCOfile.c_str(), std::ios::in);
    int counterhnco=0;
	while(file.good())
	{
		getline(file,line);
		counterhnco++;
	}
	counterhnco--;
	file.clear();
	file.close();
	file.open(HNCOfile.c_str(), std::ios::in);
    std::vector< std::vector< std::string > > HNCOarray=DefVec2(counterhnco-2,6);
    getline(file,line);
	getline(file,line);
	for(int i=0;i<counterhnco-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNCOarray[i][2]=sub;
		iss >> sub;
		HNCOarray[i][3]=sub;
		iss >> sub;
		HNCOarray[i][4]=sub;
		iss >> sub;
		HNCOarray[i][5]=sub;
	}
	file.clear();
	file.close();
	file.open(HNCACOfile.c_str(), std::ios::in);
    int counterhncaco=0;
    extern int counterhsqc;
    extern int counternum;
	while(file.good())
	{
		getline(file,line);
		counterhncaco++;
	}
	counterhncaco--;
	file.clear();
	file.close();
	file.open(HNCACOfile.c_str(), std::ios::in);
    std::vector< std::vector< std::string > > HNCACOarray=DefVec2(counterhncaco-2,7);
	getline(file,line);
	getline(file,line);
	for(int i=0;i<counterhncaco-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNCACOarray[i][2]=sub;
		iss >> sub;
		HNCACOarray[i][3]=sub;
		iss >> sub;
		HNCACOarray[i][4]=sub;
		iss >> sub;
		HNCACOarray[i][5]=sub;
		HNCACOarray[i][6]="i";
	}
	file.clear();
	file.close();
	int countertemp=counterhsqc;

    extern std::vector< std::vector <std::string> > HSQCarray;
    extern std::vector<std::string> HSQCsub;
	for(int j=0;j<counterhnco-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(HNCOarray[j][2].c_str()) >= (atof(HSQCarray[i][2].c_str()) - Ndev) &&  atof(HNCOarray[j][2].c_str()) <= (atof(HSQCarray[i][2].c_str()) + Ndev) && atof(HNCOarray[j][4].c_str()) >= (atof(HSQCarray[i][4].c_str()) - Hdev) &&  atof(HNCOarray[j][4].c_str()) <= (atof(HSQCarray[i][4].c_str()) + Hdev ))
			{
				HNCOarray[j][0]=HSQCarray[i][0];
				HNCOarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
			else if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
			{
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
                std::stringstream ss,ss2;
				std::string sub;
				ss << counternum;
				ss >> sub;
				HNCOarray[j][0]=sub;
                HSQCsub.push_back(sub);
				counternum--;
				ss2 << counternum;
				ss2 >> sub;
                HNCOarray[j][1]=sub;
                HSQCsub.push_back(sub);
				counternum++;
                HSQCsub.push_back(HNCOarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(HNCOarray[j][2]);
				counternum += 10;
				countertemp++;
                HSQCarray.push_back(HSQCsub);
			}
			else if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
			{
				HNCOarray[j][0]="?";
			}
		}
	}
    extern std::vector< std::vector <double> > SpinSysarray;
    extern std::vector<double> Spinsub;
    Spinsub.erase(Spinsub.begin(),Spinsub.end());
    for (int i=0;i<12;i++)
        Spinsub.push_back(0.0);

    for (int i=0;i<countertemp-counterhsqc;i++)
        SpinSysarray.push_back(Spinsub);
    counterhsqc=countertemp;
	for(int j=0;j<counterhncaco-2;j++)
	{
		for(int i=0;i<counterhnco-2;i++)
		{
			if(HNCOarray[i][0]!="?")
			{
				if(atof(HNCACOarray[j][2].c_str()) >= atof(HNCOarray[i][2].c_str()) - Ndev &&  atof(HNCACOarray[j][2].c_str()) <= atof(HNCOarray[i][2].c_str()) + Ndev && atof(HNCACOarray[j][4].c_str()) >= atof(HNCOarray[i][4].c_str()) - Hdev &&  atof(HNCACOarray[j][4].c_str()) <= atof(HNCOarray[i][4].c_str()) + Hdev )
				{
					HNCACOarray[j][0]=HNCOarray[i][0];
					HNCACOarray[j][1]=HNCOarray[i][1];
					if(atof(HNCACOarray[j][3].c_str()) >= atof(HNCOarray[i][3].c_str()) - Cdev &&  atof(HNCACOarray[j][3].c_str()) <= atof(HNCOarray[i][3].c_str()) + Cdev )
						HNCACOarray[j][6]="i-1";
					else
						HNCACOarray[j][6]="i";
					i=counterhnco;
				}
				else if(i==counterhnco-3 && ui->RefBox->currentText()=="All lists")
				{	
                    HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
					std::stringstream ss,ss2;
					std::string sub;
					ss << counternum;
					ss >> sub;
					HNCACOarray[j][0]=sub;
                    HSQCsub.push_back(sub);
					counternum--;
					ss2 << counternum;
					ss2 >> sub;
					HNCACOarray[j][1]=sub;
                    HSQCsub.push_back(sub);
					counternum++;
                    HSQCsub.push_back(HNCACOarray[j][2]);
                    HSQCsub.push_back("0");
                    HSQCsub.push_back(HNCACOarray[j][4]);
					counternum+=10;
                    countertemp++;
                    HSQCarray.push_back(HSQCsub);
				}
				else if(i==counterhnco-3 && ui->RefBox->currentText()!="All lists")
				{
					HNCACOarray[j][0]="?";
				}	
			}
		}
	}
	fileo.open(HNCOfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  tw2  tw3"<<std::endl;
	for(int i=0;i<counterhnco-2;i++)
		if(HNCOarray[i][0]=="?")
		{
            fileo<<std::endl<<HNCOarray[i][0]<<"-?-?  "<<HNCOarray[i][2]<<"  "<<HNCOarray[i][3]<<"  "<<HNCOarray[i][4];
		}
		else 
		{
            fileo<<std::endl<<HNCOarray[i][0]<<"N-"<<HNCOarray[i][1]<<"CO-"<<HNCOarray[i][0]<<"HN  "<<HNCOarray[i][2]<<"  "<<HNCOarray[i][3]<<"  "<<HNCOarray[i][4];
		}
	fileo.clear();
	fileo.close();
	fileo.open(HNCACOfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  tw2  tw3"<<std::endl;
	for(int i=0;i<counterhncaco-2;i++)
	{
		if(HNCACOarray[i][0]=="?")
		{
                fileo<<std::endl<<HNCACOarray[i][0]<<"-?-?  "<<HNCACOarray[i][2]<<"  "<<HNCACOarray[i][3]<<"  "<<HNCACOarray[i][4];
		}
		else 
		{
			if(HNCACOarray[i][6]=="i")
                fileo<<std::endl<<HNCACOarray[i][0]<<"N-CO-HN  "<<HNCACOarray[i][2]<<"  "<<HNCACOarray[i][3]<<"  "<<HNCACOarray[i][4];
			else if (HNCACOarray[i][6]=="i-1")	
                fileo<<std::endl<<HNCACOarray[i][0]<<"N-"<<HNCACOarray[i][1]<<"CO-"<<HNCACOarray[i][0]<<"HN  "<<HNCACOarray[i][2]<<"  "<<HNCACOarray[i][3]<<"  "<<HNCACOarray[i][4];
		}
	}
	fileo.clear();
	fileo.close();

    Spinsub.erase(Spinsub.begin(),Spinsub.end());
    for (int i=0;i<12;i++)
        Spinsub.push_back(0.0);

    for (int i=0;i<countertemp-counterhsqc;i++)
        SpinSysarray.push_back(Spinsub);

    counterhsqc=countertemp;
    int num=0;
	for(int i=0;i<counterhnco-2;i++)
	{
		if (HNCOarray[i][0]!="?")
		{
			num=atoi(HNCOarray[i][0].c_str())/10;
			SpinSysarray[num][4]=atof(HNCOarray[i][3].c_str());
            if (SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(HNCOarray[i][2].c_str());
                SpinSysarray[num][2]=atof(HNCOarray[i][4].c_str());
            }
        }
	}
	for(int i=0;i<counterhncaco-2;i++)
	{
		if (HNCACOarray[i][0]!="?")
		{
			num=atoi(HNCACOarray[i][0].c_str())/10;
			if (HNCACOarray[i][6]=="i")
			{
				SpinSysarray[num][3]=atof(HNCACOarray[i][3].c_str());
			}
			else  if (HNCACOarray[i][6]=="i-1")
			{
				if (SpinSysarray[num][4]==0.0)
				{
					SpinSysarray[num][4]=atof(HNCACOarray[i][3].c_str());
				}
				else
				{
					double co=SpinSysarray[num][4];
					double mean=0.0,stDev=0.0;
					mean=(atof(HNCACOarray[i][3].c_str())+co)/2;
					stDev=sqrt(((atof(HNCACOarray[i][3].c_str())-mean)*(atof(HNCACOarray[i][3].c_str())-mean)+(co-mean)*(co-mean))/2);
					SpinSysarray[num][4]=mean;
					SpinSysarray[num][9]=stDev;
				}
			}
            if (SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(HNCACOarray[i][2].c_str());
                SpinSysarray[num][2]=atof(HNCACOarray[i][4].c_str());
            }
		}
	}
}
void CompassSpinSystem::Fake_AssignHNCACO()
{
	QString path=ui->HNCACOLine->text(); 
	std::string HNCACOfile;
	QByteArray nByte= path.toUtf8();
	HNCACOfile=nByte.data();

    extern std::string Dir;
	
	std::string line,HNCACOfileout;
	unsigned found=HNCACOfile.find_last_of("/");
    HNCACOfileout=Dir+"/"+HNCACOfile.substr(found+1)+".compass";

	double Ndev, Hdev;
	
	Ndev = ui->devNBox->value();
	Hdev = ui->devHBox->value();

	std::ifstream file;
	std::ofstream fileo;

	file.open(HNCACOfile.c_str(), std::ios::in);
    int counterhncaco=0;
    extern int counterhsqc;
	while(file.good())
	{
		getline(file,line);
		counterhncaco++;
	}
	counterhncaco--;
	file.clear();
	file.close();
	file.open(HNCACOfile.c_str(), std::ios::in);
    std::vector< std::vector< std::string > > HNCACOarray=DefVec2(counterhncaco-2,7);
	getline(file,line);
	getline(file,line);
	for(int i=0;i<counterhncaco-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNCACOarray[i][2]=sub;
		iss >> sub;
		HNCACOarray[i][3]=sub;
		iss >> sub;
		HNCACOarray[i][4]=sub;
		iss >> sub;
		HNCACOarray[i][5]=sub;
	}
	file.clear();
	file.close();
	int countertemp=counterhsqc;
	extern int counternum;
    extern std::vector< std::vector <std::string> > HSQCarray;
    extern std::vector<std::string> HSQCsub;
    for(int j=0;j<counterhncaco-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(HNCACOarray[j][2].c_str()) >= (atof(HSQCarray[i][2].c_str()) - Ndev) &&  atof(HNCACOarray[j][2].c_str()) <= (atof(HSQCarray[i][2].c_str()) + Ndev) && atof(HNCACOarray[j][4].c_str()) >= (atof(HSQCarray[i][4].c_str()) - Hdev) &&  atof(HNCACOarray[j][4].c_str()) <= (atof(HSQCarray[i][4].c_str()) + Hdev ))
			{
				HNCACOarray[j][0]=HSQCarray[i][0];
				HNCACOarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
			else if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
			{	
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
                std::stringstream ss,ss2;
				std::string sub;
				ss << counternum;
				ss >> sub;
				HNCACOarray[j][0]=sub;
                HSQCsub.push_back(sub);
				counternum--;
				ss2 << counternum;
				ss2 >> sub;
				HNCACOarray[j][1]=sub;
                HSQCsub.push_back(sub);
				counternum++;
                HSQCsub.push_back(HNCACOarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(HNCACOarray[j][4]);
                counternum+=10;
				countertemp++;
                HSQCarray.push_back(HSQCsub);
			}
			else if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
			{
				HNCACOarray[j][0]="?";
			}	
		}
	}
    extern std::vector< std::vector <double> > SpinSysarray;
    extern std::vector<double> Spinsub;
    Spinsub.erase(Spinsub.begin(),Spinsub.end());
    for (int i=0;i<12;i++)
            Spinsub.push_back(0.0);

    for (int i=0;i<countertemp-counterhsqc;i++)
        SpinSysarray.push_back(Spinsub);

	counterhsqc=countertemp;
	for(int j=0;j<counterhncaco-3;j++)
	{
		for(int i=j+1;i<counterhncaco-2;i++)
		{
			if(atof(HNCACOarray[j][2].c_str()) >= (atof(HNCACOarray[i][2].c_str()) - Ndev) &&  atof(HNCACOarray[j][2].c_str()) <= (atof(HNCACOarray[i][2].c_str()) + Ndev) && atof(HNCACOarray[j][4].c_str()) >= (atof(HNCACOarray[i][4].c_str()) - Hdev) &&  atof(HNCACOarray[j][4].c_str()) <= (atof(HNCACOarray[i][4].c_str()) + Hdev ))
			{
				if(std::abs (atof(HNCACOarray[j][5].c_str())) <= std::abs (atof(HNCACOarray[i][5].c_str())))
				{
					HNCACOarray[j][6]="i-1";
					HNCACOarray[i][6]="i";
							}
				else
				{
					HNCACOarray[i][6]="i-1";
					HNCACOarray[j][6]="i";
				}
			}

		}
	}
	fileo.open(HNCACOfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2  w3"<<std::endl;
	for(int i=0;i<counterhncaco-2;i++)
		if(HNCACOarray[i][0]=="?")
            fileo<<std::endl<<HNCACOarray[i][0]<<"-?-?  "<<HNCACOarray[i][2]<<"  "<<HNCACOarray[i][3]<<"  "<<HNCACOarray[i][4];
		else
		{
			if(HNCACOarray[i][6]=="i")
                fileo<<std::endl<<HNCACOarray[i][0]<<"N-CO-HN  "<<HNCACOarray[i][2]<<"  "<<HNCACOarray[i][3]<<"  "<<HNCACOarray[i][4];
			else if (HNCACOarray[i][6]=="i-1")	
                fileo<<std::endl<<HNCACOarray[i][0]<<"N-"<<HNCACOarray[i][1]<<"CO-"<<HNCACOarray[i][0]<<"HN  "<<HNCACOarray[i][2]<<"  "<<HNCACOarray[i][3]<<"  "<<HNCACOarray[i][4];
		}	
	fileo.clear();
	fileo.close();
	{
	int num=0;
	for(int i=0;i<counterhncaco-2;i++)
	{
		if (HNCACOarray[i][0]!="?")
		{
			num=atoi(HNCACOarray[i][0].c_str())/10;
			if (HNCACOarray[i][6]=="i")
			{
				SpinSysarray[num][3]=atof(HNCACOarray[i][3].c_str());
			}
			else  if (HNCACOarray[i][6]=="i-1")
			{
					SpinSysarray[num][4]=atof(HNCACOarray[i][3].c_str());
			}
            if (SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(HNCACOarray[i][2].c_str());
                SpinSysarray[num][2]=atof(HNCACOarray[i][4].c_str());
             }
		}
	}
	}
}
void CompassSpinSystem::Fake_AssignHNCO()
{
	QString path=ui->HNCOLine->text(); 
	std::string HNCOfile;
	QByteArray nByte= path.toUtf8();
	HNCOfile=nByte.data();

    extern std::string Dir;
	
	std::string line,HNCOfileout;
	unsigned found=HNCOfile.find_last_of("/");
    HNCOfileout=Dir+HNCOfile.substr(found+1)+".compass";

    double Ndev, Hdev;
	
	Ndev = ui->devNBox->value();
	Hdev = ui->devHBox->value();

	std::ifstream file;
	std::ofstream fileo;
	file.open(HNCOfile.c_str(), std::ios::in);
    int counterhnco=0;
	extern int counterhsqc;
	extern int counternum;
	while(file.good())
	{
		getline(file,line);
		counterhnco++;
	}
	counterhnco--;
	file.clear();
	file.close();
	file.open(HNCOfile.c_str(), std::ios::in);
    std::vector< std::vector< std::string > > HNCOarray=DefVec2(counterhnco-2,6);

	getline(file,line);
	getline(file,line);
	for(int i=0;i<counterhnco-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNCOarray[i][2]=sub;
		iss >> sub;
		HNCOarray[i][3]=sub;
		iss >> sub;
		HNCOarray[i][4]=sub;
		iss >> sub;
		HNCOarray[i][5]=sub;
	}
	file.clear();
	file.close();
    extern std::vector< std::vector <std::string> > HSQCarray;
    extern std::vector<std::string> HSQCsub;
	int countertemp=counterhsqc;
	for(int j=0;j<counterhnco-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(HNCOarray[j][2].c_str()) >= (atof(HSQCarray[i][2].c_str()) - Ndev) &&  atof(HNCOarray[j][2].c_str()) <= (atof(HSQCarray[i][2].c_str()) + Ndev) && atof(HNCOarray[j][4].c_str()) >= (atof(HSQCarray[i][4].c_str()) - Hdev) &&  atof(HNCOarray[j][4].c_str()) <= (atof(HSQCarray[i][4].c_str()) + Hdev ))
			{
				HNCOarray[j][0]=HSQCarray[i][0];
				HNCOarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
			else if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
			{
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
                std::string sub;
				std::stringstream ss,ss2;
				ss << counternum;
				ss >> sub;
				HNCOarray[j][0]=sub;
                HSQCsub.push_back(sub);
				counternum--;
				ss2 << counternum;
				ss2 >> sub;
				HNCOarray[j][1]=sub;
                HSQCsub.push_back(sub);
                HSQCsub.push_back(HNCOarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(HNCOarray[j][4]);
                counternum++;
				counternum+=10;
				countertemp++;
                HSQCarray.push_back(HSQCsub);

			}
			else if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
			{
				HNCOarray[j][0]="?";
			}
		}
	}
    extern std::vector< std::vector <double> > SpinSysarray;
    extern std::vector<double> Spinsub;

    Spinsub.erase(Spinsub.begin(),Spinsub.end());
    for (int i=0;i<12;i++)
        Spinsub.push_back(0.0);

    for (int i=0;i<countertemp-counterhsqc;i++)
        SpinSysarray.push_back(Spinsub);

	counterhsqc=countertemp;
	fileo.open(HNCOfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2  w3"<<std::endl;
	for(int i=0;i<counterhnco-2;i++)
		if(HNCOarray[i][0]=="?")
            fileo<<std::endl<<HNCOarray[i][0]<<"-?-?  "<<HNCOarray[i][2]<<"  "<<HNCOarray[i][3]<<"  "<<HNCOarray[i][4];
		else
            fileo<<std::endl<<HNCOarray[i][0]<<"N-"<<HNCOarray[i][1]<<"CO-"<<HNCOarray[i][0]<<"HN  "<<HNCOarray[i][2]<<"  "<<HNCOarray[i][3]<<"  "<<HNCOarray[i][4];
	fileo.clear();
	fileo.close();
	int num=0;
	for(int i=0;i<counterhnco-2;i++)
	{
		if (HNCOarray[i][0]!="?")
		{
			num=atoi(HNCOarray[i][0].c_str())/10;
			SpinSysarray[num][4]=atof(HNCOarray[i][3].c_str());
            if (SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(HNCOarray[i][2].c_str());
                SpinSysarray[num][2]=atof(HNCOarray[i][4].c_str());
             }
		}
	}
}
void CompassSpinSystem::Fake_AssignHNCACBandHNCOCACB()
{
	QString	path=ui->HNCACBLine->text(); 
	std::string HNCACBfile;
	QByteArray nByte= path.toUtf8();
	HNCACBfile=nByte.data();

    extern std::string Dir;
	
	path=ui->HNCOCACBLine->text(); 
	std::string CBCACONHfile;
	nByte= path.toUtf8();
	CBCACONHfile=nByte.data();

	double Ndev, Cdev, Hdev;
	
	Ndev = ui->devNBox->value();
	Cdev = ui->devCBox->value();
	Hdev = ui->devHBox->value();

	std::string line,HNCACBfileout,CBCACONHfileout;
	unsigned found=HNCACBfile.find_last_of("/");
	unsigned found1=CBCACONHfile.find_last_of("/");
    HNCACBfileout=Dir+HNCACBfile.substr(found+1)+".compass";
    CBCACONHfileout=Dir+CBCACONHfile.substr(found1+1)+".compass";
	std::ifstream file;
	std::ofstream fileo;
	file.open(HNCACBfile.c_str(), std::ios::in);
    int counterhncacb=0;
	extern int counterhsqc;
	while(file.good())
	{
		getline(file,line);
		counterhncacb++;
	}
	counterhncacb--;
	file.clear();
	file.close();
	file.open(HNCACBfile.c_str(), std::ios::in);
    std::vector< std::vector< std::string > > HNCACBarray=DefVec2(counterhncacb-2,8);
	getline(file,line);
	getline(file,line);
	std::string negtype,postype;
	if(ui->CAButton->isChecked())
	{
		negtype="CA";
		postype="CB";
	}
	if(ui->CBButton->isChecked())
	{
		negtype="CB";
		postype="CA";
	}
	for(int i=0;i<counterhncacb-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNCACBarray[i][2]=sub;
		iss >> sub;
		HNCACBarray[i][3]=sub;
		iss >> sub;
		HNCACBarray[i][4]=sub;
		iss >> sub;
		HNCACBarray[i][5]=sub;
		if (atof(HNCACBarray[i][5].c_str()) <= 0)
		{
			HNCACBarray[i][7]=negtype;
		}
		else if(atof(HNCACBarray[i][5].c_str()) >= 0)
		{
			HNCACBarray[i][7]=postype;
		}
		HNCACBarray[i][6]="i";
	}
	file.clear();
	file.close();
	file.open(CBCACONHfile.c_str(), std::ios::in);
    int countercbcaconh=0;
	while(file.good())
	{
		getline(file,line);
		countercbcaconh++;
	}
	countercbcaconh--;
	file.clear();
	file.close();
	file.open(CBCACONHfile.c_str(), std::ios::in);
    std::vector< std::vector< std::string > > CBCACONHarray=DefVec2(countercbcaconh-2,8);
	getline(file,line);
	getline(file,line);
	for(int i=0;i<countercbcaconh-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		CBCACONHarray[i][2]=sub;
		iss >> sub;
		CBCACONHarray[i][3]=sub;
		iss >> sub;
		CBCACONHarray[i][4]=sub;
		iss >> sub;
		CBCACONHarray[i][5]=sub;
	}
	file.clear();
	file.close();

	extern int counternum;
    extern std::vector< std::vector <std::string> > HSQCarray;
    extern std::vector<std::string> HSQCsub;
	int countertemp=counterhsqc;
	for(int j=0;j<countercbcaconh-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(CBCACONHarray[j][2].c_str()) >= atof(HSQCarray[i][2].c_str()) - Ndev &&  atof(CBCACONHarray[j][2].c_str()) <= atof(HSQCarray[i][2].c_str()) + Ndev && atof(CBCACONHarray[j][4].c_str()) >= atof(HSQCarray[i][4].c_str()) - Hdev &&  atof(CBCACONHarray[j][4].c_str()) <= atof(HSQCarray[i][4].c_str()) + Hdev )
			{
				CBCACONHarray[j][0]=HSQCarray[i][0];
				CBCACONHarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
			if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
				CBCACONHarray[j][0]="?";
			if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
			{
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
                std::string sub;
				std::stringstream ss,ss2;
				ss << counternum;
				ss >> sub;
				CBCACONHarray[j][0]=sub;
                HSQCsub.push_back(sub);
				counternum--;
				ss2 << counternum;
				ss2 >> sub;
				CBCACONHarray[j][1]=sub;
                HSQCsub.push_back(sub);
                HSQCsub.push_back(CBCACONHarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(CBCACONHarray[j][4]);
                counternum++;
				counternum+=10;
				countertemp++;
                HSQCarray.push_back(HSQCsub);
			}
		}
		for(int i=0;i<counterhncacb-2;i++)
			if(atof(CBCACONHarray[j][2].c_str()) >= atof(HNCACBarray[i][2].c_str()) - Ndev &&  atof(CBCACONHarray[j][2].c_str()) <= atof(HNCACBarray[i][2].c_str()) + Ndev && atof(CBCACONHarray[j][4].c_str()) >= atof(HNCACBarray[i][4].c_str()) - Hdev &&  atof(CBCACONHarray[j][4].c_str()) <= atof(HNCACBarray[i][4].c_str()) + Hdev && atof(CBCACONHarray[j][3].c_str()) >= atof(HNCACBarray[i][3].c_str()) - Cdev && atof(CBCACONHarray[j][3].c_str()) <= atof(HNCACBarray[i][3].c_str()) + Cdev )
            {
                CBCACONHarray[j][7]=HNCACBarray[i][7];
			}
	}

    extern std::vector< std::vector <double> > SpinSysarray;
    extern std::vector<double> Spinsub;
    Spinsub.erase(Spinsub.begin(),Spinsub.end());
    for (int i=0;i<12;i++)
        Spinsub.push_back(0.0);

    for (int i=0;i<countertemp-counterhsqc;i++)
        SpinSysarray.push_back(Spinsub);

	counterhsqc=countertemp;
	for(int j=0;j<counterhncacb-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(HNCACBarray[j][2].c_str()) >= atof(HSQCarray[i][2].c_str()) - Ndev &&  atof(HNCACBarray[j][2].c_str()) <= atof(HSQCarray[i][2].c_str()) + Ndev && atof(HNCACBarray[j][4].c_str()) >= atof(HSQCarray[i][4].c_str()) - Hdev &&  atof(HNCACBarray[j][4].c_str()) <= atof(HSQCarray[i][4].c_str()) + Hdev )
			{
				HNCACBarray[j][0]=HSQCarray[i][0];
				HNCACBarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
			if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
				HNCACBarray[j][0]="?";
			if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
			{
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
                std::string sub;
				std::stringstream ss,ss2;
				ss << counternum;
				ss >> sub;
				HNCACBarray[j][0]=sub;
                HSQCsub.push_back(sub);
                counternum--;
				ss2 << counternum;
				ss2 >> sub;
				HNCACBarray[j][1]=sub;
                HSQCsub.push_back(sub);
                HSQCsub.push_back(HNCACBarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(HNCACBarray[j][4]);
                counternum++;
				counternum+=10;
				countertemp++;
                HSQCarray.push_back(HSQCsub);
			}
		}
		for(int i=0;i<countercbcaconh-2;i++)
			if(atof(HNCACBarray[j][2].c_str()) >= atof(CBCACONHarray[i][2].c_str()) - Ndev &&  atof(HNCACBarray[j][2].c_str()) <= atof(CBCACONHarray[i][2].c_str()) + Ndev && atof(HNCACBarray[j][4].c_str()) >= atof(CBCACONHarray[i][4].c_str()) - Hdev &&  atof(HNCACBarray[j][4].c_str()) <= atof(CBCACONHarray[i][4].c_str()) + Hdev ) 
			{
				if(HNCACBarray[j][7]==CBCACONHarray[i][7])
				{
					if(atof(HNCACBarray[j][3].c_str()) >= atof(CBCACONHarray[i][3].c_str()) - Cdev && atof(HNCACBarray[j][3].c_str()) <= atof(CBCACONHarray[i][3].c_str()) + Cdev )
						HNCACBarray[j][6]="i-1";
				}
			}	
	}
    Spinsub.erase(Spinsub.begin(),Spinsub.end());
    for (int i=0;i<12;i++)
        Spinsub.push_back(0.0);

    for (int i=0;i<countertemp-counterhsqc;i++)
        SpinSysarray.push_back(Spinsub);
    //Check CA/CB labeling
    for(int m=0; m<countercbcaconh-2; m++)
    {
         if (CBCACONHarray[m][7]!="CA" && CBCACONHarray[m][7]!="CB")
         {
             if (m==countercbcaconh-3)
             {
                 if (atof(CBCACONHarray[m][3].c_str()) >= 42 && atof(CBCACONHarray[m][3].c_str()) <= 48)
                 {
                     CBCACONHarray[m][7]="CA"; // Gly
                 }
             }
             for(int n=m+1;n<countercbcaconh-2;n++)
             {
                 if(atof(CBCACONHarray[m][2].c_str()) >= atof(CBCACONHarray[n][2].c_str()) - Ndev &&  atof(CBCACONHarray[m][2].c_str()) <= atof(CBCACONHarray[n][2].c_str()) + Ndev && atof(CBCACONHarray[m][4].c_str()) >= atof(CBCACONHarray[n][4].c_str()) - Hdev &&  atof(CBCACONHarray[m][4].c_str()) <= atof(CBCACONHarray[n][4].c_str()) + Hdev && CBCACONHarray[m][7] == CBCACONHarray[n][7] && CBCACONHarray[m][0]!="?")
                     {
                         if (atof(CBCACONHarray[m][3].c_str()) >= 50 && atof(CBCACONHarray[n][3].c_str()) >= 50) //Ser, Thr
                         {
                             if (atof(CBCACONHarray[m][3].c_str()) > atof(CBCACONHarray[n][3].c_str()) )
                             {
                                 CBCACONHarray[m][7]="CB";
                                 CBCACONHarray[n][7]="CA";
                                 break;
                             }
                             else
                             {
                                 CBCACONHarray[m][7]="CA";
                                 CBCACONHarray[n][7]="CB";
                                 break;
                             }
                         }
                         else
                         {
                             if (atof(CBCACONHarray[m][3].c_str()) > atof(CBCACONHarray[n][3].c_str()))
                             {
                                 CBCACONHarray[m][7]="CA";
                                 CBCACONHarray[n][7]="CB";
                                 break;
                             }
                             else
                             {
                                 CBCACONHarray[m][7]="CB";
                                 CBCACONHarray[n][7]="CA";
                                 break;
                             }
                         }
                     }
                 else if (n==countercbcaconh-3 && atof(CBCACONHarray[m][3].c_str()) >= 42 && atof(CBCACONHarray[m][3].c_str()) <= 48)
                 {
                     CBCACONHarray[m][7]="CA"; // Gly
                 }
             }
         }
         else
         {
             for(int n=0;n<countercbcaconh-2;n++)
             {
                 if(n==m)
                     continue;
                 if(atof(CBCACONHarray[m][2].c_str()) >= atof(CBCACONHarray[n][2].c_str()) - Ndev &&  atof(CBCACONHarray[m][2].c_str()) <= atof(CBCACONHarray[n][2].c_str()) + Ndev && atof(CBCACONHarray[m][4].c_str()) >= atof(CBCACONHarray[n][4].c_str()) - Hdev &&  atof(CBCACONHarray[m][4].c_str()) <= atof(CBCACONHarray[n][4].c_str()) + Hdev && CBCACONHarray[n][7] == "" && CBCACONHarray[m][0]!="?")
                     {
                         if (atof(CBCACONHarray[m][3].c_str()) >= 50 && atof(CBCACONHarray[n][3].c_str()) >= 50) //Ser, Thr
                         {
                             if (atof(CBCACONHarray[m][3].c_str()) > atof(CBCACONHarray[n][3].c_str()) )
                             {
                                 CBCACONHarray[n][7]="CA";
                                 break;
                             }
                             else
                             {
                                 CBCACONHarray[n][7]="CB";
                                 break;
                             }
                         }
                         else
                         {
                             if (atof(CBCACONHarray[m][3].c_str()) > atof(CBCACONHarray[n][3].c_str()))
                             {
                                 CBCACONHarray[n][7]="CB";
                                 break;
                             }
                             else
                             {
                                 CBCACONHarray[n][7]="CA";
                                 break;
                             }
                         }
                     }
             }
         }
     }
    //
	counterhsqc=countertemp;
	fileo.open(CBCACONHfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2  w3"<<std::endl;
	for(int i=0;i<countercbcaconh-2;i++)
		if(CBCACONHarray[i][0]=="?")
            fileo<<std::endl<<CBCACONHarray[i][0]<<"-?-?  "<<CBCACONHarray[i][2]<<"  "<<CBCACONHarray[i][3]<<"  "<<CBCACONHarray[i][4];
        else if (CBCACONHarray[i][7]!="")
            fileo<<std::endl<<CBCACONHarray[i][0]<<"N-"<<CBCACONHarray[i][1]<<CBCACONHarray[i][7]<<"-"<<CBCACONHarray[i][0]<<"HN  "<<CBCACONHarray[i][2]<<"  "<<CBCACONHarray[i][3]<<"  "<<CBCACONHarray[i][4];
		else
            fileo<<std::endl<<CBCACONHarray[i][0]<<"N-"<<CBCACONHarray[i][1]<<"C?-"<<CBCACONHarray[i][0]<<"HN  "<<CBCACONHarray[i][2]<<"  "<<CBCACONHarray[i][3]<<"  "<<CBCACONHarray[i][4];
	fileo.clear();
	fileo.close();
	fileo.open(HNCACBfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2  w3"<<std::endl;
	for(int i=0;i<counterhncacb-2;i++)
	{
		if(HNCACBarray[i][0]=="?")
            fileo<<std::endl<<HNCACBarray[i][0]<<"-?-?  "<<HNCACBarray[i][2]<<"  "<<HNCACBarray[i][3]<<"  "<<HNCACBarray[i][4];
        else if(HNCACBarray[i][6]=="i" && HNCACBarray[i][0]!="" && HNCACBarray[i][7]!="")
		{
            fileo<<std::right<<std::endl<<HNCACBarray[i][0]<<"N-"<<HNCACBarray[i][7]<<"-HN  ";
            fileo<<std::left<<HNCACBarray[i][2]<<"  "<<HNCACBarray[i][3]<<"  "<<HNCACBarray[i][4];
		}
        else if(HNCACBarray[i][6]=="i" && HNCACBarray[i][0]!="")
        {
            fileo<<std::right<<std::endl<<HNCACBarray[i][0]<<"N-C?-HN  ";
            fileo<<std::left<<HNCACBarray[i][2]<<"  "<<HNCACBarray[i][3]<<"  "<<HNCACBarray[i][4];
        }
        else if(HNCACBarray[i][6]=="i-1" && HNCACBarray[i][0]!="" && HNCACBarray[i][7]!="")
		{
            fileo<<std::right<<std::endl<<HNCACBarray[i][0]<<"N-"<<HNCACBarray[i][1]<<HNCACBarray[i][7]<<"-"<<HNCACBarray[i][0]<<"HN  ";
            fileo<<std::left<<HNCACBarray[i][2]<<"  "<<HNCACBarray[i][3]<<"  "<<HNCACBarray[i][4];
		}
        else if(HNCACBarray[i][6]=="i-1" && HNCACBarray[i][0]!="")
        {
            fileo<<std::right<<std::endl<<HNCACBarray[i][0]<<"N-"<<HNCACBarray[i][1]<<"C?-"<<HNCACBarray[i][0]<<"HN  ";
            fileo<<std::left<<HNCACBarray[i][2]<<"  "<<HNCACBarray[i][3]<<"  "<<HNCACBarray[i][4];
        }
	}
	fileo.clear();
	fileo.close();
	int num=0;

	for(int i=0;i<countercbcaconh-2;i++)
	{
		if (CBCACONHarray[i][0]!="?")
		{
			num=atoi(CBCACONHarray[i][0].c_str())/10;
			if(CBCACONHarray[i][7]=="CB")
				SpinSysarray[num][8]=atof(CBCACONHarray[i][3].c_str());
			else if(CBCACONHarray[i][7]=="CA")
				SpinSysarray[num][6]=atof(CBCACONHarray[i][3].c_str());
            if (SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(CBCACONHarray[i][2].c_str());
                SpinSysarray[num][2]=atof(CBCACONHarray[i][4].c_str());
            }
		}
    }
    for(int i=0;i<counterhncacb-2;i++)
	{
		if (HNCACBarray[i][0]!="?")
		{
			num=atoi(HNCACBarray[i][0].c_str())/10;
			if (HNCACBarray[i][6]=="i")
			{
				if(HNCACBarray[i][7]=="CB")
					SpinSysarray[num][7]=atof(HNCACBarray[i][3].c_str());
				if(HNCACBarray[i][7]=="CA")
					SpinSysarray[num][5]=atof(HNCACBarray[i][3].c_str());
			}
			else  if (HNCACBarray[i][6]=="i-1")
			{
				if (HNCACBarray[i][7]=="CB")
				{
					if (SpinSysarray[num][8]==0.0)
					{
						SpinSysarray[num][8]=atof(HNCACBarray[i][3].c_str());
					}
					else
					{
						double co=SpinSysarray[num][8];
						double mean=0.0,stDev=0.0;
						mean=(atof(HNCACBarray[i][3].c_str())+co)/2;
						stDev=sqrt(((atof(HNCACBarray[i][3].c_str())-mean)*(atof(HNCACBarray[i][3].c_str())-mean)+(co-mean)*(co-mean))/2);
						SpinSysarray[num][8]=mean;
						SpinSysarray[num][11]=stDev;
					}
				}
				else if (HNCACBarray[i][7]=="CA")
				{
					if (SpinSysarray[num][6]==0.0)
					{
						SpinSysarray[num][6]=atof(HNCACBarray[i][3].c_str());
					}
					else 
					{
						double co=SpinSysarray[num][6];
						double mean=0.0,stDev=0.0;
						mean=(atof(HNCACBarray[i][3].c_str())+co)/2;
						stDev=sqrt(((atof(HNCACBarray[i][3].c_str())-mean)*(atof(HNCACBarray[i][3].c_str())-mean)+(co-mean)*(co-mean))/2);
						SpinSysarray[num][6]=mean;
						SpinSysarray[num][10]=stDev;
					}
				}
			}
            if (SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(HNCACBarray[i][2].c_str());
                SpinSysarray[num][2]=atof(HNCACBarray[i][4].c_str());
            }
		}
	}
}
void CompassSpinSystem::Fake_AssignCBCACONH()
{
    QString	path=ui->HNCOCACBLine->text();
    std::string CBCACONHfile;
    QByteArray nByte= path.toUtf8();
    CBCACONHfile=nByte.data();

    extern std::string Dir;

    double Ndev, Hdev;

    Ndev = ui->devNBox->value();
    Hdev = ui->devHBox->value();

    std::string line,CBCACONHfileout;
    unsigned found=CBCACONHfile.find_last_of("/");
    CBCACONHfileout=Dir+CBCACONHfile.substr(found+1)+".compass";
    std::ifstream file;
    std::ofstream fileo;
    file.open(CBCACONHfile.c_str(), std::ios::in);
    int countercbcaconh=0;
    while(file.good())
    {
        getline(file,line);
        countercbcaconh++;
    }
    countercbcaconh--;
    file.clear();
    file.close();
    file.open(CBCACONHfile.c_str(), std::ios::in);
    std::vector< std::vector< std::string > > CBCACONHarray=DefVec2(countercbcaconh-2,8);
    getline(file,line);
    getline(file,line);
    for(int i=0;i<countercbcaconh-2;i++)
    {
        getline(file,line);
        std::istringstream iss(line);
        std::string sub;
        iss >> sub;
        iss >> sub;
        CBCACONHarray[i][2]=sub;
        iss >> sub;
        CBCACONHarray[i][3]=sub;
        iss >> sub;
        CBCACONHarray[i][4]=sub;
        iss >> sub;
        CBCACONHarray[i][5]=sub;
        CBCACONHarray[i][6]="i-1";
    }
    file.clear();
    file.close();
    extern std::vector< std::vector <std::string> > HSQCarray; //[5000][6]
    extern std::vector<std::string> HSQCsub;

    extern int counterhsqc;
    extern int counternum;
    int countertemp=counterhsqc;
    for(int j=0;j<countercbcaconh-2;j++)
    {
        for(int i=0;i<counterhsqc-2;i++)
        {
            if(atof(CBCACONHarray[j][2].c_str()) >= atof(HSQCarray[i][2].c_str()) - Ndev &&  atof(CBCACONHarray[j][2].c_str()) <= atof(HSQCarray[i][2].c_str()) + Ndev && atof(CBCACONHarray[j][4].c_str()) >= atof(HSQCarray[i][4].c_str()) - Hdev &&  atof(CBCACONHarray[j][4].c_str()) <= atof(HSQCarray[i][4].c_str()) + Hdev )
            {
                CBCACONHarray[j][0]=HSQCarray[i][0];
                CBCACONHarray[j][1]=HSQCarray[i][1];
                i=counterhsqc;
            }
            if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
                CBCACONHarray[j][0]="?";
            if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
            {
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
                std::string sub;
                std::stringstream ss,ss2;
                ss << counternum;
                ss >> sub;
                CBCACONHarray[j][0]=sub;
                HSQCsub.push_back(sub);
                counternum--;
                ss2 << counternum;
                ss2 >> sub;
                CBCACONHarray[j][1]=sub;
                HSQCsub.push_back(sub);
                HSQCsub.push_back(CBCACONHarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(CBCACONHarray[j][4]);
                counternum++;
                counternum+=10;
                countertemp++;
                HSQCarray.push_back(HSQCsub);
            }
        }
    }
    for(int j=0;j<countercbcaconh-2;j++)
    {
        if (CBCACONHarray[j][7]=="")
        {
            if (j==countercbcaconh-3)
            {
                if (atof(CBCACONHarray[j][3].c_str()) >= 42 && atof(CBCACONHarray[j][3].c_str()) <= 48)
                {
                    CBCACONHarray[j][7]="CA"; // Gly
                }
            }
            for(int i=j+1;i<countercbcaconh-2;i++)
            {
                if(atof(CBCACONHarray[j][2].c_str()) >= atof(CBCACONHarray[i][2].c_str()) - Ndev &&  atof(CBCACONHarray[j][2].c_str()) <= atof(CBCACONHarray[i][2].c_str()) + Ndev && atof(CBCACONHarray[j][4].c_str()) >= atof(CBCACONHarray[i][4].c_str()) - Hdev &&  atof(CBCACONHarray[j][4].c_str()) <= atof(CBCACONHarray[i][4].c_str()) + Hdev && CBCACONHarray[j][7] == CBCACONHarray[i][7] && CBCACONHarray[j][0]!="?")
                    {
                        if (atof(CBCACONHarray[j][3].c_str()) >= 50 && atof(CBCACONHarray[i][3].c_str()) >= 50) //Ser, Thr
                        {
                            if (atof(CBCACONHarray[j][3].c_str()) > atof(CBCACONHarray[i][3].c_str()) )
                            {
                                CBCACONHarray[j][7]="CB";
                                CBCACONHarray[i][7]="CA";
                                break;
                            }
                            else
                            {
                                CBCACONHarray[j][7]="CA";
                                CBCACONHarray[i][7]="CB";
                                break;
                            }
                        }
                        else
                        {
                            if (atof(CBCACONHarray[j][3].c_str()) > atof(CBCACONHarray[i][3].c_str()))
                            {
                                CBCACONHarray[j][7]="CA";
                                CBCACONHarray[i][7]="CB";
                                break;
                            }
                            else
                            {
                                CBCACONHarray[j][7]="CB";
                                CBCACONHarray[i][7]="CA";
                                break;
                            }
                        }
                    }
                else if (i==countercbcaconh-3 && atof(CBCACONHarray[j][3].c_str()) >= 42 && atof(CBCACONHarray[j][3].c_str()) <= 48)
                {
                    CBCACONHarray[j][7]="CA"; // Gly
                }
            }
        }
    }
    extern std::vector< std::vector <double> > SpinSysarray; //[5000][12]
    extern std::vector<double> Spinsub;
    Spinsub.erase(Spinsub.begin(),Spinsub.end());
    for (int i=0;i<12;i++)
        Spinsub.push_back(0.0);

    for (int i=0;i<countertemp-counterhsqc;i++)
        SpinSysarray.push_back(Spinsub);

    counterhsqc=countertemp;
    fileo.open(CBCACONHfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2  w3"<<std::endl;
    for(int i=0;i<countercbcaconh-2;i++)
    {
        if(CBCACONHarray[i][0]=="?")
            fileo<<std::right<<std::endl<<CBCACONHarray[i][0]<<"-?-?  "<<CBCACONHarray[i][2]<<"  "<<CBCACONHarray[i][3]<<"  "<<CBCACONHarray[i][4];
        else if(CBCACONHarray[i][0]!="" && CBCACONHarray[i][7]!="")
        {
            fileo<<std::right<<std::endl<<CBCACONHarray[i][0]<<"N-"<<CBCACONHarray[i][1]<<CBCACONHarray[i][7]<<"-"<<CBCACONHarray[i][0]<<"HN  ";
            fileo<<std::left<<CBCACONHarray[i][2]<<"  "<<CBCACONHarray[i][3]<<"  "<<CBCACONHarray[i][4];
        }
        else if(CBCACONHarray[i][0]!="")
        {
            fileo<<std::right<<std::endl<<CBCACONHarray[i][0]<<"N-"<<CBCACONHarray[i][1]<<"C?-"<<CBCACONHarray[i][0]<<"HN  ";
            fileo<<std::left<<CBCACONHarray[i][2]<<"  "<<CBCACONHarray[i][3]<<"  "<<CBCACONHarray[i][4];
        }
    }
    fileo.clear();
    fileo.close();
    int num=0;
    for(int i=0;i<countercbcaconh-2;i++)
    {
        if (CBCACONHarray[i][0]!="?")
        {
            num=atoi(CBCACONHarray[i][0].c_str())/10;
            if (CBCACONHarray[i][7]=="CB")
            {
                SpinSysarray[num][8]=atof(CBCACONHarray[i][3].c_str());
            }
            else if (CBCACONHarray[i][7]=="CA")
            {
                SpinSysarray[num][6]=atof(CBCACONHarray[i][3].c_str());
            }
            if (SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(CBCACONHarray[i][2].c_str());
                SpinSysarray[num][2]=atof(CBCACONHarray[i][4].c_str());
            }
        }
    }
}
void CompassSpinSystem::Fake_AssignHNCACB()
{
	QString	path=ui->HNCACBLine->text(); 
	std::string HNCACBfile;
	QByteArray nByte= path.toUtf8();
	HNCACBfile=nByte.data();

    extern std::string Dir;
	
	double Ndev, Hdev;
	
	Ndev = ui->devNBox->value();
	Hdev = ui->devHBox->value();

	std::string line,HNCACBfileout;
	unsigned found=HNCACBfile.find_last_of("/");
    HNCACBfileout=Dir+HNCACBfile.substr(found+1)+".compass";
	std::ifstream file;
	std::ofstream fileo;
	file.open(HNCACBfile.c_str(), std::ios::in);
    int counterhncacb=0;
	while(file.good())
	{
		getline(file,line);
		counterhncacb++;
	}
	counterhncacb--;
	file.clear();
	file.close();
	file.open(HNCACBfile.c_str(), std::ios::in);
    std::vector< std::vector< std::string > > HNCACBarray=DefVec2(counterhncacb-2,8);
	getline(file,line);
	getline(file,line);
	std::string negtype,postype;
	if(ui->CAButton->isChecked())
	{
		negtype="CA";
		postype="CB";
	}
	if(ui->CBButton->isChecked())
	{
		negtype="CB";
		postype="CA";
	}
	for(int i=0;i<counterhncacb-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNCACBarray[i][2]=sub;
		iss >> sub;
		HNCACBarray[i][3]=sub;
		iss >> sub;
		HNCACBarray[i][4]=sub;
		iss >> sub;
		HNCACBarray[i][5]=sub;
		if (atof(HNCACBarray[i][5].c_str()) <= 0)
		{
			HNCACBarray[i][7]=negtype;
		}
		else if(atof(HNCACBarray[i][5].c_str()) >= 0)
		{
			HNCACBarray[i][7]=postype;
		}
		HNCACBarray[i][6]="i";
	}
	file.clear();
	file.close();
    extern std::vector< std::vector <std::string> > HSQCarray; //[5000][6]
    extern std::vector<std::string> HSQCsub;
    extern int counterhsqc;
	extern int counternum;
	int countertemp=counterhsqc;
	for(int j=0;j<counterhncacb-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(HNCACBarray[j][2].c_str()) >= atof(HSQCarray[i][2].c_str()) - Ndev &&  atof(HNCACBarray[j][2].c_str()) <= atof(HSQCarray[i][2].c_str()) + Ndev && atof(HNCACBarray[j][4].c_str()) >= atof(HSQCarray[i][4].c_str()) - Hdev &&  atof(HNCACBarray[j][4].c_str()) <= atof(HSQCarray[i][4].c_str()) + Hdev )
			{
				HNCACBarray[j][0]=HSQCarray[i][0];
				HNCACBarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
			if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
				HNCACBarray[j][0]="?";
			if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
			{
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
                std::string sub;
				std::stringstream ss,ss2;
				ss << counternum;
				ss >> sub;
				HNCACBarray[j][0]=sub;
                HSQCsub.push_back(sub);
				counternum--;
				ss2 << counternum;
				ss2 >> sub;
				HNCACBarray[j][1]=sub;
                HSQCsub.push_back(sub);
                HSQCsub.push_back(HNCACBarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(HNCACBarray[j][4]);
                counternum++;
				counternum+=10;
				countertemp++;
                HSQCarray.push_back(HSQCsub);
			}
		}
	}
	for(int j=0;j<counterhncacb-3;j++)
	{
		for(int i=j+1;i<counterhncacb-2;i++)
		{
			if(atof(HNCACBarray[j][2].c_str()) >= atof(HNCACBarray[i][2].c_str()) - Ndev &&  atof(HNCACBarray[j][2].c_str()) <= atof(HNCACBarray[i][2].c_str()) + Ndev && atof(HNCACBarray[j][4].c_str()) >= atof(HNCACBarray[i][4].c_str()) - Hdev &&  atof(HNCACBarray[j][4].c_str()) <= atof(HNCACBarray[i][4].c_str()) + Hdev && HNCACBarray[j][7] == HNCACBarray[i][7] && HNCACBarray[j][0]!="?")
			{
				if(std::abs (atof(HNCACBarray[j][5].c_str())) <= std::abs (atof(HNCACBarray[i][5].c_str())))
				{
					HNCACBarray[j][6]="i-1";
					HNCACBarray[i][6]="i";
							}
				else
				{
					HNCACBarray[i][6]="i-1";
					HNCACBarray[j][6]="i";
				}
			}
		}
	}
	fileo.open(HNCACBfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2  w3"<<std::endl;
	for(int i=0;i<counterhncacb-2;i++)
	{
		if(HNCACBarray[i][0]=="?")
            fileo<<std::right<<std::endl<<HNCACBarray[i][0]<<"-?-?  "<<HNCACBarray[i][2]<<"  "<<HNCACBarray[i][3]<<"  "<<HNCACBarray[i][4];
		else
		{
            if(HNCACBarray[i][6]=="i" && HNCACBarray[i][0]!="" && HNCACBarray[i][7]!="")
			{
                fileo<<std::right<<std::endl<<HNCACBarray[i][0]<<"N-"<<HNCACBarray[i][7]<<"-HN  ";
                fileo<<std::left<<HNCACBarray[i][2]<<"  "<<HNCACBarray[i][3]<<"  "<<HNCACBarray[i][4];
			}
            else if(HNCACBarray[i][6]=="i" && HNCACBarray[i][0]!="")
            {
                fileo<<std::right<<std::endl<<HNCACBarray[i][0]<<"N-"<<"C?-HN  ";
                fileo<<std::left<<HNCACBarray[i][2]<<"  "<<HNCACBarray[i][3]<<"  "<<HNCACBarray[i][4];
            }
            else if(HNCACBarray[i][6]=="i-1" && HNCACBarray[i][0]!="" && HNCACBarray[i][7]!="")
			{
                fileo<<std::right<<std::endl<<HNCACBarray[i][0]<<"N-"<<HNCACBarray[i][1]<<HNCACBarray[i][7]<<"-"<<HNCACBarray[i][0]<<"HN  ";
                fileo<<std::left<<HNCACBarray[i][2]<<"  "<<HNCACBarray[i][3]<<"  "<<HNCACBarray[i][4];
			}
            else if(HNCACBarray[i][6]=="i-1" && HNCACBarray[i][0]!="")
            {
                fileo<<std::right<<std::endl<<HNCACBarray[i][0]<<"N-"<<HNCACBarray[i][1]<<"C?-"<<HNCACBarray[i][0]<<"HN  ";
                fileo<<std::left<<HNCACBarray[i][2]<<"  "<<HNCACBarray[i][3]<<"  "<<HNCACBarray[i][4];
            }
		}
	}
	fileo.clear();
	fileo.close();
	{
	int num=0;
    extern std::vector< std::vector <double> > SpinSysarray;
    extern std::vector<double> Spinsub;
    Spinsub.erase(Spinsub.begin(),Spinsub.end());
    for (int i=0;i<12;i++)
        Spinsub.push_back(0.0);

    for (int i=0;i<countertemp-counterhsqc;i++)
        SpinSysarray.push_back(Spinsub);
    counterhsqc=countertemp;
	for(int i=0;i<counterhncacb-2;i++)
	{
		if (HNCACBarray[i][0]!="?")
		{
			num=atoi(HNCACBarray[i][0].c_str())/10;
			if (HNCACBarray[i][6]=="i")
			{
				if(HNCACBarray[i][7]=="CB")
					SpinSysarray[num][7]=atof(HNCACBarray[i][3].c_str());
				else if(HNCACBarray[i][7]=="CA")
					SpinSysarray[num][5]=atof(HNCACBarray[i][3].c_str());
				
			}
			else  if (HNCACBarray[i][6]=="i-1")
			{
				if (HNCACBarray[i][7]=="CB")
				{
					SpinSysarray[num][8]=atof(HNCACBarray[i][3].c_str());
				}
				else if (HNCACBarray[i][7]=="CA")
				{
					SpinSysarray[num][6]=atof(HNCACBarray[i][3].c_str());
				}
			}
            if (SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(HNCACBarray[i][2].c_str());
                SpinSysarray[num][2]=atof(HNCACBarray[i][4].c_str());
            }
		}
	}
	}
}
void CompassSpinSystem::Fake_AssignHNcaCBandHNcocaCB()
{
	QString	path=ui->HNCACBLine->text(); 
	std::string HNcaCBfile;
	QByteArray nByte= path.toUtf8();
	HNcaCBfile=nByte.data();

	path=ui->HNCOCACBLine->text(); 
	std::string HNCOCACBfile;
	nByte= path.toUtf8();
	HNCOCACBfile=nByte.data();

    extern std::string Dir;
	
	double Ndev, Cdev, Hdev;
	
	Ndev = ui->devNBox->value();
	Cdev = ui->devCBox->value();
	Hdev = ui->devHBox->value();

	std::string line,HNcaCBfileout,HNCOCACBfileout;
	unsigned found=HNcaCBfile.find_last_of("/");
	unsigned found1=HNCOCACBfile.find_last_of("/");
    HNcaCBfileout=Dir+HNcaCBfile.substr(found+1)+".compass";
    HNCOCACBfileout=Dir+HNCOCACBfile.substr(found1+1)+".compass";
	std::ifstream file;
	std::ofstream fileo;
	file.open(HNcaCBfile.c_str(), std::ios::in);
    int counterhncaCB=0;
	while(file.good())
	{
		getline(file,line);
		counterhncaCB++;
	}
	counterhncaCB--;
	file.clear();
	file.close();
	file.open(HNcaCBfile.c_str(), std::ios::in);
    std::vector< std::vector< std::string > > HNcaCBarray=DefVec2(counterhncaCB-2,7);
	getline(file,line);
	getline(file,line);
	for(int i=0;i<counterhncaCB-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNcaCBarray[i][2]=sub;
		iss >> sub;
		HNcaCBarray[i][3]=sub;
		iss >> sub;
		HNcaCBarray[i][4]=sub;
		iss >> sub;
		HNcaCBarray[i][5]=sub;
		HNcaCBarray[i][6]="i";
	}
	file.clear();
	file.close();
	file.open(HNCOCACBfile.c_str(), std::ios::in);
    int counterhncocacb=0;
	while(file.good())
	{
		getline(file,line);
		counterhncocacb++;
	}
	counterhncocacb--;
	file.clear();
	file.close();
	file.open(HNCOCACBfile.c_str(), std::ios::in);
    std::vector< std::vector< std::string > > HNCOCACBarray=DefVec2(counterhncocacb-2,7);
	getline(file,line);
	getline(file,line);
	for(int i=0;i<counterhncocacb-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNCOCACBarray[i][2]=sub;
		iss >> sub;
		HNCOCACBarray[i][3]=sub;
		iss >> sub;
		HNCOCACBarray[i][4]=sub;
		iss >> sub;
		HNCOCACBarray[i][5]=sub;
	}
	file.clear();
	file.close();
    extern int counterhsqc;
    extern std::vector< std::vector <std::string> > HSQCarray; //[5000][6]
    extern std::vector<std::string> HSQCsub;

	extern int counternum;
	int countertemp=counterhsqc;
	for(int j=0;j<counterhncocacb-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(HNCOCACBarray[j][2].c_str()) >= atof(HSQCarray[i][2].c_str()) - Ndev &&  atof(HNCOCACBarray[j][2].c_str()) <= atof(HSQCarray[i][2].c_str()) + Ndev && atof(HNCOCACBarray[j][4].c_str()) >= atof(HSQCarray[i][4].c_str()) - Hdev &&  atof(HNCOCACBarray[j][4].c_str()) <= atof(HSQCarray[i][4].c_str()) + Hdev )
			{
				HNCOCACBarray[j][0]=HSQCarray[i][0];
				HNCOCACBarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
			if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
				HNCOCACBarray[j][0]="?";
			if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
			{
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
                std::string sub;
				std::stringstream ss,ss2;
				ss << counternum;
				ss >> sub;
				HNCOCACBarray[j][0]=sub;
                HSQCsub.push_back(sub);
				counternum--;
				ss2 << counternum;
				ss2 >> sub;
				HNCOCACBarray[j][1]=sub;
                HSQCsub.push_back(sub);
                HSQCsub.push_back(HNCOCACBarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(HNCOCACBarray[j][4]);
                counternum++;
				counternum+=10;
				countertemp++;
                HSQCarray.push_back(HSQCsub);
			}
		}
	}
    extern std::vector< std::vector <double> > SpinSysarray;
    extern std::vector<double> Spinsub;
    Spinsub.erase(Spinsub.begin(),Spinsub.end());
    for (int i=0;i<12;i++)
        Spinsub.push_back(0.0);

    for (int i=0;i<countertemp-counterhsqc;i++)
        SpinSysarray.push_back(Spinsub);

	counterhsqc=countertemp;
	for(int j=0;j<counterhncaCB-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(HNcaCBarray[j][2].c_str()) >= atof(HSQCarray[i][2].c_str()) - Ndev &&  atof(HNcaCBarray[j][2].c_str()) <= atof(HSQCarray[i][2].c_str()) + Ndev && atof(HNcaCBarray[j][4].c_str()) >= atof(HSQCarray[i][4].c_str()) - Hdev &&  atof(HNcaCBarray[j][4].c_str()) <= atof(HSQCarray[i][4].c_str()) + Hdev )
			{
				HNcaCBarray[j][0]=HSQCarray[i][0];
				HNcaCBarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
		if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
				HNcaCBarray[j][0]="?";
		if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
			{
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
				std::string sub;
				std::stringstream ss,ss2;
				ss << counternum;
				ss >> sub;
				HNcaCBarray[j][0]=sub;
                HSQCsub.push_back(sub);
				counternum--;
				ss2 << counternum;
				ss2 >> sub;
				HNcaCBarray[j][1]=sub;
                HSQCsub.push_back(sub);
                HSQCsub.push_back(HNcaCBarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(HNcaCBarray[j][4]);
				counternum++;
				counternum+=10;
                countertemp++;
                HSQCarray.push_back(HSQCsub);
			}
		}
		for(int i=0;i<counterhncocacb-2;i++)
			if(atof(HNcaCBarray[j][2].c_str()) >= atof(HNCOCACBarray[i][2].c_str()) - Ndev &&  atof(HNcaCBarray[j][2].c_str()) <= atof(HNCOCACBarray[i][2].c_str()) + Ndev && atof(HNcaCBarray[j][4].c_str()) >= atof(HNCOCACBarray[i][4].c_str()) - Hdev &&  atof(HNcaCBarray[j][4].c_str()) <= atof(HNCOCACBarray[i][4].c_str()) + Hdev ) 
			{
				if(atof(HNcaCBarray[j][3].c_str()) >= atof(HNCOCACBarray[i][3].c_str()) - Cdev && atof(HNcaCBarray[j][3].c_str()) <= atof(HNCOCACBarray[i][3].c_str()) + Cdev )
					HNcaCBarray[j][6]="i-1";
			}	
	}
    Spinsub.erase(Spinsub.begin(),Spinsub.end());
    for (int i=0;i<12;i++)
        Spinsub.push_back(0.0);

    for (int i=0;i<countertemp-counterhsqc;i++)
        SpinSysarray.push_back(Spinsub);
    counterhsqc=countertemp;
	fileo.open(HNCOCACBfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2  w3"<<std::endl;
	for(int i=0;i<counterhncocacb-2;i++)
    {
        if(HNCOCACBarray[i][0]=="?")
            fileo<<std::endl<<HNCOCACBarray[i][0]<<"-?-?  "<<HNCOCACBarray[i][2]<<"  "<<HNCOCACBarray[i][3]<<"  "<<HNCOCACBarray[i][4];
        else
            fileo<<std::endl<<HNCOCACBarray[i][0]<<"N-"<<HNCOCACBarray[i][1]<<"CB-"<<HNCOCACBarray[i][0]<<"HN  "<<HNCOCACBarray[i][2]<<"  "<<HNCOCACBarray[i][3]<<"  "<<HNCOCACBarray[i][4];
    }
	fileo.clear();
	fileo.close();
	fileo.open(HNcaCBfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2  w3"<<std::endl;
	for(int i=0;i<counterhncaCB-2;i++)
	{
		if(HNcaCBarray[i][0]=="?")
		{
                fileo<<std::right<<std::endl<<HNcaCBarray[i][0]<<"-?-?  ";
                fileo<<std::left<<HNcaCBarray[i][2]<<"  "<<HNcaCBarray[i][3]<<"  "<<HNcaCBarray[i][4];
		}
		else
		{
			if(HNcaCBarray[i][6]=="i")
			{
                fileo<<std::right<<std::endl<<HNcaCBarray[i][0]<<"N-CB-HN  ";
                fileo<<std::left<<HNcaCBarray[i][2]<<"  "<<HNcaCBarray[i][3]<<"  "<<HNcaCBarray[i][4];
			}
			else if(HNcaCBarray[i][6]=="i-1")
				{
                fileo<<std::right<<std::endl<<HNcaCBarray[i][0]<<"N-"<<HNcaCBarray[i][1]<<"CB-"<<HNcaCBarray[i][0]<<"HN  ";
                fileo<<std::left<<HNcaCBarray[i][2]<<"  "<<HNcaCBarray[i][3]<<"  "<<HNcaCBarray[i][4];
			}
		}
	}
	fileo.clear();
	fileo.close();
	{
	int num=0;

	for(int i=0;i<counterhncocacb-2;i++)
	{
		if (HNCOCACBarray[i][0]!="?")
		{
			num=atoi(HNCOCACBarray[i][0].c_str())/10;
			SpinSysarray[num][8]=atof(HNCOCACBarray[i][3].c_str());
		}
        if (SpinSysarray[num][1]==0.0)
        {
            SpinSysarray[num][0]=num*10;
            SpinSysarray[num][1]=atof(HNcaCBarray[i][2].c_str());
            SpinSysarray[num][2]=atof(HNcaCBarray[i][4].c_str());
        }
	}
	for(int i=0;i<counterhncaCB-2;i++)
	{
		if (HNcaCBarray[i][0]!="?")
		{
			num=atoi(HNcaCBarray[i][0].c_str())/10;
			if (HNcaCBarray[i][6]=="i")
			{
				SpinSysarray[num][7]=atof(HNcaCBarray[i][3].c_str());
			}
			else  if (HNcaCBarray[i][6]=="i-1")
			{
				if (SpinSysarray[num][8]==0.0)
				{
					SpinSysarray[num][8]=atof(HNcaCBarray[i][3].c_str());
				}
				else
				{
					double co=SpinSysarray[num][8];
					double mean=0.0,stDev=0.0;
					mean=(atof(HNcaCBarray[i][3].c_str())+co)/2;
					stDev=sqrt(((atof(HNcaCBarray[i][3].c_str())-mean)*(atof(HNcaCBarray[i][3].c_str())-mean)+(co-mean)*(co-mean))/2);
					SpinSysarray[num][8]=mean;
					SpinSysarray[num][11]=stDev;
				}
            }
            if (SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(HNcaCBarray[i][2].c_str());
                SpinSysarray[num][2]=atof(HNcaCBarray[i][4].c_str());
            }
		}
	}
	}
}
void CompassSpinSystem::Fake_AssignHNcaCB()
{
	QString	path=ui->HNCACBLine->text(); 
	std::string HNcaCBfile;
	QByteArray nByte= path.toUtf8();
	HNcaCBfile=nByte.data();

	path = ui->folderLine->text();

    extern std::string Dir;
	
	double Ndev, Hdev;
	
	Ndev = ui->devNBox->value();
	Hdev = ui->devHBox->value();

	std::string line,HNcaCBfileout;
	unsigned found=HNcaCBfile.find_last_of("/");
    HNcaCBfileout=Dir+HNcaCBfile.substr(found+1)+".compass";
	std::ifstream file;
	std::ofstream fileo;
	file.open(HNcaCBfile.c_str(), std::ios::in);
    int counterhncaCB=0;
	while(file.good())
	{
		getline(file,line);
		counterhncaCB++;
	}
	counterhncaCB--;
	file.clear();
	file.close();
	file.open(HNcaCBfile.c_str(), std::ios::in);
    std::vector< std::vector< std::string > > HNcaCBarray=DefVec2(counterhncaCB-2,7);
	getline(file,line);
	getline(file,line);
	for(int i=0;i<counterhncaCB-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNcaCBarray[i][2]=sub;
		iss >> sub;
		HNcaCBarray[i][3]=sub;
		iss >> sub;
		HNcaCBarray[i][4]=sub;
		iss >> sub;
		HNcaCBarray[i][5]=sub;
		HNcaCBarray[i][6]="i";
	}
	file.clear();
	file.close();
    extern std::vector< std::vector <std::string> > HSQCarray;
    extern std::vector<std::string> HSQCsub;
    extern int counterhsqc, counternum;
	int countertemp=counterhsqc;
	for(int j=0;j<counterhncaCB-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(HNcaCBarray[j][2].c_str()) >= atof(HSQCarray[i][2].c_str()) - Ndev &&  atof(HNcaCBarray[j][2].c_str()) <= atof(HSQCarray[i][2].c_str()) + Ndev && atof(HNcaCBarray[j][4].c_str()) >= atof(HSQCarray[i][4].c_str()) - Hdev &&  atof(HNcaCBarray[j][4].c_str()) <= atof(HSQCarray[i][4].c_str()) + Hdev )
			{
				HNcaCBarray[j][0]=HSQCarray[i][0];
				HNcaCBarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
			if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
				HNcaCBarray[j][0]="?";
			if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
			{
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
                std::string sub;
				std::stringstream ss,ss2;
				ss << counternum;
				ss >> sub;
				HNcaCBarray[j][0]=sub;
                HSQCsub.push_back(sub);
				counternum--;
				ss2 << counternum;
				ss2 >> sub;
				HNcaCBarray[j][1]=sub;
                HSQCsub.push_back(sub);
                HSQCsub.push_back(HNcaCBarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(HNcaCBarray[j][4]);
                counternum++;
				counternum+=10;
				countertemp++;
                HSQCarray.push_back(HSQCsub);
			}
		}
	}
    extern std::vector< std::vector <double> > SpinSysarray;
    extern std::vector<double> Spinsub;
    Spinsub.erase(Spinsub.begin(),Spinsub.end());
    for (int i=0;i<12;i++)
        Spinsub.push_back(0.0);

    for (int i=0;i<countertemp-counterhsqc;i++)
        SpinSysarray.push_back(Spinsub);
    counterhsqc=countertemp;
	for(int j=0;j<counterhncaCB-3;j++)
	{
		for(int i=j+1;i<counterhncaCB-2;i++)
		{
			if(HNcaCBarray[j][0] == HNcaCBarray[i][0] && HNcaCBarray[j][0]!="?")
			{
				if(std::abs (atof(HNcaCBarray[j][5].c_str())) <= std::abs (atof(HNcaCBarray[i][5].c_str())))
				{
					HNcaCBarray[j][6]="i-1";
					HNcaCBarray[i][6]="i";
				}
				else
				{
					HNcaCBarray[i][6]="i-1";
					HNcaCBarray[j][6]="i";
				}
			}
		}
	}
	fileo.open(HNcaCBfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2  w3"<<std::endl;
	for(int i=0;i<counterhncaCB-2;i++)
	{
        if(HNcaCBarray[i][0]=="?")
        {
            fileo<<std::right<<std::endl<<HNcaCBarray[i][0]<<"-?-?  ";
            fileo<<std::left<<HNcaCBarray[i][2]<<"  "<<HNcaCBarray[i][3]<<"  "<<HNcaCBarray[i][4];
        }
        else if(HNcaCBarray[i][6]=="i")
		{
            fileo<<std::right<<std::endl<<HNcaCBarray[i][0]<<"N-CB-HN  ";
            fileo<<std::left<<HNcaCBarray[i][2]<<"  "<<HNcaCBarray[i][3]<<"  "<<HNcaCBarray[i][4];
		}
		else if(HNcaCBarray[i][6]=="i-1" )
		{
            fileo<<std::right<<std::endl<<HNcaCBarray[i][0]<<"N-"<<HNcaCBarray[i][1]<<"CB-"<<HNcaCBarray[i][0]<<"HN  ";
            fileo<<std::left<<HNcaCBarray[i][2]<<"  "<<HNcaCBarray[i][3]<<"  "<<HNcaCBarray[i][4];
		}
	}
	fileo.clear();
	fileo.close();
	for(int i=0;i<counterhncaCB-2;i++)
	{
		if (HNcaCBarray[i][0]!="?")
		{
			int num=0;

			num=atoi(HNcaCBarray[i][0].c_str())/10;
			if (HNcaCBarray[i][6]=="i")
			{
				SpinSysarray[num][7]=atof(HNcaCBarray[i][3].c_str());
			}
			else  if (HNcaCBarray[i][6]=="i-1")
			{
					SpinSysarray[num][8]=atof(HNcaCBarray[i][3].c_str());
			}
            if (SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(HNcaCBarray[i][2].c_str());
                SpinSysarray[num][2]=atof(HNcaCBarray[i][4].c_str());
            }
		}
	}
}
void CompassSpinSystem::Fake_AssignHNcocaCB()
{
	QString	path=ui->HNCOCACBLine->text(); 
	std::string HNCOCACBfile;
	QByteArray nByte= path.toUtf8();
	HNCOCACBfile=nByte.data();

    extern std::string Dir;
	
	double Ndev, Hdev;
	
	Ndev = ui->devNBox->value();
	Hdev = ui->devHBox->value();

	std::string line,HNCOCACBfileout;
	unsigned found=HNCOCACBfile.find_last_of("/");
    HNCOCACBfileout=Dir+HNCOCACBfile.substr(found+1)+".compass";
	std::ifstream file;
	std::ofstream fileo;
	file.open(HNCOCACBfile.c_str(), std::ios::in);
    int counterhncocacb=0;
	while(file.good())
	{
		getline(file,line);
		counterhncocacb++;
	}
	counterhncocacb--;
	file.clear();
	file.close();
	file.open(HNCOCACBfile.c_str(), std::ios::in);
    std::vector< std::vector< std::string > > HNCOCACBarray=DefVec2(counterhncocacb-2,7);
	getline(file,line);
	getline(file,line);
	for(int i=0;i<counterhncocacb-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNCOCACBarray[i][2]=sub;
		iss >> sub;
		HNCOCACBarray[i][3]=sub;
		iss >> sub;
		HNCOCACBarray[i][4]=sub;
		iss >> sub;
		HNCOCACBarray[i][5]=sub;
	}
	file.clear();
	file.close();
    extern std::vector< std::vector <std::string> > HSQCarray;
    extern std::vector<std::string> HSQCsub;

	extern int counterhsqc,counternum;

	int countertemp=counterhsqc;
	for(int j=0;j<counterhncocacb-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(HNCOCACBarray[j][2].c_str()) >= atof(HSQCarray[i][2].c_str()) - Ndev &&  atof(HNCOCACBarray[j][2].c_str()) <= atof(HSQCarray[i][2].c_str()) + Ndev && atof(HNCOCACBarray[j][4].c_str()) >= atof(HSQCarray[i][4].c_str()) - Hdev &&  atof(HNCOCACBarray[j][4].c_str()) <= atof(HSQCarray[i][4].c_str()) + Hdev )
			{
				HNCOCACBarray[j][0]=HSQCarray[i][0];
				HNCOCACBarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
			if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
                HNCOCACBarray[j][0]="?";
			if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
			{
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
				std::string sub;
				std::stringstream ss,ss2;
				ss << counternum;
				ss >> sub;
				HNCOCACBarray[j][0]=sub;
                HSQCsub.push_back(sub);
				counternum--;
				ss2 << counternum;
				ss2 >> sub;
				HNCOCACBarray[j][1]=sub;
                HSQCsub.push_back(sub);
                HSQCsub.push_back(HNCOCACBarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(HNCOCACBarray[j][4]);
                counternum++;
				counternum+=10;
				countertemp++;
                HSQCarray.push_back(HSQCsub);
			}

		}
	}
    extern std::vector< std::vector <double> > SpinSysarray;
    extern std::vector<double> Spinsub;
    Spinsub.erase(Spinsub.begin(),Spinsub.end());
    for (int i=0;i<12;i++)
        Spinsub.push_back(0.0);
    for (int i=0;i<countertemp-counterhsqc;i++)
        SpinSysarray.push_back(Spinsub);
	counterhsqc=countertemp;
	fileo.open(HNCOCACBfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2  w3"<<std::endl;
	for(int i=0;i<counterhncocacb-2;i++)
		if(HNCOCACBarray[i][0]=="?")
            fileo<<std::endl<<HNCOCACBarray[i][0]<<"-?-?  "<<HNCOCACBarray[i][2]<<"  "<<HNCOCACBarray[i][3]<<"  "<<HNCOCACBarray[i][4];
		else
            fileo<<std::endl<<HNCOCACBarray[i][0]<<"N-"<<HNCOCACBarray[i][1]<<"CB-"<<HNCOCACBarray[i][0]<<"HN  "<<HNCOCACBarray[i][2]<<"  "<<HNCOCACBarray[i][3]<<"  "<<HNCOCACBarray[i][4];
	fileo.clear();
	fileo.close();
	for(int i=0;i<counterhncocacb-2;i++)
	{
        if (HNCOCACBarray[i][0]!="?")
		{
            int num=0;
			num=atoi(HNCOCACBarray[i][0].c_str())/10;
			SpinSysarray[num][8]=atof(HNCOCACBarray[i][3].c_str());
            if (SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(HNCOCACBarray[i][2].c_str());
                SpinSysarray[num][2]=atof(HNCOCACBarray[i][4].c_str());
            }
        }
	}
}
void CompassSpinSystem::Fake_AssignHNCAandHNCOCA()
{
	QString	path=ui->HNCALine->text(); 
	std::string HNCAfile;
	QByteArray nByte= path.toUtf8();
	HNCAfile=nByte.data();

	path=ui->HNCOCALine->text(); 
	std::string HNCOCAfile;
	nByte= path.toUtf8();
	HNCOCAfile=nByte.data();

    extern std::string Dir;
	
	double Ndev, Cdev, Hdev;
	
	Ndev = ui->devNBox->value();
	Cdev = ui->devCBox->value();
	Hdev = ui->devHBox->value();

	std::string line,HNCAfileout,HNCOCAfileout;
	unsigned found=HNCAfile.find_last_of("/");
	unsigned found1=HNCOCAfile.find_last_of("/");
    HNCAfileout=Dir+HNCAfile.substr(found+1)+".compass";
    HNCOCAfileout=Dir+HNCOCAfile.substr(found1+1)+".compass";
	std::ifstream file;
	std::ofstream fileo;
	file.open(HNCOCAfile.c_str(), std::ios::in);
    int counterhncoca=0;
	while(file.good())
	{
		getline(file,line);
		counterhncoca++;
	}
	counterhncoca--;
	file.clear();
	file.close();
	file.open(HNCOCAfile.c_str(), std::ios::in);
    std::vector< std::vector< std::string > > HNCOCAarray=DefVec2(counterhncoca-2,7);
	getline(file,line);
	getline(file,line);
	for(int i=0;i<counterhncoca-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNCOCAarray[i][2]=sub;
		iss >> sub;
		HNCOCAarray[i][3]=sub;
		iss >> sub;
		HNCOCAarray[i][4]=sub;
		iss >> sub;
		HNCOCAarray[i][5]=sub;
	}
	file.clear();
	file.close();
	file.open(HNCAfile.c_str(), std::ios::in);
	int counterhnca=0; //Number of peaks in HNCA list
	while(file.good())
	{
		getline(file,line);
		counterhnca++;
	}
	counterhnca--;
	file.clear();
	file.close();
	file.open(HNCAfile.c_str(), std::ios::in);
    std::vector< std::vector< std::string > > HNCAarray=DefVec2(counterhnca-2,7);
	getline(file,line);
	getline(file,line);
	for(int i=0;i<counterhnca-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNCAarray[i][2]=sub;
		iss >> sub;
		HNCAarray[i][3]=sub;
		iss >> sub;
		HNCAarray[i][4]=sub;
		iss >> sub;
		HNCAarray[i][5]=sub;
		HNCAarray[i][6]="i";
	}
	file.clear();
	file.close();
    extern std::vector< std::vector <std::string> > HSQCarray;
    extern std::vector<std::string> HSQCsub;

	extern int counterhsqc,counternum;

	int countertemp=counterhsqc;
	for(int j=0;j<counterhncoca-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(HNCOCAarray[j][2].c_str()) >= atof(HSQCarray[i][2].c_str()) - Ndev &&  atof(HNCOCAarray[j][2].c_str()) <= atof(HSQCarray[i][2].c_str()) + Ndev && atof(HNCOCAarray[j][4].c_str()) >= atof(HSQCarray[i][4].c_str()) - Hdev &&  atof(HNCOCAarray[j][4].c_str()) <= atof(HSQCarray[i][4].c_str()) + Hdev )
			{
				HNCOCAarray[j][0]=HSQCarray[i][0];
				HNCOCAarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
			if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
				HNCOCAarray[j][0]="?";
			if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
			{
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
                std::string sub;
				std::stringstream ss,ss2;
				ss << counternum;
				ss >> sub;
				HNCOCAarray[j][0]=sub;
                HSQCsub.push_back(sub);
                counternum--;
				ss2 << counternum;
				ss2 >> sub;
				HNCOCAarray[j][1]=sub;
                HSQCsub.push_back(sub);
                HSQCsub.push_back(HNCOCAarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(HNCOCAarray[j][4]);
                HSQCarray.push_back(HSQCsub);
                counternum++;
				counternum+=10;
				countertemp++;
			}

		}
	}
    extern std::vector< std::vector <double> > SpinSysarray;
    extern std::vector<double> Spinsub;

    Spinsub.erase(Spinsub.begin(),Spinsub.end());
    for (int i=0;i<12;i++)
        Spinsub.push_back(0.0);

    for (int i=0;i<countertemp-counterhsqc;i++)
        SpinSysarray.push_back(Spinsub);
    counterhsqc=countertemp;
	for(int j=0;j<counterhnca-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(HNCAarray[j][2].c_str()) >= atof(HSQCarray[i][2].c_str()) - Ndev &&  atof(HNCAarray[j][2].c_str()) <= atof(HSQCarray[i][2].c_str()) + Ndev && atof(HNCAarray[j][4].c_str()) >= atof(HSQCarray[i][4].c_str()) - Hdev &&  atof(HNCAarray[j][4].c_str()) <= atof(HSQCarray[i][4].c_str()) + Hdev )
			{
				HNCAarray[j][0]=HSQCarray[i][0];
				HNCAarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
			else if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
				HNCAarray[j][0]="?";
			else if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
			{
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
                std::string sub;
				std::stringstream ss,ss2;
				ss << counternum;
				ss >> sub;
				HNCAarray[j][0]=sub;
                HSQCsub.push_back(sub);
				counternum--;
				ss2 << counternum;
				ss2 >> sub;
				HNCAarray[j][1]=sub;
                HSQCsub.push_back(sub);
                HSQCsub.push_back(HNCAarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(HNCAarray[j][4]);
                HSQCarray.push_back(HSQCsub);
                counternum++;
				counternum+=10;
				countertemp++;
            }

		}
		if(HNCAarray[j][0]!="?") 
		{
			for(int i=0;i<counterhncoca-2;i++)
				if(atof(HNCAarray[j][2].c_str()) >= atof(HNCOCAarray[i][2].c_str()) - Ndev &&  atof(HNCAarray[j][2].c_str()) <= atof(HNCOCAarray[i][2].c_str()) + Ndev && atof(HNCAarray[j][4].c_str()) >= atof(HNCOCAarray[i][4].c_str()) - Hdev &&  atof(HNCAarray[j][4].c_str()) <= atof(HNCOCAarray[i][4].c_str()) + Hdev ) 
				{
					if(atof(HNCAarray[j][3].c_str()) >= atof(HNCOCAarray[i][3].c_str()) - Cdev && atof(HNCAarray[j][3].c_str()) <= atof(HNCOCAarray[i][3].c_str()) + Cdev )
						HNCAarray[j][6]="i-1";
				}	
		}
	}

    Spinsub.erase(Spinsub.begin(),Spinsub.end());
    for (int i=0;i<12;i++)
        Spinsub.push_back(0.0);

    for (int i=0;i<countertemp-counterhsqc;i++)
        SpinSysarray.push_back(Spinsub);

	counterhsqc=countertemp;
	fileo.open(HNCOCAfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2  w3"<<std::endl;
	for(int i=0;i<counterhncoca-2;i++)
		if(HNCOCAarray[i][0]=="?")
            fileo<<std::endl<<HNCOCAarray[i][0]<<"-?-?  "<<HNCOCAarray[i][2]<<"  "<<HNCOCAarray[i][3]<<"  "<<HNCOCAarray[i][4];
		else
            fileo<<std::endl<<HNCOCAarray[i][0]<<"N-"<<HNCOCAarray[i][1]<<"CA-"<<HNCOCAarray[i][0]<<"HN  "<<HNCOCAarray[i][2]<<"  "<<HNCOCAarray[i][3]<<"  "<<HNCOCAarray[i][4];
	fileo.clear();
	fileo.close();
	fileo.open(HNCAfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2  w3"<<std::endl;
	for(int i=0;i<counterhnca-2;i++)
	{
		if(HNCAarray[i][0]=="?")
		{
            fileo<<std::right<<std::endl<<HNCAarray[i][0]<<"-?-?  ";
            fileo<<std::left<<HNCAarray[i][2]<<"  "<<HNCAarray[i][3]<<"  "<<HNCAarray[i][4];
		}
		else if(HNCAarray[i][6]=="i")
		{
            fileo<<std::right<<std::endl<<HNCAarray[i][0]<<"N-CA-HN  ";
            fileo<<std::left<<HNCAarray[i][2]<<"  "<<HNCAarray[i][3]<<"  "<<HNCAarray[i][4];
		}
		else if(HNCAarray[i][6]=="i-1")
		{
            fileo<<std::right<<std::endl<<HNCAarray[i][0]<<"N-"<<HNCAarray[i][1]<<"CA-"<<HNCAarray[i][0]<<"HN  ";
            fileo<<std::left<<HNCAarray[i][2]<<"  "<<HNCAarray[i][3]<<"  "<<HNCAarray[i][4];
		}
	}
	fileo.clear();
	fileo.close();
	for(int i=0;i<counterhncoca-2;i++)
	{
		if (HNCOCAarray[i][0]!="?")
		{
			int num=0;
			num=atoi(HNCOCAarray[i][0].c_str())/10;
			SpinSysarray[num][6]=atof(HNCOCAarray[i][3].c_str());
            if (SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(HNCOCAarray[i][2].c_str());
                SpinSysarray[num][2]=atof(HNCOCAarray[i][4].c_str());
            }
		}
	}
	for(int i=0;i<counterhnca-2;i++)
	{
		if (HNCAarray[i][0]!="?")
		{
			int num=0;

			num=atoi(HNCAarray[i][0].c_str())/10;
			if (HNCAarray[i][6]=="i")
			{
				SpinSysarray[num][5]=atof(HNCAarray[i][3].c_str());
			}
			else  if (HNCAarray[i][6]=="i-1")
			{
				if (SpinSysarray[num][6]==0.0)
				{
					SpinSysarray[num][6]=atof(HNCAarray[i][3].c_str());
				}
				else
				{
					double co=SpinSysarray[num][6];
					double mean=0.0,stDev=0.0;
					mean=(atof(HNCAarray[i][3].c_str())+co)/2;
					stDev=sqrt(((atof(HNCAarray[i][3].c_str())-mean)*(atof(HNCAarray[i][3].c_str())-mean)+(co-mean)*(co-mean))/2);
					SpinSysarray[num][6]=mean;
					SpinSysarray[num][10]=stDev;
				}
			}
            if (SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(HNCAarray[i][2].c_str());
                SpinSysarray[num][2]=atof(HNCAarray[i][4].c_str());
            }
		}
	}
}
void CompassSpinSystem::Fake_AssignHNCA()
{
	QString	path=ui->HNCALine->text(); 
	std::string HNCAfile;
	QByteArray nByte= path.toUtf8();
	HNCAfile=nByte.data();

    extern std::string Dir;
	
	double Ndev, Hdev;
	
	Ndev = ui->devNBox->value();
	Hdev = ui->devHBox->value();

	std::string line,HNCAfileout;
	unsigned found=HNCAfile.find_last_of("/");
    HNCAfileout=Dir+HNCAfile.substr(found+1)+".compass";
	std::ifstream file;
	std::ofstream fileo;
	file.open(HNCAfile.c_str(), std::ios::in);
    int counterhnca=0;
	while(file.good())
	{
		getline(file,line);
		counterhnca++;
	}
	counterhnca--;
	file.clear();
	file.close();
	file.open(HNCAfile.c_str(), std::ios::in);
    std::vector < std::vector < std::string > > HNCAarray=DefVec2(counterhnca-2,7);
	getline(file,line);
	getline(file,line);
	for(int i=0;i<counterhnca-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNCAarray[i][2]=sub;
		iss >> sub;
		HNCAarray[i][3]=sub;
		iss >> sub;
		HNCAarray[i][4]=sub;
		iss >> sub;
		HNCAarray[i][5]=sub;
		HNCAarray[i][6]="i";
	}
	file.clear();
	file.close();
    extern std::vector< std::vector <std::string> > HSQCarray;
    extern std::vector<std::string> HSQCsub;
    extern int counterhsqc, counternum;

	int countertemp=counterhsqc;
	for(int j=0;j<counterhnca-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(HNCAarray[j][2].c_str()) >= atof(HSQCarray[i][2].c_str()) - Ndev &&  atof(HNCAarray[j][2].c_str()) <= atof(HSQCarray[i][2].c_str()) + Ndev && atof(HNCAarray[j][4].c_str()) >= atof(HSQCarray[i][4].c_str()) - Hdev &&  atof(HNCAarray[j][4].c_str()) <= atof(HSQCarray[i][4].c_str()) + Hdev )
			{
				HNCAarray[j][0]=HSQCarray[i][0];
				HNCAarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
			else if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
				HNCAarray[j][0]="?";
			else if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
			{
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
                std::string sub;
				std::stringstream ss,ss2;
				ss << counternum;
				ss >> sub;
				HNCAarray[j][0]=sub;
                HSQCsub.push_back(sub);
                counternum--;
				ss2 << counternum;
				ss2 >> sub;
				HNCAarray[j][1]=sub;
                HSQCsub.push_back(sub);
                HSQCsub.push_back(HNCAarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(HNCAarray[j][4]);
                counternum++;
				counternum+=10;
				countertemp++;
                HSQCarray.push_back(HSQCsub);
			}

		}
	}
    extern std::vector< std::vector <double> > SpinSysarray;
    extern std::vector<double> Spinsub;
    Spinsub.erase(Spinsub.begin(), Spinsub.end());
    for(int i=0; i<12; i++)
        Spinsub.push_back(0.0);

    for (int i=0; i<countertemp-counterhsqc; i++)
        SpinSysarray.push_back(Spinsub);

	counterhsqc=countertemp;
	for(int j=0;j<counterhnca-3;j++)
	{
		for(int i=j+1;i<counterhnca-2;i++)
		{
			if(atof(HNCAarray[j][2].c_str()) >= atof(HNCAarray[i][2].c_str()) - Ndev &&  atof(HNCAarray[j][2].c_str()) <= atof(HNCAarray[i][2].c_str()) + Ndev && atof(HNCAarray[j][4].c_str()) >= atof(HNCAarray[i][4].c_str()) - Hdev &&  atof(HNCAarray[j][4].c_str()) <= atof(HNCAarray[i][4].c_str()) + Hdev && HNCAarray[j][0]!="?")
			{
				if(std::abs (atof(HNCAarray[j][5].c_str())) <= std::abs (atof(HNCAarray[i][5].c_str())))
				{
					HNCAarray[j][6]="i-1";
					HNCAarray[i][6]="i";
				}
				else
				{
					HNCAarray[i][6]="i-1";
					HNCAarray[j][6]="i";
				}
			}
		}
	}
	fileo.open(HNCAfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2  w3"<<std::endl;
	for(int i=0;i<counterhnca-2;i++)
	{
        if(HNCAarray[i][0]=="?")
        {
            fileo<<std::right<<std::endl<<HNCAarray[i][0]<<"-?-?  ";
            fileo<<std::left<<HNCAarray[i][2]<<"  "<<HNCAarray[i][3]<<"  "<<HNCAarray[i][4];
        }
        else if(HNCAarray[i][6]=="i")
		{
            fileo<<std::right<<std::endl<<HNCAarray[i][0]<<"N-CA-HN  ";
            fileo<<std::left<<HNCAarray[i][2]<<"  "<<HNCAarray[i][3]<<"  "<<HNCAarray[i][4];
		}
		else if(HNCAarray[i][6]=="i-1")
		{
            fileo<<std::right<<std::endl<<HNCAarray[i][0]<<"N-"<<HNCAarray[i][1]<<"CA-"<<HNCAarray[i][0]<<"HN  ";
            fileo<<std::left<<HNCAarray[i][2]<<"  "<<HNCAarray[i][3]<<"  "<<HNCAarray[i][4];
		}
	}
	fileo.clear();
	fileo.close();
	for(int i=0;i<counterhnca-2;i++)
	{
		if (HNCAarray[i][0]!="?")
		{
			int num=0;

			num=atoi(HNCAarray[i][0].c_str())/10;
			if (HNCAarray[i][6]=="i")
			{
				SpinSysarray[num][5]=atof(HNCAarray[i][3].c_str());
			}
			else  if (HNCAarray[i][6]=="i-1")
				SpinSysarray[num][6]=atof(HNCAarray[i][3].c_str());
            if(SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(HNCAarray[i][2].c_str());
                SpinSysarray[num][2]=atof(HNCAarray[i][4].c_str());
            }

		}
	}
}
void CompassSpinSystem::Fake_AssignHNCOCA()
{
	QString	path=ui->HNCOCALine->text(); 
	std::string HNCOCAfile;
	QByteArray nByte= path.toUtf8();
	HNCOCAfile=nByte.data();

    extern std::string Dir;
	
	double Ndev,  Hdev;
	
	Ndev = ui->devNBox->value();
	Hdev = ui->devHBox->value();

	std::string line,HNCOCAfileout;
	unsigned found=HNCOCAfile.find_last_of("/");
    HNCOCAfileout=Dir+HNCOCAfile.substr(found+1)+".compass";
	std::ifstream file;
	std::ofstream fileo;
	file.open(HNCOCAfile.c_str(), std::ios::in);
    int counterhncoca=0;
	while(file.good())
	{
		getline(file,line);
		counterhncoca++;
	}
	counterhncoca--;
	file.clear();
	file.close();
	file.open(HNCOCAfile.c_str(), std::ios::in);
    std::vector < std::vector < std::string > > HNCOCAarray=DefVec2(counterhncoca-2,7);
	getline(file,line);
	getline(file,line);
	for(int i=0;i<counterhncoca-2;i++)
	{
		getline(file,line);
		std::istringstream iss(line);
		std::string sub;
		iss >> sub;
		iss >> sub;
		HNCOCAarray[i][2]=sub;
		iss >> sub;
		HNCOCAarray[i][3]=sub;
		iss >> sub;
		HNCOCAarray[i][4]=sub;
		iss >> sub;
		HNCOCAarray[i][5]=sub;
	}
	file.clear();
	file.close();
    extern std::vector< std::vector <std::string> > HSQCarray; //[5000][6]
    extern std::vector<std::string> HSQCsub;
	extern int counterhsqc,counternum;

	int countertemp=counterhsqc;
	for(int j=0;j<counterhncoca-2;j++)
	{
		for(int i=0;i<counterhsqc-2;i++)
		{
			if(atof(HNCOCAarray[j][2].c_str()) >= atof(HSQCarray[i][2].c_str()) - Ndev &&  atof(HNCOCAarray[j][2].c_str()) <= atof(HSQCarray[i][2].c_str()) + Ndev && atof(HNCOCAarray[j][4].c_str()) >= atof(HSQCarray[i][4].c_str()) - Hdev &&  atof(HNCOCAarray[j][4].c_str()) <= atof(HSQCarray[i][4].c_str()) + Hdev )
			{
				HNCOCAarray[j][0]=HSQCarray[i][0];
				HNCOCAarray[j][1]=HSQCarray[i][1];
				i=counterhsqc;
			}
			else if(i==counterhsqc-3 && ui->RefBox->currentText()!="All lists")
				HNCOCAarray[j][0]="?";
			else if(i==counterhsqc-3 && ui->RefBox->currentText()=="All lists")
			{
                HSQCsub.erase(HSQCsub.begin(),HSQCsub.end());
                std::string sub;
				std::stringstream ss,ss2;
				ss << counternum;
				ss >> sub;
				HNCOCAarray[j][0]=sub;
                HSQCsub.push_back(sub);
				counternum--;
				ss2 << counternum;
				ss2 >> sub;
				HNCOCAarray[j][1]=sub;
                HSQCsub.push_back(sub);
                HSQCsub.push_back(HNCOCAarray[j][2]);
                HSQCsub.push_back("0");
                HSQCsub.push_back(HNCOCAarray[j][4]);
                counternum++;
				counternum+=10;
				countertemp++;
                HSQCarray.push_back(HSQCsub);
			}

		}
	}

    extern std::vector< std::vector <double> > SpinSysarray; //[5000][12]
    extern std::vector<double> Spinsub;
    Spinsub.erase(Spinsub.begin(), Spinsub.end());
    for(int i=0; i<12; i++)
        Spinsub.push_back(0.0);

    for (int i=0; i<countertemp-counterhsqc; i++)
        SpinSysarray.push_back(Spinsub);

    counterhsqc=countertemp;
	fileo.open(HNCOCAfileout.c_str(), std::ios::out);
    fileo<<"Assignment  w1  w2  w3"<<std::endl;
	for(int i=0;i<counterhncoca-2;i++)
		if(HNCOCAarray[i][0]=="?")
            fileo<<std::endl<<HNCOCAarray[i][0]<<"-?-?  "<<HNCOCAarray[i][2]<<"  "<<HNCOCAarray[i][3]<<"  "<<HNCOCAarray[i][4];
		else
            fileo<<std::endl<<HNCOCAarray[i][0]<<"N-"<<HNCOCAarray[i][1]<<"CA-"<<HNCOCAarray[i][0]<<"HN  "<<HNCOCAarray[i][2]<<"  "<<HNCOCAarray[i][3]<<"  "<<HNCOCAarray[i][4];
	fileo.clear();
	fileo.close();
	for(int i=0;i<counterhncoca-2;i++)
    {
		if (HNCOCAarray[i][0]!="?")
		{
			int num=0;

			num=atoi(HNCOCAarray[i][0].c_str())/10;
			SpinSysarray[num][6]=atof(HNCOCAarray[i][3].c_str());
            if(SpinSysarray[num][1]==0.0)
            {
                SpinSysarray[num][0]=num*10;
                SpinSysarray[num][1]=atof(HNCOCAarray[i][2].c_str());
                SpinSysarray[num][2]=atof(HNCOCAarray[i][4].c_str());
            }
        }
	}
}
std::string CompassSpinSystem::ftoa1(double dub)
{
	std::stringstream ss;
	ss<< dub;
	std::string sub=ss.str();
	return sub;
}

void CompassSpinSystem::on_clearButton_clicked()
{
    clear_form();
}

void CompassSpinSystem::on_loadPriorButton_clicked()
{
    load_project_parameters();
}

void CompassSpinSystem::on_quitButton_clicked()
{
    QApplication::quit();
}

void CompassSpinSystem::showError()
{
    QueryError7 winQE7;
    winQE7.setWindowModality(Qt::ApplicationModal);
    if(winQE7.exec())
        return;
}
