#ifndef COMPASSHELP2_H
#define COMPASSHELP2_H

#include <QDialog>
namespace Ui
{
	class CompassHelp2;
}

class CompassHelp2 : public QDialog
{
	Q_OBJECT

public:
	CompassHelp2(QWidget *parent = 0);
	~CompassHelp2();

private:
	Ui::CompassHelp2 *ui;

private slots:
	void on_closeButton_clicked();
};

#endif
