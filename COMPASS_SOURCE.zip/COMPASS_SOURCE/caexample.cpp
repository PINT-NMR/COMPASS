#include "caexample.h"
#include "ui_caexample.h"

CaExample::CaExample(QDialog *parent) :
    QDialog(parent),
	ui(new Ui::CaExample)
{
	ui->setupUi(this);
}

CaExample::~CaExample()
{
	delete ui;
}

void CaExample::on_closecaButton_clicked()
{
    accept();
}
