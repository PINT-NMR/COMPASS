#ifndef COMPASSHELP4_H
#define COMPASSHELP4_H

#include <QDialog>
namespace Ui
{
	class CompassHelp4;
}

class CompassHelp4 : public QDialog
{
	Q_OBJECT

public:
	CompassHelp4(QWidget *parent = 0);
	~CompassHelp4();

private:
	Ui::CompassHelp4 *ui;

private slots:
	void on_closeButton_clicked();
};

#endif
