#ifndef COMPASSLABELEXAMPLE_H
#define COMPASSLABELEXAMPLE_H
#include <QDialog>

namespace Ui
{
    class CompassLabelExample;
}

class CompassLabelExample : public QDialog
{
    Q_OBJECT

public:
    explicit CompassLabelExample(QDialog *parent = 0);
    ~CompassLabelExample();

private:
    Ui::CompassLabelExample *ui;

private slots:
    void on_closeButton_clicked();

};
#endif
