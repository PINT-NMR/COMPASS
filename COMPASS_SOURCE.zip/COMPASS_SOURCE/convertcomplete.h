#ifndef CONVERTCOMPLETE_H
#define CONVERTCOMPLETE_H

#include <QDialog>

namespace Ui
{
	class ConvertComplete;
}

class ConvertComplete : public QDialog
{
	Q_OBJECT

public:
	ConvertComplete(QWidget *parent = 0);
	~ConvertComplete();

private slots:
    void on_closeButton_clicked();

private:
	Ui::ConvertComplete *ui;

};

#endif
