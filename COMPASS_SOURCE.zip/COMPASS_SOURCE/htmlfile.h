#include "compassvec.h"
using namespace std;

void htmlfile(string namefiles, int matchI, bool ss);
