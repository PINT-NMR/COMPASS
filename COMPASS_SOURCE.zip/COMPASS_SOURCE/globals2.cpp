#include <globals2.h>

std::vector< std::vector < std::string > > HSQCarray; //[5000][6]
std::vector< std::vector < double > > SpinSysarray; //[5000][12]
std::vector<std::string> HSQCsub;
std::vector<double> Spinsub;
int counterhsqc=0;
int counternum=10;
QString fileRes="",fileWarn="";
QString qDir;
std::string Dir;
