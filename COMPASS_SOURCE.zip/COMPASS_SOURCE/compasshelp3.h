#ifndef COMPASSHELP3_H
#define COMPASSHELP3_H

#include <QDialog>
namespace Ui
{
	class CompassHelp3;
}

class CompassHelp3 : public QDialog
{
	Q_OBJECT

public:
	CompassHelp3(QWidget *parent = 0);
	~CompassHelp3();

private:
	Ui::CompassHelp3 *ui;

private slots:
	void on_closeButton_clicked();

signals:
    void closeHelp();
};

#endif
