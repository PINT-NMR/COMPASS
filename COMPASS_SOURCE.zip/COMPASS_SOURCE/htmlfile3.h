#ifndef HTMLFILE3_H
#define HTMLFILE3_H
#include "compassvec.h"
using namespace std;

void htmlfile3(string namefiles, int matchI, bool ss);

#endif // HTMLFILE3_H
