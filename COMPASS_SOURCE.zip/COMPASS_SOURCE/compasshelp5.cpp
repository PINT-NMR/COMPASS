#include "compasshelp5.h"
#include "ui_compasslabelhelp.h"
#include <QtWidgets>
#include "QRect"
#include "QDesktopWidget"

CompassHelp5::CompassHelp5(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CompassHelp5)
{
    ui->setupUi(this);
}

CompassHelp5::~CompassHelp5()
{
    delete ui;
}

void CompassHelp5::on_exampleButton_clicked()
{
    CompassLabelExample winLabel;
    winLabel.setWindowModality(Qt::ApplicationModal);
    if(winLabel.exec())
        return;
}

void CompassHelp5::on_closeButton_clicked()
{
    accept();
}
