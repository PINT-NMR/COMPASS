#ifndef QUERYERROR2_H
#define QUERYERROR2_H

#include <QMainWindow>

namespace Ui
{
	class QueryError2;
}

class QueryError2 : public QMainWindow
{
	Q_OBJECT

public:
	QueryError2(QWidget *parent = 0);
	~QueryError2();

protected:
	void changeEvent(QEvent *e);

private:
	Ui::QueryError2 *ui;

private slots:
	void readerr2file();
};

#endif
