#ifndef GENERATOR_H
#define GENERATOR_H

#include "compassvec.h"
#include "passdef.h"
#include "globals.h"
#include "mfunc.h"

struct GeneratorType
{
    string resultFile;
    string indexFile;
    string caFile;
    string cbcaFile;
    string coFile;
    string hsqcFile;
    string caFile2;
    string cbcaFile2;
    string coFile2;

    GeneratorType()	{
        resultFile = "EMPTY";
        indexFile = "EMPTY";
        caFile = "EMPTY";
        cbcaFile = "EMPTY";
        coFile = "EMPTY" ;
        hsqcFile = "EMPTY";
        caFile2 = "EMPTY";
        cbcaFile2 = "EMPTY";
        coFile2 = "EMPTY" ;
    }

void generate(string resultfile, string indexfile, string cafile, string cbcafile, string cofile, string hsqcfile, string cafile2, string cbcafile2, string cofile2, string namefiles)
    {
        std::string manual = namefiles;
        manual += "Analysis/manualmode.bak";
        namefiles+="Results/";
        fstream errorFile;
        string errors1 = namefiles;
        errors1 +="Temp/rename_errors.txt";
        errorFile.open(errors1.c_str(), ios::out);
        resultFile = resultfile;
        indexFile = indexfile;
        if(cafile!="EMPTY")
        {
            caFile = namefiles;
            unsigned pos = cafile.find_last_of("/");
            caFile += cafile.substr(pos+1);
            caFile+=".compass";
        }
        if(cbcafile!="EMPTY")
        {
            cbcaFile = namefiles;
            unsigned pos = cbcafile.find_last_of("/");
            cbcaFile += cbcafile.substr(pos+1);
            cbcaFile+=".compass";
        }
        if(cofile!="EMPTY")
        {
            coFile = namefiles;
            unsigned pos = cofile.find_last_of("/");
            coFile += cofile.substr(pos+1);
            coFile+=".compass";
        }
        if(hsqcfile!="EMPTY")
        {
            hsqcFile = namefiles;
            unsigned pos = hsqcfile.find_last_of("/");
            hsqcFile += hsqcfile.substr(pos+1);
            hsqcFile+=".compass";
        }
        if(cafile2!="EMPTY")
        {
            caFile2 = namefiles;
            unsigned pos = cafile2.find_last_of("/");
            caFile2 += cafile2.substr(pos+1);
            caFile2+=".compass";
        }
        if(cbcafile2!="EMPTY")
        {
            cbcaFile2 = namefiles;
            unsigned pos = cbcafile2.find_last_of("/");
            cbcaFile2 += cbcafile2.substr(pos+1);
            cbcaFile2+=".compass";
        }
        if(cofile2!="EMPTY")
        {
            coFile2 = namefiles;
            unsigned pos = cofile2.find_last_of("/");
            coFile2 += cofile2.substr(pos+1);
            coFile2+=".compass";
        }

        ifstream file;
        vector<string> idxVec, tempVec;
        vector<vector<string> > changeVec;
        vector<vector<string> > writeVec;
        string line, temp_aa, temp_no;
        string resultfile1=resultfile;
        resultfile1+="1";
        string resultfile2=resultfile;
        resultfile2+="2";
        string resultfile3=resultfile;
        resultfile3+="3";
    file.open(indexfile.c_str(), ios::in); //indice.idx
    string sub;
    while(file>>sub)
        idxVec.push_back(sub);
    file.clear();
    file.close();

    for(uint i=0; i<idxVec.size(); i++)
        for(uint j=i+1; j<idxVec.size(); j++)
            if(idxVec[i]==idxVec[j])
                idxVec.erase (idxVec.begin()+j);

    for (uint i=0; i<idxVec.size(); i++)
    {
        if(idxVec[i].substr(0,1)=="1")
            file.open(resultfile1.c_str());
        if(idxVec[i].substr(0,1)=="2")
            file.open(resultfile2.c_str());
        if(idxVec[i].substr(0,1)=="3")
            file.open(resultfile3.c_str());
        if(idxVec[i].substr(0,1)=="4")
            file.open(manual.c_str());

        bool found_idx=false;
        vector<string> tmp;
        while(getline(file, line))
        {
            string sub, str;
            str=line;
            istringstream iss(line);
            iss >> sub;

            if (idxVec[i]==sub)
            {
                found_idx=true;
                tmp.push_back(str.substr(7));
            }
            else if(found_idx)
            {
                if (sub=="#")
                {
                    getline(file, line);
                    tmp.push_back(line.substr(2));
                    changeVec.push_back(tmp); //changeVec[][0]= SEQ NR ... changeVec[][1]= aa1->aaX
                    break;
                }
            }
        }
        file.clear();
        file.close();
    }
for (uint i=0; i<changeVec.size(); i++)
{
    istringstream iss(changeVec[i][0]);
    iss >> sub; //PRO-HIS-ALA
    string seq =sub;
    iss >> sub; //200-202
    unsigned pos = sub.find_last_of("-");
    int resNo = atoi(sub.substr(0,pos).c_str());
    vector<string> tmp;
    for(uint j=0; j<seq.length(); j+=4)
    {
        tmp.push_back(res1(seq.substr(j,3))+itoa_write(resNo)); //tmp[0]=P200, [1]=H201, [2]=A202
        resNo++;
    }

    istringstream iss2(changeVec[i][1]);
    vector<string> tmp2;
    while(iss2 >> sub)
    {
        unsigned pos2 = sub.find_last_of("-");
        tmp2.push_back(sub.substr(0,pos2-2));//tmp2[0]=1290N-1289 , [1]=1290N-, [2]= A222N-D221, [3]= A222N-
    }
    int count=0;
    for(uint j=0; j<tmp2.size(); j++)
    {
        vector<string> tmp_final;
        if(j%2==0)
        {
            tmp_final.push_back(tmp[count+1]+"N-"+tmp[count]); //H201N-P200
            tmp_final.push_back(tmp2[j]);//1290N-1289
            count++;
        }
        else
        {
            tmp_final.push_back(tmp[count]+"N-"); //H201N-
            tmp_final.push_back(tmp2[j]); //1290N-
        }
        writeVec.push_back(tmp_final); // writeVec[0][0]=H201N-P200, [0][1]= 1290N-1289 (NEW OLD)
    }
}
for(uint i=0; i<writeVec.size(); i++) //Remove "xxx" prefix
{
    if(writeVec[i][1].substr(0,3)=="xxx")
    {
        if(writeVec[i][1].substr(writeVec[i][1].length()-1,1)=="-")
        {
            writeVec.erase(writeVec.begin()+i);
            i--;
        }
        else
        {
            unsigned posH2 = writeVec[i][1].find_first_of("-");
            writeVec[i][1]=writeVec[i][1].substr(3,posH2-2);
        }
    }
}

vector<string> suffix; //CA,CB,CO,HN
suffix.push_back("CA-HN");
suffix.push_back("CB-HN");
suffix.push_back("CO-HN");
suffix.push_back("HN");
//
extern QString profile;
string fcsedit=profile.toStdString();
std::ifstream fileCS;
fileCS.open(fcsedit.c_str(), std::ios::in);
getline(fileCS, line);
fileCS.clear();
fileCS.close();
std::string csedit = line + "Analysis/csedit";
fileCS.open(csedit.c_str(), std::ios::in);
vector<vector<string> > csVec, checkVec;
while(getline(fileCS,line))
{
    vector<string> CStmp, tmpCheck;
    istringstream issCS(line);
    string subCS;
    while(issCS >> subCS)
    {
        CStmp.push_back(subCS);
        tmpCheck.push_back("1");
    }
    csVec.push_back(CStmp);
    csVec[csVec.size()-1][0]+="N-";
    checkVec.push_back(tmpCheck);
}
fileCS.clear();
fileCS.close();
vector<vector<string> > newVec, newVec2;
//
{
    int unass=1000;
    ifstream ca_in_file, cbca_in_file, co_in_file, hsqc_in_file, ca_in_file2, cbca_in_file2, co_in_file2;
    fstream ca_out_file, cbca_out_file, co_out_file, hsqc_out_file, ca_out_file2, cbca_out_file2, co_out_file2;
    if(cbcaFile2!="EMPTY")
    {
        cbca_out_file2.open (cbcaFile2.c_str(), ios::out);
        cbca_out_file2<<"      Assignment         w1         w2         w3   "<<endl<<endl;
        cbca_in_file2.open(cbcafile2.c_str(), ios::in);
        getline(cbca_in_file2, line);
        getline(cbca_in_file2, line);
        while(getline(cbca_in_file2,line))
        {
            string tmp=line;
            istringstream issT(tmp);
            string subT;
            vector<string> print;
            while(issT >> subT)
                print.push_back(subT);
            unsigned posT = print[0].find_last_of("-");
            int aorb=1;
            if(print[0].substr(posT-1,1)=="B")
                aorb=2;
            bool written =false;
            for(uint i=0; i<csVec.size(); i++)
            {
                if(print[0].length()>csVec[i][0].length())
                {
                    if(print[0].substr(0,csVec[i][0].length())==csVec[i][0])
                    {
                        if(aorb==1)
                        {
                            print[2]=csVec[i][4];
                            checkVec[i][4]="-1";
                            break;
                        }
                        else
                        {
                            print[2]=csVec[i][6];
                            checkVec[i][6]="-1";
                            break;
                        }
                    }
                }
            }
            if(print[2]=="0")
                continue;
            for(uint i=0; i<writeVec.size(); i++)
            {
                if(writeVec[i][1]==print[0].substr(0,posT-2))
                {
                    if(aorb==1)
                    {
                        unsigned posT2 = writeVec[i][0].find_first_of("-");
                        cbca_out_file2 << writeVec[i][0] <<"CA-"<<writeVec[i][0].substr(0,posT2-1)<<"HN";
                    }
                    else
                    {
                        unsigned posT2 = writeVec[i][0].find_first_of("-");
                        cbca_out_file2 << writeVec[i][0] <<"CB-"<<writeVec[i][0].substr(0,posT2-1)<<"HN";
                    }
                    for(uint j=1; j<print.size(); j++)
                        cbca_out_file2<<" "<<print[j];
                    cbca_out_file2<<"\n";
                    written=true;
                    break;
                }
            }
            if(!written)
            {
                unsigned posL = print[0].find_first_of("-");
                for(uint l=0; l<newVec.size(); l++)
                {
                    if(newVec[l][1].length()<=posL+1)
                    {
                        if(newVec[l][1]==print[0].substr(0,newVec[l][1].length()))
                        {
                            if(aorb==1)
                                cbca_out_file2<<newVec2[l][0]<<"CA-"<<newVec2[l][1];
                            else
                                cbca_out_file2<<newVec2[l][0]<<"CB-"<<newVec2[l][1];
                            for(uint j=1; j<print.size(); j++)
                                cbca_out_file2<<" "<<print[j];
                            cbca_out_file2<<"\n";
                            written=true;
                        }
                    }
                }
                if(!written)
                {
                    if(aorb==1)
                        cbca_out_file2<<itoa_write(unass)<<"N-"<<itoa_write(unass-1)<<"CA-"<<itoa_write(unass)<<"HN";
                    else
                        cbca_out_file2<<itoa_write(unass)<<"N-"<<itoa_write(unass-1)<<"CB-"<<itoa_write(unass)<<"HN";
                    for(uint j=1; j<print.size(); j++)
                        cbca_out_file2<<" "<<print[j];
                    cbca_out_file2<<"\n";
                    vector<string> tmpNew;
                    tmpNew.push_back(itoa_write(unass)+"N-");
                    unsigned posT3 = print[0].find_first_of("-");
                    tmpNew.push_back(print[0].substr(0,posT3+1));
                    newVec.push_back(tmpNew);
                    vector<string> tmpNew2;
                    tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                    tmpNew2.push_back(itoa_write(unass)+"HN");
                    newVec2.push_back(tmpNew2);
                    unass+=10;
                }
            }
        }

        cbca_in_file2.clear();
        cbca_in_file2.close();
        if(cbcaFile=="EMPTY")
        {
            // Check unassigned
            for(uint i=0; i<csVec.size(); i++)
            {
                if(csVec[i][6]!="0" && checkVec[i][6]=="1")
                {
                    for(uint j=0; j<writeVec.size(); j++)
                    {
                        if(writeVec[j][1].length()>csVec[i][0].length())
                        {
                            if(writeVec[j][1].substr(0,csVec[i][0].length())==csVec[i][0])
                            {
                                unsigned posD= writeVec[j][0].find_first_of("-");
                                cbca_out_file2<<writeVec[j][0]<<"CB-"<<writeVec[j][0].substr(0,posD-1)<<"HN "<<csVec[i][1]<<" "<<csVec[i][6]<<" "<<csVec[i][2]<<"\n";
                                checkVec[i][6]="-1";
                                break;
                            }
                        }
                    }
                    if(checkVec[i][6]=="1")
                    {
                        for(uint l=0; l<newVec.size(); l++)
                        {
                            if(newVec[l][1]==csVec[i][0])
                            {
                                cbca_out_file2<<newVec2[l][0]<<"CB-"<<newVec2[l][1]<<" "<<csVec[i][1]<<" "<<csVec[i][6]<<" "<<csVec[i][2]<<"\n";
                                checkVec[i][6]="-1";
                                break;
                            }
                        }
                    }
                    if(checkVec[i][6]=="1")
                    {
                        cbca_out_file2<<itoa_write(unass)<<"N-"<<itoa_write(unass-1)<<"CB-"<<itoa_write(unass)<<"HN "<<csVec[i][1]<<" "<<csVec[i][6]<<" "<<csVec[i][2]<<"\n";
                        checkVec[i][6]="-1";
                        vector<string> tmpNew;
                        tmpNew.push_back(itoa_write(unass)+"N-");
                        tmpNew.push_back(csVec[i][0]);
                        newVec.push_back(tmpNew);
                        vector<string> tmpNew2;
                        tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                        tmpNew2.push_back(itoa_write(unass)+"HN");
                        newVec2.push_back(tmpNew2);
                        unass+=10;
                    }
                }
            }
            //end check unassigned
        }
        cbca_out_file2.clear();
        cbca_out_file2.close();
    }
    if(cbcaFile!="EMPTY")
    {
        cbca_out_file.open (cbcaFile.c_str(), ios::out);
        cbca_out_file<<"      Assignment         w1         w2         w3   "<<endl<<endl;
        cbca_in_file.open (cbcafile.c_str(), ios::in);
        getline(cbca_in_file, line);
        getline(cbca_in_file, line);
        while(getline(cbca_in_file,line))
        {
            string tmp=line;
            istringstream issT(tmp);
            string subT;
            vector<string> print;
            while(issT >> subT)
                print.push_back(subT);
            unsigned posT = print[0].find_last_of("-");
            int aorb=1;
            if(print[0].substr(posT-1,1)=="B")
                aorb=2;
            bool internal=true;
            bool written =false;
            if(print[0].substr(posT-3,1)!="-")
                internal=false;
            for(uint i=0; i<csVec.size(); i++)
            {
                if(print[0].length()>csVec[i][0].length())
                {
                    if(print[0].substr(0,csVec[i][0].length())==csVec[i][0])
                    {
                        if(internal)
                        {
                            if(aorb==1)
                            {
                                print[2]=csVec[i][3];
                                checkVec[i][3]="-1";
                                break;
                            }
                            else
                            {
                                print[2]=csVec[i][5];
                                checkVec[i][5]="-1";
                                break;
                            }
                        }
                        else
                        {
                            if(aorb==1)
                            {
                                print[2]=csVec[i][4];
                                checkVec[i][4]="-1";
                                break;
                            }
                            else
                            {
                                print[2]=csVec[i][6];
                                checkVec[i][6]="-1";
                                break;
                            }
                        }
                    }
                }
            }
            if(print[2]=="0")
                continue;
            for(uint i=0; i<writeVec.size(); i++)
            {
                if(writeVec[i][1]==print[0].substr(0,posT-2))
                {
                    if(aorb==1)
                    {
                        if(internal)
                            cbca_out_file << writeVec[i][0] << suffix[0];
                        else
                        {
                            unsigned posT2 = writeVec[i][0].find_first_of("-");
                            cbca_out_file << writeVec[i][0] <<"CA-"<<writeVec[i][0].substr(0,posT2-1)<<"HN";
                        }
                    }
                    else
                    {
                        if(internal)
                            cbca_out_file << writeVec[i][0] << suffix[1];
                        else
                        {
                            unsigned posT2 = writeVec[i][0].find_first_of("-");
                            cbca_out_file << writeVec[i][0] <<"CB-"<<writeVec[i][0].substr(0,posT2-1)<<"HN";
                        }
                    }
                    for(uint j=1; j<print.size(); j++)
                        cbca_out_file<<" "<<print[j];
                    cbca_out_file<<"\n";
                    written=true;
                    break;
                }
            }
            if(!written)
            {
                unsigned posL = print[0].find_first_of("-");
                for(uint l=0; l<newVec.size(); l++)
                {
                    if(newVec[l][1].length()<=posL+1)
                    {
                        if(newVec[l][1]==print[0].substr(0,newVec[l][1].length()))
                        {
                            if(internal)
                            {
                                if(aorb==1)
                                    cbca_out_file<<newVec[l][0]<<suffix[0];
                                else
                                    cbca_out_file<<newVec[l][0]<<suffix[1];
                            }
                            else
                            {
                                if(aorb==1)
                                    cbca_out_file<<newVec2[l][0]<<"CA-"<<newVec2[l][1];
                                else
                                    cbca_out_file<<newVec2[l][0]<<"CB-"<<newVec2[l][1];
                            }
                            for(uint j=1; j<print.size(); j++)
                                cbca_out_file<<" "<<print[j];
                            cbca_out_file<<"\n";
                            written=true;
                        }
                    }
                }
                if(!written)
                {
                    if(internal)
                    {
                        if(aorb==1)
                            cbca_out_file<< itoa_write(unass)<< "N-"<<suffix[0];
                        else
                            cbca_out_file<< itoa_write(unass)<< "N-"<<suffix[1];
                        for(uint j=1; j<print.size(); j++)
                            cbca_out_file<<" "<<print[j];
                        cbca_out_file<<"\n";
                        vector<string> tmpNew;
                        tmpNew.push_back(itoa_write(unass)+"N-");
                        tmpNew.push_back(print[0].substr(0,posT-2));
                        newVec.push_back(tmpNew);
                        vector<string> tmpNew2;
                        tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                        tmpNew2.push_back(itoa_write(unass)+"HN");
                        newVec2.push_back(tmpNew2);
                        unass+=10;
                    }
                    else
                    {
                        if(aorb==1)
                            cbca_out_file<<itoa_write(unass)<<"N-"<<itoa_write(unass-1)<<"CA-"<<itoa_write(unass)<<"HN";
                        else
                            cbca_out_file<<itoa_write(unass)<<"N-"<<itoa_write(unass-1)<<"CB-"<<itoa_write(unass)<<"HN";
                        for(uint j=1; j<print.size(); j++)
                            cbca_out_file<<" "<<print[j];
                        cbca_out_file<<"\n";
                        vector<string> tmpNew;
                        tmpNew.push_back(itoa_write(unass)+"N-");
                        unsigned posT3 = print[0].find_first_of("-");
                        tmpNew.push_back(print[0].substr(0,posT3+1));
                        newVec.push_back(tmpNew);
                        vector<string> tmpNew2;
                        tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                        tmpNew2.push_back(itoa_write(unass)+"HN");
                        newVec2.push_back(tmpNew2);
                        unass+=10;
                    }
                }
            }
        }
        cbca_in_file.clear();
        cbca_in_file.close();
        // Check unassigned
        for(uint i=0; i<csVec.size(); i++)
        {
            if(csVec[i][5]!="0" && checkVec[i][5]=="1")
            {
                for(uint j=0; j<writeVec.size(); j++)
                {
                    if(writeVec[j][1]==csVec[i][0])
                    {
                        cbca_out_file<<writeVec[j][0]<<suffix[1]<<" "<<csVec[i][1]<<" "<<csVec[i][5]<<" "<<csVec[i][2]<<"\n";
                        checkVec[i][5]="-1";
                        break;
                    }
                }
                if(checkVec[i][5]=="1")
                {
                    for(uint l=0; l<newVec.size(); l++)
                    {
                        if(newVec[l][1]==csVec[i][0])
                        {
                            cbca_out_file<<newVec[l][0]<<suffix[1]<<" "<<csVec[i][1]<<" "<<csVec[i][5]<<" "<<csVec[i][2]<<"\n";
                            checkVec[i][5]="-1";
                            break;
                        }
                    }
                }
                if(checkVec[i][5]=="1")
                {
                    cbca_out_file<<itoa_write(unass)<<"N-"<<suffix[1]<<" "<<csVec[i][1]<<" "<<csVec[i][5]<<" "<<csVec[i][2]<<"\n";
                    checkVec[i][5]="-1";
                    vector<string> tmpNew;
                    tmpNew.push_back(itoa_write(unass)+"N-");
                    tmpNew.push_back(csVec[i][0]);
                    newVec.push_back(tmpNew);
                    vector<string> tmpNew2;
                    tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                    tmpNew2.push_back(itoa_write(unass)+"HN");
                    newVec2.push_back(tmpNew2);
                    unass+=10;
                }
            }
            if(csVec[i][6]!="0" && checkVec[i][6]=="1")
            {
                for(uint j=0; j<writeVec.size(); j++)
                {
                    if(writeVec[j][1].length()>csVec[i][0].length())
                    {
                        if(writeVec[j][1].substr(0,csVec[i][0].length())==csVec[i][0])
                        {
                            unsigned posD= writeVec[j][0].find_first_of("-");
                            cbca_out_file<<writeVec[j][0]<<"CB-"<<writeVec[j][0].substr(0,posD-1)<<"HN "<<csVec[i][1]<<" "<<csVec[i][6]<<" "<<csVec[i][2]<<"\n";
                            checkVec[i][6]="-1";
                            break;
                        }
                    }
                }
                if(checkVec[i][6]=="1")
                {
                    for(uint l=0; l<newVec.size(); l++)
                    {
                        if(newVec[l][1]==csVec[i][0])
                        {
                            cbca_out_file<<newVec2[l][0]<<"CB-"<<newVec2[l][1]<<" "<<csVec[i][1]<<" "<<csVec[i][6]<<" "<<csVec[i][2]<<"\n";
                            checkVec[i][6]="-1";
                            break;
                        }
                    }
                }
                if(checkVec[i][6]=="1")
                {
                    cbca_out_file<<itoa_write(unass)<<"N-"<<itoa_write(unass-1)<<"CB-"<<itoa_write(unass)<<"HN "<<csVec[i][1]<<" "<<csVec[i][6]<<" "<<csVec[i][2]<<"\n";
                    checkVec[i][6]="-1";
                    vector<string> tmpNew;
                    tmpNew.push_back(itoa_write(unass)+"N-");
                    tmpNew.push_back(csVec[i][0]);
                    newVec.push_back(tmpNew);
                    vector<string> tmpNew2;
                    tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                    tmpNew2.push_back(itoa_write(unass)+"HN");
                    newVec2.push_back(tmpNew2);
                    unass+=10;
                }
            }
        }
        //end check unassigned
        cbca_out_file.clear();
        cbca_out_file.close();
    }
    if(caFile2!="EMPTY")
    {
        ca_out_file2.open (caFile2.c_str(), ios::out);
        ca_out_file2 << "      Assignment         w1         w2         w3   "<<endl<<endl;
        ca_in_file2.open (cafile2.c_str(), ios::in);
        getline(ca_in_file2, line);
        getline(ca_in_file2, line);
        while(getline(ca_in_file2,line))
        {
            string tmp=line;
            istringstream issT(tmp);
            string subT;
            vector<string> print;
            while(issT >> subT)
                print.push_back(subT);
            unsigned posT = print[0].find_last_of("-");
            bool written =false;
            for(uint i=0; i<csVec.size(); i++)
            {
                if(print[0].length()>csVec[i][0].length())
                {
                    if(print[0].substr(0,csVec[i][0].length())==csVec[i][0])
                    {
                        print[2]=csVec[i][4];
                        checkVec[i][4]="-1";
                        break;
                    }
                }
            }
            if(print[2]=="0")
                continue;
            for(uint i=0; i<writeVec.size(); i++)
            {
                if(writeVec[i][1]==print[0].substr(0,posT-2))
                {
                    unsigned posT2 = writeVec[i][0].find_first_of("-");
                    ca_out_file2 << writeVec[i][0] <<"CA-"<<writeVec[i][0].substr(0,posT2-1)<<"HN";
                    for(uint j=1; j<print.size(); j++)
                        ca_out_file2<<" "<<print[j];
                    ca_out_file2<<"\n";
                    written=true;
                    break;
                }
            }
            if(!written)
            {
                unsigned posL = print[0].find_first_of("-");
                for(uint l=0; l<newVec.size(); l++)
                {
                    if(newVec[l][1].length()<=posL+1)
                    {
                        if(newVec[l][1]==print[0].substr(0,newVec[l][1].length()))
                        {
                            ca_out_file2<<newVec2[l][0]<<"CA-"<<newVec2[l][1];
                            for(uint j=1; j<print.size(); j++)
                                ca_out_file2<<" "<<print[j];
                            ca_out_file2<<"\n";
                            written=true;
                        }
                    }
                }
                if(!written)
                {
                    ca_out_file2<<itoa_write(unass)<<"N-"<<itoa_write(unass-1)<<"CA-"<<itoa_write(unass)<<"HN";
                    for(uint j=1; j<print.size(); j++)
                        ca_out_file2<<" "<<print[j];
                    ca_out_file2<<"\n";
                    vector<string> tmpNew;
                    tmpNew.push_back(itoa_write(unass)+"N-");
                    unsigned posT3 = print[0].find_first_of("-");
                    tmpNew.push_back(print[0].substr(0,posT3+1));
                    newVec.push_back(tmpNew);
                    vector<string> tmpNew2;
                    tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                    tmpNew2.push_back(itoa_write(unass)+"HN");
                    newVec2.push_back(tmpNew2);
                    unass+=10;
                }
            }
        }
        ca_in_file2.clear();
        ca_in_file2.close();
        if(caFile=="EMPTY")
        {
            // Check unassigned
            for(uint i=0; i<csVec.size(); i++)
            {
                if(csVec[i][4]!="0" && checkVec[i][4]=="1")
                {
                    for(uint j=0; j<writeVec.size(); j++)
                    {
                        if(writeVec[j][1].length()>csVec[i][0].length())
                        {
                            if(writeVec[j][1].substr(0,csVec[i][0].length())==csVec[i][0])
                            {
                                unsigned posD= writeVec[j][0].find_first_of("-");
                                ca_out_file2<<writeVec[j][0]<<"CA-"<<writeVec[j][0].substr(0,posD-1)<<"HN "<<csVec[i][1]<<" "<<csVec[i][4]<<" "<<csVec[i][2]<<"\n";
                                checkVec[i][4]="-1";
                                break;
                            }
                        }
                    }
                    if(checkVec[i][4]=="1")
                    {
                        for(uint l=0; l<newVec.size(); l++)
                        {
                            if(newVec[l][1]==csVec[i][0])
                            {
                                ca_out_file2<<newVec2[l][0]<<"CA-"<<newVec2[l][1]<<" "<<csVec[i][1]<<" "<<csVec[i][4]<<" "<<csVec[i][2]<<"\n";
                                checkVec[i][4]="-1";
                                break;
                            }
                        }
                    }
                    if(checkVec[i][4]=="1")
                    {
                        ca_out_file2<<itoa_write(unass)<<"N-"<<itoa_write(unass-1)<<"CA-"<<itoa_write(unass)<<"HN "<<csVec[i][1]<<" "<<csVec[i][4]<<" "<<csVec[i][2]<<"\n";
                        checkVec[i][4]="-1";
                        vector<string> tmpNew;
                        tmpNew.push_back(itoa_write(unass)+"N-");
                        tmpNew.push_back(csVec[i][0]);
                        newVec.push_back(tmpNew);
                        vector<string> tmpNew2;
                        tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                        tmpNew2.push_back(itoa_write(unass)+"HN");
                        newVec2.push_back(tmpNew2);
                        unass+=10;
                    }
                }
            }
            //end check unassigned
        }
        ca_out_file2.clear();
        ca_out_file2.close();

    }
    if(caFile!="EMPTY")
    {
        ca_out_file.open (caFile.c_str(), ios::out);
        ca_out_file << "      Assignment         w1         w2         w3   "<<endl<<endl;

        ca_in_file.open (cafile.c_str(), ios::in);
        getline(ca_in_file,line);
        getline(ca_in_file,line);
        while(getline(ca_in_file,line))
        {
            string tmp=line;
            istringstream issT(tmp);
            string subT;
            vector<string> print;
            while(issT >> subT)
                print.push_back(subT);
            unsigned posT = print[0].find_last_of("-");
            bool internal=true;
            bool written =false;
            if(print[0].substr(posT-3,1)!="-")
                internal=false;
            for(uint i=0; i<csVec.size(); i++)
            {
                if(print[0].length()>csVec[i][0].length())
                {
                    if(print[0].substr(0,csVec[i][0].length())==csVec[i][0])
                    {
                        if(internal)
                        {
                            print[2]=csVec[i][3];
                            checkVec[i][3]="-1";
                            break;
                        }
                        else
                        {
                            print[2]=csVec[i][4];
                            checkVec[i][4]="-1";
                            break;
                        }
                    }
                }
            }
            if(print[2]=="0")
                continue;
            for(uint i=0; i<writeVec.size(); i++)
            {
                if(writeVec[i][1]==print[0].substr(0,posT-2))
                {
                    if(internal)
                        ca_out_file << writeVec[i][0] << suffix[0];
                    else
                    {
                        unsigned posT2 = writeVec[i][0].find_first_of("-");
                        ca_out_file << writeVec[i][0] << "CA-"<<writeVec[i][0].substr(0,posT2-1)<<"HN";
                    }
                    for(uint j=1; j<print.size(); j++)
                        ca_out_file<<" "<<print[j];
                    ca_out_file<<"\n";
                    written=true;
                    break;
                }
            }
            if(!written)
            {
                unsigned posL = print[0].find_first_of("-");
                for(uint l=0; l<newVec.size(); l++)
                {
                    if(newVec[l][1].length()<=posL+1)
                    {
                        if(newVec[l][1]==print[0].substr(0,newVec[l][1].length()))
                        {
                            if(internal)
                                ca_out_file<<newVec[l][0]<<suffix[0];
                            else
                                ca_out_file<<newVec2[l][0]<<"CA-"<<newVec2[l][1];
                            for(uint j=1; j<print.size(); j++)
                                ca_out_file<<" "<<print[j];
                            ca_out_file<<"\n";
                            written=true;
                        }
                    }
                }
                if(!written)
                {
                    if(internal)
                    {
                        ca_out_file<< itoa_write(unass)<< "N-"<<suffix[0];
                        for(uint j=1; j<print.size(); j++)
                            ca_out_file<<" "<<print[j];
                        ca_out_file<<"\n";
                        vector<string> tmpNew;
                        tmpNew.push_back(itoa_write(unass)+"N-");
                        tmpNew.push_back(print[0].substr(0,posT-2));
                        newVec.push_back(tmpNew);
                        vector<string> tmpNew2;
                        tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                        tmpNew2.push_back(itoa_write(unass)+"HN");
                        newVec2.push_back(tmpNew2);
                        unass+=10;
                    }
                    else
                    {
                        ca_out_file<<itoa_write(unass)<<"N-"<<itoa_write(unass-1)<<"CA-"<<itoa_write(unass)<<"HN";
                        for(uint j=1; j<print.size(); j++)
                            ca_out_file<<" "<<print[j];
                        ca_out_file<<"\n";
                        vector<string> tmpNew;
                        tmpNew.push_back(itoa_write(unass)+"N-");
                        unsigned posT3 = print[0].find_first_of("-");
                        tmpNew.push_back(print[0].substr(0,posT3+1));
                        newVec.push_back(tmpNew);
                        vector<string> tmpNew2;
                        tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                        tmpNew2.push_back(itoa_write(unass)+"HN");
                        newVec2.push_back(tmpNew2);
                        unass+=10;
                    }
                }
            }
        }
        ca_in_file.clear();
        ca_in_file.close();
        // Check unassigned
        for(uint i=0; i<csVec.size(); i++)
        {
            if(csVec[i][3]!="0" && checkVec[i][3]=="1")
            {
                for(uint j=0; j<writeVec.size(); j++)
                {
                    if(writeVec[j][1]==csVec[i][0])
                    {
                        ca_out_file<<writeVec[j][0]<<suffix[0]<<" "<<csVec[i][1]<<" "<<csVec[i][3]<<" "<<csVec[i][2]<<"\n";
                        checkVec[i][3]="-1";
                        break;
                    }
                }
                if(checkVec[i][3]=="1")
                {
                    for(uint l=0; l<newVec.size(); l++)
                    {
                        if(newVec[l][1]==csVec[i][0])
                        {
                            ca_out_file<<newVec[l][0]<<suffix[0]<<" "<<csVec[i][1]<<" "<<csVec[i][3]<<" "<<csVec[i][2]<<"\n";
                            checkVec[i][3]="-1";
                            break;
                        }
                    }
                }
                if(checkVec[i][3]=="1")
                {
                    ca_out_file<<itoa_write(unass)<<"N-"<<suffix[0]<<" "<<csVec[i][1]<<" "<<csVec[i][3]<<" "<<csVec[i][2]<<"\n";
                    checkVec[i][3]="-1";
                    vector<string> tmpNew;
                    tmpNew.push_back(itoa_write(unass)+"N-");
                    tmpNew.push_back(csVec[i][0]);
                    newVec.push_back(tmpNew);
                    vector<string> tmpNew2;
                    tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                    tmpNew2.push_back(itoa_write(unass)+"HN");
                    newVec2.push_back(tmpNew2);
                    unass+=10;
                }
            }
            if(csVec[i][4]!="0" && checkVec[i][4]=="1")
            {
                for(uint j=0; j<writeVec.size(); j++)
                {
                    if(writeVec[j][1].length()>csVec[i][0].length())
                    {
                        if(writeVec[j][1].substr(0,csVec[i][0].length())==csVec[i][0])
                        {
                            unsigned posD= writeVec[j][0].find_first_of("-");
                            ca_out_file<<writeVec[j][0]<<"CA-"<<writeVec[j][0].substr(0,posD-1)<<"HN "<<csVec[i][1]<<" "<<csVec[i][4]<<" "<<csVec[i][2]<<"\n";
                            checkVec[i][4]="-1";
                            break;
                        }
                    }
                }
                if(checkVec[i][4]=="1")
                {
                    for(uint l=0; l<newVec.size(); l++)
                    {
                        if(newVec[l][1]==csVec[i][0])
                        {
                            ca_out_file<<newVec2[l][0]<<"CA-"<<newVec2[l][1]<<" "<<csVec[i][1]<<" "<<csVec[i][4]<<" "<<csVec[i][2]<<"\n";
                            checkVec[i][4]="-1";
                            break;
                        }
                    }
                }
                if(checkVec[i][4]=="1")
                {
                    ca_out_file<<itoa_write(unass)<<"N-"<<itoa_write(unass-1)<<"CA-"<<itoa_write(unass)<<"HN "<<csVec[i][1]<<" "<<csVec[i][4]<<" "<<csVec[i][2]<<"\n";
                    checkVec[i][4]="-1";
                    vector<string> tmpNew;
                    tmpNew.push_back(itoa_write(unass)+"N-");
                    tmpNew.push_back(csVec[i][0]);
                    newVec.push_back(tmpNew);
                    vector<string> tmpNew2;
                    tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                    tmpNew2.push_back(itoa_write(unass)+"HN");
                    newVec2.push_back(tmpNew2);
                    unass+=10;
                }
            }
        }
        //end check unassigned
        ca_out_file.clear();
        ca_out_file.close();
    }
    if(coFile2!="EMPTY")
    {
        co_out_file2.open (coFile2.c_str(), ios::out);
        co_out_file2 << "      Assignment         w1         w2         w3   "<<endl<<endl;
        co_in_file2.open (cofile2.c_str(), ios::in);
        getline(co_in_file2, line);
        getline(co_in_file2, line);
        while(getline(co_in_file2,line))
        {
            string tmp=line;
            istringstream issT(tmp);
            string subT;
            vector<string> print;
            while(issT >> subT)
                print.push_back(subT);
            unsigned posT = print[0].find_last_of("-");
            bool written =false;
            for(uint i=0; i<csVec.size(); i++)
            {
                if(print[0].length()>csVec[i][0].length())
                {
                    if(print[0].substr(0,csVec[i][0].length())==csVec[i][0])
                    {
                        print[2]=csVec[i][8];
                        checkVec[i][8]="-1";
                        break;
                    }
                }
            }
            if(print[2]=="0")
                continue;
            for(uint i=0; i<writeVec.size(); i++)
            {
                if(writeVec[i][1]==print[0].substr(0,posT-2))
                {
                    unsigned posT2 = writeVec[i][0].find_first_of("-");
                    co_out_file2 << writeVec[i][0] <<"CO-"<<writeVec[i][0].substr(0,posT2-1)<<"HN";
                    for(uint j=1; j<print.size(); j++)
                        co_out_file2<<" "<<print[j];
                    co_out_file2<<"\n";
                    written=true;
                    break;
                }
            }
            if(!written)
            {
                unsigned posL = print[0].find_first_of("-");
                for(uint l=0; l<newVec.size(); l++)
                {
                    if(newVec[l][1].length()<=posL+1)
                    {
                        if(newVec[l][1]==print[0].substr(0,newVec[l][1].length()))
                        {
                            co_out_file2<<newVec2[l][0]<<"CO-"<<newVec2[l][1];
                            for(uint j=1; j<print.size(); j++)
                                co_out_file2<<" "<<print[j];
                            co_out_file2<<"\n";
                            written=true;
                        }
                    }
                }
                if(!written)
                {
                    co_out_file2<<itoa_write(unass)<<"N-"<<itoa_write(unass-1)<<"CO-"<<itoa_write(unass)<<"HN";
                    for(uint j=1; j<print.size(); j++)
                        co_out_file2<<" "<<print[j];
                    co_out_file2<<"\n";
                    vector<string> tmpNew;
                    tmpNew.push_back(itoa_write(unass)+"N-");
                    unsigned posT3 = print[0].find_first_of("-");
                    tmpNew.push_back(print[0].substr(0,posT3+1));
                    newVec.push_back(tmpNew);
                    vector<string> tmpNew2;
                    tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                    tmpNew2.push_back(itoa_write(unass)+"HN");
                    newVec2.push_back(tmpNew2);
                    unass+=10;
                }
            }
        }
        co_in_file2.clear();
        co_in_file2.close();
        if(coFile=="EMPTY")
        {
            // Check unassigned
            for(uint i=0; i<csVec.size(); i++)
            {
                if(csVec[i][8]!="0" && checkVec[i][8]=="1")
                {
                    for(uint j=0; j<writeVec.size(); j++)
                    {
                        if(writeVec[j][1].length()>csVec[i][0].length())
                        {
                            if(writeVec[j][1].substr(0,csVec[i][0].length())==csVec[i][0])
                            {
                                unsigned posD= writeVec[j][0].find_first_of("-");
                                co_out_file2<<writeVec[j][0]<<"CO-"<<writeVec[j][0].substr(0,posD-1)<<"HN "<<csVec[i][1]<<" "<<csVec[i][8]<<" "<<csVec[i][2]<<"\n";
                                checkVec[i][8]="-1";
                                break;
                            }
                        }
                    }
                    if(checkVec[i][8]=="1")
                    {
                        for(uint l=0; l<newVec.size(); l++)
                        {
                            if(newVec[l][1]==csVec[i][0])
                            {
                                co_out_file2<<newVec2[l][0]<<"CO-"<<newVec2[l][1]<<" "<<csVec[i][1]<<" "<<csVec[i][8]<<" "<<csVec[i][2]<<"\n";
                                checkVec[i][8]="-1";
                                break;
                            }
                        }
                    }
                    if(checkVec[i][8]=="1")
                    {
                        co_out_file2<<itoa_write(unass)<<"N-"<<itoa_write(unass-1)<<"CO-"<<itoa_write(unass)<<"HN "<<csVec[i][1]<<" "<<csVec[i][8]<<" "<<csVec[i][2]<<"\n";
                        checkVec[i][8]="-1";
                        vector<string> tmpNew;
                        tmpNew.push_back(itoa_write(unass)+"N-");
                        tmpNew.push_back(csVec[i][0]);
                        newVec.push_back(tmpNew);
                        vector<string> tmpNew2;
                        tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                        tmpNew2.push_back(itoa_write(unass)+"HN");
                        newVec2.push_back(tmpNew2);
                        unass+=10;
                    }
                }
            }
            //end check unassigned
        }
        co_out_file2.clear();
        co_out_file2.close();
    }
    if(coFile!="EMPTY")
    {
        co_out_file.open (coFile.c_str(), ios::out);
        co_out_file << "      Assignment         w1         w2         w3   "<<endl<<endl;
        co_in_file.open (cofile.c_str(), ios::in);
        getline(co_in_file, line);
        getline(co_in_file, line);
        while(getline(co_in_file,line))
        {
            string tmp=line;
            istringstream issT(tmp);
            string subT;
            vector<string> print;
            while(issT >> subT)
                print.push_back(subT);
            unsigned posT = print[0].find_last_of("-");
            bool internal=true;
            bool written =false;
            if(print[0].substr(posT-3,1)!="-")
                internal=false;
            for(uint i=0; i<csVec.size(); i++)
            {
                if(print[0].length()>csVec[i][0].length())
                {
                    if(print[0].substr(0,csVec[i][0].length())==csVec[i][0])
                    {
                        if(internal)
                        {
                            print[2]=csVec[i][7];
                            checkVec[i][7]="-1";
                            break;
                        }
                        else
                        {
                            print[2]=csVec[i][8];
                            checkVec[i][8]="-1";
                            break;
                        }
                    }
                }
            }
            if(print[2]=="0")
                continue;
            for(uint i=0; i<writeVec.size(); i++)
            {
                if(writeVec[i][1]==print[0].substr(0,posT-2))
                {
                    if(internal)
                        co_out_file << writeVec[i][0] << suffix[2];
                    else
                    {
                        unsigned posT2 = writeVec[i][0].find_first_of("-");
                        co_out_file << writeVec[i][0] <<"CO-"<<writeVec[i][0].substr(0,posT2-1)<<"HN";
                    }
                    for(uint j=1; j<print.size(); j++)
                        co_out_file<<" "<<print[j];
                    co_out_file<<"\n";
                    written=true;
                    break;
                }
            }
            if(!written)
            {
                unsigned posL = print[0].find_first_of("-");
                for(uint l=0; l<newVec.size(); l++)
                {
                    if(newVec[l][1].length()<=posL+1)
                    {
                        if(newVec[l][1]==print[0].substr(0,newVec[l][1].length()))
                        {
                            if(internal)
                                co_out_file<<newVec[l][0]<<suffix[2];
                            else
                                co_out_file<<newVec2[l][0]<<"CO-"<<newVec2[l][1];
                            for(uint j=1; j<print.size(); j++)
                                co_out_file<<" "<<print[j];
                            co_out_file<<"\n";
                            written=true;
                        }
                    }
                }
                if(!written)
                {
                    if(internal)
                    {
                        co_out_file<< itoa_write(unass)<< "N-"<<suffix[2];
                        for(uint j=1; j<print.size(); j++)
                            co_out_file<<" "<<print[j];
                        co_out_file<<"\n";
                        vector<string> tmpNew;
                        tmpNew.push_back(itoa_write(unass)+"N-");
                        tmpNew.push_back(print[0].substr(0,posT-2));
                        newVec.push_back(tmpNew);
                        vector<string> tmpNew2;
                        tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                        tmpNew2.push_back(itoa_write(unass)+"HN");
                        newVec2.push_back(tmpNew2);
                        unass+=10;
                    }
                    else
                    {
                        co_out_file<<itoa_write(unass)<<"N-"<<itoa_write(unass-1)<<"CO-"<<itoa_write(unass)<<"HN";
                        for(uint j=1; j<print.size(); j++)
                            co_out_file<<" "<<print[j];
                        co_out_file<<"\n";
                        vector<string> tmpNew;
                        tmpNew.push_back(itoa_write(unass)+"N-");
                        unsigned posT3 = print[0].find_first_of("-");
                        tmpNew.push_back(print[0].substr(0,posT3+1));
                        newVec.push_back(tmpNew);
                        vector<string> tmpNew2;
                        tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                        tmpNew2.push_back(itoa_write(unass)+"HN");
                        newVec2.push_back(tmpNew2);
                        unass+=10;
                    }
                }
            }
        }
        co_in_file.clear();
        co_in_file.close();
        // Check unassigned
        for(uint i=0; i<csVec.size(); i++)
        {
            if(csVec[i][7]!="0" && checkVec[i][7]=="1")
            {
                for(uint j=0; j<writeVec.size(); j++)
                {
                    if(writeVec[j][1]==csVec[i][0])
                    {
                        co_out_file<<writeVec[j][0]<<suffix[2]<<" "<<csVec[i][1]<<" "<<csVec[i][7]<<" "<<csVec[i][2]<<"\n";
                        checkVec[i][7]="-1";
                        break;
                    }
                }
                if(checkVec[i][7]=="1")
                {
                    for(uint l=0; l<newVec.size(); l++)
                    {
                        if(newVec[l][1]==csVec[i][0])
                        {
                            co_out_file<<newVec[l][0]<<suffix[2]<<" "<<csVec[i][1]<<" "<<csVec[i][7]<<" "<<csVec[i][2]<<"\n";
                            checkVec[i][7]="-1";
                            break;
                        }
                    }
                }
                if(checkVec[i][7]=="1")
                {
                    co_out_file<<itoa_write(unass)<<"N-"<<suffix[2]<<" "<<csVec[i][1]<<" "<<csVec[i][7]<<" "<<csVec[i][2]<<"\n";
                    checkVec[i][7]="-1";
                    vector<string> tmpNew;
                    tmpNew.push_back(itoa_write(unass)+"N-");
                    tmpNew.push_back(csVec[i][0]);
                    newVec.push_back(tmpNew);
                    vector<string> tmpNew2;
                    tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                    tmpNew2.push_back(itoa_write(unass)+"HN");
                    newVec2.push_back(tmpNew2);
                    unass+=10;
                }
            }
            if(csVec[i][8]!="0" && checkVec[i][8]=="1")
            {
                for(uint j=0; j<writeVec.size(); j++)
                {
                    if(writeVec[j][1].length()>csVec[i][0].length())
                    {
                        if(writeVec[j][1].substr(0,csVec[i][0].length())==csVec[i][0])
                        {
                            unsigned posD= writeVec[j][0].find_first_of("-");
                            co_out_file<<writeVec[j][0]<<"CO-"<<writeVec[j][0].substr(0,posD-1)<<"HN "<<csVec[i][1]<<" "<<csVec[i][8]<<" "<<csVec[i][2]<<"\n";
                            checkVec[i][8]="-1";
                            break;
                        }
                    }
                }
                if(checkVec[i][8]=="1")
                {
                    for(uint l=0; l<newVec.size(); l++)
                    {
                        if(newVec[l][1]==csVec[i][0])
                        {
                            co_out_file<<newVec2[l][0]<<"CO-"<<newVec2[l][1]<<" "<<csVec[i][1]<<" "<<csVec[i][8]<<" "<<csVec[i][2]<<"\n";
                            checkVec[i][8]="-1";
                            break;
                        }
                    }
                }
                if(checkVec[i][8]=="1")
                {
                    co_out_file<<itoa_write(unass)<<"N-"<<itoa_write(unass-1)<<"CO-"<<itoa_write(unass)<<"HN "<<csVec[i][1]<<" "<<csVec[i][8]<<" "<<csVec[i][2]<<"\n";
                    checkVec[i][8]="-1";
                    vector<string> tmpNew;
                    tmpNew.push_back(itoa_write(unass)+"N-");
                    tmpNew.push_back(csVec[i][0]);
                    newVec.push_back(tmpNew);
                    vector<string> tmpNew2;
                    tmpNew2.push_back(itoa_write(unass)+"N-"+itoa_write(unass-1));
                    tmpNew2.push_back(itoa_write(unass)+"HN");
                    newVec2.push_back(tmpNew2);
                    unass+=10;
                }
            }
        }
        //end check unassigned
        co_out_file.clear();
        co_out_file.close();
    }
    if(hsqcFile!="EMPTY")
    {
        hsqc_out_file.open(hsqcFile.c_str(), ios::out);
        hsqc_out_file<<"      Assignment         w1         w2"<<endl<<endl;
        hsqc_in_file.open (hsqcfile.c_str(), ios::in);
        getline(hsqc_in_file, line);
        getline(hsqc_in_file, line);
        while(getline(hsqc_in_file,line))
        {
            string tmp=line;
            istringstream issT(tmp);
            string subT;
            vector<string> print;
            while(issT >> subT)
                print.push_back(subT);
            unsigned posT = print[0].find_last_of("-");
            posT++;
            bool written =false;
            for(uint i=0; i<writeVec.size(); i++)
            {
                if(writeVec[i][1].length()>posT)
                {
                    if(writeVec[i][1].substr(0,posT)==print[0].substr(0,posT))
                    {
                        unsigned posF = writeVec[i][0].find_last_of("-");
                        hsqc_out_file<<writeVec[i][0].substr(0,posF+1)<<suffix[3];
                        for(uint j=1; j<print.size(); j++)
                            hsqc_out_file<<" "<<print[j];
                        hsqc_out_file<<"\n";
                        written=true;
                        break;
                    }
                }
            }
            if(!written)
            {
                unsigned posL = print[0].find_first_of("-");
                for(uint l=0; l<newVec.size(); l++)
                {
                    if(newVec[l][1].length()<=posL+1)
                    {
                        if(newVec[l][1]==print[0].substr(0,newVec[l][1].length()))
                        {
                            hsqc_out_file<<newVec[l][0]<<suffix[3];
                            for(uint j=1; j<print.size(); j++)
                                hsqc_out_file<<" "<<print[j];
                            hsqc_out_file<<"\n";
                            written=true;
                        }
                    }
                }
                if(!written)
                {
                    hsqc_out_file<<itoa_write(unass)<<"N-"<<suffix[3];
                    for(uint j=1; j<print.size(); j++)
                        hsqc_out_file<<" "<<print[j];
                    hsqc_out_file<<"\n";
                    unass+=10;
                }
            }
        }
        hsqc_in_file.clear();
        hsqc_in_file.close();
        hsqc_out_file.clear();
        hsqc_out_file.close();
    }
errorFile.clear();
errorFile.close();
}
}
string getAa(string str)
{
    if(!isalpha(str[0]))
        return mconvert(atoi(str.c_str())-1);
    string AA ="ACDEFGHIKLMNPQRSTVWY";
    for(uint i=0; i<AA.length();i++)
    {
        if(str[0]==AA[i])
            break;
        else if(i==AA.length()-1)
            return mconvert(atoi(str.substr(1).c_str())-1);
    }
    int sequential = atoi(str.substr(1).c_str())-1;
    extern QString profile;
    std::string seq, line;
    string fname=profile.toStdString();
    std::ifstream file;
    file.open(fname.c_str(), std::ios::in);
    for(int i=0; i<5; i++)
        getline(file, line);
    seq=line;
    getline(file, line);
    int first = atoi(line.c_str());
    file.clear();
    file.close();
    file.open(seq.c_str(), std::ios::in);
    string sub;
    while(file >> sub)
    {
        if(first==sequential)
            return res1(sub)+mconvert(sequential);
        first++;
    }
    file.clear();
    file.close();
    return str;
}
string itoa_write(int integer)
    {
        string converted;
        stringstream converted_out;
        converted_out << integer;
        converted = converted_out.str();
        return converted;
    }


string res1(string res3)
{
    if (res3 == "ALA")
        return "A";
    else if (res3 == "CYS")
        return "C";
    else if (res3 == "ASP")
        return "D";
    else if (res3 == "GLU")
        return "E";
    else if (res3 == "PHE")
        return "F";
    else if (res3 == "GLY")
        return "G";
    else if (res3 == "HIS")
        return "H";
    else if (res3 == "ILE")
        return "I";
    else if (res3 == "LYS")
        return "K";
    else if (res3 == "LEU")
        return "L";
    else if (res3 == "MET")
        return "M";
    else if (res3 == "ASN")
        return "N";
    else if (res3 == "PRO")
        return "P";
    else if (res3 == "GLN")
        return "Q";
    else if (res3 == "ARG")
        return "R";
    else if (res3 == "SER")
        return "S";
    else if (res3 == "THR")
        return "T";
    else if (res3 == "VAL")
        return "V";
    else if (res3 == "TRP")
        return "W";
    else //TYR
        return "Y";

}

};

#endif
