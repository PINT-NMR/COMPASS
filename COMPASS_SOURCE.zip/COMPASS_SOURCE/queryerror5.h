#ifndef QUERYERROR5_H
#define QUERYERROR5_H

#include <QDialog>

namespace Ui
{
	class QueryError5;
}

class QueryError5 : public QDialog
{
	Q_OBJECT

public:
	QueryError5(QWidget *parent = 0);
	~QueryError5();

private:
	Ui::QueryError5 *ui;

signals:	
};

#endif
