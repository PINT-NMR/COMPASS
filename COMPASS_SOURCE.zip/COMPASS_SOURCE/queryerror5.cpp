#include "queryerror5.h"
#include "ui_queryerror5.h"
#include <QtWidgets>
#include <cstdlib>
#include "QRect"		
#include "QDesktopWidget"	
#include <fstream>
#include <iostream>
#include "globals.h"

QueryError5::QueryError5(QWidget *parent) :
    QDialog(parent),
	ui(new Ui::QueryError5)
{
	ui->setupUi(this);
    connect (ui->buttonBox, SIGNAL( accepted()), this, SLOT(accept()));
    connect (ui->buttonBox, SIGNAL( rejected()), this, SLOT(reject()));
}
QueryError5::~QueryError5()
{
	delete ui;
}
