#ifndef COMPASSHTML_H
#define COMPASSHTML_H
#include "compassvec.h"
#include "globals.h"
void compasshtml();
#endif
