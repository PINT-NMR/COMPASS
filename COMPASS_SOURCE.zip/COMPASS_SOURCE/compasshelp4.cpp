#include "compasshelp4.h"
#include "ui_compasshelp4.h"
#include <QtWidgets>

CompassHelp4::CompassHelp4(QWidget *parent) :
    QDialog(parent),
	ui(new Ui::CompassHelp4)
{
	ui->setupUi(this);
}

CompassHelp4::~CompassHelp4()
{
	delete ui;
}

void CompassHelp4::on_closeButton_clicked()
{
    accept();
}
