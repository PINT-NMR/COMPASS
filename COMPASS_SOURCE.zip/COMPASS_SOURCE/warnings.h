#ifndef WARNINGS_H
#define WARNINGS_H

#include <QMainWindow>

namespace Ui
{
	class Warnings;
}

class Warnings : public QMainWindow
{
	Q_OBJECT

public:
	Warnings(QWidget *parent = 0);
	~Warnings();

protected:
	void changeEvent(QEvent *e);

private:
	Ui::Warnings *ui;

private slots:
	void on_buttonBox_accepted();
};

#endif
