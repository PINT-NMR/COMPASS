#ifndef SSP2_H
#define SSP2_H

#include <fstream>
#include <cmath>
#include <iostream> 
#include <stdlib.h> 
#include <string.h>

int getAa2(std::string aa);
double refdbCA2(int res);
double refdbCB2(int res);
double refdbCO2(int res);
double refdbHN2(int res);
double refdbN2(int res);
double refdbSSCA2(int res, int col);
double refdbSSCB2(int res, int col);
double refdbSSCO2(int res, int col);
double refdbSSHN2(int res, int col);
double refdbSSN2(int res, int col);
void sspCalc2(std::string CA, std::string CB, std::string CO, std::string HN, std::string N, std::string SEQ, std::string fname);
#endif
