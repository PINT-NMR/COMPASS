#ifndef QUERYERROR4_H
#define QUERYERROR4_H

#include <QDialog>

namespace Ui
{
	class QueryError4;
}

class QueryError4 : public QDialog
{
	Q_OBJECT

public:
	QueryError4(QWidget *parent = 0);
	~QueryError4();
private:
	Ui::QueryError4 *ui;

private slots:
	void errorSet();
    void on_closeErrButton2_clicked();
};

#endif
