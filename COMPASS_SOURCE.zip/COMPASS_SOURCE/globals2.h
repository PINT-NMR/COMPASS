#include <QtWidgets>
#include <cstdlib>
#include <vector>
namespace Ui
{
	extern int counterhsqc;
	extern int counternum;
    extern std::vector< std::vector <std::string> > HSQCarray; //[5000][6]
    extern std::vector< std::vector <double> > SpinSysarray; //[5000][12]
    extern std::vector<std::string> HSQCsub;
    extern std::vector<double> Spinsub;
	extern QString fileRes,fileWarn;
    extern QString qDir;
    extern std::string Dir;
}
