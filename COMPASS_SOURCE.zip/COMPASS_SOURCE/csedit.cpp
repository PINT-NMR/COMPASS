#include "csedit.h"
#include "ui_csedit.h"
#include "ctype.h"

CSedit::CSedit(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CSedit)
{
    ui->setupUi(this);
    setup();
    connect(ui->csTable, SIGNAL(cellChanged(int,int)), this, SLOT(activeCell(int,int)));
    connect(ui->csTable, SIGNAL(itemChanged(QTableWidgetItem *)), this, SLOT(validate(QTableWidgetItem *)));
}

CSedit::~CSedit()
{
    delete ui;

}
void CSedit::on_saveButton_clicked()
{
    extern QString profile;
    std::string fname, line;
    fname=profile.toStdString().c_str();
    std::ifstream fileI;
    fileI.open(fname.c_str(), std::ios::in);
    getline(fileI, line);
    std::string root = line + "Analysis/csedit";
    fileI.clear();
    fileI.close();
    std::fstream file;
    file.open(root.c_str(), std::ios::out);
    for(int i=0; i<ui->csTable->rowCount(); i++)
    {
        std::vector<std::string> strVec;
        for(int j=0; j<ui->csTable->columnCount(); j++)
        {
            strVec.push_back(mconvert(ui->csTable->item(i,j)->text()));
        }
        bool write = false;
        for(uint j=3; j<strVec.size(); j++)
            if(strVec[j]!=csVec[i][j])
            {
                write=true;
                break;
            }
        if(write)
        {
            for(uint j=0; j<strVec.size(); j++)
                file<<strVec[j]<<" ";
            file<<"\n";
        }
    }
    file.clear();
    file.close();
    extern bool csBackup;
    csBackup = true;
    accept();
}
void CSedit::activeCell(int row,int col)
{
    curr1 = row;
    curr2 = col;
}
void CSedit::validate(QTableWidgetItem * item1)
{
    if(item1->text()=="")
        item1->setText("0");
    else
    {
        bool isNum =false;
        item1->text().toDouble(&isNum);
        if(!isNum)
            item1->setText(mconvert(csVec[item1->row()][item1->column()]));
        else if(item1->text().toDouble()<0.0)
            item1->setText(mconvert(csVec[item1->row()][item1->column()]));
    }
}
void CSedit::on_helpButton_clicked()
{
    QMessageBox::StandardButton dialog;
    dialog = QMessageBox::warning(this, "COMPASS",
                 "Changing the chemical shifts of CA, CB and/or CO will have no effect on the analysis.\nRepeat the analysis with updated chemical shifts to get new fragment lists.\nThis function simply allows the user to directly add, remove or change chemical shift values for all spin systems.\nConsequently, the SSP analysis will be based on these chemical shifts and COMPASS will make these changes to the final output files.\n\nThis function is very useful for correcting minor errors and adding new peaks without having to repeat the analysis to get a correct SSP analysis and making manual changes to the peak lists after COMPASS usage.\n\nWarning! There is no limitation when changing existent chemical shifts. However, in order to add new CA, CB or CO chemical shifts the corresponding file must exist. For example, you cannot add a CA(i) chemical shift if you lack an HNCA(i)(i-1) file.",
                 QMessageBox::Close);
    if( dialog == QMessageBox::Close)
    {}
}
void CSedit::setup()
{
    extern QString profile;
    std::string fname, line, cafile, cbcafile, cofile, cafile2, cbcafile2, cofile2, hsqcfile;
    fname=profile.toStdString();
    std::ifstream file;
    file.open(fname.c_str(), std::ios::in);
    getline(file, line);
    std::string root = line + "Analysis/csedit";
    getline(file, line);
    cafile=line;
    getline(file, line);
    cbcafile=line;
    getline(file, line);
    cofile=line;
    for(int i=0; i<3; i++)
        getline(file, line);
    cafile2=line;
    getline(file, line);
    cbcafile2=line;
    getline(file, line);
    cofile2=line;
    getline(file, line);
    hsqcfile=line;
    file.clear();
    file.close();

    if(hsqcfile!="EMPTY")
    {
        file.open(hsqcfile.c_str(), std::ios::in);
        getline(file, line);
        getline(file, line);
        while(getline(file, line))
        {
            std::vector<std::string> tmp;
            std::istringstream iss(line);
            std::string sub;
            iss >> sub;
            tmp.push_back(sub.substr(0,sub.length()-4));
            iss >> sub;
            tmp.push_back(sub);
            iss >> sub;
            tmp.push_back(sub);
            for(int i =0; i<6; i++)
                tmp.push_back("0");
            csVec.push_back(tmp);
        }
        file.clear();
        file.close();
    }
    if(cafile!="EMPTY")
    {
        file.open(cafile.c_str(), std::ios::in);
        getline(file, line);
        getline(file, line);
        while(getline(file, line))
        {
            std::vector<std::string> tmp;
            std::istringstream iss(line);
            std::string sub;
            iss >> sub;
            unsigned pos;
            pos = sub.find_first_of("-");
            bool internal=true;
            if(sub.substr(pos)!="-CA-HN")
                internal=false;
            bool exist = false;
            int idx =0;
            for(uint i=0; i<csVec.size(); i++)
            {
                if(csVec[i][0]==sub.substr(0,pos-1))
                {
                    exist=true;
                    idx = i;
                    break;
                }
            }
            tmp.push_back(sub.substr(0,pos-1));
            iss >> sub;
            tmp.push_back(sub);
            std::string sub2;
            iss >> sub2;
            iss >> sub;
            tmp.push_back(sub);
            if(internal)
            {
                tmp.push_back(sub2);
                tmp.push_back("0");
            }
            else
            {
                tmp.push_back("0");
                tmp.push_back(sub2);
            }
            for(int i =0; i<4; i++)
                tmp.push_back("0");
            if(!exist)
                csVec.push_back(tmp);
            else
            {
                for(int i=3; i<5; i++)
                    if(csVec[idx][i]=="0")
                        csVec[idx][i]=tmp[i];
            }
        }
        file.clear();
        file.close();
    }
    if(cafile2!="EMPTY")
    {
        file.open(cafile2.c_str(), std::ios::in);
        getline(file, line);
        getline(file, line);
        while(getline(file, line))
        {
            std::vector<std::string> tmp;
            std::istringstream iss(line);
            std::string sub;
            iss >> sub;
            unsigned pos;
            pos = sub.find_first_of("-");
            bool exist = false;
            int idx =0;
            for(uint i=0; i<csVec.size(); i++)
            {
                if(csVec[i][0]==sub.substr(0,pos-1))
                {
                    exist=true;
                    idx = i;
                    break;
                }
            }
            tmp.push_back(sub.substr(0,pos-1));
            iss >> sub;
            tmp.push_back(sub);
            std::string sub2;
            iss >> sub2;
            iss >> sub;
            tmp.push_back(sub);
            tmp.push_back("0");
            tmp.push_back(sub2);
            for(int i =0; i<4; i++)
                tmp.push_back("0");
            if(!exist)
                csVec.push_back(tmp);
            else
            {
                for(int i=3; i<5; i++)
                    if(csVec[idx][i]=="0")
                        csVec[idx][i]=tmp[i];
            }
        }
        file.clear();
        file.close();
    }
    if(cbcafile!="EMPTY")
    {
        file.open(cbcafile.c_str(), std::ios::in);
        getline(file, line);
        getline(file, line);
        while(getline(file, line))
        {
            std::vector<std::string> tmp;
            std::istringstream iss(line);
            std::string sub;
            iss >> sub;
            unsigned pos;
            pos = sub.find_first_of("-");
            unsigned pos2;
            pos2 = sub.find_last_of("-");
            bool CA=true;
            if(sub.substr(pos2-1,1)=="B")
                CA=false;
            bool internal=true;
            if(sub.substr(pos)!="-CB-HN" && sub.substr(pos)!="-CA-HN")
                internal=false;
            bool exist = false;
            int idx =0;
            for(uint i=0; i<csVec.size(); i++)
            {
                if(csVec[i][0]==sub.substr(0,pos-1))
                {
                    exist=true;
                    idx = i;
                    break;
                }
            }
            tmp.push_back(sub.substr(0,pos-1));
            iss >> sub;
            tmp.push_back(sub);
            std::string sub2;
            iss >> sub2;
            iss >> sub;
            tmp.push_back(sub);
            if(internal && CA)
            {
                tmp.push_back(sub2);
                tmp.push_back("0");
                tmp.push_back("0");
                tmp.push_back("0");
            }
            else if(CA)
            {
                tmp.push_back("0");
                tmp.push_back(sub2);
                tmp.push_back("0");
                tmp.push_back("0");
            }
            else if(internal)
            {
                tmp.push_back("0");
                tmp.push_back("0");
                tmp.push_back(sub2);
                tmp.push_back("0");
            }
            else
            {
                tmp.push_back("0");
                tmp.push_back("0");
                tmp.push_back("0");
                tmp.push_back(sub2);
            }
            for(int i =0; i<2; i++)
                tmp.push_back("0");
            if(!exist)
                csVec.push_back(tmp);
            else
            {
                for(int i=3; i<7; i++)
                    if(csVec[idx][i]=="0")
                        csVec[idx][i]=tmp[i];
            }
        }
        file.clear();
        file.close();
    }
    if(cbcafile2!="EMPTY")
    {
        file.open(cbcafile2.c_str(), std::ios::in);
        getline(file, line);
        getline(file, line);
        while(getline(file, line))
        {
            std::vector<std::string> tmp;
            std::istringstream iss(line);
            std::string sub;
            iss >> sub;
            unsigned pos;
            pos = sub.find_first_of("-");
            unsigned pos2;
            pos2 = sub.find_last_of("-");
            bool CA=true;
            if(sub.substr(pos2-1,1)=="B")
                CA=false;
            bool exist = false;
            int idx =0;
            for(uint i=0; i<csVec.size(); i++)
            {
                if(csVec[i][0]==sub.substr(0,pos-1))
                {
                    exist=true;
                    idx = i;
                    break;
                }
            }
            tmp.push_back(sub.substr(0,pos-1));
            iss >> sub;
            tmp.push_back(sub);
            std::string sub2;
            iss >> sub2;
            iss >> sub;
            tmp.push_back(sub);
            if(CA)
            {
                tmp.push_back("0");
                tmp.push_back(sub2);
                tmp.push_back("0");
                tmp.push_back("0");
            }
            else
            {
                tmp.push_back("0");
                tmp.push_back("0");
                tmp.push_back("0");
                tmp.push_back(sub2);
            }
            for(int i =0; i<2; i++)
                tmp.push_back("0");
            if(!exist)
                csVec.push_back(tmp);
            else
            {
                for(int i=3; i<7; i++)
                    if(csVec[idx][i]=="0")
                        csVec[idx][i]=tmp[i];
            }
        }
        file.clear();
        file.close();
    }
    if(cofile!="EMPTY")
    {
        file.open(cofile.c_str(), std::ios::in);
        getline(file, line);
        getline(file, line);
        while(getline(file, line))
        {
            std::vector<std::string> tmp;
            std::istringstream iss(line);
            std::string sub;
            iss >> sub;
            unsigned pos;
            pos = sub.find_first_of("-");
            bool internal=true;
            if(sub.substr(pos)!="-CO-HN")
                internal=false;
            bool exist = false;
            int idx =0;
            for(uint i=0; i<csVec.size(); i++)
            {
                if(csVec[i][0]==sub.substr(0,pos-1))
                {
                    exist=true;
                    idx = i;
                    break;
                }
            }
            tmp.push_back(sub.substr(0,pos-1));
            iss >> sub;
            tmp.push_back(sub);
            std::string sub2;
            iss >> sub2;
            iss >> sub;
            tmp.push_back(sub);
            if(internal)
            {
                tmp.push_back("0");
                tmp.push_back("0");
                tmp.push_back("0");
                tmp.push_back("0");
                tmp.push_back(sub2);
                tmp.push_back("0");
            }
            else
            {
                tmp.push_back("0");
                tmp.push_back("0");
                tmp.push_back("0");
                tmp.push_back("0");
                tmp.push_back("0");
                tmp.push_back(sub2);
            }
            if(!exist)
                csVec.push_back(tmp);
            else
            {
                for(int i=7; i<9; i++)
                    if(csVec[idx][i]=="0")
                        csVec[idx][i]=tmp[i];
            }
        }
        file.clear();
        file.close();
    }
    if(cofile2!="EMPTY")
    {
        file.open(cofile2.c_str(), std::ios::in);
        getline(file, line);
        getline(file, line);
        while(getline(file, line))
        {
            std::vector<std::string> tmp;
            std::istringstream iss(line);
            std::string sub;
            iss >> sub;
            unsigned pos;
            pos = sub.find_first_of("-");
            bool exist = false;
            int idx =0;
            for(uint i=0; i<csVec.size(); i++)
            {
                if(csVec[i][0]==sub.substr(0,pos-1))
                {
                    exist=true;
                    idx = i;
                    break;
                }
            }
            tmp.push_back(sub.substr(0,pos-1));
            iss >> sub;
            tmp.push_back(sub);
            std::string sub2;
            iss >> sub2;
            iss >> sub;
            tmp.push_back(sub);
            tmp.push_back("0");
            tmp.push_back("0");
            tmp.push_back("0");
            tmp.push_back("0");
            tmp.push_back("0");
            tmp.push_back(sub2);
            if(!exist)
                csVec.push_back(tmp);
            else
            {
                if(csVec[idx][8]=="0")
                    csVec[idx][8]=tmp[8];
            }
        }
        file.clear();
        file.close();
    }
    ui->csTable->setColumnCount(9);
    for(uint i=0; i<csVec.size(); i++)
    {
        ui->csTable->insertRow(ui->csTable->rowCount());
        for(int j=0; j<9; j++)
        {
            QTableWidgetItem *item;
            item = new QTableWidgetItem;
            if(j<3)
                item->setFlags(item->flags() ^ Qt::ItemIsEditable);
            item->setText(mconvert(csVec[i][j]));
            ui->csTable->setItem(ui->csTable->rowCount()-1,j,item);
        }
    }
    ui->csTable->setHorizontalHeaderItem(0,new QTableWidgetItem("Spin system"));
    ui->csTable->setHorizontalHeaderItem(1,new QTableWidgetItem("N"));
    ui->csTable->setHorizontalHeaderItem(2,new QTableWidgetItem("HN"));
    ui->csTable->setHorizontalHeaderItem(3,new QTableWidgetItem("CA(i)"));
    ui->csTable->setHorizontalHeaderItem(4,new QTableWidgetItem("CA(i-1)"));
    ui->csTable->setHorizontalHeaderItem(5,new QTableWidgetItem("CB(i)"));
    ui->csTable->setHorizontalHeaderItem(6,new QTableWidgetItem("CB(i-1)"));
    ui->csTable->setHorizontalHeaderItem(7,new QTableWidgetItem("CO(i)"));
    ui->csTable->setHorizontalHeaderItem(8,new QTableWidgetItem("CO(i-1)"));
    readChanges(root);
}
void CSedit::on_cancelButton_clicked()
{
    reject();
}


void CSedit::on_defaultButton_clicked()
{
    QMessageBox::StandardButton dialog;
    dialog = QMessageBox::warning(this, "COMPASS",
                 "Do you want to restore all chemical shifts to the values used in the analysis?",
                 QMessageBox::Ok | QMessageBox::Cancel);
    if( dialog == QMessageBox::Ok)
    {
        for(uint i=0; i<csVec.size(); i++)
            for(uint j=0; j<csVec[i].size(); j++)
                ui->csTable->item(i,j)->setText(mconvert(csVec[i][j]));
    }
}
void CSedit::readChanges(std::string root)
{
    std::ifstream file;
    file.open(root.c_str(), std::ios::in);
    std::string line;
    std::vector<std::vector<std::string> > strVec2;
    while(getline(file, line))
    {
        std::vector<std::string> strVec;
        std::string sub;
        std::istringstream iss(line);
        while(iss >> sub)
            strVec.push_back(sub);
        strVec2.push_back(strVec);
    }
    file.clear();
    file.close();
    for(uint i=0; i<strVec2.size(); i++)
    {
        for(uint j=0; j<csVec.size(); j++)
            if(strVec2[i][0]==csVec[j][0])
            {
                for(uint k=0; k<strVec2[i].size(); k++)
                    ui->csTable->item(j,k)->setText(mconvert(strVec2[i][k]));
                break;
            }
    }
}
