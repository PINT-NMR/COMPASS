#ifndef COMPASSHELP5_H
#define COMPASSHELP5_H

#include <QDialog>
#include "compasslabelexample.h"
namespace Ui
{
    class CompassHelp5;
}

class CompassHelp5 : public QDialog
{
    Q_OBJECT

public:
    explicit CompassHelp5(QWidget *parent = 0);
    ~CompassHelp5();

private:
    Ui::CompassHelp5 *ui;

private slots:
    void on_closeButton_clicked();
    void on_exampleButton_clicked();
};

#endif
