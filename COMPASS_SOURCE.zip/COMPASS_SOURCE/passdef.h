#ifndef PASS_DEF
    #define PASS_DEF
    #define CUTOFF 0.0
    #define MAX_TOP 100
    #define DEFAULT_TOP 20
    #define MAX_RES 10
    #define MAX_LINE 10000

    #define LOOP 0
    #define HELIX 1
    #define STRAND 2

    #define ALA 0    
    #define CYS 1    
    #define ASP 2    
    #define GLU 3   
    #define PHE 4  
    #define GLY 5 
    #define HIS 6
    #define ILE 7
    #define LYS 8
    #define LEU 9
    #define MET 10
    #define ASN 11
    #define PRO 12
    #define GLN 13
    #define ARG 14
    #define SER 15
    #define THR 16
    #define VAL 17
    #define TRP 18
    #define TYR 19
#endif

