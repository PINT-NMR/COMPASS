#include <QtWidgets>
#include <cstdlib>
namespace Ui
{
    extern QString Resolution;
	extern int xAxisFirst;
	extern int xAxisLast;
	extern QString errorMessage2;
	extern std::string chiValq;
	extern std::string SpinPar0;
	extern std::string SpinPar1;
	extern std::string SpinPar2;
	extern std::string SpinPar3;
	extern std::string SpinPar4;
	extern std::string SpinPar5;
	extern std::string SpinPar6;
	extern std::string SpinPar7;
	extern std::string SpinPar8;
	extern std::string SpinPar9;
	extern std::string SpinPar10;
	extern std::string SpinPar11;
	extern std::string refPar;
	extern QString errorMessage;
	extern QString compassfile;
	extern QString cafile;
	extern QString cbcafile;
	extern QString cofile;
	extern QString cafile2;
	extern QString cbcafile2;
	extern QString cofile2;
	extern QString profile;
	extern QString hsqcfile;
	extern QString filenames;
	extern QString warnings;
	extern QString warnCA;
	extern QString warnCB;
	extern QString warnCO;
	extern QString warnDev;
	extern int limit1;
	extern int limit2;
	extern int limit3;
	extern QString FormatError;
	extern QString invalid;
	extern QString match23;
	extern QString cerror;
    extern std::string arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg13, arg14, arg15, arg16;
    extern int arg10, arg11, arg17;
    extern double arg12;
    extern std::string arg1b, arg2b, arg3b, arg4b, arg5b, arg6b, arg7b, arg8b, arg9b, arg13b, arg14b, arg15b, arg16b;
    extern int arg10b, arg11b, arg17b;
    extern double arg12b;
    extern int p1, p2, p3;
    extern bool preassign;
    extern bool csBackup;
}
