#include "htmlfile3.h"

using namespace std;

void htmlfile3(string namefiles, int matchI, bool ss)
{
    string match, fnameIn, fnameOut, fnameOutBak, line, lineIss, lineArr[31], sub;
    bool ssCorr=false;
    int lineC, length;
    stringstream converted;
    ifstream inputfile;
    ofstream outputfile, bakfile;
    converted << matchI;
    converted >> match;
    for(int q=0; q<2; q++)
    {
        if(q==0)
        {
            fnameIn = namefiles + "Analysis/compass_result2_match" + match + "_sort";
            fnameOut= namefiles + "Analysis/compass_result2_match" + match + "_sort_html";
        }
        else
        {
            fnameIn = namefiles + "Analysis/compass_result2_match" + match + "_sortCHI";
            fnameOut= namefiles + "Analysis/compass_result2_match" + match + "_sortCHI_html";
        }
        fnameOutBak= fnameOut + ".bak";
        inputfile.open(fnameIn.c_str(), ios::in);
        if(inputfile.is_open())
        {
            lineC=0;
            while(inputfile.good())
            {
                getline(inputfile, line);
                lineC++;
            }
            inputfile.clear();
            inputfile.close();
            lineC--;
            lineC/=31;
            inputfile.open(fnameIn.c_str(), ios::in);
            outputfile.open(fnameOut.c_str(), ios::out);
            bakfile.open(fnameOutBak.c_str(), ios::out);
            for(int i=0; i<lineC; i++)
            {
                for (int j=0; j<31; j++)
                {
                    getline(inputfile, line);
                    lineArr[j]=line;
                }
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                outputfile<<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;

                for(int j=3; j<23; j++)
                {
                    lineIss=lineArr[j];
                    if(ss==true)
                    {
                        ssCorr=false;
                        string lineCorr = lineIss;
                        istringstream issCorr(lineCorr);
                        while(issCorr>>sub)
                        {}
                        if(sub=="Yes")
                            ssCorr=true;
                    }
                    istringstream iss(lineIss);
                    iss >> sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                        bakfile    <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                    }
                    string ID ="<a href=\""+sub+"\"style=\"text-decoration:none;\">"+sub+"</a>";
                    outputfile << ID;
                    bakfile << ID;
                    if(j<12)
                    {
                        outputfile <<" &nbsp;&nbsp;";
                        bakfile    <<" &nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile <<" &nbsp;";
                        bakfile    <<" &nbsp;";
                    }
                    iss >>sub;
                    outputfile<<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile   <<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss >>sub;
                    length=sub.length();
                    outputfile<<sub<<" ";
                    bakfile<<sub<<" ";
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss>>sub;
                    outputfile << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile    << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss>>sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile << sub <<"</FONT><br>"<<endl;
                        bakfile    << sub <<"</FONT><br>"<<endl;
                    }
                    else
                    {
                        outputfile << sub <<"<br>"<<endl;
                        bakfile    << sub <<"<br>"<<endl;
                    }

                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                bakfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                lineIss=lineArr[24];
                istringstream iss(lineIss);
                iss >> sub;
                iss >> sub;
                iss >> sub;
                unsigned pos = sub.find_first_of("-");
                string sub_temp = sub.substr(0,pos-1) + "N-HN";
                if(sub_temp.substr(0,3)=="xxx")
                    sub_temp=sub_temp.substr(3);
                length = sub_temp.length();
                outputfile<<sub_temp<<"(i-1)";
                bakfile   <<sub_temp<<"(i-1)";
                if(10-length>0)
                    for(int j=0; j<=10-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                outputfile<<sub_temp<<"<br>"<<endl;
                bakfile   <<sub_temp<<"<br>"<<endl;
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2<br>"<<endl;
                bakfile   <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2<br>"<<endl;
                for(int j=27; j<30; j++)
                {
                    if(j==27)
                    {
                        outputfile<<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else if(j==28)
                    {
                        outputfile<<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile<<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    lineIss=lineArr[j];
                    istringstream iss2(lineIss);
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    outputfile<<sub<<"<br>"<<endl;
                    bakfile<<sub<<"<br>"<<endl;
                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
            }
            inputfile.clear();
            inputfile.close();
            outputfile.clear();
            outputfile.close();
            bakfile.clear();
            bakfile.close();
        }
    }
    for(int q=0; q<2; q++)
    {
        if(q==0)
        {
            fnameIn = namefiles + "Analysis/compass_result3_match" + match + "_sort";
            fnameOut= namefiles + "Analysis/compass_result3_match" + match + "_sort_html";
        }
        else
        {
            fnameIn = namefiles + "Analysis/compass_result3_match" + match + "_sortCHI";
            fnameOut= namefiles + "Analysis/compass_result3_match" + match + "_sortCHI_html";
        }
        fnameOutBak= fnameOut + ".bak";
        inputfile.open(fnameIn.c_str(), ios::in);
        if(inputfile.is_open())
        {
            lineC=0;
            while(inputfile.good())
            {
                getline(inputfile, line);
                lineC++;
            }
            inputfile.clear();
            inputfile.close();
            lineC--;
            lineC/=31;
            inputfile.open(fnameIn.c_str(), ios::in);
            outputfile.open(fnameOut.c_str(), ios::out);
            bakfile.open(fnameOutBak.c_str(), ios::out);
            for(int i=0; i<lineC; i++)
            {
                for (int j=0; j<31; j++)
                {
                    getline(inputfile, line);
                    lineArr[j]=line;
                }
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                outputfile<<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;

                for(int j=3; j<23; j++)
                {
                    lineIss=lineArr[j];
                    if(ss==true)
                    {
                        ssCorr=false;
                        string lineCorr = lineIss;
                        istringstream issCorr(lineCorr);
                        while(issCorr>>sub)
                        {}
                        if(sub=="Yes")
                            ssCorr=true;
                    }
                    istringstream iss(lineIss);
                    iss >> sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                        bakfile    <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                    }
                    string ID ="<a href=\""+sub+"\"style=\"text-decoration:none;\">"+sub+"</a>";
                    outputfile << ID;
                    bakfile << ID;
                    if(j<12)
                    {
                        outputfile <<" &nbsp;&nbsp;";
                        bakfile    <<" &nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile <<" &nbsp;";
                        bakfile    <<" &nbsp;";
                    }
                    iss >>sub;
                    outputfile<<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile   <<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss >>sub;
                    length=sub.length();
                    outputfile<<sub<<" ";
                    bakfile<<sub<<" ";
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss>>sub;
                    outputfile << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile    << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss>>sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile << sub <<"</FONT><br>"<<endl;
                        bakfile    << sub <<"</FONT><br>"<<endl;
                    }
                    else
                    {
                        outputfile << sub <<"<br>"<<endl;
                        bakfile    << sub <<"<br>"<<endl;
                    }

                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                bakfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                lineIss=lineArr[24];
                istringstream iss(lineIss);
                iss >> sub;
                iss >> sub;
                iss >> sub;
                unsigned pos = sub.find_first_of("-");
                string sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp<<"(i-1)";
                bakfile   <<sub_temp<<"(i-1)";
                if(10-length>0)
                    for(int j=0; j<=10-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                outputfile<<sub_temp<<"<br>"<<endl;
                bakfile   <<sub_temp<<"<br>"<<endl;
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile   <<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3<br>"<<endl;
                bakfile   <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3<br>"<<endl;
                for(int j=27; j<30; j++)
                {
                    if(j==27)
                    {
                        outputfile<<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else if(j==28)
                    {
                        outputfile<<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile<<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    lineIss=lineArr[j];
                    istringstream iss2(lineIss);
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    outputfile<<sub<<"<br>"<<endl;
                    bakfile<<sub<<"<br>"<<endl;
                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile   <<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
            }
            inputfile.clear();
            inputfile.close();
            outputfile.clear();
            outputfile.close();
            bakfile.clear();
            bakfile.close();
        }
    }
    for(int q=0; q<2; q++)
    {
        if(q==0)
        {
            fnameIn = namefiles + "Analysis/compass_result4_match" + match + "_sort";
            fnameOut= namefiles + "Analysis/compass_result4_match" + match + "_sort_html";
        }
        else
        {
            fnameIn = namefiles + "Analysis/compass_result4_match" + match + "_sortCHI";
            fnameOut= namefiles + "Analysis/compass_result4_match" + match + "_sortCHI_html";
        }
        fnameOutBak= fnameOut + ".bak";
        inputfile.open(fnameIn.c_str(), ios::in);
        if(inputfile.is_open())
        {
            lineC=0;
            while(inputfile.good())
            {
                getline(inputfile, line);
                lineC++;
            }
            inputfile.clear();
            inputfile.close();
            lineC--;
            lineC/=31;
            inputfile.open(fnameIn.c_str(), ios::in);
            outputfile.open(fnameOut.c_str(), ios::out);
            bakfile.open(fnameOutBak.c_str(), ios::out);
            for(int i=0; i<lineC; i++)
            {
                for (int j=0; j<31; j++)
                {
                    getline(inputfile, line);
                    lineArr[j]=line;
                }
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                outputfile<<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;

                for(int j=3; j<23; j++)
                {
                    lineIss=lineArr[j];
                    if(ss==true)
                    {
                        ssCorr=false;
                        string lineCorr = lineIss;
                        istringstream issCorr(lineCorr);
                        while(issCorr>>sub)
                        {}
                        if(sub=="Yes")
                            ssCorr=true;
                    }
                    istringstream iss(lineIss);
                    iss >> sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                        bakfile    <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                    }
                    string ID ="<a href=\""+sub+"\"style=\"text-decoration:none;\">"+sub+"</a>";
                    outputfile << ID;
                    bakfile << ID;
                    if(j<12)
                    {
                        outputfile <<" &nbsp;&nbsp;";
                        bakfile    <<" &nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile <<" &nbsp;";
                        bakfile    <<" &nbsp;";
                    }
                    iss >>sub;
                    outputfile<<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile   <<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss >>sub;
                    length=sub.length();
                    outputfile<<sub<<" ";
                    bakfile<<sub<<" ";
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss>>sub;
                    outputfile << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile    << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss>>sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile << sub <<"</FONT><br>"<<endl;
                        bakfile    << sub <<"</FONT><br>"<<endl;
                    }
                    else
                    {
                        outputfile << sub <<"<br>"<<endl;
                        bakfile    << sub <<"<br>"<<endl;
                    }

                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                bakfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                lineIss=lineArr[24];
                istringstream iss(lineIss);
                iss >> sub;
                iss >> sub;
                iss >> sub;
                unsigned pos = sub.find_first_of("-");
                string sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp<<"(i-1)";
                bakfile   <<sub_temp<<"(i-1)";
                if(10-length>0)
                    for(int j=0; j<=10-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                outputfile<<sub_temp<<"<br>"<<endl;
                bakfile   <<sub_temp<<"<br>"<<endl;
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 4<br>"<<endl;
                bakfile   <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 4<br>"<<endl;
                for(int j=27; j<30; j++)
                {
                    if(j==27)
                    {
                        outputfile<<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else if(j==28)
                    {
                        outputfile<<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile<<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    lineIss=lineArr[j];
                    istringstream iss2(lineIss);
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                    iss2 >> sub;
                    outputfile<<sub<<"<br>"<<endl;
                    bakfile<<sub<<"<br>"<<endl;
                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
               }
            inputfile.clear();
            inputfile.close();
            outputfile.clear();
            outputfile.close();
            bakfile.clear();
            bakfile.close();
        }
    }
    for(int q=0; q<2; q++)
    {
        if(q==0)
        {
            fnameIn = namefiles + "Analysis/compass_result5_match" + match + "_sort";
            fnameOut= namefiles + "Analysis/compass_result5_match" + match + "_sort_html";
        }
        else
        {
            fnameIn = namefiles + "Analysis/compass_result5_match" + match + "_sortCHI";
            fnameOut= namefiles + "Analysis/compass_result5_match" + match + "_sortCHI_html";
        }
        fnameOutBak= fnameOut + ".bak";
        inputfile.open(fnameIn.c_str(), ios::in);
        if(inputfile.is_open())
        {
            lineC=0;
            while(inputfile.good())
            {
                getline(inputfile, line);
                lineC++;
            }
            inputfile.clear();
            inputfile.close();
            lineC--;
            lineC/=31;
            inputfile.open(fnameIn.c_str(), ios::in);
            outputfile.open(fnameOut.c_str(), ios::out);
            bakfile.open(fnameOutBak.c_str(), ios::out);
            for(int i=0; i<lineC; i++)
            {
                for (int j=0; j<31; j++)
                {
                    getline(inputfile, line);
                    lineArr[j]=line;
                }
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                outputfile<<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;

                for(int j=3; j<23; j++)
                {
                    lineIss=lineArr[j];
                    if(ss==true)
                    {
                        ssCorr=false;
                        string lineCorr = lineIss;
                        istringstream issCorr(lineCorr);
                        while(issCorr>>sub)
                        {}
                        if(sub=="Yes")
                            ssCorr=true;
                    }
                    istringstream iss(lineIss);
                    iss >> sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                        bakfile    <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                    }
                    string ID ="<a href=\""+sub+"\"style=\"text-decoration:none;\">"+sub+"</a>";
                    outputfile << ID;
                    bakfile << ID;
                    if(j<12)
                    {
                        outputfile <<" &nbsp;&nbsp;";
                        bakfile    <<" &nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile <<" &nbsp;";
                        bakfile    <<" &nbsp;";
                    }
                    iss >>sub;
                    outputfile<<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile   <<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss >>sub;
                    length=sub.length();
                    outputfile<<sub<<" ";
                    bakfile<<sub<<" ";
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss>>sub;
                    outputfile << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile    << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss>>sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile << sub <<"</FONT><br>"<<endl;
                        bakfile    << sub <<"</FONT><br>"<<endl;
                    }
                    else
                    {
                        outputfile << sub <<"<br>"<<endl;
                        bakfile    << sub <<"<br>"<<endl;
                    }

                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                bakfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                lineIss=lineArr[24];
                istringstream iss(lineIss);
                iss >> sub;
                iss >> sub;
                iss >> sub;
                unsigned pos = sub.find_first_of("-");
                string sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp<<"(i-1)";
                bakfile   <<sub_temp<<"(i-1)";
                if(10-length>0)
                    for(int j=0; j<=10-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                outputfile<<sub_temp<<"<br>"<<endl;
                bakfile   <<sub_temp<<"<br>"<<endl;
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 5<br>"<<endl;
                bakfile   <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 5<br>"<<endl;
                for(int j=27; j<30; j++)
                {
                    if(j==27)
                    {
                        outputfile<<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else if(j==28)
                    {
                        outputfile<<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile<<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    lineIss=lineArr[j];
                    istringstream iss2(lineIss);
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }


                    iss2 >> sub;
                    outputfile<<sub<<"<br>"<<endl;
                    bakfile<<sub<<"<br>"<<endl;
                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
            }
            inputfile.clear();
            inputfile.close();
            outputfile.clear();
            outputfile.close();
            bakfile.clear();
            bakfile.close();
        }
    }
    for(int q=0; q<2; q++)
    {
        if(q==0)
        {
            fnameIn = namefiles + "Analysis/compass_result6_match" + match + "_sort";
            fnameOut= namefiles + "Analysis/compass_result6_match" + match + "_sort_html";
        }
        else
        {
            fnameIn = namefiles + "Analysis/compass_result6_match" + match + "_sortCHI";
            fnameOut= namefiles + "Analysis/compass_result6_match" + match + "_sortCHI_html";
        }
        fnameOutBak= fnameOut + ".bak";
        inputfile.open(fnameIn.c_str(), ios::in);
        if(inputfile.is_open())
        {
            lineC=0;
            while(inputfile.good())
            {
                getline(inputfile, line);
                lineC++;
            }
            inputfile.clear();
            inputfile.close();
            lineC--;
            lineC/=31;
            inputfile.open(fnameIn.c_str(), ios::in);
            outputfile.open(fnameOut.c_str(), ios::out);
            bakfile.open(fnameOutBak.c_str(), ios::out);
            for(int i=0; i<lineC; i++)
            {
                for (int j=0; j<31; j++)
                {
                    getline(inputfile, line);
                    lineArr[j]=line;
                }
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                outputfile<<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;

                for(int j=3; j<23; j++)
                {
                    lineIss=lineArr[j];
                    if(ss==true)
                    {
                        ssCorr=false;
                        string lineCorr = lineIss;
                        istringstream issCorr(lineCorr);
                        while(issCorr>>sub)
                        {}
                        if(sub=="Yes")
                            ssCorr=true;
                    }
                    istringstream iss(lineIss);
                    iss >> sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                        bakfile    <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                    }
                    string ID ="<a href=\""+sub+"\"style=\"text-decoration:none;\">"+sub+"</a>";
                    outputfile << ID;
                    bakfile << ID;
                    if(j<12)
                    {
                        outputfile <<" &nbsp;&nbsp;";
                        bakfile    <<" &nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile <<" &nbsp;";
                        bakfile    <<" &nbsp;";
                    }
                    iss >>sub;
                    outputfile<<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile   <<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss >>sub;
                    length=sub.length();
                    outputfile<<sub<<" ";
                    bakfile<<sub<<" ";
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss>>sub;
                    outputfile << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile    << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss>>sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile << sub <<"</FONT><br>"<<endl;
                        bakfile    << sub <<"</FONT><br>"<<endl;
                    }
                    else
                    {
                        outputfile << sub <<"<br>"<<endl;
                        bakfile    << sub <<"<br>"<<endl;
                    }

                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;

                outputfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                bakfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                lineIss=lineArr[24];
                istringstream iss(lineIss);
                iss >> sub;
                iss >> sub;
                iss >> sub;
                unsigned pos = sub.find_first_of("-");
                string sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp<<"(i-1)";
                bakfile   <<sub_temp<<"(i-1)";
                if(10-length>0)
                    for(int j=0; j<=10-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }


                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                outputfile<<sub_temp<<"<br>"<<endl;
                bakfile   <<sub_temp<<"<br>"<<endl;
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 6<br>"<<endl;
                bakfile   <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 6<br>"<<endl;
                for(int j=27; j<30; j++)
                {
                    if(j==27)
                    {
                        outputfile<<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else if(j==28)
                    {
                        outputfile<<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile<<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    lineIss=lineArr[j];
                    istringstream iss2(lineIss);
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }


                    iss2 >> sub;
                    outputfile<<sub<<"<br>"<<endl;
                    bakfile<<sub<<"<br>"<<endl;
                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
            }
            inputfile.clear();
            inputfile.close();
            outputfile.clear();
            outputfile.close();
            bakfile.clear();
            bakfile.close();
        }
    }
    for(int q=0; q<2; q++)
    {
        if(q==0)
        {
            fnameIn = namefiles + "Analysis/compass_result7_match" + match + "_sort";
            fnameOut= namefiles + "Analysis/compass_result7_match" + match + "_sort_html";
        }
        else
        {
            fnameIn = namefiles + "Analysis/compass_result7_match" + match + "_sortCHI";
            fnameOut= namefiles + "Analysis/compass_result7_match" + match + "_sortCHI_html";
        }
        fnameOutBak= fnameOut + ".bak";
        inputfile.open(fnameIn.c_str(), ios::in);
        if(inputfile.is_open())
        {
            lineC=0;
            while(inputfile.good())
            {
                getline(inputfile, line);
                lineC++;
            }
            inputfile.clear();
            inputfile.close();
            lineC--;
            lineC/=31;
            inputfile.open(fnameIn.c_str(), ios::in);
            outputfile.open(fnameOut.c_str(), ios::out);
            bakfile.open(fnameOutBak.c_str(), ios::out);
            for(int i=0; i<lineC; i++)
            {
                for (int j=0; j<31; j++)
                {
                    getline(inputfile, line);
                    lineArr[j]=line;
                }
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                outputfile<<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;

                for(int j=3; j<23; j++)
                {
                    lineIss=lineArr[j];
                    if(ss==true)
                    {
                        ssCorr=false;
                        string lineCorr = lineIss;
                        istringstream issCorr(lineCorr);
                        while(issCorr>>sub)
                        {}
                        if(sub=="Yes")
                            ssCorr=true;
                    }
                    istringstream iss(lineIss);
                    iss >> sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                        bakfile    <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                    }
                    string ID ="<a href=\""+sub+"\"style=\"text-decoration:none;\">"+sub+"</a>";
                    outputfile << ID;
                    bakfile << ID;
                    if(j<12)
                    {
                        outputfile <<" &nbsp;&nbsp;";
                        bakfile    <<" &nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile <<" &nbsp;";
                        bakfile    <<" &nbsp;";
                    }
                    iss >>sub;
                    outputfile<<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile   <<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss >>sub;
                    length=sub.length();
                    outputfile<<sub<<" ";
                    bakfile<<sub<<" ";
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss>>sub;
                    outputfile << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile    << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss>>sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile << sub <<"</FONT><br>"<<endl;
                        bakfile    << sub <<"</FONT><br>"<<endl;
                    }
                    else
                    {
                        outputfile << sub <<"<br>"<<endl;
                        bakfile    << sub <<"<br>"<<endl;
                    }

                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                bakfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                lineIss=lineArr[24];
                istringstream iss(lineIss);
                iss >> sub;
                iss >> sub;
                iss >> sub;
                unsigned pos = sub.find_first_of("-");
                string sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp<<"(i-1)";
                bakfile   <<sub_temp<<"(i-1)";
                if(10-length>0)
                    for(int j=0; j<=10-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }



                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                outputfile<<sub_temp<<"<br>"<<endl;
                bakfile   <<sub_temp<<"<br>"<<endl;
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 6 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 7<br>"<<endl;
                bakfile   <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 6 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 7<br>"<<endl;
                for(int j=27; j<30; j++)
                {
                    if(j==27)
                    {
                        outputfile<<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else if(j==28)
                    {
                        outputfile<<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile<<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    lineIss=lineArr[j];
                    istringstream iss2(lineIss);
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                    iss2 >> sub;
                    outputfile<<sub<<"<br>"<<endl;
                    bakfile<<sub<<"<br>"<<endl;
                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
            }
            inputfile.clear();
            inputfile.close();
            outputfile.clear();
            outputfile.close();
            bakfile.clear();
            bakfile.close();
        }
    }
    for(int q=0; q<2; q++)
    {
        if(q==0)
        {
            fnameIn = namefiles + "Analysis/compass_result8_match" + match + "_sort";
            fnameOut= namefiles + "Analysis/compass_result8_match" + match + "_sort_html";
        }
        else
        {
            fnameIn = namefiles + "Analysis/compass_result8_match" + match + "_sortCHI";
            fnameOut= namefiles + "Analysis/compass_result8_match" + match + "_sortCHI_html";
        }
        fnameOutBak= fnameOut + ".bak";
        inputfile.open(fnameIn.c_str(), ios::in);
        if(inputfile.is_open())
        {
            lineC=0;
            while(inputfile.good())
            {
                getline(inputfile, line);
                lineC++;
            }
            inputfile.clear();
            inputfile.close();
            lineC--;
            lineC/=31;
            inputfile.open(fnameIn.c_str(), ios::in);
            outputfile.open(fnameOut.c_str(), ios::out);
            bakfile.open(fnameOutBak.c_str(), ios::out);
            for(int i=0; i<lineC; i++)
            {
                for (int j=0; j<31; j++)
                {
                    getline(inputfile, line);
                    lineArr[j]=line;
                }
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                outputfile<<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;

                for(int j=3; j<23; j++)
                {
                    lineIss=lineArr[j];
                    if(ss==true)
                    {
                        ssCorr=false;
                        string lineCorr = lineIss;
                        istringstream issCorr(lineCorr);
                        while(issCorr>>sub)
                        {}
                        if(sub=="Yes")
                            ssCorr=true;
                    }
                    istringstream iss(lineIss);
                    iss >> sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                        bakfile    <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                    }
                    string ID ="<a href=\""+sub+"\"style=\"text-decoration:none;\">"+sub+"</a>";
                    outputfile << ID;
                    bakfile << ID;
                    if(j<12)
                    {
                        outputfile <<" &nbsp;&nbsp;";
                        bakfile    <<" &nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile <<" &nbsp;";
                        bakfile    <<" &nbsp;";
                    }
                    iss >>sub;
                    outputfile<<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile   <<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss >>sub;
                    length=sub.length();
                    outputfile<<sub<<" ";
                    bakfile<<sub<<" ";
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss>>sub;
                    outputfile << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile    << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss>>sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile << sub <<"</FONT><br>"<<endl;
                        bakfile    << sub <<"</FONT><br>"<<endl;
                    }
                    else
                    {
                        outputfile << sub <<"<br>"<<endl;
                        bakfile    << sub <<"<br>"<<endl;
                    }

                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash; &ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                outputfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                lineIss=lineArr[24];
                istringstream iss(lineIss);
                iss >> sub;
                iss >> sub;
                iss >> sub;
                unsigned pos = sub.find_first_of("-");
                string sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp<<"(i-1)";
                bakfile   <<sub_temp<<"(i-1)";
                if(10-length>0)
                    for(int j=0; j<=10-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                outputfile<<sub_temp<<"<br>"<<endl;
                bakfile   <<sub_temp<<"<br>"<<endl;
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 6 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 7 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 8<br>"<<endl;
                bakfile   <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 6 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 7 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 8<br>"<<endl;
                for(int j=27; j<30; j++)
                {
                    if(j==27)
                    {
                        outputfile<<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else if(j==28)
                    {
                        outputfile<<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile<<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    lineIss=lineArr[j];
                    istringstream iss2(lineIss);
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                    iss2 >> sub;
                    outputfile<<sub<<"<br>"<<endl;
                    bakfile<<sub<<"<br>"<<endl;
                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
            }
            inputfile.clear();
            inputfile.close();
            outputfile.clear();
            outputfile.close();
            bakfile.clear();
            bakfile.close();
        }
    }
    for(int q=0; q<2; q++)
    {
        if(q==0)
        {
            fnameIn = namefiles + "Analysis/compass_result9_match" + match + "_sort";
            fnameOut= namefiles + "Analysis/compass_result9_match" + match + "_sort_html";
        }
        else
        {
            fnameIn = namefiles + "Analysis/compass_result9_match" + match + "_sortCHI";
            fnameOut= namefiles + "Analysis/compass_result9_match" + match + "_sortCHI_html";
        }
        fnameOutBak= fnameOut + ".bak";
        inputfile.open(fnameIn.c_str(), ios::in);
        if(inputfile.is_open())
        {
            lineC=0;
            while(inputfile.good())
            {
                getline(inputfile, line);
                lineC++;
            }
            inputfile.clear();
            inputfile.close();
            lineC--;
            lineC/=31;
            inputfile.open(fnameIn.c_str(), ios::in);
            outputfile.open(fnameOut.c_str(), ios::out);
            bakfile.open(fnameOutBak.c_str(), ios::out);
            for(int i=0; i<lineC; i++)
            {
                for (int j=0; j<31; j++)
                {
                    getline(inputfile, line);
                    lineArr[j]=line;
                }
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                outputfile<<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;

                for(int j=3; j<23; j++)
                {
                    lineIss=lineArr[j];
                    if(ss==true)
                    {
                        ssCorr=false;
                        string lineCorr = lineIss;
                        istringstream issCorr(lineCorr);
                        while(issCorr>>sub)
                        {}
                        if(sub=="Yes")
                            ssCorr=true;
                    }
                    istringstream iss(lineIss);
                    iss >> sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                        bakfile    <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                    }
                    string ID ="<a href=\""+sub+"\"style=\"text-decoration:none;\">"+sub+"</a>";
                    outputfile << ID;
                    bakfile << ID;
                    if(j<12)
                    {
                        outputfile <<" &nbsp;&nbsp;";
                        bakfile    <<" &nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile <<" &nbsp;";
                        bakfile    <<" &nbsp;";
                    }
                    iss >>sub;
                    outputfile<<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile   <<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss >>sub;
                    length=sub.length();
                    outputfile<<sub<<" ";
                    bakfile<<sub<<" ";
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss>>sub;
                    outputfile << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile    << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss>>sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile << sub <<"</FONT><br>"<<endl;
                        bakfile    << sub <<"</FONT><br>"<<endl;
                    }
                    else
                    {
                        outputfile << sub <<"<br>"<<endl;
                        bakfile    << sub <<"<br>"<<endl;
                    }

                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;

                outputfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                bakfile<<"Peak name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                lineIss=lineArr[24];
                istringstream iss(lineIss);
                iss >> sub;
                iss >> sub;
                iss >> sub;
                unsigned pos = sub.find_first_of("-");
                string sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp<<"(i-1)";
                bakfile   <<sub_temp<<"(i-1)";
                if(10-length>0)
                    for(int j=0; j<=10-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(15-length>0)
                    for(int j=0; j<=15-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }


                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                outputfile<<sub_temp<<"<br>"<<endl;
                bakfile   <<sub_temp<<"<br>"<<endl;
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 6 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 7 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 8 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 9<br>"<<endl;
                bakfile   <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 6 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 7 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 8 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 9<br>"<<endl;
                for(int j=27; j<30; j++)
                {
                    if(j==27)
                    {
                        outputfile<<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&alpha; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else if(j==28)
                    {
                        outputfile<<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&beta; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile<<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>CO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    }
                    lineIss=lineArr[j];
                    istringstream iss2(lineIss);
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<16-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                    iss2 >> sub;
                    outputfile<<sub<<"<br>"<<endl;
                    bakfile<<sub<<"<br>"<<endl;
                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
            }
            inputfile.clear();
            inputfile.close();
            outputfile.clear();
            outputfile.close();
            bakfile.clear();
            bakfile.close();
        }
    }
    for(int q=0; q<2; q++)
    {
        if(q==0)
        {
            fnameIn = namefiles + "Analysis/compass_result10_match" + match + "_sort";
            fnameOut= namefiles + "Analysis/compass_result10_match" + match + "_sort_html";
        }
        else
        {
            fnameIn = namefiles + "Analysis/compass_result10_match" + match + "_sortCHI";
            fnameOut= namefiles + "Analysis/compass_result10_match" + match + "_sortCHI_html";
        }
        fnameOutBak= fnameOut + ".bak";
        inputfile.open(fnameIn.c_str(), ios::in);
        if(inputfile.is_open())
        {
            lineC=0;
            while(inputfile.good())
            {
                getline(inputfile, line);
                lineC++;
            }
            inputfile.clear();
            inputfile.close();
            lineC--;
            lineC/=31;
            inputfile.open(fnameIn.c_str(), ios::in);
            outputfile.open(fnameOut.c_str(), ios::out);
            bakfile.open(fnameOutBak.c_str(), ios::out);
            for(int i=0; i<lineC; i++)
            {
                for (int j=0; j<31; j++)
                {
                    getline(inputfile, line);
                    lineArr[j]=line;
                }
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                outputfile<<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                outputfile<<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;
                bakfile   <<"Index &nbsp;&nbsp;&nbsp;Residue type &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SSE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&chi;<sup>2</sup><br>"<<endl;
                bakfile   <<"***** &nbsp;&nbsp;&nbsp;************ &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;********** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*** &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**<br>"<<endl;

                for(int j=3; j<23; j++)
                {
                    lineIss=lineArr[j];
                    if(ss==true)
                    {
                        ssCorr=false;
                        string lineCorr = lineIss;
                        istringstream issCorr(lineCorr);
                        while(issCorr>>sub)
                        {}
                        if(sub=="Yes")
                            ssCorr=true;
                    }
                    istringstream iss(lineIss);
                    iss >> sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                        bakfile    <<"<FONT style=\"BACKGROUND-COLOR: #E3F6CE\">";
                    }
                    string ID ="<a href=\""+sub+"\"style=\"text-decoration:none;\">"+sub+"</a>";
                    outputfile << ID;
                    bakfile << ID;
                    if(j<12)
                    {
                        outputfile <<" &nbsp;&nbsp;";
                        bakfile    <<" &nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile <<" &nbsp;";
                        bakfile    <<" &nbsp;";
                    }
                    iss >>sub;
                    outputfile<<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile   <<sub<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss >>sub;
                    length=sub.length();
                    outputfile<<sub<<" ";
                    bakfile<<sub<<" ";
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss>>sub;
                    outputfile << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    bakfile    << sub <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                    iss>>sub;
                    if(ss==true && ssCorr==true)
                    {
                        outputfile << sub <<"</FONT><br>"<<endl;
                        bakfile    << sub <<"</FONT><br>"<<endl;
                    }
                    else
                    {
                        outputfile << sub <<"<br>"<<endl;
                        bakfile    << sub <<"<br>"<<endl;
                    }

                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                bakfile<<"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"<<endl;
                lineIss=lineArr[24];
                istringstream iss(lineIss);
                iss >> sub;
                iss >> sub;
                iss >> sub;
                unsigned pos = sub.find_first_of("-");
                string sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp<<"(i-1)";
                bakfile   <<sub_temp<<"(i-1)";
                if(9-length>0)
                    for(int j=0; j<=9-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(14-length>0)
                    for(int j=0; j<=14-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(14-length>0)
                    for(int j=0; j<=14-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(14-length>0)
                    for(int j=0; j<=14-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(14-length>0)
                    for(int j=0; j<=14-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(14-length>0)
                    for(int j=0; j<=14-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(14-length>0)
                    for(int j=0; j<=14-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(14-length>0)
                    for(int j=0; j<=14-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                length = sub_temp.length();
                outputfile<<sub_temp;
                bakfile   <<sub_temp;
                if(14-length>0)
                    for(int j=0; j<=14-length; j++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }


                iss >> sub;
                iss >> sub;
                pos = sub.find_first_of("-");
                sub_temp = sub.substr(0,pos-1) + "N-HN";
                outputfile<<sub_temp<<"<br>"<<endl;
                bakfile   <<sub_temp<<"<br>"<<endl;
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                outputfile<<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 6 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 7 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 8 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 9 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 10<br>"<<endl;
                bakfile   <<" &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 2 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 5 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 6 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 7 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 8 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 9 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Residue 10<br>"<<endl;
                for(int j=27; j<30; j++)
                {
                    if(j==27)
                    {
                        outputfile<<"<sup>13</sup>C&alpha; &nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&alpha; &nbsp;&nbsp;";
                    }
                    else if(j==28)
                    {
                        outputfile<<"<sup>13</sup>C&beta; &nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>C&beta; &nbsp;&nbsp;";
                    }
                    else
                    {
                        outputfile<<"<sup>13</sup>CO &nbsp;&nbsp;";
                        bakfile   <<"<sup>13</sup>CO &nbsp;&nbsp;";
                    }
                    lineIss=lineArr[j];
                    istringstream iss2(lineIss);
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }
                    iss2 >> sub;
                    length=sub.length();
                    outputfile<<sub;
                    bakfile   <<sub;
                    for(int k=0; k<15-length; k++)
                    {
                        outputfile<<"&nbsp;";
                        bakfile   <<"&nbsp;";
                    }

                    iss2 >> sub;
                    outputfile<<sub<<"<br>"<<endl;
                    bakfile<<sub<<"<br>"<<endl;
                }
                outputfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
                bakfile<<"&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;&ndash;<br>"<<endl;
            }
            inputfile.clear();
            inputfile.close();
            outputfile.clear();
            outputfile.close();
            bakfile.clear();
            bakfile.close();
        }
    }
}

