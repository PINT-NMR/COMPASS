#ifndef CAEXAMPLE_H
#define CAEXAMPLE_H

#include <QDialog>

namespace Ui
{
	class CaExample;
}

class CaExample : public QDialog
{
	Q_OBJECT

public:
    explicit CaExample(QDialog *parent = 0);
	~CaExample();

private:
	Ui::CaExample *ui;

private slots:
	void on_closecaButton_clicked();
};

#endif
