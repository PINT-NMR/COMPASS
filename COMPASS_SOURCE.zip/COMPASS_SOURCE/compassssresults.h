#ifndef COMPASSSSRESULTS_H
#define COMPASSSSRESULTS_H

#include <QMainWindow>
namespace Ui
{
	class CompassSSResults;
}

class CompassSSResults : public QMainWindow
{
	Q_OBJECT

public:
	CompassSSResults(QWidget *parent = 0);
	~CompassSSResults();

protected:
	void changeEvent(QEvent *e);

private:
	Ui::CompassSSResults *ui;

private slots:
	void read_file();
    void on_closeButton_clicked();

};

#endif
