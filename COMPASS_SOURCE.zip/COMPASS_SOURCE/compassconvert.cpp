#include "compassconvert.h"
#include "ui_compassconvert.h"
#include "QRect"
#include "QDesktopWidget"
#include "compassvec.h"
#include <QtWidgets>
#include "globals.h"
#include "qfiledialog.h"
#include <algorithm>
#include "compassfunctions.h"

CompassConvert::CompassConvert(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CompassConvert)
{
    ui->setupUi(this);
    int index = ui->filetypeBox->findText("3D NMR data");
    handleIndex(index);
    connect(ui->mixedcaseButton, SIGNAL(clicked(bool)), this, SLOT(toggleMixed()));
    connect(ui->uppercaseButton, SIGNAL(clicked(bool)), this, SLOT(toggleUpper()));
    connect(ui->threeletterButton, SIGNAL(clicked(bool)), this, SLOT(toggleThree()));
    connect(ui->oneletterButton, SIGNAL(clicked(bool)), this, SLOT(toggleOne()));
    connect(ui->filetypeBox, SIGNAL(currentIndexChanged(int)), this,SLOT(handleIndex(int)));
    connect(ui->unassignBox, SIGNAL(stateChanged(int)), this,SLOT(handleState(int)));
    connect(ui->format2dBox, SIGNAL(stateChanged(int)), this,SLOT(handleState2d(int)));
    connect(ui->format3dBox, SIGNAL(stateChanged(int)), this,SLOT(handleState3d(int)));
    connect(ui->mixedcaseButton, SIGNAL(clicked(bool)), this,SLOT(formatSeq2(bool)));
    connect(ui->oneletterButton, SIGNAL(clicked(bool)), this,SLOT(formatSeq2(bool)));
    connect(ui->uppercaseButton, SIGNAL(clicked(bool)), this,SLOT(formatSeq2(bool)));
    connect(ui->threeletterButton, SIGNAL(clicked(bool)), this,SLOT(formatSeq2(bool)));
    connect(ui->fromcustomButton, SIGNAL(clicked(bool)), this,SLOT(toggleCustom()));
    connect(ui->fromcompassButton, SIGNAL(clicked(bool)), this,SLOT(toggleCompass()));
    connect(ui->fromcustomButton, SIGNAL(clicked(bool)), this,SLOT(handleConv(bool)));
    connect(ui->fromcompassButton, SIGNAL(clicked(bool)), this,SLOT(handleConv(bool)));
    connect(ui->whitespaceBox, SIGNAL(stateChanged(int)), this,SLOT(formatSeq(int)));
    connect(ui->vol2dBox, SIGNAL(stateChanged(int)), this,SLOT(toggleVol2d(int)));
    connect(ui->vol3dBox, SIGNAL(stateChanged(int)), this,SLOT(toggleVol3d(int)));
    connect(ui->uppercaseBox, SIGNAL(stateChanged(int)), this,SLOT(formatPeak(int)));
    connect(ui->nEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    connect(ui->cEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    connect(ui->hEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    connect(ui->alphaEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    connect(ui->betaEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    connect(ui->carbonylEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    connect(ui->norderBox, SIGNAL(valueChanged(int)), this,SLOT(handleFormat2(int)));
    connect(ui->horderBox, SIGNAL(valueChanged(int)), this,SLOT(handleFormat2(int)));
    connect(ui->corderBox, SIGNAL(valueChanged(int)), this,SLOT(handleFormat2(int)));
}

void CompassConvert::toggleMixed()
{
    ui->uppercaseButton->setChecked(!ui->mixedcaseButton->isChecked());
}
void CompassConvert::toggleUpper()
{
    ui->mixedcaseButton->setChecked(!ui->uppercaseButton->isChecked());
}
void CompassConvert::toggleOne()
{
    ui->threeletterButton->setChecked(!ui->oneletterButton->isChecked());
}
void CompassConvert::toggleThree()
{
    ui->oneletterButton->setChecked(!ui->threeletterButton->isChecked());
}

void CompassConvert::disconnectAll()
{
    disconnect(ui->filetypeBox, SIGNAL(currentIndexChanged(int)), this,SLOT(handleIndex(int)));
    disconnect(ui->unassignBox, SIGNAL(stateChanged(int)), this,SLOT(handleState(int)));
    disconnect(ui->format2dBox, SIGNAL(stateChanged(int)), this,SLOT(handleState2d(int)));
    disconnect(ui->format3dBox, SIGNAL(stateChanged(int)), this,SLOT(handleState3d(int)));
    disconnect(ui->mixedcaseButton, SIGNAL(clicked(bool)), this,SLOT(formatSeq2(bool)));
    disconnect(ui->oneletterButton, SIGNAL(clicked(bool)), this,SLOT(formatSeq2(bool)));
    disconnect(ui->uppercaseButton, SIGNAL(clicked(bool)), this,SLOT(formatSeq2(bool)));
    disconnect(ui->threeletterButton, SIGNAL(clicked(bool)), this,SLOT(formatSeq2(bool)));
    disconnect(ui->fromcustomButton, SIGNAL(clicked(bool)), this,SLOT(handleConv(bool)));
    disconnect(ui->fromcompassButton, SIGNAL(clicked(bool)), this,SLOT(handleConv(bool)));
    disconnect(ui->whitespaceBox, SIGNAL(stateChanged(int)), this,SLOT(formatSeq(int)));
    disconnect(ui->vol2dBox, SIGNAL(stateChanged(int)), this,SLOT(toggleVol2d(int)));
    disconnect(ui->vol3dBox, SIGNAL(stateChanged(int)), this,SLOT(toggleVol3d(int)));
    disconnect(ui->uppercaseBox, SIGNAL(stateChanged(int)), this,SLOT(formatPeak(int)));
    disconnect(ui->nEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    disconnect(ui->cEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    disconnect(ui->hEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    disconnect(ui->alphaEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    disconnect(ui->betaEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    disconnect(ui->carbonylEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    disconnect(ui->norderBox, SIGNAL(valueChanged(int)), this,SLOT(handleFormat2(int)));
    disconnect(ui->horderBox, SIGNAL(valueChanged(int)), this,SLOT(handleFormat2(int)));
    disconnect(ui->corderBox, SIGNAL(valueChanged(int)), this,SLOT(handleFormat2(int)));
}

void CompassConvert::connectAll()
{
    connect(ui->filetypeBox, SIGNAL(currentIndexChanged(int)), this,SLOT(handleIndex(int)));
    connect(ui->unassignBox, SIGNAL(stateChanged(int)), this,SLOT(handleState(int)));
    connect(ui->format2dBox, SIGNAL(stateChanged(int)), this,SLOT(handleState2d(int)));
    connect(ui->format3dBox, SIGNAL(stateChanged(int)), this,SLOT(handleState3d(int)));
    connect(ui->mixedcaseButton, SIGNAL(clicked(bool)), this,SLOT(formatSeq2(bool)));
    connect(ui->oneletterButton, SIGNAL(clicked(bool)), this,SLOT(formatSeq2(bool)));
    connect(ui->uppercaseButton, SIGNAL(clicked(bool)), this,SLOT(formatSeq2(bool)));
    connect(ui->threeletterButton, SIGNAL(clicked(bool)), this,SLOT(formatSeq2(bool)));
    connect(ui->fromcustomButton, SIGNAL(clicked(bool)), this,SLOT(handleConv(bool)));
    connect(ui->fromcompassButton, SIGNAL(clicked(bool)), this,SLOT(handleConv(bool)));
    connect(ui->whitespaceBox, SIGNAL(stateChanged(int)), this,SLOT(formatSeq(int)));
    connect(ui->vol2dBox, SIGNAL(stateChanged(int)), this,SLOT(toggleVol2d(int)));
    connect(ui->vol3dBox, SIGNAL(stateChanged(int)), this,SLOT(toggleVol3d(int)));
    connect(ui->uppercaseBox, SIGNAL(stateChanged(int)), this,SLOT(formatPeak(int)));
    connect(ui->nEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    connect(ui->cEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    connect(ui->hEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    connect(ui->alphaEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    connect(ui->betaEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    connect(ui->carbonylEdit, SIGNAL(textChanged(QString)), this,SLOT(handleFormat(QString)));
    connect(ui->norderBox, SIGNAL(valueChanged(int)), this,SLOT(handleFormat2(int)));
    connect(ui->horderBox, SIGNAL(valueChanged(int)), this,SLOT(handleFormat2(int)));
    connect(ui->corderBox, SIGNAL(valueChanged(int)), this,SLOT(handleFormat2(int)));
}

CompassConvert::~CompassConvert()
{
    delete ui;
}

bool CompassConvert::alphaCheck(QString word)
{
    std::string w = word.toUtf8().data();
    for (unsigned int i=0; i<w.length(); i++)
        if(!isalpha(w[i]))
            return false;
    return true;
}

QString CompassConvert::fileCheck()
{
    int ncol, hcol, pcol, vcol, header, ccol, nl, cal, cbl, coL, hl;
    QString n, c, h, a, b, o, ca, cb, co;
    int nO, cO, hO, cmax;
    ncol= hcol= pcol= vcol= header= ccol= nl= cal= cbl= coL= hl =nO= cO= hO= cmax=0;
    if(ui->filetypeBox->currentIndex()==0 || ui->filetypeBox->currentIndex()==1)
    {
        if(!alphaCheck(ui->nEdit->text()))
            return "<sup>15</sup>N denotation contains non-alphabetic characters. Aborting.";
        if(!alphaCheck(ui->hEdit->text()))
            return "<sup>1</sup>H denotation contains non-alphabetic characters. Aborting.";
        if(ui->filetypeBox->currentIndex()==0)
        {
            if(!alphaCheck(ui->cEdit->text()))
                return "<sup>13</sup>C denotation contains non-alphabetic characters. Aborting.";
            if(!alphaCheck(ui->alphaEdit->text()))
                return "Alpha denotation contains non-alphabetic characters. Aborting.";
            if(!alphaCheck(ui->betaEdit->text()))
                return "Beta denotation contains non-alphabetic characters. Aborting.";
            if(!alphaCheck(ui->carbonylEdit->text()))
                return "Carbonyl denotation contains non-alphabetic characters. Aborting.";
        }
    }
    if(ui->fromcustomButton->isChecked())
    {

        n= ui->nEdit->text();
        h= ui->hEdit->text();
        nO= ui->norderBox->value();
        hO= ui->horderBox->value();
        nl=n.length();
        hl=h.length();
        if(ui->filetypeBox->currentIndex()==0)
        {
            a= ui->alphaEdit->text();
            b= ui->betaEdit->text();
            o= ui->carbonylEdit->text();
            c= ui->cEdit->text();
            cO= ui->corderBox->value();
            ca= c+a;
            cb= c+b;
            co= c+o;
            ca.length() > cb.length() ? cmax=ca.length() : cmax=cb.length();
            cmax > co.length() ? NULL : cmax = co.length();
            cal=ca.length();
            cbl=cb.length();
            coL=co.length();
            if(cO!=3)
            {
                ca+="-";
                cb+="-";
                co+="-";
            }
        }
        if((nO!=3 && ui->filetypeBox->currentIndex()==0) || (nO!=2 && ui->filetypeBox->currentIndex()==1))
            n+="-";
        if ((hO!=3 && ui->filetypeBox->currentIndex()==0) || (hO!=2 && ui->filetypeBox->currentIndex()==1))
            h+="-";
    }
    if(ui->filetypeBox->currentIndex()==0) //3d
    {
        ncol=ui->ncol3dBox->value();
        hcol=ui->hcol3dBox->value();
        pcol=ui->peakcol3dBox->value();
        if(ui->vol3dBox->isChecked())
            vcol=ui->volcol3dBox->value();
        else
            vcol =0;
        if(ui->fromcompassButton->isChecked())
        {
            header=2;
            vcol = 0;
        }
        else
        {
            header=ui->row3dEdit->value();
        }
        ccol=ui->ccol3dBox->value();
    }
    else //2d
    {
        ncol=ui->ncol2dBox->value();
        hcol=ui->hcol2dBox->value();
        pcol=ui->peakcol2dBox->value();
        if(ui->vol2dBox->isChecked())
            vcol=ui->volcol2dBox->value();
        else
            vcol=0;
        if(ui->fromcompassButton->isChecked())
            header=2;
        else
            header=ui->row2dEdit->value();
        ccol=0;
    }
    int col = max(ncol, hcol);
    col = max(col, pcol);
    col = max(col, ccol);
    col = max(col, vcol);
    QString fname = ui->fileLine->text();
    {
        QFile qf(fname);
        if(!qf.exists())
            return "The input file does not exist. Aborting.";
    }
    std::string fname2 = fname.toUtf8().data();
    std::ifstream file;
    int iC=0;
    file.open(fname2.c_str(), std::ios::in);
    std::string line;
    while(getline(file, line))
    {
        std::string line_temp = line;
        iC++;
        std::istringstream iss(line_temp);
        std::string sub;
        int sC=0;
        while(iss >> sub)
        {
            sC++;
            if(iC>header && (sC==ncol || sC==ccol || sC==hcol || sC==vcol))
            {
                for(unsigned int i=0; i<sub.length(); i++)
                {
                    if(!isdigit(sub[i]) && sub[i]!='.')
                    {
                        file.clear();
                        file.close();
                        QString ret = QString::fromUtf8(sub.c_str());
                        ret+=" is not a valid ";
                        if(sC==ncol)
                            ret+="nitrogen chemical shift. Aborting.";
                        else if (sC==ccol)
                            ret+="carbon chemical shift. Aborting.";
                        else if (sC==hcol)
                            ret+="hydrogen chemical shift. Aborting.";
                        else
                            ret+="format for peak intensity. Aborting.";
                        return ret;
                    }
                }
            }
            else if(pcol==sC && iC>header)
            {
                int hypC=0;
                for(unsigned int i=0; i<sub.length(); i++)
                {
                    if((!isalpha(sub[i]) && sub[i]!='-' && !isdigit(sub[i])) && ui->fromcompassButton->isChecked())
                    {
                        file.clear();
                        file.close();
                        QString ret = QString::fromUtf8(sub.c_str());
                        ret+=" is not a valid COMPASS peak format. Aborting.";
                        return ret;
                    }
                    if(sub[i]=='-')
                        hypC++;
                }
                if(hypC!=2 && ui->filetypeBox->currentIndex()==0) //3D
                {
                    file.clear();
                    file.close();
                    QString ret = QString::fromUtf8(sub.c_str());
                    ret+=" is not a valid 3D NMR data format. Aborting.";
                    return ret;
                }
                else if(hypC!=1 && ui->filetypeBox->currentIndex()==1)
                {
                    file.clear();
                    file.close();
                    QString ret = QString::fromUtf8(sub.c_str());
                    ret+=" is not a valid 2D NMR data format. Aborting.";
                    return ret;
                }
                if(ui->fromcustomButton->isChecked())
                {
                    if(ui->filetypeBox->currentIndex()==0) //3D
                    {
                        unsigned int pos = sub.find_first_of("-");
                        if((nO==1 && pos-nl<1) || (hO==1 && pos-hl < 1) || (cO==1 && pos-cmax<1))
                        {
                            file.clear();
                            file.close();
                            QString ret = QString::fromUtf8(sub.c_str());
                            ret+=" is not labeled correctly. Aborting.";
                            return ret;
                        }
                        else if(nO==1 && sub.substr(pos-nl, nl+1) != n.toUtf8().data())
                        {
                            file.clear();
                            file.close();
                            QString ret = QString::fromUtf8(sub.c_str());
                            ret+=" does not match the submitted custom format. Aborting.";
                            return ret;
                        }
                        else if(hO==1 && sub.substr(pos-hl, hl+1)!=h.toUtf8().data())
                        {
                            file.clear();
                            file.close();
                            QString ret = QString::fromUtf8(sub.c_str());
                            ret+=" does not match the submitted custom format. Aborting.";
                            return ret;
                        }
                        else if(cO==1 && sub.substr(pos-cal, cal+1)!=ca.toUtf8().data() && sub.substr(pos-cbl, cbl+1)!=cb.toUtf8().data() && sub.substr(pos-coL, coL+1)!=co.toUtf8().data())
                        {
                            file.clear();
                            file.close();
                            QString ret = QString::fromUtf8(sub.c_str());
                            ret+=" does not match the submitted custom format. Aborting.";
                            return ret;
                        }
                        pos = sub.find_last_of("-");
                        if(nO==1 && pos-nl<1)
                        {
                             file.clear();
                             file.close();
                             QString ret = QString::fromUtf8(sub.c_str());
                             ret+=" is not labeled correctly. Aborting.";
                             return ret;
                        }
                        else if(nO==2 && sub.substr(pos-nl, nl+1)!=n.toUtf8().data())
                        {
                             file.clear();
                             file.close();
                             QString ret = QString::fromUtf8(sub.c_str());
                             ret+=" does not match the submitted custom format. Aborting.";
                             return ret;
                        }
                        else if(hO==2 && sub.substr(pos-hl, hl+1)!=h.toUtf8().data())
                        {
                            file.clear();
                            file.close();
                            QString ret = QString::fromUtf8(sub.c_str());
                            ret+=" does not match the submitted custom format. Aborting.";
                            return ret;
                        }
                        else if(cO==2 && sub.substr(pos-cal, cal+1)!=ca.toUtf8().data() && sub.substr(pos-cbl, cbl+1)!=cb.toUtf8().data() && sub.substr(pos-coL, coL+1)!=co.toUtf8().data())
                        {
                            file.clear();
                            file.close();
                            QString ret = QString::fromUtf8(sub.c_str());
                            ret+=" does not match the submitted custom format. Aborting.";
                            return ret;
                        }
                        if(nO==3)
                        {
                            int l = sub.length();
                            if(sub.substr(l-nl, nl+1)!=n.toUtf8().data())
                            {
                                file.clear();
                                file.close();
                                QString ret = QString::fromUtf8(sub.c_str());
                                ret+=" does not match the submitted custom format. Aborting.";
                                return ret;
                            }
                        }
                        else if(hO==3)
                        {
                            int l = sub.length();
                            if(sub.substr(l-hl, hl+1)!=h.toUtf8().data())
                            {
                                file.clear();
                                file.close();
                                QString ret = QString::fromUtf8(sub.c_str());
                                ret+=" does not match the submitted custom format. Aborting.";
                                return ret;
                            }
                        }
                        else
                        {
                            int l = sub.length();
                            if(sub.substr(l-cal, cal+1)!=ca.toUtf8().data() && sub.substr(l-cbl, cbl+1)!=cb.toUtf8().data() && sub.substr(l-coL, coL+1)!=co.toUtf8().data())
                            {
                                file.clear();
                                file.close();
                                QString ret = QString::fromUtf8(sub.c_str());
                                ret+=" does not match the submitted custom format. Aborting.";
                                return ret;
                            }
                        }
                    }
                    else
                    {
                        unsigned pos = sub.find_first_of("-");
                        if((nO==1 && pos-nl<1) || (hO==1 && pos-hl<1))
                        {
                            file.clear();
                            file.close();
                            QString ret = QString::fromUtf8(sub.c_str());
                            ret+=" is not labeled correctly. Aborting.";
                            return ret;
                        }
                        else if(nO==1 && sub.substr(pos-nl, nl+1)!=n.toUtf8().data())
                        {
                            file.clear();
                            file.close();
                            QString ret = QString::fromUtf8(sub.c_str());
                            ret+=" does not match the submitted custom format. Aborting.";
                            return ret;
                        }
                        else if(hO==1 && sub.substr(pos-hl, hl+1)!=h.toUtf8().data())
                        {
                            file.clear();
                            file.close();
                            QString ret = QString::fromUtf8(sub.c_str());
                            ret+=" does not match the submitted custom format. Aborting.";
                            return ret;
                        }
                        if(nO==2)
                        {
                            int l = sub.length();
                            if(sub.substr(l-nl, nl)!=n.toUtf8().data())
                            {
                                file.clear();
                                file.close();
                                QString ret = QString::fromUtf8(sub.c_str());
                                ret+=" does not match the submitted custom format. Aborting.";
                                return ret;
                            }
                        }
                        else if(hO==2)
                        {
                            int l = sub.length();
                            if(sub.substr(l-hl, hl)!=h.toUtf8().data())
                            {
                                file.clear();
                                file.close();
                                QString ret = QString::fromUtf8(sub.c_str());
                                ret+=" does not match the submitted custom format. Aborting.";
                                return ret;
                            }
                        }
                    }
                }
            }
        }
        if(iC>header && col>sC)
        {
            file.clear();
            file.close();
            QString ret = "Too few columns in a non-header line. Aborting.\nThe line number causing the error is ";
            ret+=QString::number(iC);
            return ret;
        }
        else if(iC>header && col<sC)
        {
            file.clear();
            file.close();
            QString ret = "Too many columns in a non-header line. Aborting.\nThe line number causing the error is ";
            ret+=QString::number(iC);
            return ret;
        }
    }
    file.clear();
    file.close();
    if(iC<=header)
        return "The number of header lines exceeds available lines in the input file.\nAborting.";
    if(iC==0)
        return "The input file is empty. Aborting.";

    return "";
}
void CompassConvert::convertOSui()
{
    ui->label2d->setDisabled(true);
    ui->label2d_2->setDisabled(true);
    ui->label2d_3->setDisabled(true);
    ui->label2d_4->setDisabled(true);
    ui->label2d_5->setDisabled(true);
    ui->label2d_6->setDisabled(true);
    ui->label2d_8->setDisabled(true);
    ui->ncol2dBox->setDisabled(true);
    ui->vol2dBox->setDisabled(true);
    ui->volcol2dBox->setDisabled(true);
    ui->hcol2dBox->setDisabled(true);
    ui->peakcol2dBox->setDisabled(true);
    ui->format2dBox->setDisabled(true);
    ui->row2dEdit->setDisabled(true);

    ui->label3d->setDisabled(true);
    ui->label3d_2->setDisabled(true);
    ui->label3d_3->setDisabled(true);
    ui->label3d_4->setDisabled(true);
    ui->label3d_5->setDisabled(true);
    ui->label3d_6->setDisabled(true);
    ui->label3d_7->setDisabled(true);
    ui->label3d_8->setDisabled(true);
    ui->volcol3dBox->setDisabled(true);
    ui->vol3dBox->setDisabled(true);
    ui->ncol3dBox->setDisabled(true);
    ui->ccol3dBox->setDisabled(true);
    ui->hcol3dBox->setDisabled(true);
    ui->peakcol3dBox->setDisabled(true);
    ui->format3dBox->setDisabled(true);
    ui->row3dEdit->setDisabled(true);

    ui->labelseq_5->setDisabled(true);
    ui->rowseqEdit->setDisabled(true);
    ui->labelseq->setDisabled(true);
    ui->labelseq_2->setDisabled(true);
    ui->labelseq_3->setDisabled(true);
    ui->labelseq_4->setDisabled(true);
    ui->mixedcaseButton->setDisabled(true);
    ui->uppercaseButton->setDisabled(true);
    ui->whitespaceBox->setDisabled(true);
    ui->threeletterButton->setDisabled(true);
    ui->oneletterButton->setDisabled(true);

    ui->labelp->setDisabled(true);
    ui->labelp_2->setDisabled(true);
    ui->labelp_3->setDisabled(true);
    ui->labelp_4->setDisabled(true);
    ui->labelp_5->setDisabled(true);
    ui->labelp_6->setDisabled(true);
    ui->labelp_7->setDisabled(true);
    ui->labelp_8->setDisabled(true);
    ui->labelp_9->setDisabled(true);
    ui->labelp_10->setDisabled(true);
    ui->labelp_11->setDisabled(true);
    ui->labelp_12->setDisabled(true);
    ui->labelp_13->setDisabled(true);
    ui->labelp_14->setDisabled(true);
    ui->labelp_15->setDisabled(true);
    ui->nEdit->setDisabled(true);
    ui->cEdit->setDisabled(true);
    ui->hEdit->setDisabled(true);
    ui->alphaEdit->setDisabled(true);
    ui->betaEdit->setDisabled(true);
    ui->carbonylEdit->setDisabled(true);
    ui->norderBox->setDisabled(true);
    ui->corderBox->setDisabled(true);
    ui->horderBox->setDisabled(true);
    ui->unassignBox->setDisabled(true);
    ui->uppercaseBox->setDisabled(true);
}
void CompassConvert::convertOS()
{
    QString fnam = ui->fileLine->text();
    QByteArray qByte = fnam.toUtf8();
    std::string fname = qByte.data();
    std::string outname =fname +".compass";
    std::ofstream fileO;
    std::ifstream file;
    file.open(fname.c_str(), std::ios::in);
    fileO.open(outname.c_str(), std::ios::out);
    bool first = true;
    std::string line;
    while(getline(file, line))
    {
        if(!first)
            fileO<<"\n";
        std::istringstream iss(line);
        std::string sub;
        iss>>sub;
        fileO<<sub;
        while(iss>>sub)
        {
            fileO<<"\t"<<sub;
        }
        first = false;
    }
    file.clear();
    file.close();
    fileO.clear();
    fileO.close();
}
void CompassConvert::on_convButton_clicked()
{
    bool exist1=false, exist2=false;
    QString qfolder = ui->folderLine->text();
    exist1=QDir(qfolder).exists();
    QString fnam = ui->fileLine->text();
    QByteArray qByte = fnam.toUtf8();
    std::string fname = qByte.data();
    std::ifstream file;
    file.open(fname.c_str(), std::ios::in);
    if(!file.is_open())
        exist2=false;
    else
    {
        exist2=true;
        file.clear();
        file.close();
    }
    if(ui->folderLine->text()=="" || ui->fileLine->text()=="" || exist1==false || exist2==false)
    {
        extern QString cerror;
        cerror="Error";
        ConvertError winCerror;
        winCerror.setWindowModality(Qt::ApplicationModal);
        if(winCerror.exec())
            cerror="Error";
    }
    else if(ui->filetypeBox->currentText()=="2D NMR data")
    {
        if(ui->fromcustomButton->isChecked())
            convert2dtoCompass();
        else
            convert2dtoCustom();
    }
    else if(ui->filetypeBox->currentText()=="3D NMR data")
    {
        if(ui->fromcustomButton->isChecked())
            convert3dtoCompass();
        else
            convert3dtoCustom();
    }
    else if(ui->filetypeBox->currentText()=="Data from another OS")
    {
        convertOS();
    }
    else
    {
        if(ui->fromcustomButton->isChecked())
            convertseqtoCompass();
        else
            convertseqtoCustom();
    }
    extern QString cerror;
    if (cerror=="")
    {
        ConvertComplete winComp;
        winComp.setWindowModality(Qt::ApplicationModal);
        if(winComp.exec())
            return;
    }

}

void CompassConvert::on_menuButton_clicked()
{
    emit goToMain();
}

void CompassConvert::on_helpButton_clicked()
{
    CompassHelp3 winHelp3;
    winHelp3.setWindowModality(Qt::ApplicationModal);
    if(winHelp3.exec())
        return;
}
void CompassConvert::on_fileButton_clicked()
{
    QString path;
    path = QFileDialog::getOpenFileName(
    this,
    "Choose a file to convert",
    QString::null,
    QString::null);
    if(path!="")
    {
        ui->fileLine->setText(convSlash(path));
    }
    if(ui->folderLine->text()=="")
    {
        QString w = convSlash(path);
        std::string pathC = w.toUtf8().data();
        unsigned pos = pathC.find_last_of("/");
        std::string sub = pathC.substr(0,pos+1);
        path = QString::fromUtf8(sub.c_str());
        ui->folderLine->setText(path);
    }
}
void CompassConvert::on_folderButton_clicked()
{
    QString path;
    QFileDialog dialog(this);
    dialog.setFileMode(QFileDialog::Directory);
    path = QFileDialog::getExistingDirectory(
    this,
    "Choose a directory",
    QString::null, QFileDialog::ShowDirsOnly);
    if(path.isNull() == false)
    {
        path=convSlash(path);
        path+="/";
        ui->folderLine->setText(path);
    }

}
void CompassConvert::toggleCustom()
{
    ui->fromcompassButton->setChecked(!ui->fromcustomButton->isChecked());
}
void CompassConvert::toggleCompass()
{
    ui->fromcustomButton->setChecked(!ui->fromcompassButton->isChecked());
}

void CompassConvert::handleConv(bool state)
{
    disconnectAll();
    if(state==false)
    {}
    if(ui->fromcompassButton->isChecked() && ui->filetypeBox->currentText()=="2D NMR data")
    {
        ui->unassignBox->setChecked(false);
        ui->label2d_8->setDisabled(true);
        ui->volcol2dBox->setDisabled(true);
        ui->vol2dBox->setDisabled(true);
        ui->format2dBox->setEnabled(true);
        ui->unassignBox->setEnabled(true);
    }
    else if(ui->fromcompassButton->isChecked() && ui->filetypeBox->currentText()=="3D NMR data")
    {
        ui->unassignBox->setChecked(false);
        ui->label3d_7->setDisabled(true);
        ui->volcol3dBox->setDisabled(true);
        ui->vol3dBox->setDisabled(true);
        ui->format3dBox->setEnabled(true);
        ui->unassignBox->setEnabled(true);
    }
    else if(ui->fromcustomButton->isChecked() && ui->filetypeBox->currentText()=="3D NMR data" && ui-> vol3dBox->isChecked())
    {
        ui->unassignBox->setChecked(false);
        ui->label3d_7->setEnabled(true);
        ui->volcol3dBox->setEnabled(true);
        ui->vol3dBox->setEnabled(true);
        ui->format3dBox->setDisabled(true);
        ui->unassignBox->setDisabled(true);
    }
    else if(ui->fromcustomButton->isChecked() && ui->filetypeBox->currentText()=="2D NMR data" && ui->vol2dBox->isChecked())
    {
        ui->unassignBox->setChecked(false);
        ui->label2d_8->setEnabled(true);
        ui->volcol2dBox->setEnabled(true);
        ui->vol2dBox->setEnabled(true);
        ui->format2dBox->setDisabled(true);
        ui->unassignBox->setDisabled(true);
    }
    else if(ui->fromcustomButton->isChecked() && ui->filetypeBox->currentText()=="2D NMR data")
    {
        ui->unassignBox->setChecked(false);
        ui->vol2dBox->setEnabled(true);
    }
    else if(ui->fromcustomButton->isChecked() && ui->filetypeBox->currentText()=="3D NMR data")
    {
        ui->unassignBox->setChecked(false);
        ui->vol3dBox->setEnabled(true);
    }
    connectAll();
}
void CompassConvert::handleIndex(int index)
{
    if(index==0)
        convert3d();
    else if(index==1)
        convert2d();
    else if(index==3)
        convertOSui();
    else
        convertSeq();
}
void CompassConvert::convert3d()
{
    if(ui->unassignBox->isChecked())
        ui->unassignBox->click();
    if(ui->vol2dBox->isChecked()==false)
        ui->vol2dBox->click();
    if(ui->format2dBox->isChecked()==false)
        ui->format2dBox->click();

    hide2d();
    hideSeq();
    show3d();
    showPeak3d();
    ui->norderBox->setMaximum(3);
    ui->horderBox->setMaximum(3);
    ui->norderBox->setValue(1);
    ui->corderBox->setValue(2);
    ui->horderBox->setValue(3);
    if(ui->fromcustomButton->isChecked())
        ui->unassignBox->setDisabled(true);
    else if (ui->format3dBox->isChecked())
    {
        if(ui->unassignBox->isChecked())
            unassignhide();
    }
    else
        showPeak3d();
    if(ui->vol3dBox->isChecked())
        ui->label_8->setText("for Label usage");
    else
        ui->label_8->setText("for Analyze usage");

}
void CompassConvert::convert2d()
{
    if(ui->unassignBox->isChecked())
        ui->unassignBox->click();
    if(ui->vol3dBox->isChecked()==false)
        ui->vol3dBox->click();
    if(ui->format3dBox->isChecked()==false)
        ui->format3dBox->click();
    hide3d();
    hideSeq();
    show2d();
    showPeak2d();
    ui->norderBox->setMaximum(2);
    ui->horderBox->setMaximum(2);
    ui->norderBox->setValue(1);
    ui->horderBox->setValue(2);
    if(ui->fromcustomButton->isChecked())
        ui->unassignBox->setDisabled(true);
    else if (ui->format2dBox->isChecked())
    {
        if(ui->unassignBox->isChecked())
            unassignhide();
    }
    else
        showPeak2d();
    if(ui->vol2dBox->isChecked())
        ui->label_8->setText("for Label usage");
    else
        ui->label_8->setText("for Analyze usage");
}
void CompassConvert::convertSeq()
{
    if(ui->unassignBox->isChecked())
        ui->unassignBox->click();
    if(ui->vol2dBox->isChecked()==false)
        ui->format2dBox->click();
    if(ui->vol3dBox->isChecked()==false)
        ui->format3dBox->click();
    if(ui->format2dBox->isChecked()==false)
        ui->format2dBox->click();
    if(ui->format3dBox->isChecked()==false)
        ui->format3dBox->click();
    hide3d();
    hide2d();
    showSeq();
    hidePeak();
    ui->label_8->setText("for Analyze usage");
}
void CompassConvert::hide3d()
{
    ui->label3d->setDisabled(true);
    ui->label3d_2->setDisabled(true);
    ui->label3d_3->setDisabled(true);
    ui->label3d_4->setDisabled(true);
    ui->label3d_5->setDisabled(true);
    ui->label3d_6->setDisabled(true);
    ui->label3d_7->setDisabled(true);
    ui->label3d_8->setDisabled(true);
    ui->volcol3dBox->setDisabled(true);
    ui->vol3dBox->setDisabled(true);
    ui->ncol3dBox->setDisabled(true);
    ui->ccol3dBox->setDisabled(true);
    ui->hcol3dBox->setDisabled(true);
    ui->peakcol3dBox->setDisabled(true);
    ui->format3dBox->setDisabled(true);
    ui->row3dEdit->setDisabled(true);
}
void CompassConvert::hide2d()
{
    ui->label2d->setDisabled(true);
    ui->label2d_2->setDisabled(true);
    ui->label2d_3->setDisabled(true);
    ui->label2d_4->setDisabled(true);
    ui->label2d_5->setDisabled(true);
    ui->label2d_6->setDisabled(true);
    ui->label2d_8->setDisabled(true);
    ui->ncol2dBox->setDisabled(true);
    ui->vol2dBox->setDisabled(true);
    ui->volcol2dBox->setDisabled(true);
    ui->hcol2dBox->setDisabled(true);
    ui->peakcol2dBox->setDisabled(true);
    ui->format2dBox->setDisabled(true);
    ui->row2dEdit->setDisabled(true);
}
void CompassConvert::hideSeq()
{
    ui->labelseq_5->setDisabled(true);
    ui->rowseqEdit->setDisabled(true);
    ui->labelseq->setDisabled(true);
    ui->labelseq_2->setDisabled(true);
    ui->labelseq_3->setDisabled(true);
    ui->labelseq_4->setDisabled(true);
    ui->mixedcaseButton->setDisabled(true);
    ui->uppercaseButton->setDisabled(true);
    ui->whitespaceBox->setDisabled(true);
    ui->threeletterButton->setDisabled(true);
    ui->oneletterButton->setDisabled(true);
}
void CompassConvert::show3d()
{
    ui->label3d->setEnabled(true);
    ui->label3d_2->setEnabled(true);
    ui->label3d_3->setEnabled(true);
    ui->label3d_4->setEnabled(true);
    ui->label3d_5->setEnabled(true);
    ui->label3d_6->setEnabled(true);
    ui->label3d_8->setEnabled(true);
    ui->ncol3dBox->setEnabled(true);
    ui->ccol3dBox->setEnabled(true);
    ui->hcol3dBox->setEnabled(true);
    ui->peakcol3dBox->setEnabled(true);
    if(ui->fromcompassButton->isChecked())
    {
        ui->format3dBox->setEnabled(true);
        ui->unassignBox->setEnabled(true);
    }
    else
        ui->unassignBox->setDisabled(true);

    ui->row3dEdit->setEnabled(true);
    if(ui->fromcustomButton->isChecked() && ui->vol3dBox->isChecked())
    {
        ui->label3d_7->setEnabled(true);
        ui->volcol3dBox->setEnabled(true);
        ui->vol3dBox->setEnabled(true);
    }
    else if(ui->fromcustomButton->isChecked())
        ui->vol3dBox->setEnabled(true);
}
void CompassConvert::show2d()
{
    ui->row2dEdit->setEnabled(true);
    if(ui->fromcustomButton->isChecked() && ui->vol2dBox->isChecked())
    {
        ui->label2d_8->setEnabled(true);
        ui->vol2dBox->setEnabled(true);
        ui->volcol2dBox->setEnabled(true);
    }
    else if(ui->fromcustomButton->isChecked())
        ui->vol2dBox->setEnabled(true);

    ui->label2d->setEnabled(true);
    ui->label2d_2->setEnabled(true);
    ui->label2d_3->setEnabled(true);
    ui->label2d_4->setEnabled(true);
    ui->label2d_5->setEnabled(true);
    ui->label2d_6->setEnabled(true);
    ui->ncol2dBox->setEnabled(true);
    ui->hcol2dBox->setEnabled(true);
    ui->peakcol2dBox->setEnabled(true);
    if(ui->fromcompassButton->isChecked())
    {
        ui->format2dBox->setEnabled(true);
        ui->unassignBox->setEnabled(true);
    }
    else
        ui->unassignBox->setDisabled(true);
}
void CompassConvert::showSeq()
{
    ui->labelseq->setEnabled(true);
    ui->labelseq_2->setEnabled(true);
    ui->labelseq_3->setEnabled(true);
    ui->labelseq_4->setEnabled(true);
    ui->labelseq_5->setEnabled(true);
    ui->rowseqEdit->setEnabled(true);
    ui->mixedcaseButton->setEnabled(true);
    ui->uppercaseButton->setEnabled(true);
    ui->whitespaceBox->setEnabled(true);
    ui->threeletterButton->setEnabled(true);
    ui->oneletterButton->setEnabled(true);
}
void CompassConvert::showPeak3d()
{
    ui->labelp->setEnabled(true);
    ui->labelp_2->setEnabled(true);
    ui->labelp_3->setEnabled(true);
    ui->labelp_4->setEnabled(true);
    ui->labelp_5->setEnabled(true);
    ui->labelp_6->setEnabled(true);
    ui->labelp_7->setEnabled(true);
    ui->labelp_8->setEnabled(true);
    ui->labelp_9->setEnabled(true);
    ui->labelp_10->setEnabled(true);
    ui->labelp_11->setEnabled(true);
    ui->labelp_12->setEnabled(true);
    ui->labelp_13->setEnabled(true);
    ui->labelp_14->setEnabled(true);
    ui->labelp_15->setEnabled(true);
    ui->nEdit->setEnabled(true);
    ui->cEdit->setEnabled(true);
    ui->hEdit->setEnabled(true);
    ui->alphaEdit->setEnabled(true);
    ui->betaEdit->setEnabled(true);
    ui->carbonylEdit->setEnabled(true);
    ui->norderBox->setEnabled(true);
    ui->corderBox->setEnabled(true);
    ui->horderBox->setEnabled(true);
    ui->unassignBox->setEnabled(true);
    ui->uppercaseBox->setEnabled(true);

}
void CompassConvert::showPeak2d()
{
    ui->labelp_4->setDisabled(true);
    ui->cEdit->setDisabled(true);
    ui->labelp_8->setDisabled(true);
    ui->labelp_9->setDisabled(true);
    ui->labelp_10->setDisabled(true);
    ui->labelp_11->setDisabled(true);
    ui->corderBox->setDisabled(true);
    ui->cEdit->setDisabled(true);
    ui->labelp_14->setDisabled(true);
    ui->alphaEdit->setDisabled(true);
    ui->betaEdit->setDisabled(true);
    ui->carbonylEdit->setDisabled(true);

    ui->nEdit->setEnabled(true);
    ui->hEdit->setEnabled(true);
    ui->labelp->setEnabled(true);
    ui->labelp_2->setEnabled(true);
    ui->labelp_3->setEnabled(true);
    ui->labelp_5->setEnabled(true);
    ui->labelp_6->setEnabled(true);
    ui->labelp_7->setEnabled(true);
    ui->labelp_12->setEnabled(true);
    ui->labelp_13->setEnabled(true);
    ui->labelp_15->setEnabled(true);
    ui->norderBox->setEnabled(true);
    ui->horderBox->setEnabled(true);
    ui->unassignBox->setEnabled(true);
    ui->uppercaseBox->setEnabled(true);


}
void CompassConvert::hidePeak()
{
    ui->labelp->setDisabled(true);
    ui->labelp_2->setDisabled(true);
    ui->labelp_3->setDisabled(true);
    ui->labelp_4->setDisabled(true);
    ui->labelp_5->setDisabled(true);
    ui->labelp_6->setDisabled(true);
    ui->labelp_7->setDisabled(true);
    ui->labelp_8->setDisabled(true);
    ui->labelp_9->setDisabled(true);
    ui->labelp_10->setDisabled(true);
    ui->labelp_11->setDisabled(true);
    ui->labelp_12->setDisabled(true);
    ui->labelp_13->setDisabled(true);
    ui->labelp_14->setDisabled(true);
    ui->labelp_15->setDisabled(true);
    ui->nEdit->setDisabled(true);
    ui->cEdit->setDisabled(true);
    ui->hEdit->setDisabled(true);
    ui->alphaEdit->setDisabled(true);
    ui->betaEdit->setDisabled(true);
    ui->carbonylEdit->setDisabled(true);
    ui->norderBox->setDisabled(true);
    ui->corderBox->setDisabled(true);
    ui->horderBox->setDisabled(true);
    ui->unassignBox->setDisabled(true);
    ui->uppercaseBox->setDisabled(true);

}
void CompassConvert::handleState(int state)
{
    if(state==0)
    {
        if(ui->filetypeBox->currentText()=="2D NMR data")
            showPeak2d();
        else
            showPeak3d();
        formatPeak(1);
    }
    else
    {
        unassignhide();
        if(ui->filetypeBox->currentText()=="2D NMR data")
            ui->labelp_7->setText("?-?");
        else
            ui->labelp_7->setText("?-?-?");
    }
}
void CompassConvert::unassignhide()
{
    ui->labelp_2->setDisabled(true);
    ui->labelp_3->setDisabled(true);
    ui->labelp_4->setDisabled(true);
    ui->labelp_5->setDisabled(true);
    ui->labelp_8->setDisabled(true);
    ui->labelp_9->setDisabled(true);
    ui->labelp_10->setDisabled(true);
    ui->labelp_11->setDisabled(true);
    ui->labelp_12->setDisabled(true);
    ui->labelp_13->setDisabled(true);
    ui->labelp_14->setDisabled(true);
    ui->labelp_15->setDisabled(true);
    ui->nEdit->setDisabled(true);
    ui->cEdit->setDisabled(true);
    ui->hEdit->setDisabled(true);
    ui->alphaEdit->setDisabled(true);
    ui->betaEdit->setDisabled(true);
    ui->carbonylEdit->setDisabled(true);
    ui->norderBox->setDisabled(true);
    ui->corderBox->setDisabled(true);
    ui->horderBox->setDisabled(true);
    ui->uppercaseBox->setDisabled(true);
}
void CompassConvert::handleState2d(int state)
{
    if(state==0)
        hidePeak();
    else
        showPeak2d();
    if(ui->vol2dBox->isChecked())
        ui->label_8->setText("for Label usage");
    else
        ui->label_8->setText("for Analyze usage");
}
void CompassConvert::handleState3d(int state)
{
    if(state==0)
        hidePeak();
    else
        showPeak3d();
    if(ui->vol3dBox->isChecked())
        ui->label_8->setText("for Label usage");
    else
        ui->label_8->setText("for Analyze usage");
}
void CompassConvert::formatSeq2(bool click)
{
    if(click==true)
    {}
    formatSeq(1);
}
void CompassConvert::formatSeq(int state)
{
    if(state==0)
    {}
    if(ui->threeletterButton->isChecked() && ui->uppercaseButton->isChecked() && ui->whitespaceBox->isChecked())
        ui->labelseq_4->setText("THR ALA LEU");
    else if(ui->threeletterButton->isChecked() && ui->uppercaseButton->isChecked() && ui->whitespaceBox->isChecked()==false)
        ui->labelseq_4->setText("THRALALEU");
    else if(ui->threeletterButton->isChecked() && ui->uppercaseButton->isChecked()==false && ui->whitespaceBox->isChecked())
        ui->labelseq_4->setText("Thr Ala Leu");
    else if(ui->threeletterButton->isChecked() && ui->uppercaseButton->isChecked()==false && ui->whitespaceBox->isChecked()==false)
        ui->labelseq_4->setText("ThrAlaLeu");
    else if(ui->threeletterButton->isChecked()==false && ui->uppercaseButton->isChecked()==false && ui->whitespaceBox->isChecked()==false)
        ui->labelseq_4->setText("TAL");
    else if(ui->threeletterButton->isChecked()==false && ui->uppercaseButton->isChecked() && ui->whitespaceBox->isChecked()==false)
        ui->labelseq_4->setText("TAL");
    else if(ui->threeletterButton->isChecked()==false && ui->uppercaseButton->isChecked()==false && ui->whitespaceBox->isChecked())
        ui->labelseq_4->setText("T A L");
    else if(ui->threeletterButton->isChecked()==false && ui->uppercaseButton->isChecked() && ui->whitespaceBox->isChecked())
        ui->labelseq_4->setText("T A L");
}
void CompassConvert::toggleVol2d(int state)
{
    if (state==0)
    {
        ui->label2d_8->setDisabled(true);
        ui->volcol2dBox->setDisabled(true);
    }
    else
    {
        ui->label2d_8->setEnabled(true);
        ui->volcol2dBox->setEnabled(true);
    }
        if(ui->vol2dBox->isChecked())
            ui->label_8->setText("for Label usage");
        else
            ui->label_8->setText("for Analyze usage");
}
void CompassConvert::toggleVol3d(int state)
{
    if (state==0)
    {
        ui->label3d_7->setDisabled(true);
        ui->volcol3dBox->setDisabled(true);
    }
    else
    {
        ui->label3d_7->setEnabled(true);
        ui->volcol3dBox->setEnabled(true);
    }
        if(ui->vol3dBox->isChecked())
            ui->label_8->setText("for Label usage");
        else
            ui->label_8->setText("for Analyze usage");
}
void CompassConvert::handleFormat(QString state)
{
    if(state=="")
    {}
    formatPeak(1);
}
void CompassConvert::handleFormat2(int state)
{
    if(state==0)
    {}
    formatPeak(1);
}
void CompassConvert::formatPeak(int state)
{
    if(state==0)
    {}
    QString str, str2, str3, str4, str5, str6, res, res2, N, C, H, CA, CB, CO;
    int Norder, Corder, Horder;
    if(ui->uppercaseBox->isChecked()==false)
    {
        res = "a";
        res2= "s";
    }
    else
    {
        res ="A";
        res2="S";
    }
    N = ui->nEdit->text();
    H = ui->hEdit->text();
    Norder = ui->norderBox->value();
    Horder = ui->horderBox->value();
    if(N=="" || H=="")
        ui->labelp_7->setText("");
    else if(ui->filetypeBox->currentText()=="3D NMR data" && (ui->alphaEdit->text()=="" || ui->betaEdit->text()==""))
        ui->labelp_7->setText("");
    else if(ui->filetypeBox->currentText()=="3D NMR data" && (ui->norderBox->value()==ui->corderBox->value() || ui->norderBox->value()==ui->horderBox->value() || ui->horderBox->value()==ui->corderBox->value() ))
        ui->labelp_7->setText("");
    else if(ui->filetypeBox->currentText()=="2D NMR data" && ui->horderBox->value()==ui->norderBox->value())
        ui->labelp_7->setText("");
    else
    {
        if(ui->filetypeBox->currentText()=="2D NMR data")
        {
            if(Norder==1)
                str=res+"50"+N+"-"+H;
            else
                str=res+"50"+H+"-"+N;
        }
        else
        {
            C = ui->cEdit->text();
            CA= C;
            CB= C;
            CO= C;
            CA += ui->alphaEdit->text();
            CB += ui->betaEdit->text();
            CO += ui->carbonylEdit->text();
            Corder = ui->corderBox->value();

            if(Corder==1)
            {
                if(Horder==2)
                {
                    str=res+"50"+CA+"-"+H+"-"+N;
                    str2=res+"50"+CB+"-"+H+"-"+N;
                    str3=res+"50"+CO+"-"+H+"-"+N;
                    str4=res2+"49"+CA+"-"+res+"50"+H+"-"+res+"50"+N;
                    str5=res2+"49"+CB+"-"+res+"50"+H+"-"+res+"50"+N;
                    str6=res2+"49"+CO+"-"+res+"50"+H+"-"+res+"50"+N;
                }
                else
                {
                    str=res+"50"+CA+"-"+N+"-"+H;
                    str2=res+"50"+CB+"-"+N+"-"+H;
                    str3=res+"50"+CO+"-"+N+"-"+H;
                    str4=res2+"49"+CA+"-"+res+"50"+N+"-"+res+"50"+H;
                    str5=res2+"49"+CB+"-"+res+"50"+N+"-"+res+"50"+H;
                    str6=res2+"49"+CO+"-"+res+"50"+N+"-"+res+"50"+H;
                }
            }
            if(Norder==1)
            {
                if(Horder==2)
                {
                    str=res+"50"+N+"-"+H+"-"+CA;
                    str2=res+"50"+N+"-"+H+"-"+CB;
                    str3=res+"50"+N+"-"+H+"-"+CO;
                    str4=res+"50"+N+"-"+res+"50"+H+"-"+res2+"49"+CA;
                    str5=res+"50"+N+"-"+res+"50"+H+"-"+res2+"49"+CB;
                    str6=res+"50"+N+"-"+res+"50"+H+"-"+res2+"49"+CO;
                }
                else
                {
                    str=res+"50"+N+"-"+CA+"-"+H;
                    str2=res+"50"+N+"-"+CB+"-"+H;
                    str3=res+"50"+N+"-"+CO+"-"+H;
                    str4=res+"50"+N+"-"+res2+"49"+CA+"-"+res+"50"+H;
                    str5=res+"50"+N+"-"+res2+"49"+CB+"-"+res+"50"+H;
                    str6=res+"50"+N+"-"+res2+"49"+CO+"-"+res+"50"+H;
                }
            }
            if(Horder==1)
            {
                if(Norder==2)
                {
                    str=res+"50"+H+"-"+N+"-"+CA;
                    str2=res+"50"+H+"-"+N+"-"+CB;
                    str3=res+"50"+H+"-"+N+"-"+CO;
                    str4=res+"50"+H+"-"+res+"50"+N+"-"+res2+"49"+CA;
                    str5=res+"50"+H+"-"+res+"50"+N+"-"+res2+"49"+CB;
                    str6=res+"50"+H+"-"+res+"50"+N+"-"+res2+"49"+CO;
                }
                else
                {
                    str=res+"50"+H+"-"+CA+"-"+N;
                    str2=res+"50"+H+"-"+CB+"-"+N;
                    str3=res+"50"+H+"-"+CO+"-"+N;
                    str4=res+"50"+H+"-"+res2+"49"+CO+"-"+res+"50"+N;
                    str5=res+"50"+H+"-"+res2+"49"+CO+"-"+res+"50"+N;
                    str6=res+"50"+H+"-"+res2+"49"+CO+"-"+res+"50"+N;
                }
            }
            str+="\t\t";
            str+=str2;
            str+="\t\t";
            str+=str3;
            str+="\n";
            str+=str4;
            str+="\t";
            str+=str5;
            str+="\t";
            str+=str6;
        }
        ui->labelp_7->setText(str);
    }
}
void CompassConvert::convert2dtoCompass()
{
    {
        extern QString cerror;
        cerror="";
    }
    int ncol, hcol, pcol, header, vcol=0;
    std::string line;
    ncol = ui->ncol2dBox->value();
    hcol = ui->hcol2dBox->value();
    pcol = ui->peakcol2dBox->value();
    if(ui->vol2dBox->isChecked())
        vcol = ui->volcol2dBox->value();
    header = ui->row2dEdit->value();
    if(ui->vol2dBox->isChecked()==false && (ncol==hcol || ncol==pcol || hcol==ncol))
    {
        extern QString cerror;
        cerror="The column numbers must be unique.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The column numbers must be unique.\nAborting.";
    }
    else if(ui->vol2dBox->isChecked() && (ncol==hcol || ncol==pcol || hcol==ncol || vcol==ncol || vcol==hcol || vcol==pcol))
    {
        extern QString cerror;
        cerror="The column numbers must be unique.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The column numbers must be unique.\nAborting.";
    }
    else if(ui->norderBox->value() == ui->horderBox->value())
    {
        extern QString cerror;
        cerror="The atom order must be unique.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The atom order must be unique.\nAborting.";
    }
    else if(ui->nEdit->text() == "" || ui->hEdit->text() == "")
    {
        extern QString cerror;
        cerror="The atom denotation cannot be empty.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The atom denotation cannot be empty.\nAborting.";
    }
    else
    {
        QString fnam = ui->fileLine->text();
        QByteArray qByte = fnam.toUtf8();
        std::string fname = qByte.data();
        std::string outname =fname +".compass";
        std::ofstream fileO;
        std::ifstream file;
        file.open(fname.c_str(), std::ios::in);
        int rC=0, cC=0;
        while(file.good())
        {
            getline(file, line);
            rC++;
            if(rC==header+1)
            {
                std::string check =line, subC;
                std::istringstream issC(check);
                cC=0;
                while(issC >> subC)
                    cC++;
            }
        }
        file.clear();
        file.close();
        if(line=="")
            rC--;
        QString cerror2 = fileCheck();
        if(cerror2 != "")
        {
            extern QString cerror;
            cerror=cerror2;
            ConvertError2 winCerror2;
            winCerror2.setWindowModality(Qt::ApplicationModal);
            if(winCerror2.exec())
                cerror=cerror2;
        }
        else if(ui->vol2dBox->isChecked()==false && (cC<ncol || cC<hcol || cC<pcol))
        {
            extern QString cerror;
            cerror="Too few columns in the submitted file.\nAborting.";
            ConvertError2 winCerror2;
            winCerror2.setWindowModality(Qt::ApplicationModal);
            if(winCerror2.exec())
                cerror="Too few columns in the submitted file.\nAborting.";
        }

        else if(ui->vol2dBox->isChecked() && (cC<ncol || cC<hcol || cC<pcol || cC<vcol))
        {
            extern QString cerror;
            cerror="Too few columns in the submitted file.\nAborting.";
            ConvertError2 winCerror2;
            winCerror2.setWindowModality(Qt::ApplicationModal);
            if(winCerror2.exec())
                cerror="Too few columns in the submitted file.\nAborting.";
        }
        else if(line=="" && rC==0)
        {
            extern QString cerror;
            cerror="The submitted file is empty.\nAborting.";
            ConvertError2 winCerror2;
            winCerror2.setWindowModality(Qt::ApplicationModal);
            if(winCerror2.exec())
                cerror="The submitted file is empty.\nAborting.";
        }
        else if(rC<header)
        {
            extern QString cerror;
            cerror="Header lines exceed the total number of lines of the submitted file.\nAborting.";
            ConvertError2 winCerror2;
            winCerror2.setWindowModality(Qt::ApplicationModal);
            if(winCerror2.exec())
                cerror="Header lines exceed the total number of lines of the submitted file.\nAborting.";
        }
        else
        {
                    int norder = ui->norderBox->value();
                    QString nPrefixq = ui->nEdit->text();
                    QString hPrefixq = ui->hEdit->text();
                    QString addedq;
                    if(norder==1)
                        addedq=nPrefixq+"-"+hPrefixq;
                    else
                        addedq=hPrefixq+"-"+nPrefixq;

                    QByteArray qByte = addedq.toUtf8();
                    std::string added = qByte.data();

                    fileO.open(outname.c_str(), std::ios::out);
                    fileO<<"\n";
                    file.open(fname.c_str(), std::ios::in);
                    for (int l=0; l<header; l++)
                        getline(file, line);
                    for(int i=0; i<rC-header; i++)
                    {
                        getline(file, line);
                        std::string temp =line, sub;
                        std::istringstream iss(temp);
                        std::string peak, N, H, V;
                        int maxC=pcol;
                        if(maxC<ncol)
                            maxC=ncol;
                        if(maxC<hcol)
                            maxC=hcol;
                        if(ui->vol2dBox->isChecked() && maxC<vcol)
                            maxC=vcol;
                        for (int a=1; a<=maxC; a++)
                        {
                            iss >> sub;
                            if(a==pcol)
                                peak = sub;
                            else if(a==hcol)
                                H = sub;
                            else if(a==ncol)
                                N = sub;
                            else if(ui->vol2dBox->isChecked() && vcol==a)
                                V = sub;
                        }

                        unsigned pos = peak.find(added);
                        std::string peakO;
                        char c = peak[0];
                        if(isalpha(c))
                        {
                            peakO = toupper(c);
                            peakO+= peak.substr(1,pos-1);
                            peakO+= "N-HN";
                        }
                        else
                            peakO = peak.substr(0,pos)+"N-HN";
                        if(ui->vol2dBox->isChecked())
                            fileO<<"\n"<<peakO<<"\t"<<N<<"\t"<<H<<"\t"<<V;
                        else
                            fileO<<"\n"<<peakO<<"\t"<<N<<"\t"<<H;
                    }
                    file.clear();
                    file.close();
                    fileO.clear();
                    fileO.close();
        }
    }
}
void CompassConvert::convert2dtoCustom()
{
    {
        extern QString cerror;
        cerror="";
    }
    int ncol, hcol, pcol;
    std::string line;
    ncol = ui->ncol2dBox->value();
    hcol = ui->hcol2dBox->value();
    pcol = ui->peakcol2dBox->value();
    if(ncol==hcol || ncol==pcol || hcol==ncol)
    {
        extern QString cerror;
        cerror="The column numbers must be unique.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The column numbers must be unique.\nAborting.";
    }
    else if(ncol+hcol+pcol!=6)
    {
        extern QString cerror;
        cerror="The column numbers must be a combination of 1, 2 and 3.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The column numbers must be a combination of 1, 2 and 3.\nAborting.";
    }
    else if(ui->format2dBox->isChecked() && ui->norderBox->value() == ui->horderBox->value())
    {
        extern QString cerror;
        cerror="The atom order must be unique.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The atom order must be unique.\nAborting.";
    }
    else if(ui->format2dBox->isChecked() && (ui->nEdit->text() == "" || ui->hEdit->text() == "") )
    {
        extern QString cerror;
        cerror="The atom denotation cannot be empty.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The atom denotation cannot be empty.\nAborting.";
    }
    else
    {
        QString fnam = ui->fileLine->text();
        QByteArray qByte = fnam.toUtf8();
        std::string fname = qByte.data();
        std::string outname =fname +".compass";
        std::ofstream fileO;
        std::ifstream file;
        file.open(fname.c_str(), std::ios::in);
        int rC=0;
        while(file.good())
        {
            getline(file, line);
            rC++;
        }
        file.clear();
        file.close();
        if(line=="")
            rC--;
        QString cerror2 = fileCheck();
        if(cerror2 != "")
        {
            extern QString cerror;
            cerror=cerror2;
            ConvertError2 winCerror2;
            winCerror2.setWindowModality(Qt::ApplicationModal);
            if(winCerror2.exec())
                cerror=cerror2;
        }
        else if(line=="" && rC==0)
        {
            extern QString cerror;
            cerror="The submitted file is empty.\nAborting.";
            ConvertError2 winCerror2;
            winCerror2.setWindowModality(Qt::ApplicationModal);
            if(winCerror2.exec())
                cerror="The submitted file is empty.\nAborting.";
        }
        else
        {
            if(ui->format2dBox->isChecked())
            {
                if(ui->unassignBox->isChecked())
                {
                    fileO.open(outname.c_str(), std::ios::out);
                    file.open(fname.c_str(), std::ios::in);
                    for (int z=0; z<ui->row2dEdit->value();z++)
                        fileO<<"\n";
                    getline(file, line);
                    getline(file, line);
                    for(int i=0; i<rC-2; i++)
                    {
                        getline(file, line);
                        std::string temp =line, sub;
                        std::istringstream iss(temp);
                        std::string peak, N, H;
                        iss >> sub;
                        peak = sub;
                        iss >> sub;
                        N = sub;
                        iss >> sub;
                        H = sub;

                        if(ncol==1 && hcol ==2 && pcol==3)
                            fileO<<N<<"\t"<<H<<"\t"<<"?-?";
                        else if(ncol==1 && hcol ==3 && pcol==2)
                            fileO<<N<<"\t"<<"?-?"<<"\t"<<H;
                        else if(ncol==2 && hcol ==1 && pcol==3)
                            fileO<<H<<"\t"<<N<<"\t"<<"?-?";
                        else if(ncol==2 && hcol ==3 && pcol==1)
                            fileO<<"?-?"<<"\t"<<N<<"\t"<<H;
                        else if(ncol==3 && hcol ==1 && pcol==2)
                            fileO<<H<<"\t"<<"?-?"<<"\t"<<N;
                        else if(ncol==3 && hcol ==2 && pcol==1)
                            fileO<<"?-?"<<"\t"<<H<<"\t"<<N;
                        if(i!=rC-3)
                            fileO<<"\n";
                    }
                    file.clear();
                    file.close();
                    fileO.clear();
                    fileO.close();
                }
                else
                {
                    int norder = ui->norderBox->value();
                    QString nPrefixq = ui->nEdit->text();
                    QString hPrefixq = ui->hEdit->text();
                    QString addedq;
                    if(norder==1)
                        addedq=nPrefixq+"-"+hPrefixq;
                    else
                        addedq=hPrefixq+"-"+nPrefixq;

                    QByteArray qByte = addedq.toUtf8();
                    std::string added = qByte.data();

                    fileO.open(outname.c_str(), std::ios::out);
                    file.open(fname.c_str(), std::ios::in);
                    for (int z=0; z<ui->row2dEdit->value();z++)
                        fileO<<"\n";
                    getline(file, line);
                    getline(file, line);
                    for(int i=0; i<rC-2; i++)
                    {
                        getline(file, line);
                        std::string temp =line, sub;
                        std::istringstream iss(temp);
                        std::string peak, N, H;
                        iss >> sub;
                        peak = sub;
                        iss >> sub;
                        N = sub;
                        iss >> sub;
                        H = sub;

                        unsigned pos = peak.find("N-HN");
                        std::string peakO;
                        if(ui->uppercaseBox->isChecked()==false)
                        {
                            char c = peak[0];
                            if(isalpha(c))
                            {
                                peakO = tolower(c);
                                peakO+= peak.substr(1,pos-1);
                                peakO+= added;
                            }
                            else
                                peakO = peak.substr(0,pos)+added;
                        }
                        else
                            peakO = peak.substr(0,pos)+added;

                        if(ncol==1 && hcol ==2 && pcol==3)
                            fileO<<N<<"\t"<<H<<"\t"<<peakO<<"\n";
                        else if(ncol==1 && hcol ==3 && pcol==2)
                            fileO<<N<<"\t"<<peakO<<"\t"<<H<<"\n";
                        else if(ncol==2 && hcol ==1 && pcol==3)
                            fileO<<H<<"\t"<<N<<"\t"<<peakO<<"\n";
                        else if(ncol==2 && hcol ==3 && pcol==1)
                            fileO<<peakO<<"\t"<<N<<"\t"<<H<<"\n";
                        else if(ncol==3 && hcol ==1 && pcol==2)
                            fileO<<H<<"\t"<<peakO<<"\t"<<N<<"\n";
                        else if(ncol==3 && hcol ==2 && pcol==1)
                            fileO<<peakO<<"\t"<<H<<"\t"<<N<<"\n";
                    }
                    file.clear();
                    file.close();
                    fileO.clear();
                    fileO.close();
                }
            }
            else
            {
                fileO.open(outname.c_str(), std::ios::out);
                file.open(fname.c_str(), std::ios::in);
                for (int z=0; z<ui->row2dEdit->value();z++)
                    fileO<<"\n";
                getline(file, line);
                getline(file, line);
                for(int i=0; i<rC-2; i++)
                {
                    getline(file, line);
                    std::string temp =line, sub;
                    std::istringstream iss(temp);
                    std::string peak, N, H;
                    iss >> sub;
                    peak = sub;
                    iss >> sub;
                    N = sub;
                    iss >> sub;
                    H = sub;

                    if(ncol==1 && hcol ==2 && pcol==3)
                        fileO<<N<<"\t"<<H<<"\t"<<peak<<"\n";
                    else if(ncol==1 && hcol ==3 && pcol==2)
                        fileO<<N<<"\t"<<peak<<"\t"<<H<<"\n";
                    else if(ncol==2 && hcol ==1 && pcol==3)
                        fileO<<H<<"\t"<<N<<"\t"<<peak<<"\n";
                    else if(ncol==2 && hcol ==3 && pcol==1)
                        fileO<<peak<<"\t"<<N<<"\t"<<H<<"\n";
                    else if(ncol==3 && hcol ==1 && pcol==2)
                        fileO<<H<<"\t"<<peak<<"\t"<<N<<"\n";
                    else if(ncol==3 && hcol ==2 && pcol==1)
                        fileO<<peak<<"\t"<<H<<"\t"<<N<<"\n";
                }
                file.clear();
                file.close();
                fileO.clear();
                fileO.close();
            }
        }
    }
}
void CompassConvert::convert3dtoCompass()
{
    {
        extern QString cerror;
        cerror="";
    }
    int ncol, hcol, pcol, header, vcol=0, ccol;
    std::string line;
    ncol = ui->ncol3dBox->value();
    ccol = ui->ccol3dBox->value();
    hcol = ui->hcol3dBox->value();
    pcol = ui->peakcol3dBox->value();

    std::string CA, CB, CO;
    QString Cq  = ui->cEdit->text();
    QString CAq = Cq + ui->alphaEdit->text();
    QString CBq = Cq + ui->betaEdit->text();
    QString COq = Cq + ui->carbonylEdit->text();


    if(ui->vol3dBox->isChecked())
        vcol = ui->volcol3dBox->value();
    header = ui->row3dEdit->value();
    if(ui->vol3dBox->isChecked()==false && (ncol==hcol || ncol==pcol || hcol==ncol || ccol==ncol || ccol==hcol || ccol==pcol))
    {
        extern QString cerror;
        cerror="The column numbers must be unique.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The column numbers must be unique.\nAborting.";
    }
    else if(CAq==CBq || CAq==COq || CBq==COq)
    {
        extern QString cerror;
        cerror="The <sup>13</sup>C denotation must be unique.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The <sup>13</sup>C denotation must be unique.\nAborting.";
    }
    else if(ui->vol3dBox->isChecked() && (ncol==hcol || ncol==pcol || hcol==ncol || vcol==ncol || vcol==hcol || vcol==pcol || ccol==pcol || ccol==vcol || ccol==ncol || ccol==hcol))
    {
        extern QString cerror;
        cerror="The column numbers must be unique.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The column numbers must be unique.\nAborting.";
    }
    else if(ui->norderBox->value() == ui->horderBox->value() || ui->norderBox->value() == ui->corderBox->value() || ui->horderBox->value() == ui->corderBox->value() )
    {
        extern QString cerror;
        cerror="The atom order must be unique.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The atom order must be unique.\nAborting.";
    }
    else if(ui->nEdit->text() == "" || ui->hEdit->text() == "" || ui->cEdit->text() == "")
    {
        extern QString cerror;
        cerror="The atom denotation cannot be empty.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The atom denotation cannot be empty.\nAborting.";
    }
    else
    {
        QString fnam = ui->fileLine->text();
        QByteArray qByte = fnam.toUtf8();
        std::string fname = qByte.data();
        std::string outname =fname +".compass";
        std::ofstream fileO;
        std::ifstream file;
        file.open(fname.c_str(), std::ios::in);
        int rC=0, cC=0;
        while(file.good())
        {
            getline(file, line);
            rC++;
            if(rC==header+1)
            {
                std::string check =line, subC;
                std::istringstream issC(check);
                cC=0;
                while(issC >> subC)
                    cC++;
            }
        }
        file.clear();
        file.close();
        if(line=="")
            rC--;
        QString cerror2 = fileCheck();
        if(cerror2 != "")
        {
            extern QString cerror;
            cerror=cerror2;
            ConvertError2 winCerror2;
            winCerror2.setWindowModality(Qt::ApplicationModal);
            if(winCerror2.exec())
                cerror=cerror2;
        }
        else if(ui->vol3dBox->isChecked()==false && (cC<ncol || cC<hcol || cC<pcol || cC<ccol))
        {
            extern QString cerror;
            cerror="Too few columns in the submitted file.\nAborting.";
            ConvertError2 winCerror2;
            winCerror2.setWindowModality(Qt::ApplicationModal);
            if(winCerror2.exec())
                cerror="Too few columns in the submitted file.\nAborting.";
        }
        else if(ui->vol3dBox->isChecked() && (cC<ncol || cC<hcol || cC<pcol || cC<vcol || cC<ccol))
        {
            extern QString cerror;
            cerror="Too few columns in the submitted file.\nAborting.";
            ConvertError2 winCerror2;
            winCerror2.setWindowModality(Qt::ApplicationModal);
            if(winCerror2.exec())
                cerror="Too few columns in the submitted file.\nAborting.";
        }
        else if(line=="" && rC==0)
        {
            extern QString cerror;
            cerror="The submitted file is empty.\nAborting.";
            ConvertError2 winCerror2;
            winCerror2.setWindowModality(Qt::ApplicationModal);
            if(winCerror2.exec())
                cerror="The submitted file is empty.\nAborting.";
        }
        else if(rC<header)
        {
            extern QString cerror;
            cerror="Header lines exceed the total number of lines of the submitted file.\nAborting.";
            ConvertError2 winCerror2;
            winCerror2.setWindowModality(Qt::ApplicationModal);
            if(winCerror2.exec())
                cerror="Header lines exceed the total number of lines of the submitted file.\nAborting.";
        }
        else
        {
                    int norder = ui->norderBox->value();
                    int corder = ui->corderBox->value();

                    QString nPrefixq = ui->nEdit->text();
                    QString hPrefixq = ui->hEdit->text();

                    std::string CA, CB, CO, N, H;

                    qByte = nPrefixq.toUtf8();
                    N = qByte.data();
                    qByte = hPrefixq.toUtf8();
                    H = qByte.data();
                    qByte = CAq.toUtf8();
                    CA = qByte.data();
                    qByte = CBq.toUtf8();
                    CB = qByte.data();
                    qByte = COq.toUtf8();
                    CO = qByte.data();

                    fileO.open(outname.c_str(), std::ios::out);
                    fileO<<"\n";
                    file.open(fname.c_str(), std::ios::in);
                    for (int l=0; l<header; l++)
                        getline(file, line);
                    for(int i=0; i<rC-header; i++)
                    {
                        bool minus1 =false;
                        getline(file, line);
                        std::string temp =line, sub;
                        std::istringstream iss(temp);
                        std::string peak, N2, H2, V2, C2, C;
                        int maxC=pcol;
                        if(maxC<ncol)
                            maxC=ncol;
                        if(maxC<hcol)
                            maxC=hcol;
                        if(maxC<ccol)
                            maxC=ccol;
                        if(ui->vol2dBox->isChecked() && maxC<vcol)
                            maxC=vcol;
                        for (int a=1; a<=maxC; a++)
                        {
                            iss >> sub;
                            if(a==pcol)
                                peak = sub;
                            else if(a==hcol)
                                H2 = sub;
                            else if(a==ncol)
                                N2 = sub;
                            else if(a==ccol)
                                C2 = sub;
                            else if(ui->vol2dBox->isChecked() && vcol==a)
                                V2 = sub;
                        }

                        unsigned pos = peak.find_last_of("-");
                        unsigned pos2= peak.find_first_of("-");
                        int Nlen = N.length();
                        int Hlen = H.length();
                        int Clen = C.length();
                        bool isCA=false;
                        bool isCB=false;
                        std::string peakO="";

                        if(corder==1)
                        {
                            if(peak.substr(pos2-CA.length(),CA.length())==CA)
                                isCA=true;
                            else if(peak.substr(pos2-CB.length(),CB.length())==CB)
                                isCB=true;
                        }
                        else if(corder==2)
                        {
                            if(peak.substr(pos-CA.length(),CA.length())==CA)
                                isCA=true;
                            else if(peak.substr(pos-CB.length(),CB.length())==CB)
                                isCB=true;
                        }
                        else
                        {
                            int len = peak.length();
                            if(peak.substr(len-CA.length(),CA.length())==CA)
                                isCA=true;
                            else if(peak.substr(len-CB.length(),CB.length())==CB)
                                isCB=true;
                        }
                        if(isCA==true)
                            C=CA;
                        else if(isCB==true)
                            C=CB;
                        else
                            C=CO;
                        Clen = C.length();

                        if(corder==2)
                        {
                            if(peak.substr(pos2,Clen+2)=="-"+C+"-")
                                minus1=false;
                            else
                                minus1=true;
                        }
                        else if (corder==1)
                        {
                            if(peak.substr(pos2,Nlen+2)!="-"+N+"-" && peak.substr(pos2, Hlen+2)!="-"+H+"-")
                                minus1=true;
                            else
                                minus1=false;
                        }
                        std::string alpha1, alpha2;



                        char c = peak[0];
                        if(corder==1)
                        {
                            if(isalpha(c))
                            {
                                if(minus1==true)
                                {
                                    alpha2= toupper(c);
                                }
                                else
                                    alpha1= toupper(c);

                            }
                            else
                            {
                                if(minus1==true)
                                    alpha2= peak[0];
                                else
                                    alpha1= peak[0];
                            }
                            if(minus1==true)
                            {
                                c=peak[pos2+1];
                                if(isalpha(c))
                                    alpha1=toupper(c);
                                else
                                    alpha1=peak.substr(pos2+1,1);
                            }
                            else
                            {
                                alpha2="";
                            }
                        }
                        else
                        {
                            if(isalpha(c))
                            {
                                alpha1= toupper(c);
                            }
                            else
                            {
                                alpha1= peak[0];
                            }
                            if(minus1==true)
                            {
                                if(corder==2)
                                {
                                    c=peak[pos2+1];
                                    if(isalpha(c))
                                        alpha2=toupper(c);
                                    else
                                        alpha2=peak.substr(pos2+1,1);
                                }
                                else
                                {
                                    c=peak[pos+1];
                                    if(isalpha(c))
                                        alpha2=toupper(c);
                                    else
                                        alpha2=peak.substr(pos+1,1);
                                }
                            }
                            else
                                alpha2="";
                        }
                        if(corder==1)
                        {
                            if(norder==2)
                            {
                                if(minus1==true)
                                {
                                    if(isCA==true)
                                        peakO=alpha1+peak.substr(pos2+2,pos-pos2-2-Nlen)+"N-"+alpha2+peak.substr(1,pos2-Clen-1)+"CA-"+alpha1+peak.substr(pos2+2,pos-pos2-2-Nlen)+"HN";
                                    else if(isCB==true)
                                        peakO=alpha1+peak.substr(pos2+2,pos-pos2-2-Nlen)+"N-"+alpha2+peak.substr(1,pos2-Clen-1)+"CB-"+alpha1+peak.substr(pos2+2,pos-pos2-2-Nlen)+"HN";
                                    else
                                        peakO=alpha1+peak.substr(pos2+2,pos-pos2-2-Nlen)+"N-"+alpha2+peak.substr(1,pos2-Clen-1)+"CO-"+alpha1+peak.substr(pos2+2,pos-pos2-2-Nlen)+"HN";
                                }
                                else
                                {
                                    if(isCA==true)
                                        peakO=alpha1+peak.substr(pos2+2,pos-pos2-2-Nlen)+"N-CA-HN";
                                    else if(isCB==true)
                                        peakO=alpha1+peak.substr(pos2+2,pos-pos2-2-Nlen)+"N-CB-HN";
                                    else
                                        peakO=alpha1+peak.substr(pos2+2,pos-pos2-2-Nlen)+"N-CO-HN";
                                }
                            }
                            else
                            {
                                if(minus1==true)
                                {
                                    if(isCA==true)
                                        peakO=alpha1+peak.substr(pos2+2,pos-pos2-2-Hlen)+"N-"+alpha2+peak.substr(1,pos2-Clen-1)+"CA-"+alpha1+peak.substr(pos2+2,pos-pos2-2-Hlen)+"HN";
                                    else if(isCB==true)
                                        peakO=alpha1+peak.substr(pos2+2,pos-pos2-2-Hlen)+"N-"+alpha2+peak.substr(1,pos2-Clen-1)+"CB-"+alpha1+peak.substr(pos2+2,pos-pos2-2-Hlen)+"HN";
                                    else
                                        peakO=alpha1+peak.substr(pos2+2,pos-pos2-2-Hlen)+"N-"+alpha2+peak.substr(1,pos2-Clen-1)+"CO-"+alpha1+peak.substr(pos2+2,pos-pos2-2-Hlen)+"HN";
                                }
                                else
                                {
                                    if(isCA==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Clen)+"N-CA-HN";
                                    else if(isCB==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Clen)+"N-CB-HN";
                                    else
                                        peakO=alpha1+peak.substr(1,pos2-1-Clen)+"N-CO-HN";
                                }
                            }
                        }
                        else if(corder==2)
                        {
                            if(norder==1)
                            {
                                if(minus1==true)
                                {
                                    if(isCA==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Nlen)+"N-"+alpha2+peak.substr(pos2+2,pos-pos2-Clen-2)+"CA-"+alpha1+peak.substr(1,pos2-1-Nlen)+"HN";
                                    else if(isCB==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Nlen)+"N-"+alpha2+peak.substr(pos2+2,pos-pos2-Clen-2)+"CB-"+alpha1+peak.substr(1,pos2-1-Nlen)+"HN";
                                    else
                                        peakO=alpha1+peak.substr(1,pos2-1-Nlen)+"N-"+alpha2+peak.substr(pos2+2,pos-pos2-Clen-2)+"CO-"+alpha1+peak.substr(1,pos2-1-Nlen)+"HN";
                                }
                                else
                                {
                                    if(isCA==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Nlen)+"N-CA-HN";
                                    else if(isCB==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Nlen)+"N-CB-HN";
                                    else
                                        peakO=alpha1+peak.substr(1,pos2-1-Nlen)+"N-CO-HN";
                                }
                            }
                            else
                            {
                                if(minus1==true)
                                {
                                    if(isCA==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Hlen)+"N-"+alpha2+peak.substr(pos2+2,pos-pos2-Clen-2)+"CA-"+alpha1+peak.substr(1,pos2-1-Hlen)+"HN";
                                    else if(isCB==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Hlen)+"N-"+alpha2+peak.substr(pos2+2,pos-pos2-Clen-2)+"CB-"+alpha1+peak.substr(1,pos2-1-Hlen)+"HN";
                                    else
                                        peakO=alpha1+peak.substr(1,pos2-1-Hlen)+"N-"+alpha2+peak.substr(pos2+2,pos-pos2-Clen-2)+"CO-"+alpha1+peak.substr(1,pos2-1-Hlen)+"HN";
                                }
                                else
                                {
                                    if(isCA==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Hlen)+"N-CA-HN";
                                    else if(isCB==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Hlen)+"N-CB-HN";
                                    else
                                        peakO=alpha1+peak.substr(1,pos2-1-Hlen)+"N-CO-HN";
                                }
                            }
                        }
                        else
                        {
                            if(norder==1)
                            {
                                if(minus1==true)
                                {
                                    if(isCA==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Nlen)+"N-"+alpha2+peak.substr(pos+2,peak.length()-pos-Clen-2)+"CA-"+alpha1+peak.substr(1,pos2-1-Nlen)+"HN";
                                    else if(isCB==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Nlen)+"N-"+alpha2+peak.substr(pos+2,peak.length()-pos-Clen-2)+"CB-"+alpha1+peak.substr(1,pos2-1-Nlen)+"HN";
                                    else
                                        peakO=alpha1+peak.substr(1,pos2-1-Nlen)+"N-"+alpha2+peak.substr(pos+2,peak.length()-pos-Clen-2)+"CO-"+alpha1+peak.substr(1,pos2-1-Nlen)+"HN";
                                }
                                else
                                {
                                    if(isCA==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Nlen)+"N-CA-HN";
                                    else if(isCB==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Nlen)+"N-CB-HN";
                                    else
                                        peakO=alpha1+peak.substr(1,pos2-1-Nlen)+"N-CO-HN";
                                }
                            }
                            else
                            {
                                if(minus1==true)
                                {
                                    if(isCA==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Hlen)+"N-"+alpha2+peak.substr(pos+2,peak.length()-pos-Clen-2)+"CA-"+alpha1+peak.substr(1,pos2-1-Hlen)+"HN";
                                    else if(isCB==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Hlen)+"N-"+alpha2+peak.substr(pos+2,peak.length()-pos-Clen-2)+"CB-"+alpha1+peak.substr(1,pos2-1-Hlen)+"HN";
                                    else
                                        peakO=alpha1+peak.substr(1,pos2-1-Hlen)+"N-"+alpha2+peak.substr(pos+2,peak.length()-pos-Clen-2)+"CO-"+alpha1+peak.substr(1,pos2-1-Hlen)+"HN";
                                }
                                else
                                {
                                    if(isCA==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Hlen)+"N-CA-HN";
                                    else if(isCB==true)
                                        peakO=alpha1+peak.substr(1,pos2-1-Hlen)+"N-CB-HN";
                                    else
                                        peakO=alpha1+peak.substr(1,pos2-1-Hlen)+"N-CO-HN";
                                }
                            }

                        }


                        if(ui->vol2dBox->isChecked())
                        {
                            if(minus1==false)
                                fileO<<"\n"<<peakO<<"\t\t"<<N2<<"\t"<<C2<<"\t"<<H2<<"\t"<<V2;
                            else
                                fileO<<"\n"<<peakO<<"\t"<<N2<<"\t"<<C2<<"\t"<<H2<<"\t"<<V2;
                        }
                        else
                        {
                            if(minus1==false)
                                fileO<<"\n"<<peakO<<"\t\t"<<N2<<"\t"<<C2<<"\t"<<H2;
                            else
                                fileO<<"\n"<<peakO<<"\t"<<N2<<"\t"<<C2<<"\t"<<H2;
                        }
                    }
                    file.clear();
                    file.close();
                    fileO.clear();
                    fileO.close();
        }
    }
}
void CompassConvert::convert3dtoCustom()
{
    {
        extern QString cerror;
        cerror="";
    }
    int ncol, hcol, pcol,ccol;
    std::string line;
    ncol = ui->ncol3dBox->value();
    ccol = ui->ccol3dBox->value();
    hcol = ui->hcol3dBox->value();
    pcol = ui->peakcol3dBox->value();
    if(ncol==hcol || ncol==pcol || hcol==ncol || ncol==ccol || hcol==ccol || pcol==ccol)
    {
        extern QString cerror;
        cerror="The column numbers must be unique.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The column numbers must be unique.\nAborting.";
    }
    else if(ncol+hcol+pcol+ccol!=10)
    {
        extern QString cerror;
        cerror="The column numbers must be a combination of 1, 2, 3 and 4.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The column numbers must be a combination of 1, 2, 3 and 4.\nAborting.";
    }
    else if(ui->format3dBox->isChecked() && (ui->norderBox->value() == ui->horderBox->value() || ui->corderBox->value() == ui->horderBox->value() || ui->norderBox->value() == ui->corderBox->value() ))
    {
        extern QString cerror;
        cerror="The atom order must be unique.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The atom order must be unique.\nAborting.";
    }
    else if(ui->format3dBox->isChecked() && (ui->nEdit->text() == "" || ui->hEdit->text() == "" || ui->cEdit->text() == "") )
    {
        extern QString cerror;
        cerror="The atom denotation cannot be empty.\nAborting.";
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            cerror="The atom denotation cannot be empty.\nAborting.";
    }
    else
    {
        QString fnam = ui->fileLine->text();
        QByteArray qByte = fnam.toUtf8();
        std::string fname = qByte.data();
        std::string outname =fname +".compass";
        std::ofstream fileO;
        std::ifstream file;
        file.open(fname.c_str(), std::ios::in);
        int rC=0;
        while(file.good())
        {
            getline(file, line);
            rC++;
        }
        file.clear();
        file.close();
        if(line=="")
            rC--;
        QString cerror2 = fileCheck();
        if(cerror2 != "")
        {
            extern QString cerror;
            cerror=cerror2;
            ConvertError2 winCerror2;
            winCerror2.setWindowModality(Qt::ApplicationModal);
            if(winCerror2.exec())
                cerror=cerror2;
        }
        else if(line=="" && rC==0)
        {
            extern QString cerror;
            cerror="The submitted file is empty.\nAborting.";
            ConvertError2 winCerror2;
            winCerror2.setWindowModality(Qt::ApplicationModal);
            if(winCerror2.exec())
                cerror="The submitted file is empty.\nAborting.";
        }
        else
        {
            if(ui->format3dBox->isChecked())
            {
                if(ui->unassignBox->isChecked())
                {
                    fileO.open(outname.c_str(), std::ios::out);
                    file.open(fname.c_str(), std::ios::in);
                    getline(file, line);
                    getline(file, line);
                    for (int z=0; z<ui->row3dEdit->value();z++)
                        fileO<<"\n";
                    for(int i=0; i<rC-2; i++)
                    {
                        getline(file, line);
                        std::string temp =line, sub;
                        std::istringstream iss(temp);
                        std::string peak, N, H, C;
                        iss >> sub;
                        peak = sub;
                        iss >> sub;
                        N = sub;
                        iss >> sub;
                        C = sub;
                        iss >> sub;
                        H = sub;
                        for(int j=1; j<5; j++)
                        {
                            if(ncol==j)
                                fileO<<N;
                            else if(hcol==j)
                                fileO<<H;
                            else if(ccol==j)
                                fileO<<C;
                            else
                                fileO<<"?-?-?";
                                if(j<4)
                                fileO<<"\t";
                            else
                            {
                                if(i!=rC-3)
                                    fileO<<"\n";
                            }
                        }
                    }
                    file.clear();
                    file.close();
                    fileO.clear();
                    fileO.close();
                }
                else
                {
                    int norder = ui->norderBox->value();
                    int horder = ui->horderBox->value();
                    int corder = ui->corderBox->value();
                    QString nPrefixq = ui->nEdit->text();
                    QString hPrefixq = ui->hEdit->text();
                    QString cPrefixq = ui->cEdit->text();
                    QString aPrefixq = ui->alphaEdit->text();
                    QString bPrefixq = ui->betaEdit->text();
                    QString oPrefixq = ui->carbonylEdit->text();
                    QString CAq = cPrefixq + aPrefixq;
                    QString CBq = cPrefixq + bPrefixq;
                    QString COq = cPrefixq + oPrefixq;

                    QByteArray qByte;
                    std::string nPre, hPre, CA, CB, CO;
                    qByte = nPrefixq.toUtf8();
                    nPre = qByte.data();
                    qByte = hPrefixq.toUtf8();
                    hPre = qByte.data();
                    qByte = CAq.toUtf8();
                    CA = qByte.data();
                    qByte = CBq.toUtf8();
                    CB = qByte.data();
                    qByte = COq.toUtf8();
                    CO = qByte.data();
                    fileO.open(outname.c_str(), std::ios::out);
                    file.open(fname.c_str(), std::ios::in);
                    for (int z=0; z<ui->row3dEdit->value();z++)
                        fileO<<"\n";
                    getline(file, line);
                    getline(file, line);
                    for(int i=0; i<rC-2; i++)
                    {
                        std::string peakO="";
                        getline(file, line);
                        std::string temp =line, sub;
                        std::istringstream iss(temp);
                        std::string peak, N, H, C;
                        iss >> sub;
                        peak = sub; // N130N-G129CA-N130HN, N130N-CA-HN
                        iss >> sub;
                        N = sub;
                        iss >> sub;
                        C = sub;
                        iss >> sub;
                        H = sub;

                        unsigned pos = peak.find_last_of("-"); // N130N-G129CA'-'N130HN, N130N-CA'-'HN
                        bool minus1 = false;
                        if(peak.substr(pos+1)!="HN")
                            minus1=true;
                        bool isCA=false, isCB=false;
                        if(peak.substr(pos-1,1)=="A")
                        {
                            isCA=true;
                        }
                        else if(peak.substr(pos-1,1)=="B")
                        {
                            isCB=true;
                        }

                        std::string peakNo, peakNo2, alph1, alph2;
                        unsigned pos2 = peak.find_first_of("-");    // N130N'-'G129CA-N130HN, N130N'-'CA-HN
                        pos2--;                                     // N130'N'-G129CA-N130HN, N130'N'-CA-HN
                        if(ui->uppercaseBox->isChecked()==false)
                        {
                            char c = peak[0];                       // 'N'130N-G129CA-N130HN, 'N'130N-CA-HN
                            if(isalpha(c))
                                alph1 = tolower(c);                 // alph1= 'n'
                            else
                                alph1 = peak[0];                    // alph1= 'N'
                            if(minus1==true)
                            {
                                c = peak[pos2+2];                   // c= 'G'
                                if(isalpha(c))
                                    alph2 = tolower(c);             //alph2='g'
                                else
                                    alph2 = peak[pos2+2];           //alph2='G'
                            }
                        }
                        else
                        {

                            peakNo=peak.substr(0,pos2);             // 'N130'N-G129CA-N130HN, 'N130'N-CA-HN
                            if(minus1==true)
                            {
                                peakNo2=peak.substr(pos2+2,pos-pos2-4); // N130N-'G129'CA-N130HN
                            }

                        }

                        for(int k=1; k<4; k++)
                        {
                            if(norder==k)
                            {
                                if(ui->uppercaseBox->isChecked()==false && (minus1==true || norder==1))
                                {
                                    peakO+=alph1;               //peakO='n'
                                    peakO+=peak.substr(1,pos2-1);//peakO='n130'
                                }
                                else if(minus1==true || norder==1)
                                {
                                    peakO+=peakNo;              //peakO= N130
                                }

                                peakO+= nPre;                   // peakO= n/N130N
                            }
                            else if (corder==k)
                            {
                                if(ui->uppercaseBox->isChecked()==false)
                                {
                                    if(minus1==true)
                                    {
                                        peakO+=alph2;                           //peakO=G
                                        peakO+=peak.substr(pos2+3,pos-pos2-5);  //peakO=G129
                                    }
                                    else if (corder==1)
                                    {
                                        peakO+=alph1;                           //N130
                                        peakO+=peak.substr(1,pos2-1);
                                    }
                                }
                                else
                                {
                                    if(minus1==true)
                                    {
                                        peakO+=peakNo2;                         //peakO=G129
                                    }
                                    else if(corder==1)
                                    {
                                        peakO+=peakNo;                          //N130
                                    }
                                }

                                if(isCA==true)
                                {
                                    peakO+= CA;
                                }
                                else if (isCB==true)
                                {
                                    peakO+= CB;
                                }
                                else
                                {
                                    peakO+= CO;
                                }
                            }
                            else if (horder==k)
                            {
                                if(ui->uppercaseBox->isChecked()==false && (minus1==true || horder==1))
                                {
                                    peakO+=alph1;
                                    peakO+=peak.substr(1,pos2-1);
                                }
                                else if(minus1==true || horder==1)
                                    peakO+=peakNo;
                                peakO+= hPre;
                            }
                            if(k<3)
                                peakO+="-";
                        }

                        for(int j=1; j<5; j++)
                        {
                            if(ncol==j)
                                fileO<<N;
                            else if(hcol==j)
                                fileO<<H;
                            else if(ccol==j)
                                fileO<<C;
                            else
                                fileO<<peakO;
                            if(j<4 && pcol==j && minus1==false)
                                fileO<<"\t\t";
                            else if(j<4)
                                fileO<<"\t";
                            else
                                fileO<<"\n";
                        }
                    }
                    file.clear();
                    file.close();
                    fileO.clear();
                    fileO.close();
                }
            }
            else
            {
                fileO.open(outname.c_str(), std::ios::out);
                file.open(fname.c_str(), std::ios::in);
                getline(file, line);
                getline(file, line);
                for (int z=0; z<ui->row3dEdit->value();z++)
                    fileO<<"\n";
                for(int i=0; i<rC-2; i++)
                {
                    getline(file, line);
                    std::string temp =line, sub;
                    std::istringstream iss(temp);
                    std::string peak, N, H, C;
                    iss >> sub;
                    peak = sub;
                    iss >> sub;
                    N = sub;
                    iss >> sub;
                    C = sub;
                    iss >> sub;
                    H = sub;

                    for(int j=1; j<5; j++)
                    {
                        if(ncol==j)
                            fileO<<N;
                        else if(hcol==j)
                            fileO<<H;
                        else if(ccol==j)
                            fileO<<C;
                        else
                            fileO<<peak;
                        if(j<4)
                            fileO<<"\t";
                        else
                            fileO<<"\n";
                    }
                }
                file.clear();
                file.close();
                fileO.clear();
                fileO.close();
            }
        }
    }
}
void CompassConvert::convertseqtoCompass()
{
    {
        extern QString cerror;
        cerror="";
    }
    bool error =false, illegal=false;
    std::string type;
    if(ui->oneletterButton->isChecked())
        type="1";
    else
        type="3";

    if(ui->uppercaseButton->isChecked())
        type+="u";
    else
        type+="m";

    bool delimiter;
    if(ui->whitespaceBox->isChecked())
        delimiter =true;
    else
        delimiter =false;
    int header = ui->rowseqEdit->value();
    std::string seq="", caps="Yes", line, sub;

    QString fnam = ui->fileLine->text();
    QByteArray qByte = fnam.toUtf8();
    std::string fname = qByte.data();
    std::ifstream file;
    file.open(fname.c_str(), std::ios::in);
    int rC=0;
    std::string temp="";
    for(int j=0; j<header; j++)
    {
        if(file.good())
        {
            getline(file, line);
            rC++;
        }
    }
    while(file.good())
    {
        getline(file, line);
        if(line!="")
        {
            temp+=line;
            if(delimiter==true)
                temp+=" ";
        }
        rC++;
    }
    if(line=="")
        rC--;
    if(temp=="" && rC==1)
    {
        extern QString cerror;
        cerror="The submitted file is empty.\nAborting.";
        error=true;
    }
    else if (rC<=header)
    {
        extern QString cerror;
        error=true;
        cerror="Header lines exceed the total number of lines of the submitted file.\nAborting.";
    }
    file.clear();
    file.close();

    if (error==false && ui->threeletterButton->isChecked() && delimiter ==true)
    {
        seq=temp;
        std::istringstream iss(temp);
        while(iss >> sub)
        {
            illegal=legalcheck(sub, type);
            if(illegal==false)
            {
                extern QString cerror;
                error=true;
                QString subq = QString::fromUtf8(sub.c_str());
                cerror="The format of "+subq+" does not match the custom format.\nAborting.";
                break;
            }
        }
    }
    else if(error==false)
    {
        file.open(fname.c_str(), std::ios::in);
        for(int i=0; i<header; i++)
            getline(file, line);
        rC-=header;
        for(int i=0; i<rC; i++)
        {
            getline(file, line);
            if (delimiter==true)
            {
                seq+=line;
                seq+=" ";
            }
            else
            {
                seq+=line;
            }
        }
        std::string tmp=seq;
        file.clear();
        file.close();
        if(delimiter==true && ui->threeletterButton->isChecked())
        {
            std::istringstream iss(tmp);
            while(iss >> sub)
            {
                illegal=legalcheck(sub, type);
                if(illegal==false)
                {
                    extern QString cerror;
                    error=true;
                    QString subq = QString::fromUtf8(sub.c_str());
                    cerror="The format of "+subq+" does not match the custom format.\nAborting.";
                    break;
                }
            }
        }
        else if (delimiter==false && ui->oneletterButton->isChecked())
        {
            int strlen = tmp.length();
            for(int i=0; i<strlen; i++)
            {
                if(tmp[i]==' ')
                    continue;
                illegal=legalcheckChar(tmp[i], type);
                if(illegal==false)
                {
                    std::stringstream ss2;
                    ss2 << tmp[i];
                    std::string tmp2;
                    ss2 >> tmp2;
                    extern QString cerror;
                    error=true;
                    QString subQ = QString::fromUtf8(tmp2.c_str());
                    cerror="The format of "+subQ+" does not match the custom format.\nAborting.";
                    break;
                }
            }
        }
        else if(delimiter ==true && ui->oneletterButton->isChecked())
        {
            seq="";
            std::istringstream iss(tmp);
            while(iss >> sub)
            {
                illegal=legalcheck(sub, type);
                if(illegal==false)
                {
                    extern QString cerror;
                    error=true;
                    QString subq = QString::fromUtf8(sub.c_str());
                    cerror="The format of "+subq+" does not match the custom format.\nAborting.";
                    break;
                }
                seq+=sub;
            }
        }
        else
        {
            std::string tmps="";
            int strlen = tmp.length();
            for(int i=0; i<strlen; i+=3)
            {
                if(tmp[i]==' ')
                {
                    if(tmp[i+1]!=' ')
                        i++;
                    else
                    {
                        if(tmp[i+2]!=' ')
                            i+=2;
                        else
                            continue;
                    }
                }
                std::stringstream ss, ss2, ss3;
                std::string subS ="";
                ss << tmp[i];
                ss >> subS;
                std::string subS2 =subS;
                ss2 << tmp[i+1];
                ss2 >> subS;
                subS2 +=subS;
                ss3 << tmp[i+2];
                ss3 >> subS;
                subS2 +=subS;

                illegal=legalcheck(subS2, type);
                if(illegal==false)
                {
                    extern QString cerror;
                    error=true;
                    QString subQ = QString::fromUtf8(subS2.c_str());
                    cerror="The format of "+subQ+" does not match the custom format.\nAborting.";
                    break;
                }
                tmps+=subS2;
                tmps+=" ";
            }
            seq=tmps;
        }
    }

    if(ui->oneletterButton->isChecked() && error==false)
        onetwothree(seq, true, caps);
    else if (ui->threeletterButton->isChecked() && ui->uppercaseButton->isChecked() && error==false)
        threetothree(seq, true, "Yes");
    else if (ui->threeletterButton->isChecked() && ui->uppercaseButton->isChecked()==false && error==false)
        threetothree(seq, true, "Yes");
    else
    {
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            return;
    }

}
void CompassConvert::convertseqtoCustom()
{
    {
        extern QString cerror;
        cerror="";
    }
    bool error =false, illegal=false;
    std::string type;
    if(ui->oneletterButton->isChecked())
        type="1";
    else
        type="3";

    if(ui->uppercaseButton->isChecked())
        type+="u";
    else
        type+="m";

    bool delimiter;
    if(ui->whitespaceBox->isChecked())
        delimiter =true;
    else
        delimiter =false;
    std::string seq="", caps, line, sub;
    if(ui->uppercaseButton->isChecked())
        caps="Yes";
    else
        caps="No";

    QString fnam = ui->fileLine->text();
    QByteArray qByte = fnam.toUtf8();
    std::string fname = qByte.data();
    std::ifstream file;
    file.open(fname.c_str(), std::ios::in);
    int rC=0;
    std::string temp="";
    while(file.good())
    {
        getline(file, line);
        if(line!="")
            temp=line;
        rC++;
    }
    if(line=="")
        rC--;
    if(temp=="" && rC==1)
    {
        extern QString cerror;
        cerror="The submitted file is empty.\nAborting.";
        error=true;
    }
    else if (rC>1)
    {
        extern QString cerror;
        error=true;
        cerror="The submitted file is not of COMPASS format.\nAborting.";
    }
    file.clear();
    file.close();

    if (error==false)
    {
        file.open(fname.c_str(), std::ios::in);
        getline(file, line);
        seq=line;
        file.clear();
        file.close();
        std::istringstream iss(line);
        while(iss >> sub)
        {
            illegal=legalcheck(sub, "3u");
            if(illegal==false)
            {
                extern QString cerror;
                error=true;
                QString subq = QString::fromUtf8(sub.c_str());
                cerror="The format of "+subq+" does not match the COMPASS format.\nAborting.";
                break;
            }
        }
    }

    if(ui->oneletterButton->isChecked() && error==false)
        threetwoone(seq, delimiter);
    else if (ui->threeletterButton->isChecked() && error==false)
        threetothree(seq, delimiter, caps);
    else
    {
        ConvertError2 winCerror2;
        winCerror2.setWindowModality(Qt::ApplicationModal);
        if(winCerror2.exec())
            return;
    }
}
bool CompassConvert::legalcheck(std::string sub, std::string type)
{
    bool exist=false;
    std::string u3[20];
    u3[0]="ALA";
    u3[1]="CYS";
    u3[2]="ASP";
    u3[3]="GLU";
    u3[4]="PHE";
    u3[5]="GLY";
    u3[6]="HIS";
    u3[7]="ILE";
    u3[8]="LEU";
    u3[9]="LYS";
    u3[10]="MET";
    u3[11]="ASN";
    u3[12]="PRO";
    u3[13]="GLN";
    u3[14]="ARG";
    u3[15]="SER";
    u3[16]="THR";
    u3[17]="VAL";
    u3[18]="TRP";
    u3[19]="TYR";
    std::string u1[20];
    u1[0]="A";
    u1[1]="C";
    u1[2]="D";
    u1[3]="E";
    u1[4]="F";
    u1[5]="G";
    u1[6]="H";
    u1[7]="I";
    u1[8]="L";
    u1[9]="K";
    u1[10]="M";
    u1[11]="N";
    u1[12]="P";
    u1[13]="Q";
    u1[14]="R";
    u1[15]="S";
    u1[16]="T";
    u1[17]="V";
    u1[18]="W";
    u1[19]="Y";
    std::string m3[20];
    m3[0]="Ala";
    m3[1]="Cys";
    m3[2]="Asp";
    m3[3]="Glu";
    m3[4]="Phe";
    m3[5]="Gly";
    m3[6]="His";
    m3[7]="Ile";
    m3[8]="Leu";
    m3[9]="Lys";
    m3[10]="Met";
    m3[11]="Asn";
    m3[12]="Pro";
    m3[13]="Gln";
    m3[14]="Arg";
    m3[15]="Ser";
    m3[16]="Thr";
    m3[17]="Val";
    m3[18]="Trp";
    m3[19]="Tyr";
    if(type=="1m" || type =="1u")
    {
        for(int i=0; i<20;i++)
            if(u1[i]==sub)
            {
                exist=true;
                break;
            }
    }
    else if(type=="3u")
    {
        for(int i=0; i<20;i++)
        {
            if(u3[i]==sub)
            {
                exist=true;
                break;
            }
        }
    }
    else
    {
        for(int i=0; i<20;i++)
            if(m3[i]==sub)
            {
                exist=true;
                break;
            }
    }
        return exist;
}
bool CompassConvert::legalcheckChar(char sub, std::string type)
{
    if(type=="")
    {}
    std::string subc;
    std::stringstream ss;
    ss << sub;
    ss >> subc;
    bool exist=false;
    std::string u1[20];
    u1[0]="A";
    u1[1]="C";
    u1[2]="D";
    u1[3]="E";
    u1[4]="F";
    u1[5]="G";
    u1[6]="H";
    u1[7]="I";
    u1[8]="L";
    u1[9]="K";
    u1[10]="M";
    u1[11]="N";
    u1[12]="P";
    u1[13]="Q";
    u1[14]="R";
    u1[15]="S";
    u1[16]="T";
    u1[17]="V";
    u1[18]="W";
    u1[19]="Y";
        for(int i=0; i<20;i++)
            if(u1[i]==subc)
            {
                exist=true;
                break;
            }
        return exist;
}

void CompassConvert::onetwothree(std::string seq, bool delimiter, std::string caps)
{
    QString fnam= ui->fileLine->text();
    QByteArray qByte = fnam.toUtf8();
    std::string fname =qByte.data();

    QString folder = ui->folderLine->text();
    qByte = folder.toUtf8();
    std::string foname = qByte.data();
    unsigned pos = fname.find_last_of("/");
    foname+=fname.substr(pos);
    foname+=".compass";

    std::ofstream file;
    file.open(foname.c_str());
    int strlen=0;
    strlen=seq.length();
    char str[2000];
    strcpy(str, seq.c_str());

    for (int i = 0; i <strlen; i++)
    {
        file<<convert2(str[i], delimiter, caps);
    }
    file.clear();
    file.close();
}
void CompassConvert::threetwoone(std::string seq, bool delimiter)
{
    QString fnam= ui->fileLine->text();
    QByteArray qByte = fnam.toUtf8();
    std::string fname =qByte.data();

    QString folder = ui->folderLine->text();
    qByte = folder.toUtf8();
    std::string foname = qByte.data();
    unsigned pos = fname.find_last_of("/");
    foname+=fname.substr(pos);
    foname+=".compass";

    std::ofstream file;
    file.open(foname.c_str());
    std::string line=seq;
    int counter=0;
    stringstream iss(seq);
    string str;
    do{
        iss >> str;
        counter++;
    }while(iss);
    stringstream iss2(line);
    for(int i=0; i<counter-1; i++)
    {
        iss2 >> str;
        file<<convert(str, delimiter);
    }
    file.clear();
    file.close();
}
void CompassConvert::threetothree(std::string seq, bool delimiter, std::string caps)
{
    QString fnam= ui->fileLine->text();
    QByteArray qByte = fnam.toUtf8();
    std::string fname =qByte.data();

    QString folder = ui->folderLine->text();
    qByte = folder.toUtf8();
    std::string foname = qByte.data();
    unsigned pos = fname.find_last_of("/");
    foname+=fname.substr(pos);
    foname+=".compass";

    std::ofstream file;
    file.open(foname.c_str());
    std::string line=seq;
    int counter=0;
    stringstream iss(seq);
    string str;
    do{
        iss >> str;
        counter++;
    }while(iss);
    stringstream iss2(line);
    for(int i=0; i<counter-1; i++)
    {
        iss2 >> str;
        file<<convert3(str, delimiter, caps);
    }
    file.clear();
    file.close();
}

std::string CompassConvert::convert(std::string fasta, bool delimiter)
{
    std::string converted="FORMATERROR";
        if(fasta=="Ala" || fasta=="ALA")
            converted="A";
        else if(fasta=="Cys" || fasta=="CYS")
            converted="C";
        else if(fasta=="ASP" || fasta=="Asp")
            converted="D";
        else if(fasta=="GLU" || fasta=="Glu")
            converted="E";
        else if(fasta=="Phe" || fasta=="PHE")
            converted="F";
        else if(fasta=="Gly" || fasta=="GLY")
            converted="G";
        else if(fasta=="His" || fasta=="HIS")
            converted="H";
        else if(fasta=="Ile" || fasta=="ILE")
            converted="I";
        else if(fasta=="Lys" || fasta=="LYS")
            converted="K";
        else if(fasta=="Leu" || fasta=="LEU")
            converted="L";
        else if(fasta=="Met" || fasta=="MET")
            converted="M";
        else if(fasta=="Asn" || fasta=="ASN")
            converted="N";
        else if(fasta=="Pro" || fasta=="PRO")
            converted="P";
        else if(fasta=="Gln" || fasta=="GLN")
            converted="Q";
        else if(fasta=="Arg" || fasta=="ARG")
            converted="R";
        else if(fasta=="Ser" || fasta=="SER")
            converted="S";
        else if(fasta=="Thr" || fasta=="THR")
            converted="T";
        else if(fasta=="Val" || fasta=="VAL")
            converted="V";
        else if(fasta=="Trp" || fasta=="TRP")
            converted="W";
        else if(fasta=="Tyr" || fasta=="TYR")
            converted="Y";
    if(delimiter==true)
        converted+=" ";
    return converted;
}
std::string CompassConvert::convert3(std::string fasta, bool delimiter, std::string caps)
{
    std::string converted="FORMATERROR";
    if(caps=="No")
    {
        if(fasta=="ALA")
            converted="Ala";
        else if(fasta=="CYS")
            converted="Cys";
        else if(fasta=="ASP")
            converted="Asp";
        else if(fasta=="GLU")
            converted="Glu";
        else if(fasta=="PHE")
            converted="Phe";
        else if(fasta=="GLY")
            converted="Gly";
        else if(fasta=="HIS")
            converted="His";
        else if(fasta=="ILE")
            converted="Ile";
        else if(fasta=="LYS")
            converted="Lys";
        else if(fasta=="LEU")
            converted="Leu";
        else if(fasta=="MET")
            converted="Met";
        else if(fasta=="ASN")
            converted="Asn";
        else if(fasta=="PRO")
            converted="Pro";
        else if(fasta=="GLN")
            converted="Gln";
        else if(fasta=="ARG")
            converted="Arg";
        else if(fasta=="SER")
            converted="Ser";
        else if(fasta=="THR")
            converted="Thr";
        else if(fasta=="VAL")
            converted="Val";
        else if(fasta=="TRP")
            converted="Trp";
        else if(fasta=="TYR")
            converted="Tyr";
    }
    else
    {
        if(fasta=="Ala")
            converted="ALA";
        else if(fasta=="Cys")
            converted="CYS";
        else if(fasta=="Asp")
            converted="ASP";
        else if(fasta=="Glu")
            converted="GLU";
        else if(fasta=="Phe")
            converted="PHE";
        else if(fasta=="Gly")
            converted="GLY";
        else if(fasta=="His")
            converted="HIS";
        else if(fasta=="Ile")
            converted="ILE";
        else if(fasta=="Lys")
            converted="LYS";
        else if(fasta=="Leu")
            converted="LEU";
        else if(fasta=="Met")
            converted="MET";
        else if(fasta=="Asn")
            converted="ASN";
        else if(fasta=="Pro")
            converted="PRO";
        else if(fasta=="Gln")
            converted="GLN";
        else if(fasta=="Arg")
            converted="ARG";
        else if(fasta=="Ser")
            converted="SER";
        else if(fasta=="Thr")
            converted="THR";
        else if(fasta=="Val")
            converted="VAL";
        else if(fasta=="Trp")
            converted="TRP";
        else if(fasta=="Tyr")
            converted="TYR";
        else
            converted=fasta;
    }
    if(delimiter==true)
        converted+=" ";
    return converted;
}
std::string CompassConvert::convert2(char c, bool delimiter, std::string caps)
{
    string fasta;
    string converted="";
    stringstream ss;
    ss << c;
    ss >> fasta;
    if(caps=="Yes")
    {
        if(fasta=="A")
            converted="ALA";
        else if(fasta=="C")
            converted="CYS";
        else if(fasta=="D")
            converted="ASP";
        else if(fasta=="E")
            converted="GLU";
        else if(fasta=="F")
            converted="PHE";
        else if(fasta=="G")
            converted="GLY";
        else if(fasta=="H")
            converted="HIS";
        else if(fasta=="I")
            converted="ILE";
        else if(fasta=="K")
            converted="LYS";
        else if(fasta=="L")
            converted="LEU";
        else if(fasta=="M")
            converted="MET";
        else if(fasta=="N")
            converted="ASN";
        else if(fasta=="P")
            converted="PRO";
        else if(fasta=="Q")
            converted="GLN";
        else if(fasta=="R")
            converted="ARG";
        else if(fasta=="S")
            converted="SER";
        else if(fasta=="T")
            converted="THR";
        else if(fasta=="V")
            converted="VAL";
        else if(fasta=="W")
            converted="TRP";
        else if(fasta=="Y")
            converted="TYR";
    }
    else
    {
        if(fasta=="A")
            converted="Ala";
        else if(fasta=="C")
            converted="Cys";
        else if(fasta=="D")
            converted="Asp";
        else if(fasta=="E")
            converted="Glu";
        else if(fasta=="F")
            converted="Phe";
        else if(fasta=="G")
            converted="Gly";
        else if(fasta=="H")
            converted="His";
        else if(fasta=="I")
            converted="Ile";
        else if(fasta=="K")
            converted="Lys";
        else if(fasta=="L")
            converted="Leu";
        else if(fasta=="M")
            converted="Met";
        else if(fasta=="N")
            converted="Asn";
        else if(fasta=="P")
            converted="Pro";
        else if(fasta=="Q")
            converted="Gln";
        else if(fasta=="R")
            converted="Arg";
        else if(fasta=="S")
            converted="Ser";
        else if(fasta=="T")
            converted="Thr";
        else if(fasta=="V")
            converted="Val";
        else if(fasta=="W")
            converted="Trp";
        else if(fasta=="Y")
            converted="Tyr";
    }


    if(delimiter==true && converted!="")
        converted+=" ";
    return converted;
}


void CompassConvert::on_quitButton_clicked()
{
    QApplication::quit();
}
