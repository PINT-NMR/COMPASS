#include "compassabout.h"
#include "ui_compassabout.h"

CompassAbout::CompassAbout(QWidget *parent) :
        QWidget(parent),
	ui(new Ui::CompassAbout)
{
	ui->setupUi(this);
}

CompassAbout::~CompassAbout()
{
	delete ui;
}

void CompassAbout::on_close_aboutButton_2_clicked()
{
    emit goToMain();
}
