#include "queryerror7.h"
#include "ui_queryerror7.h"
#include <QtWidgets>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <globals.h>

QueryError7::QueryError7(QWidget *parent) :
    QDialog(parent),
	ui(new Ui::QueryError7)
{
	ui->setupUi(this);
	setError();
}

QueryError7::~QueryError7()
{
	delete ui;
}
void QueryError7::setError()
{
	extern QString errorMessage2;
	if (errorMessage2=="Error!")
	{
		ui->Error_label->setText(errorMessage2);
		ui->Errorsymbol->show();
	}
	else
	{
		ui->Error_label->setText(errorMessage2);
		ui->Errorsymbol->hide();
	}
	extern QString errorMessage;
	ui->errorBrowser7->setText(errorMessage);
}

void QueryError7::on_closeErrButton6_clicked()
{
    accept();
}
