#include "compassssresults.h"
#include "ui_compassssresults.h"
#include <QtWidgets>
#include "QRect"		//Used for centering windows
#include "QDesktopWidget"	//Used for centering windows
#include "globals2.h"
#include <iostream>

CompassSSResults::CompassSSResults(QWidget *parent) :
	QMainWindow(parent),
	ui(new Ui::CompassSSResults)
{
	ui->setupUi(this);
	QRect position = frameGeometry();	
	position.moveCenter(QDesktopWidget().availableGeometry().center());
 	move(position.topLeft());
	read_file();
}

CompassSSResults::~CompassSSResults()
{
	delete ui;
}

void CompassSSResults::changeEvent(QEvent *e)
{
	QMainWindow::changeEvent(e);
	switch (e->type())
	{
		case QEvent::LanguageChange:
			ui->retranslateUi(this);
			break;
			default:
			break;
	}
}
void CompassSSResults::read_file()
{
    extern QString fileRes,fileWarn;
	QFile resfile(fileRes);
	resfile.open(QFile::ReadOnly | QFile::Text);
	QTextStream ReadFile(&resfile);
	ui->resBrowser->setText("");
    //ui->resBrowser->insertHtml(ReadFile.readAll()); //html
//    ui->resBrowser->setFont (QFont ("Consolas", 8)); //Windows Version
	ui->resBrowser->setText(ReadFile.readAll()); //orig.

    if (QFile::exists(fileWarn))
    {
        QFile warnfile(fileWarn);
        warnfile.open(QFile::ReadOnly | QFile::Text);
        QTextStream ReadFile2(&warnfile);
        ui->warnBrowser->setText("");
        //ui->warnBrowser->insertHtml(ReadFile2.readAll()); //html //html
        ui->warnBrowser->setText(ReadFile2.readAll()); //orig.
  //      ui->warnBrowser->setFont (QFont ("Consolas", 8)); //Windows Version

    }
    else
    {
        ui->warnBrowser->setText("No warnings to display.");
    }

}
