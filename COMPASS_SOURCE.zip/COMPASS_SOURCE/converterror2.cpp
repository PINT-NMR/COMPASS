#include "converterror2.h"
#include "ui_converterror2.h"
#include <QtWidgets>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include "globals.h"

ConvertError2::ConvertError2(QWidget *parent) :
    QDialog(parent),
	ui(new Ui::ConvertError2)
{
	ui->setupUi(this);
	errorSet();
}

ConvertError2::~ConvertError2()
{
	delete ui;
}
void ConvertError2::errorSet()
{
	extern QString cerror;
	ui->errorBrowser->setText(cerror);
}

void ConvertError2::on_closeButton_clicked()
{
    accept();
}
