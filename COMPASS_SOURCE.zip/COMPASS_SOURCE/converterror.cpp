#include "converterror.h"
#include "ui_converterror.h"
#include <QtWidgets>
#include <cstdlib>
#include <fstream>
#include <iostream>

ConvertError::ConvertError(QWidget *parent) :
    QDialog(parent),
	ui(new Ui::ConvertError)
{
	ui->setupUi(this);
}

ConvertError::~ConvertError()
{
	delete ui;
}

void ConvertError::on_closeButton_clicked()
{
    accept();
}
