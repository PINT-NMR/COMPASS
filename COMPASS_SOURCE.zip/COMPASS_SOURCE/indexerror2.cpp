#include "indexerror2.h"
#include "ui_indexerror2.h"
#include <QtWidgets>
#include <cstdlib>
#include "QRect"
#include "QDesktopWidget"
#include <fstream>
#include <iostream>
#include <globals.h>

IndexError2::IndexError2(QWidget *parent) :
	QMainWindow(parent),
	ui(new Ui::IndexError2)
{
	ui->setupUi(this);
	QRect position = frameGeometry();	
	position.moveCenter(QDesktopWidget().availableGeometry().center());
 	move(position.topLeft());
	readerrfile2();
}

IndexError2::~IndexError2()
{
	delete ui;
}

void IndexError2::changeEvent(QEvent *e)
{
	QMainWindow::changeEvent(e);
	switch (e->type())
	{
		case QEvent::LanguageChange:
			ui->retranslateUi(this);
			break;
			default:
			break;
	}
}

void IndexError2::readerrfile2()
{
	extern QString filenames;
	QString fread = filenames;
	fread+="Temp/rename_errors.txt";
	QFile file(fread);
	file.open(QFile::ReadOnly | QFile::Text);
	QTextStream ReadFile(&file);
	ui->errorBrowser->setText(ReadFile.readAll());
}
