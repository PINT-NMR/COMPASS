#include "compasshelp.h"
#include "ui_compasshelp.h"
#include "caexample.h"

CompassHelp::CompassHelp(QWidget *parent) :
    QDialog(parent),
	ui(new Ui::CompassHelp)
{
	ui->setupUi(this);
}

CompassHelp::~CompassHelp()
{
	delete ui;
}

void CompassHelp::on_closehelpButton_clicked()
{
    accept();
}

void CompassHelp::on_cahelpButton_clicked()
{
    CaExample widgetCa;
    widgetCa.setWindowModality(Qt::ApplicationModal);
    if(widgetCa.exec())
        return;
}
