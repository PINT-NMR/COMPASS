#include "compassquery.h"
#include "ui_compassquery.h"
#include <cstdlib> 
#include "QRect"
#include "QDesktopWidget" 
#include "queryerror4.h"
#include "queryerror5.h"
#include "queryformaterror.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include "globals.h"
#include "compass.h"
#include "compass2.h"
#include "compass3.h"
#include <unistd.h>
#include <stdio.h>
#include <QFile>
#include <qfiledialog.h>
#include <compassdir.h>
#include <compassfunctions.h>
#include "globals3.h"
#include "compassrm.h"
#include "QFileInfo"
#include "mfunc.h"
#include "compasshelp.h"
//
#include "QTime"
//
#include <thread>
//

QString CompassQuery::File_Format_Check3D(std::string infile, std::string Ctype, std::string Ftype)
{
    std::ifstream file;
    std::string line, sub;
    bool iOK=false;
    QString retstr="Passed";
    file.open(infile.c_str(), std::ios::in);
    int counter=0;
    while(file.good())
    {
        getline(file,line);
        counter++;
    }
    file.clear();
    file.close();
    if (counter==0)
    {
        retstr= QString::fromUtf8(infile.c_str());
        retstr += " is empty or does not exist. Please check your input file.";
        return retstr;
    }
    else if (counter<2)
    {
        retstr= QString::fromUtf8(infile.c_str());
        retstr += " does not have a valid format. Please check your input file.";
        return retstr;
    }
    file.open(infile.c_str(), std::ios::in);
    getline(file,line);
    getline(file,line);
    if (line!="")
    {
        file.clear();
        file.close();
        retstr= "Line 2 of ";
        retstr+= QString::fromUtf8(infile.c_str());
        retstr += " does not have a valid format. Please check your input file.";
        return retstr;
    }
    int counter2=2;
    counter-=3;
    for(int c=0; c<counter;c++)
    {
        counter2++;
        getline(file,line);
        std::string arr[5];
        //		linetemp=line;
        std::istringstream iss(line);
        int lc=0;
        while (iss>>sub)
        {
            if ( lc==5)
            {
                retstr= QString::fromUtf8(infile.c_str());
                retstr += " contains the line ";
                retstr += QString::fromUtf8(line.c_str());
                retstr += ", which has too many columns. Please check your input file.";
                file.clear();
                file.close();
                return retstr;
            }
            else
                arr[lc++]=sub;
        }
        if (lc==0)
        {
            retstr= "Line "% QString::number(counter2)%" in "% QString::fromUtf8(infile.c_str())%" is empty. Please check your input file.";
            file.clear();
            file.close();
            return retstr;
        }
        else if (lc<4)
        {
            retstr= "The file ";
            retstr+= QString::fromUtf8(infile.c_str());
            retstr += " contains the line: \n ";
            retstr +=  QString::fromUtf8(line.c_str());
            retstr += " \n, which has too few columns. Please check your input file.";
            file.clear();
            file.close();
            return retstr;
        }
        else
        {
            for (int j=1;j<4;j++)
            {
                int num = arr[j].length();
                for (int i=0;i<num;i++)
                {
                    if (!isdigit(arr[j][i]) && arr[j][i]!='.')
                    {
                        retstr = "Column ";
                        retstr += QString::number(j+1);
                        retstr +=" in ";
                        retstr += QString::fromUtf8(infile.c_str());
                        retstr += " contains a non-numerical symbol. Please check your input file.";
                        file.clear();
                        file.close();
                        return retstr;
                    }
                }
            }
            if (atof(arr[1].c_str())<=90.0 || atof(arr[1].c_str())>145.0)
            {
                retstr = "Column 2 in ";
                retstr += QString::fromUtf8(infile.c_str());
                retstr += " does not contain nitrogen chemical shifts. Please check your input file.";
                file.clear();
                file.close();
                return retstr;
            }
            if (atof(arr[3].c_str())<=2.0 || atof(arr[3].c_str())>14.0)
            {
                retstr = "Column 4 in ";
                retstr += QString::fromUtf8(infile.c_str());
                retstr += " does not contain hydrogen chemical shifts. Please check your input file.";
                file.clear();
                file.close();
                return retstr;
            }
            int num = arr[0].length();
            int hc=0;
            for (int i=0;i<num;i++)
            {
                if (arr[0][i]=='-')
                    hc++;
            }
            if(hc!=2)
            {
                retstr=QString::fromUtf8(arr[0].c_str());
                retstr+= " in the file ";
                retstr+= QString::fromUtf8(infile.c_str());
                retstr+=" is not of a valid peak format.\nSee 'Help' for valid peak formats. Aborting.";
                file.clear();
                file.close();
                return retstr;
            }
            unsigned pos=arr[0].find_last_of("-");
            unsigned pos2=arr[0].find_first_of("-");
            if (Ctype=="CA")
            {
                if (arr[0].substr(pos-2, 2)=="CB")
                {
                    retstr=QString::fromUtf8(arr[0].c_str());
                    retstr+=" in the file ";
                    retstr+=QString::fromUtf8(infile.c_str());
                    retstr+=" is not of a valid peak format.\nIf CA and CB shifts are listed in the same files please submit the files only as HNCB files. \nSee 'Help' for valid peak formats. Aborting.";
                    file.clear();
                    file.close();
                    return retstr;
                }
                else if(Ftype=="i-1" && (arr[0].substr(pos-2, 2)!="CA" || arr[0].substr(arr[0].length()-2,2)!="HN" || arr[0].substr(pos2-1,1)!="N" || arr[0].substr(pos-3,1)=="-"))
                {
                    retstr=QString::fromUtf8(arr[0].c_str());
                    retstr+=" in the file ";
                    retstr+=QString::fromUtf8(infile.c_str());
                    retstr+=" is not of a valid peak format. This file may only contain HNCA (i-1) peaks. \nSee 'Help' for valid peak formats. Aborting.";
                    file.clear();
                    file.close();
                    return retstr;
                }
                else if(Ftype=="i" && (arr[0].substr(pos-2, 2)!="CA" || arr[0].substr(arr[0].length()-2,2)!="HN" || arr[0].substr(pos2-1,1)!="N"))
                {
                    retstr=QString::fromUtf8(arr[0].c_str());
                    retstr+=" in the file ";
                    retstr+=QString::fromUtf8(infile.c_str());
                    retstr+=" is not of a valid peak format.\nSee 'Help' for valid peak formats. Aborting.";
                    file.clear();
                    file.close();
                    return retstr;
                }
                if (atof(arr[2].c_str())<=30.0 || atof(arr[2].c_str())>75.0)
                {
                    retstr = "Column 3 in ";
                    retstr += QString::fromUtf8(infile.c_str());
                    retstr += " does not contain CA chemical shifts. Please check your input file.";
                    file.clear();
                    file.close();
                    return retstr;
                }
            }
            else if(Ctype=="CB" )
            {
                if(Ftype=="i-1" && ((arr[0].substr(pos-2, 2)!="CA" && arr[0].substr(pos-2, 2)!="CB") || arr[0].substr(arr[0].length()-2,2)!="HN" || arr[0].substr(pos2-1,1)!="N" || arr[0].substr(pos-3,1)=="-"))
                {
                    retstr=QString::fromUtf8(arr[0].c_str());
                    retstr+=" in the file ";
                    retstr+=QString::fromUtf8(infile.c_str());
                    retstr+=" is not of a valid peak format. This file may only contain HNCB (i-1) and HNCA (i-1) peaks.\nSee 'Help' for valid peak formats. Aborting.";
                    file.clear();
                    file.close();
                    return retstr;
                }
                else if(Ftype=="i" && ((arr[0].substr(pos-2, 2)!="CA" && arr[0].substr(pos-2, 2)!="CB") || arr[0].substr(arr[0].length()-2,2)!="HN" || arr[0].substr(pos2-1,1)!="N"))
                {
                    retstr=QString::fromUtf8(arr[0].c_str());
                    retstr+=" in the file ";
                    retstr+=QString::fromUtf8(infile.c_str());
                    retstr+=" is not of a valid peak format. \nSee 'Help' for valid peak formats. Aborting.";
                    file.clear();
                    file.close();
                    return retstr;
                }

                if (atof(arr[2].c_str())<=0.0 || atof(arr[2].c_str())>90.0)
                {
                    retstr = "Column 3 in ";
                    retstr += QString::fromUtf8(infile.c_str());
                    retstr += " does not contain correct chemical shifts. Please check your input file.";
                    file.clear();
                    file.close();
                    return retstr;
                }
            }
            else
            {
                if(Ftype=="i-1" && (arr[0].substr(pos-2, 2)!="CO" || arr[0].substr(arr[0].length()-2,2)!="HN" || arr[0].substr(pos2-1,1)!="N" || arr[0].substr(pos-3,1)=="-"))
                {
                    retstr=QString::fromUtf8(arr[0].c_str());
                    retstr+=" in the file ";
                    retstr+=QString::fromUtf8(infile.c_str());
                    retstr+=" is not of a valid peak format. This file may only contain HNCO (i-1) peaks. \nSee 'Help' for valid peak formats. Aborting.";
                    file.clear();
                    file.close();
                    return retstr;
                }
                else if(Ftype=="i" && (arr[0].substr(pos-2, 2)!="CO" || arr[0].substr(arr[0].length()-2,2)!="HN" || arr[0].substr(pos2-1,1)!="N"))
                {
                    retstr=QString::fromUtf8(arr[0].c_str());
                    retstr+=" in the file ";
                    retstr+=QString::fromUtf8(infile.c_str());
                    retstr+=" is not of a valid peak format. \nSee 'Help' for valid peak formats. Aborting.";
                    file.clear();
                    file.close();
                    return retstr;
                }
                if (atof(arr[2].c_str())<=150.0 || atof(arr[2].c_str())>200.0)
                {
                    retstr = "Column 4 in ";
                    retstr += QString::fromUtf8(infile.c_str());
                    retstr += " does not contain CO chemical shifts. Please check your input file.";
                    file.clear();
                    file.close();
                    return retstr;
                }
            }
            if (Ftype=="i" && arr[0].substr(pos-3,1)=="-")
                iOK=true;
        }

    }
    file.clear();
    file.close();

    if (iOK==false && Ftype=="i")
    {
        retstr = "The file ";
        retstr += QString::fromUtf8(infile.c_str());
        retstr += " is submitted as an (i)(i-1) file but does not contain any (i) shifts. Please submit files on correct position.";
        return retstr;
    }
    return retstr;
}
QString CompassQuery::File_Format_Check2D(std::string infile)
{
    std::ifstream file;
    std::string line, sub;
    std::string arr[4];
    file.open(infile.c_str(), std::ios::in);
    int counter=0;
    while(file.good())
    {
        getline(file,line);
        counter++;
    }
    file.clear();
    file.close();
    if (counter==0)
        return "The HSQC file is empty. Please check your input file.";
    else if (counter<2)
        return "The HSQC file does not have a valid format. Please check your input file.";
    file.open(infile.c_str(), std::ios::in);
    getline(file,line);
    getline(file,line);
    if (line!="")
    {
        file.clear();
        file.close();
        return "Line 2 of the submitted HSQC file does not have a valid format. Please check your input file.";
    }
    QString retstr="Passed";
    int counter2=2;
    counter-=3;
    for(int c=0; c<counter;c++)
    {
        counter2++;
        getline(file,line);
        std::istringstream iss(line);
        int lc=0;
        while (iss>>sub)
        {
            if (lc==4)
            {
                retstr= "The submitted HSQC file contains the line ";
                retstr += QString::fromUtf8(line.c_str());
                retstr += ", which has too many columns. Please check your input file.";
                break;
            }
            arr[lc++]=sub;
        }
        if (lc==0)
        {
            retstr= "Line "% QString::number(counter2)%" in the submitted HSQC file is empty. Please check your input file.";
            break;
        }
        else if (lc!=4 && lc!=3)
        {
            retstr= "The submitted HSQC file has too few columns. Please check your input file.";
            break;
        }
        else if (retstr!="Passed")
        {
            break;
        }
        else
        {
            int num = arr[0].length();
            int hc=0;
            for (int i=0;i<num;i++)
            {
                if (arr[0][i]=='-')
                    hc++;
            }
            if(hc!=1)
            {
                retstr=QString::fromUtf8(arr[0].c_str());
                retstr+= " in the submitted HSQC file is not of a valid peak format.\nSee 'Help' for valid peak formats. Aborting.";
                break;
            }
            unsigned pos=arr[0].find_last_of("-");
            if(arr[0].substr(pos-1, 1)!="N" || arr[0].substr(arr[0].length()-2,2)!="HN")
            {
                retstr=QString::fromUtf8(arr[0].c_str());
                retstr+=" in the submitted HSQC list is not of a valid peak format.\nSee 'Help' for valid peak formats. Aborting.";
                break;
            }
            num = arr[1].length();
            for (int i=0;i<num;i++)
            {
                if (!isdigit(arr[1][i]) && arr[1][i]!='.')
                {
                    retstr= "Column 2 in the submitted HSQC file contains a non-numerical symbol. Please check your input file.";
                    break;
                }
            }
            if (retstr!="Passed")
                break;
            num = arr[2].length();
            for (int i=0;i<num;i++)
            {
                if (!isdigit(arr[2][i]) && arr[2][i]!='.')
                {
                    retstr= "Column 3 in the submitted HSQC file contains a non-numerical symbol. Please check your input file.";
                    break;
                }
            }
            if (retstr!="Passed")
                break;
            if (atof(arr[1].c_str())<=90.0 || atof(arr[1].c_str())>145.0)
            {
                retstr= "Column 2 in the submitted HSQC file does not contain nitrogen chemical shifts. Please check your input file.";
                break;
            }
            if (atof(arr[2].c_str())<=2.0 || atof(arr[2].c_str())>14.0)
            {
                retstr= "Column 3 in the submitted HSQC file does not contain hydrogen chemical shifts. Please check your input file.";
                break;
            }
            num = arr[3].length();
            for (int i=0;i<num;i++)
            {
                if (!isdigit(arr[3][i]) && arr[3][0]!='-')
                {
                    retstr= "Column 4 in the submitted HSQC file contains a non-numerical symbol. Please check your input file.";
                    break;
                }
            }
            if (retstr!="Passed")
                break;
        }
    }
    file.clear();
    file.close();
    return retstr;
}

CompassQuery::CompassQuery(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CompassQuery)
{
    analyzing = false;
	ui->setupUi(this);
    setParam();
    connectLines();
    getDir();
} 
void CompassQuery::connectLines()
{
    connect(ui->caLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->caLine_2, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->cbcaLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->cbcaLine_2, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->coLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->coLine_2, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->hsqcLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->ssLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->seqLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->projectLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->folderLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    connect(ui->firstBox, SIGNAL(valueChanged(int)), this, SLOT(saveParam()));
    connect(ui->devBox, SIGNAL(valueChanged(double)), this, SLOT(saveParam()));
    connect(ui->devBox_2, SIGNAL(valueChanged(double)), this, SLOT(saveParam()));
    connect(ui->devBox_3, SIGNAL(valueChanged(double)), this, SLOT(saveParam()));
    connect(ui->fBox, SIGNAL(valueChanged(int)), this, SLOT(saveParam()));
    connect(ui->fBox_2, SIGNAL(valueChanged(int)), this, SLOT(saveParam()));
    connect(ui->fBox_3, SIGNAL(valueChanged(int)), this, SLOT(saveParam()));
}
void CompassQuery::disconnectAll()
{
    disconnect(ui->caLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    disconnect(ui->caLine_2, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    disconnect(ui->cbcaLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    disconnect(ui->cbcaLine_2, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    disconnect(ui->coLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    disconnect(ui->coLine_2, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    disconnect(ui->hsqcLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    disconnect(ui->ssLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    disconnect(ui->seqLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    disconnect(ui->projectLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    disconnect(ui->folderLine, SIGNAL(textChanged(QString)), this, SLOT(saveParam()));
    disconnect(ui->firstBox, SIGNAL(valueChanged(int)), this, SLOT(saveParam()));
    disconnect(ui->devBox, SIGNAL(valueChanged(double)), this, SLOT(saveParam()));
    disconnect(ui->devBox_2, SIGNAL(valueChanged(double)), this, SLOT(saveParam()));
    disconnect(ui->devBox_3, SIGNAL(valueChanged(double)), this, SLOT(saveParam()));
    disconnect(ui->fBox, SIGNAL(valueChanged(int)), this, SLOT(saveParam()));
    disconnect(ui->fBox_2, SIGNAL(valueChanged(int)), this, SLOT(saveParam()));
    disconnect(ui->fBox_3, SIGNAL(valueChanged(int)), this, SLOT(saveParam()));

}

void CompassQuery::connectAll()
{
    connectLines();
}

void CompassQuery::clear_form()
{
    extern bool running;
    if(running ==false)
    {
        ui->caLine->setText("");
        ui->caLine_2->setText("");
        ui->cbcaLine->setText("");
        ui->cbcaLine_2->setText("");
        ui->coLine->setText("");
        ui->coLine_2->setText("");
        ui->hsqcLine->setText("");
        ui->seqLine->setText("");
        ui->ssLine->setText("");
        getDir();
        ui->projectLine->setText("");
        ui->firstBox->setValue(0);
        ui->deutBox->setCurrentIndex(0);
        ui->devBox->setValue(0.2);
        ui->devBox_2->setValue(0.2);
        ui->devBox_3->setValue(0.2);
        ui->fBox->setValue(10);
        ui->fBox_3->setValue(10);
        ui->fBox_2->setValue(10);
    }
}

void CompassQuery::setParam()
{
    extern QString capar, capar2, cbcapar, cbcapar2, copar, copar2, hsqcpar, seqpar, sspar, savepar, propar;
    extern int firstpar, sampar, i1par, i2par, i3par;
    extern double d1par, d2par, d3par;

    ui->caLine->setText(capar);
    ui->caLine_2->setText(capar2);
    ui->cbcaLine->setText(cbcapar);
    ui->cbcaLine_2->setText(cbcapar2);
    ui->coLine->setText(copar);
    ui->coLine_2->setText(copar2);
    ui->hsqcLine->setText(hsqcpar);
    ui->seqLine->setText(seqpar);
    ui->ssLine->setText(sspar);
    ui->folderLine->setText(savepar);
    ui->projectLine->setText(propar);
    ui->firstBox->setValue(firstpar);
    ui->deutBox->setCurrentIndex(sampar);
    ui->devBox->setValue(d1par);
    ui->devBox_2->setValue(d2par);
    ui->devBox_3->setValue(d3par);
    ui->fBox->setValue(i1par);
    ui->fBox_2->setValue(i2par);
    ui->fBox_3->setValue(i3par);

}
void CompassQuery::saveParam()
{
    extern QString capar, capar2, cbcapar, cbcapar2, copar, copar2, hsqcpar, seqpar, sspar, savepar, propar;
    extern int firstpar,sampar, i1par, i2par, i3par;
    extern double d1par, d2par, d3par;

    capar = ui->caLine->text();
    capar2 = ui->caLine_2->text();
    cbcapar = ui->cbcaLine->text();
    cbcapar2 = ui->cbcaLine_2->text();
    copar = ui->coLine->text();
    copar2 = ui->coLine_2->text();
    hsqcpar = ui->hsqcLine->text();
    seqpar = ui->seqLine->text();
    sspar = ui->ssLine->text();
    savepar = ui->folderLine->text();
    propar = ui->projectLine->text();
    firstpar = ui->firstBox->value();
    sampar = ui->deutBox->currentIndex();
    d1par = ui->devBox->value();
    d2par = ui->devBox_2->value();
    d3par = ui->devBox_3->value();
    i1par = ui->fBox->value();
    i2par = ui->fBox_2->value();
    i3par = ui->fBox_3->value();

}
void CompassQuery::getDir()
{
	char cwd[1024];
	getcwd(cwd, sizeof(cwd));
	std::stringstream ss;
	std::string s;
	ss << cwd;
	ss >> s;
	QString Qcwd = QString::fromUtf8(s.c_str());
    ui->folderLine->setText(convSlash(Qcwd));
}
CompassQuery::~CompassQuery()
{
    delete ui;
}
QString CompassQuery::format_check(std::string cafile, std::string cafile2, std::string cbcafile, std::string cbcafile2, std::string cofile, std::string cofile2, std::string hsqcfile, std::string seq, std::string ss)
{
    QString format="Passed";
	std::string line, sub;
	std::string aaArr[20];
    std::ifstream file;
    extern QString match23;
	int match23i=0, caI=0, cbI=0, coI=0;
	aaArr[0]="ALA";
	aaArr[1]="ARG";
	aaArr[2]="ASP";
	aaArr[3]="ASN";
	aaArr[4]="CYS";
	aaArr[5]="GLU";
	aaArr[6]="GLN";
	aaArr[7]="GLY";
	aaArr[8]="HIS";
	aaArr[9]="LEU";
	aaArr[10]="ILE";
	aaArr[11]="LYS";
	aaArr[12]="PRO";
	aaArr[13]="MET";
	aaArr[14]="SER";
	aaArr[15]="THR";
	aaArr[16]="TRP";
	aaArr[17]="TYR";
	aaArr[18]="VAL";
    aaArr[19]="PHE";

	if (cafile!="")
	{
        format=File_Format_Check3D(cafile,"CA","i");
        if (format=="Passed")
            caI+=2;
    }
	if(cafile2!="" && format=="Passed")
	{
        format=File_Format_Check3D(cafile2,"CA","i-1");
        if (format=="Passed")
            caI++;
	}
	if(cbcafile!="" && format=="Passed")
	{
        format=File_Format_Check3D(cbcafile,"CB","i");
        if (format=="Passed")
        {
            file.open(cbcafile.c_str(), std::ios::in);
            getline(file, line);
            getline(file, line);
            while(!file.eof())
            {
                getline(file, line);
                std::istringstream iss(line);
                iss >> sub;
                unsigned pos=sub.find_last_of("-");
                if(sub.substr(pos-2,2)=="CA")
                {
                    match23i=1;
                    break;
                }
            }
		}
        if (format=="Passed")
            cbI+=2;
		if (match23i==1)
            caI+=2;
        file.clear();
		file.close();
	}
	if(cbcafile2!="" && format=="Passed")
	{
        format=File_Format_Check3D(cbcafile2,"CB","i-1");
        if (format=="Passed")
            cbI++;
	}
	if(cofile!="" && format=="Passed")
	{
        format=File_Format_Check3D(cofile,"CO","i");
        if (format=="Passed")
            coI+=2;
    }
    if(cofile2!="" && format=="Passed")
	{
        format=File_Format_Check3D(cofile2,"CO","i-1");
        if (format=="Passed")
            coI++;
    }
	if(caI>1)
		caI=2;
	if(cbI>1)
		cbI=2;
	if(coI>1)
		coI=2;
	if(caI+cbI+coI==6)
		match23="6";
	else if((caI==2 && cbI==2) || (caI==2 && coI==2) || (cbI==2 && coI==2))
		match23="4";
	else
		match23="2";

	if(hsqcfile!="" && format=="Passed")
	{
        format=File_Format_Check2D(hsqcfile);
    }
    int cseq=0;
	if(seq!="" && format=="Passed")
	{
		file.open(seq.c_str(), std::ios::in);
		getline(file, line);

        std::istringstream iss(line);
		do{
			iss >> sub;
            cseq++;
			for(int i=0; i<20; i++)
			{
				if(sub==aaArr[i])
				{
					break;;
				}
				else if(i==19)
				{
                    format=QString::fromUtf8(sub.c_str());
                    format+=" in the submitted protein sequence is not of a valid amino acid format.\nSee 'Help' for valid amino acid format. Aborting.";
					break;
				}
			}
			if(format!="Passed")
				break;
		}while(iss);
		file.clear();
		file.close();
	}
    int css=0;
	if(ss!="" && format=="Passed")
	{
		file.open(ss.c_str(), std::ios::in);
		getline(file, line);
		std::istringstream iss(line);
		do{
			iss >> sub;
            css++;
			if(sub!="helx" && sub!="loop" && sub!="strd" && sub!="xxxx")
			{
                format=QString::fromUtf8(sub.c_str());
                format+=" in the submitted secondary sequence is not of a valid format.\nSee 'Help' for valid formats. Aborting.";

                break;
			}

		}while(iss);
		file.clear();
		file.close();
        if (css!=cseq && format=="Passed")
        {
            format =" The submitted secondary structure sequence does not have the same number of elements as the amino acid sequence.\nPlease check your input files. Aborting.";
        }
	}

    return format;
}
void CompassQuery::loadParams()
{
    extern bool running;
    if(running==false)
    {
        QString path;
        path = QFileDialog::getOpenFileName(
        this,
        "Choose a parameter file",
        QString::null,
        tr("Parameter files (*.cpar)"));
        if(path!="")
            loadParam(path);
    }
}
void CompassQuery::loadParam(QString path)
{
	QByteArray qByte = path.toUtf8();
	std::string fname = qByte.data();
	std::ifstream file;
	std::string line;
	file.open(fname.c_str(), std::ios::in);
	getline(file, line);
	QString qline = QString::fromUtf8(line.c_str());
	if(qline!="EMPTY")
        ui->caLine->setText(convSlash(qline));
	else
		ui->caLine->setText("");
	getline(file, line);
	qline = QString::fromUtf8(line.c_str());
	if(qline!="EMPTY")
        ui->caLine_2->setText(convSlash(qline));
	else
		ui->caLine_2->setText("");
	getline(file, line);
	qline = QString::fromUtf8(line.c_str());
	if(qline!="EMPTY")
        ui->cbcaLine->setText(convSlash(qline));
	else
		ui->cbcaLine->setText("");
	getline(file, line);
	qline = QString::fromUtf8(line.c_str());
	if(qline!="EMPTY")
        ui->cbcaLine_2->setText(convSlash(qline));
	else
		ui->cbcaLine_2->setText("");
	getline(file, line);
	qline = QString::fromUtf8(line.c_str());
	if(qline!="EMPTY")
        ui->coLine->setText(convSlash(qline));
	else
		ui->coLine->setText("");
	getline(file, line);
	qline = QString::fromUtf8(line.c_str());
	if(qline!="EMPTY")
        ui->coLine_2->setText(convSlash(qline));
	else
		ui->coLine_2->setText("");

	getline(file, line);
	qline = QString::fromUtf8(line.c_str());
	if(qline!="EMPTY")
        ui->hsqcLine->setText(convSlash(qline));
	else
		ui->hsqcLine->setText("");
	getline(file, line);
	qline = QString::fromUtf8(line.c_str());
	if(qline!="EMPTY")
        ui->seqLine->setText(convSlash(qline));
	else
		ui->seqLine->setText("");
	getline(file, line);
	qline = QString::fromUtf8(line.c_str());
	if(qline!="EMPTY")
        ui->ssLine->setText(convSlash(qline));
	else
		ui->ssLine->setText("");

	getline(file, line);
	getline(file, line);
	int first = atoi(line.c_str());
	ui->firstBox->setValue(first);

	getline(file, line);
	qline = QString::fromUtf8(line.c_str());
	if(qline=="Double labeled")
	{
		int index = ui->deutBox->findText("Double labeled");
		ui->deutBox->setCurrentIndex(index);
	}
	else if(qline=="Partially deuterated")
	{
		int index = ui->deutBox->findText("Partially deuterated");
		ui->deutBox->setCurrentIndex(index);
	}
	else
	{
		int index = ui->deutBox->findText("Perdeuterated");
		ui->deutBox->setCurrentIndex(index);
	}
	getline(file, line);
	double m1 = atof(line.c_str());
	getline(file, line);
	double m2 = atof(line.c_str());
	getline(file, line);
	double m3 = atof(line.c_str());
	getline(file, line);
	int i1 = atoi(line.c_str());
	getline(file, line);
	int i2 = atoi(line.c_str());
	getline(file, line);
	int i3 = atoi(line.c_str());
	ui->devBox->setValue(m1);
	ui->devBox_2->setValue(m2);
	ui->devBox_3->setValue(m3);
	ui->fBox->setValue(i1);
	ui->fBox_2->setValue(i2);
	ui->fBox_3->setValue(i3);
	extern std::string SpinPar0;
	extern std::string SpinPar1;
	extern std::string SpinPar2;
	extern std::string SpinPar3;
	extern std::string SpinPar4;
	extern std::string SpinPar5;
	extern std::string SpinPar6;
	extern std::string SpinPar7;
	extern std::string SpinPar8;
	extern std::string SpinPar9;
	extern std::string SpinPar10;
	extern std::string SpinPar11;
	extern std::string refPar;
	getline(file,line);
	SpinPar0 = line;
	getline(file,line);
	SpinPar1 = line;
	getline(file,line);
	SpinPar2 = line;
	getline(file,line);
	SpinPar3 = line;
	getline(file,line);
	SpinPar4 = line;
	getline(file,line);
	SpinPar5 = line;
	getline(file,line);
	SpinPar6 = line;
	getline(file,line);
	SpinPar7 = line;
	getline(file,line);
	SpinPar8 = line;
	getline(file,line);
	SpinPar9 = line;
	getline(file,line);
	SpinPar10 = line;
	getline(file,line);
	SpinPar11 = line;
	getline(file,line);
	refPar = line;
    getline(file,line);
    QDir fold(QString::fromUtf8(line.c_str()));
    if (fold.exists())
        ui->folderLine->setText(QString::fromUtf8(line.c_str()));
    getline(file,line);
    ui->projectLine->setText(QString::fromUtf8(line.c_str()));
    file.clear();
	file.close();
}
void CompassQuery::on_folderButton_clicked()
{
    if(analyzing) return;
	QString path;
	QFileDialog dialog(this);
	dialog.setFileMode(QFileDialog::Directory);
	path = QFileDialog::getExistingDirectory(
	this,
	"Choose a directory",
	QString::null, QFileDialog::ShowDirsOnly);
	if(path.isNull() == false)
	{
		path+="/";
        ui->folderLine->setText(convSlash(path));
	}

}
void CompassQuery::on_caButton_clicked()		
{
    if(analyzing) return;
	QString path;					
	path = QFileDialog::getOpenFileName(		
	this,
    "Choose an HNCA(i)(i-1) file",
	QString::null,
	QString::null);
	if(path!="")					
    ui->caLine->setText(convSlash(path));
}
void CompassQuery::on_caButton_2_clicked()		
{
    if(analyzing) return;
	QString path;					
	path = QFileDialog::getOpenFileName(		
	this,
	"Choose an HNCA(i-1) file",			
	QString::null,
	QString::null);
	if(path!="")				
    ui->caLine_2->setText(convSlash(path));
    saveParam();
}
void CompassQuery::on_cbcaButton_clicked()
{
    if(analyzing) return;
	QString path;
	path = QFileDialog::getOpenFileName(
	this,
	"Choose an HNCB(i)(i-1) file",
	QString::null,
	QString::null);
	if(path!="")
    ui->cbcaLine->setText(convSlash(path));

}
void CompassQuery::on_menu_queryButton_clicked()
{
    if(analyzing) return;
    emit goToMain();
}

void CompassQuery::on_cbcaButton_2_clicked()
{
    if(analyzing) return;
	QString path;
	path = QFileDialog::getOpenFileName(
	this,
	"Choose an HNCB(i-1) file",
	QString::null,
	QString::null);
	if(path!="")
    ui->cbcaLine_2->setText(convSlash(path));

}
void CompassQuery::on_coButton_clicked()
{
    if(analyzing) return;
	QString path;
	path = QFileDialog::getOpenFileName(
	this,
	"Choose an HNCO(i)(i-1) file",
	QString::null,
	QString::null);
	if(path!="")
    ui->coLine->setText(convSlash(path));

}
void CompassQuery::on_coButton_2_clicked()
{
    if(analyzing) return;
	QString path;
	path = QFileDialog::getOpenFileName(
	this,
	"Choose an HNCO(i-1) file",
	QString::null,
	QString::null);
	if(path!="")
    ui->coLine_2->setText(convSlash(path));

}
void CompassQuery::on_hsqcButton_clicked()
{
    if(analyzing) return;
	QString path;
	path = QFileDialog::getOpenFileName(
	this,
	"Choose an HSQC file",
	QString::null,
	QString::null);
	if(path!="")
    ui->hsqcLine->setText(convSlash(path));

}
void CompassQuery::on_seqButton_clicked()
{
    if(analyzing) return;
	QString path;
	path = QFileDialog::getOpenFileName(
	this,
	"Choose a protein sequence file",
	QString::null,
	QString::null);
	if(path!="")
    ui->seqLine->setText(convSlash(path));

}
void CompassQuery::on_ssButton_clicked()
{
    if(analyzing) return;
	QString path;
	path = QFileDialog::getOpenFileName(
	this,
	"Choose a secondary structure file",
	QString::null,
	QString::null);
	if(path!="")
        ui->ssLine->setText(convSlash(path));

}
void CompassQuery::on_analyzeButton_clicked()
{
    if(analyzing) return;
    analyzing = true;
    disconnectAll();
    QString cafile, cbcafile, cofile, seq, ss, cmd_line, profile2, filenames;
    QString cafile2, cbcafile2, cofile2, hsqcfile, trosy, ssp_deut, folder, project;
    std::string cafileS, cbcafileS, cofileS, seqS, ssS, cafile2S, cbcafile2S, cofile2S, hsqcfileS;

    cafile = ui->caLine->text();
    cbcafile = ui->cbcaLine->text();
    cofile = ui->coLine->text();
    cafile2 = ui->caLine_2->text();
    cbcafile2 = ui->cbcaLine_2->text();
    cofile2 = ui->coLine_2->text();
    hsqcfile = ui->hsqcLine->text();
    folder = ui->folderLine->text();
    project = ui->projectLine->text();
    seq = ui->seqLine->text();
    ss = ui->ssLine->text();
    bool fileOk=true;
    std::ifstream file;
    extern QString invalid;

    QByteArray conv;
    conv=cafile.toUtf8();
    cafileS=conv.data();
    conv=cbcafile.toUtf8();
    cbcafileS=conv.data();
    conv=cofile.toUtf8();
    cofileS=conv.data();
    conv=cafile2.toUtf8();
    cafile2S=conv.data();
    conv=cbcafile2.toUtf8();
    cbcafile2S=conv.data();
    conv=cofile2.toUtf8();
    cofile2S=conv.data();
    conv=ss.toUtf8();
    ssS=conv.data();
    conv=seq.toUtf8();
    seqS=conv.data();
    conv=hsqcfile.toUtf8();
    hsqcfileS=conv.data();

    if( cbcafile=="" && cafile=="" && (cofile=="" || seq=="" || folder==""))
    {      
        fileOk=false;
        invalid="Please submit a protein sequence, a save directory, an HSQC file and at least one (i)(i-1) input file containing chemical shifts of CA, CB or CO.";
    }
    else if(hsqcfile=="")
    {
        fileOk=false;
        invalid="Please submit a protein sequence, a save directory, an HSQC file and at least one (i)(i-1) input file containing chemical shifts of CA, CB or CO.";
    }
    else if (seqS=="")
    {
       fileOk=false;
       invalid="The protein sequence is missing!\nAborting.";
    }
    if(fileOk==true && seqS!="")
    {
        file.open(seqS.c_str(), std::ios::in);
        if(!file.is_open())
        {
            fileOk=false;
            invalid="The protein sequence file is invalid.\nAborting.";
        }
        file.clear();
        file.close();
    }
    if(fileOk==true && cafileS!="" )
    {
        file.open(cafileS.c_str(), std::ios::in);
        if(!file.is_open())
        {
            fileOk=false;
            invalid="The HNCA(i)(i-1) file is invalid.\nAborting.";
        }
        file.clear();
        file.close();
    }
    if(fileOk==true && cafile2S!="" )
    {
        file.open(cafile2S.c_str(), std::ios::in);
        if(!file.is_open())
        {
            fileOk=false;
            invalid="The HNCA(i-1) file is invalid.\nAborting.";
        }
        file.clear();
        file.close();
    }
    if(fileOk==true && cbcafileS!="" )
    {
        file.open(cbcafileS.c_str(), std::ios::in);
        if(!file.is_open())
        {
            fileOk=false;
            invalid="The HNCB(i)(i-1) file is invalid.\nAborting.";
        }
        file.clear();
        file.close();
    }
    if(fileOk==true && cbcafile2S!="" )
    {
        file.open(cbcafile2S.c_str(), std::ios::in);
        if(!file.is_open())
        {
            fileOk=false;
            invalid="The HNCB(i-1) file is invalid.\nAborting.";
        }
        file.clear();
        file.close();
        }
    if(fileOk==true && cofileS!="" )
    {
        file.open(cofileS.c_str(), std::ios::in);
        if(!file.is_open())
        {
            fileOk=false;
            invalid="The HNCO(i)(i-1) file is invalid.\nAborting.";
        }
        file.clear();
        file.close();
    }
    if(fileOk==true && cofile2S!="" )
    {
        file.open(cofile2S.c_str(), std::ios::in);
        if(!file.is_open())
        {
            fileOk=false;
            invalid="The HNCO(i-1) file is invalid.\nAborting.";
        }
        file.clear();
        file.close();
    }
    if(fileOk==true && hsqcfileS!="" )
    {
        file.open(hsqcfileS.c_str(), std::ios::in);
        if(!file.is_open())
        {
            fileOk=false;
            invalid="The HSQC file is invalid.\nAborting.";
        }
        file.clear();
        file.close();
     }
    if(fileOk==true && ssS!="" )
     {
        file.open(ssS.c_str(), std::ios::in);
        if(!file.is_open())
        {
            fileOk=false;
            invalid="The secondary structure file is invalid.\nAborting.";
        }
        file.clear();
        file.close();
     }
    if(fileOk==true && folder!="" )
     {
        if(QDir(folder).exists()==false)
        {
            fileOk=false;
            invalid="The submitted folder does not exist.\nAborting";
        }
     }
    if(fileOk==true && project=="" )
     {
        fileOk=false;
        invalid="The project name is missing.\nAborting.";
     }
    if (fileOk==true && ui->projectLine->text()!="" )
     {
        QString check=checkProjectName(ui->projectLine->text());
        if (check!="")
        {
            invalid = check;
            fileOk=false;
        }
     }
    bool exist2=false;
    if (fileOk!=false)
    {
        QString qfolder = ui->folderLine->text();
        qfolder=makeSlashLast(qfolder);

        qfolder+=ui->projectLine->text();
        exist2=QDir(qfolder).exists();
    }
    if (fileOk==false)
    {
        QueryError4 winQE4;
        winQE4.setWindowModality(Qt::ApplicationModal);
        if(winQE4.exec())
        {
            analyzing = false;
            return;
        }

    }
    else if(exist2==true)
    {
         QueryError5 winQE5;
         winQE5.setWindowModality(Qt::ApplicationModal);
         if(winQE5.exec())
         {
             analysis();
             return;
         }
    }
    else
    {
        analysis();
        return;
    }
    analyzing = false;
}
void CompassQuery::analysis()
{
    extern bool running;
    running =true;
    bool cont =true;
    bool ssEx=true;
    QString devErr="";
    {
            extern bool abortBool;
            abortBool = false;
    }
    ui->abortButton->setEnabled(true);
    connect(ui->abortButton, SIGNAL(clicked()), this, SLOT(abortAnalysis()));

    extern int progress1, progress2, progress3, total1, total2, total3;
    progress1 = progress2 = progress3 = 0;
    total1 = total2 = total3 = 1;

    ui->doneBrowser->setText("");
    ui->progressBar->setValue(0);
    QApplication::processEvents();

    QString cafile, cbcafile, cofile, seq, ss, cmd_line, profile2, filenames, outname, outnameb, outnamec;
    std::string cafileS, cbcafileS, cofileS, seqS, ssS, cafile2S, cbcafile2S, cofile2S, hsqcfileS;
    QString cafile2, cbcafile2, cofile2, hsqcfile, trosy, ssp_deut, folder;
    std::string deutS;
    double dev, dev2, dev3;
    int first;

    if (ui->deutBox->currentText()=="Double labeled")
    {
        deutS="EMPTY";
        ssp_deut="EMPTY";
    }
    else if (ui->deutBox->currentText()=="Perdeuterated")
    {
        deutS="-D";
        ssp_deut="D";
    }
    else
    {
        deutS="-pD";
        ssp_deut="pD";
    }
    trosy="No";
    first = ui->firstBox->value();
    dev = ui->devBox->value();
    dev2= ui->devBox_2->value();
    dev3= ui->devBox_3->value();
    cafile = ui->caLine->text();
    cbcafile = ui->cbcaLine->text();
    cofile = ui->coLine->text();
    cafile2 = ui->caLine_2->text();
    cbcafile2 = ui->cbcaLine_2->text();
    cofile2 = ui->coLine_2->text();
    hsqcfile = ui->hsqcLine->text();
    folder = ui->folderLine->text();
    seq = ui->seqLine->text();
    ss = ui->ssLine->text();
    QByteArray conv;
    conv=cafile.toUtf8();
    cafileS=conv.data();
    conv=cbcafile.toUtf8();
    cbcafileS=conv.data();
    conv=cofile.toUtf8();
    cofileS=conv.data();
    conv=cafile2.toUtf8();
    cafile2S=conv.data();
    conv=cbcafile2.toUtf8();
    cbcafile2S=conv.data();
    conv=cofile2.toUtf8();
    cofile2S=conv.data();
    conv=ss.toUtf8();
    ssS=conv.data();
    conv=seq.toUtf8();
    seqS=conv.data();
    conv=hsqcfile.toUtf8();
    hsqcfileS=conv.data();

    QString rmcmd;
    QString cmd_line2;
    std::ifstream errorFile2;
    std::string line2;
    QByteArray nByte;
	extern QString profile;
    profile2 = folder;

    filenames = profile2;
    filenames = makeSlashLast(filenames);
    filenames+= ui->projectLine->text();
    filenames = makeSlashLast(filenames);

    profile = filenames;
	bool passed_format_check=false;
	bool errorQ=false;
	QString dErr="";
    QString format;
	
    	format=format_check(cafile.toStdString().c_str(), cafile2.toStdString().c_str(), cbcafile.toStdString().c_str(), cbcafile2.toStdString().c_str(), cofile.toStdString().c_str(), cofile2.toStdString().c_str(), hsqcfile.toStdString().c_str(), seq.toStdString().c_str(), ss.toStdString().c_str());
	if(format=="Passed")
		passed_format_check=true;
	else
	{
        extern QString FormatError;
        FormatError=format;
	}
	if(passed_format_check==true)
	{
		if(cafile!="")
			dErr= mconvert(checkDup(mconvert(cafile)));
		if(dErr=="" && cafile2!="")
			dErr= mconvert(checkDup(mconvert(cafile2)));
		if(dErr=="" && cbcafile!="")
			dErr= mconvert(checkDup(mconvert(cbcafile)));
		if(dErr=="" && cbcafile2!="")
			dErr= mconvert(checkDup(mconvert(cbcafile2)));
		if(dErr=="" && cofile!="")
			dErr= mconvert(checkDup(mconvert(cofile)));
		if(dErr=="" && cofile2!="")
			dErr= mconvert(checkDup(mconvert(cofile2)));
		if(dErr=="" && hsqcfile!="")
			dErr= mconvert(checkDup(mconvert(hsqcfile)));
		if(dErr!="")
			passed_format_check=false;
	}
	if(passed_format_check==true)
    {
        if(!QDir(filenames).exists())
        {
            QDir dir = QDir::root();
            dir.mkpath(filenames);
        }
        else
        {
            QString cain, cain2, cbin, cbin2, coin, coin2, hsqcin;
            cain = cafile.section("/",-1,-1);
            cain2 = cafile2.section("/",-1,-1);
            cbin = cbcafile.section("/",-1,-1);
            cbin2 = cbcafile2.section("/",-1,-1);
            coin = cofile.section("/",-1,-1);
            coin2 = cofile2.section("/",-1,-1);
            hsqcin = hsqcfile.section("/",-1,-1);
            delFile del;
            del.setList(makeSlashLast(ui->folderLine->text()), makeSlashLast(ui->projectLine->text()), cain, cain2, cbin, cbin2, coin, coin2, hsqcin);
        }
        QString mDir  = filenames;
        mDir += "Project_Files/";
        if(!QDir(mDir).exists())
        {
            QDir dir = QDir::root();
            dir.mkpath(mDir);
        }
        QString mDir2 = filenames;
        mDir2+="Analysis";
        if(!QDir(mDir2).exists())
        {
            QDir dir = QDir::root();
            dir.mkpath(mDir2);
        }
        mDir2 = filenames;
        mDir2+= "Temp";
        if(!QDir(mDir2).exists())
        {
            QDir dir = QDir::root();
            dir.mkpath(mDir2);
        }
        mDir2 = filenames;
        mDir2+= "Results";
        if(!QDir(mDir2).exists())
        {
            QDir dir = QDir::root();
            dir.mkpath(mDir2);
        }

        profile2 = makeSlashLast(profile2);
        profile2+= ui->projectLine->text();
        profile2 = makeSlashLast(profile2);
        outname=profile2%"Temp/outputfileXXXXXX.txt1";
        outnameb=profile2%"Temp/outputfileXXXXXX.txt2";
        outnamec=profile2%"Temp/outputfileXXXXXX.txt3";
        profile2+="Project_Files/";
        profile2+= ui->projectLine->text();
        profile2 += ".cpro";

		std::fstream proFile;

            QString cain, cain2, cbin, cbin2, coin, coin2, hsqcin;
	    if(cafile!="")
	            cain =mDir%cafile.section("/",-1,-1);
	    else
		    cain="";
	    if(cafile2!="")
	            cain2 = mDir%cafile2.section("/",-1,-1);
	    else
		    cain2="";
	    if(cbcafile!="")
	            cbin = mDir%cbcafile.section("/",-1,-1);
	    else
		    cbin="";
	    if(cbcafile2!="")
	            cbin2 = mDir%cbcafile2.section("/",-1,-1);
	    else
		    cbin2 = "";
	    if(cofile!="")
	            coin = mDir%cofile.section("/",-1,-1);
	    else
		    coin="";
	    if(cofile2!="")
	            coin2 = mDir%cofile2.section("/",-1,-1);
	    if(hsqcfile!="")
	            hsqcin = mDir%hsqcfile.section("/",-1,-1);
	    else
		    hsqcin="";

		proFile.open(profile2.toStdString().c_str(), std::ios::out);
		QString proname;
		proname = filenames;
		proFile<<proname.toStdString().c_str()<<"\n";


		std::fstream parF;
		std::string parN = proname.toStdString().c_str();
		parN+= "Project_Files/parameters.cpar";
		parF.open(parN.c_str(), std::ios::out);
		if(cafile=="")
		{
			proFile<<"EMPTY"<<"\n";
			parF<<"EMPTY"<<"\n";
		}
		else
		{
			proFile<<cain.toStdString().c_str()<<"\n";
			parF<<cafile.toStdString().c_str()<<"\n";
		}
		if(cafile2=="")
			parF<<"EMPTY"<<"\n";
		else
			parF<<cafile2.toStdString().c_str()<<"\n";
		if(cbcafile=="")
			parF<<"EMPTY"<<"\n";
		else
			parF<<cbcafile.toStdString().c_str()<<"\n";
		if(cbcafile2=="")
			parF<<"EMPTY"<<"\n";
		else
			parF<<cbcafile2.toStdString().c_str()<<"\n";
		if(cofile=="")
			parF<<"EMPTY"<<"\n";
		else
			parF<<cofile.toStdString().c_str()<<"\n";
		if(cofile2=="")
			parF<<"EMPTY"<<"\n";
		else
			parF<<cofile2.toStdString().c_str()<<"\n";
		if(hsqcfile=="")
			parF<<"EMPTY"<<"\n";
		else
			parF<<hsqcfile.toStdString().c_str()<<"\n";
		if(seq=="")
			parF<<"EMPTY"<<"\n";
		else
			parF<<seq.toStdString().c_str()<<"\n";
		if(ss=="")
			parF<<"EMPTY"<<"\n";
		else
            parF<<ss.toStdString().c_str()<<"\n";
		parF<<trosy.toStdString().c_str()<<"\n";
		int firstP = ui->firstBox->value();
		std::stringstream conv2;
		conv2 << firstP;
		std::string firstS; 
		conv2 >> firstS;
        parF<<firstS<<"\n";
		if (ui->deutBox->currentText()=="Double labeled")
			parF<<"Double labeled\n";
		else if (ui->deutBox->currentText()=="Perdeuterated")
			parF<<"Perdeuterated\n";
		else
			parF<<"Partially deuterated\n";

		double m1d = ui->devBox->value();
		double m2d = ui->devBox_2->value();
		double m3d = ui->devBox_3->value();
		parF<<m1d<<"\n";
		parF<<m2d<<"\n";
		parF<<m3d<<"\n";
		int m1i = ui->fBox->value();
		int m2i = ui->fBox_2->value();
		int m3i = ui->fBox_3->value();
		parF<<m1i<<"\n";
		parF<<m2i<<"\n";
		parF<<m3i<<"\n";
		extern std::string SpinPar0;
		extern std::string SpinPar1;
		extern std::string SpinPar2;
		extern std::string SpinPar3;
		extern std::string SpinPar4;
		extern std::string SpinPar5;
		extern std::string SpinPar6;
		extern std::string SpinPar7;
		extern std::string SpinPar8;
		extern std::string SpinPar9;
		extern std::string SpinPar10;
		extern std::string SpinPar11;
		extern std::string refPar;
		parF<<SpinPar0<<"\n";
		parF<<SpinPar1<<"\n";
		parF<<SpinPar2<<"\n";
		parF<<SpinPar3<<"\n";
		parF<<SpinPar4<<"\n";
		parF<<SpinPar5<<"\n";
		parF<<SpinPar6<<"\n";
		parF<<SpinPar7<<"\n";
		parF<<SpinPar8<<"\n";
		parF<<SpinPar9<<"\n";
		parF<<SpinPar10<<"\n";
		parF<<SpinPar11<<"\n";
		parF<<refPar<<"\n";
        parF<<makeSlashLast(ui->folderLine->text()).toUtf8().data()<<"\n";
        parF<<ui->projectLine->text().toUtf8().data()<<"\n";
        parF.clear();
		parF.close();

		if(cbcafile=="")
			proFile<<"EMPTY"<<"\n";
		else
			proFile<<cbin.toStdString().c_str()<<"\n";
		if(cofile=="")
			proFile<<"EMPTY"<<"\n";
		else
			proFile<<coin.toStdString().c_str()<<"\n";
		proFile<<seq.toStdString().c_str()<<"\n";
		proFile<<first<<"\n";
		if(cafile2=="")
			proFile<<"EMPTY"<<"\n";
		else
			proFile<<cain2.toStdString().c_str()<<"\n";
		if(cbcafile2=="")
			proFile<<"EMPTY"<<"\n";
		else
			proFile<<cbin2.toStdString().c_str()<<"\n";
		if(cofile2=="")
			proFile<<"EMPTY"<<"\n";
		else
			proFile<<coin2.toStdString().c_str()<<"\n";
		if(hsqcfile=="")
			proFile<<"EMPTY"<<"\n";
		else
			proFile<<hsqcin.toStdString().c_str()<<"\n";
		proFile<<ssp_deut.toStdString().c_str()<<"\n";
		proFile<<trosy.toStdString().c_str()<<"\n";
		if(ss=="")
			proFile<<"EMPTY"<<"\n";
		else
			proFile<<ss.toStdString().c_str()<<"\n";
        proFile<<"PRE\n";

		proFile.clear();
		proFile.close();

        ui->doneBrowser->setAlignment(Qt::AlignRight);
        ui->doneBrowser->setText("\tAnalyzing");
        QApplication::processEvents();
        std::string filenamesS;
		extern QString match23;
        double dev_temp=0.0;

	if(cain!="")
	{
		if(QFile::exists(cain))
			QFile::remove(cain);
		convertFiles(cafile, cain);
	}
	if(cain2!="")
	{
		if(QFile::exists(cain2))
			QFile::remove(cain2);
		convertFiles(cafile2, cain2);
	}
	if(cbin!="")
	{
		if(QFile::exists(cbin))
			QFile::remove(cbin);
		convertFiles(cbcafile, cbin);
	}
	if(cbin2!="")
	{
		if(QFile::exists(cbin2))
			QFile::remove(cbin2);
		convertFiles(cbcafile2, cbin2);
	}
	if(coin!="")
	{
		if(QFile::exists(coin))
			QFile::remove(coin);
		convertFiles(cofile, coin);
	}
	if(coin2!="")
	{
		if(QFile::exists(coin2))
			QFile::remove(coin2);
		convertFiles(cofile2, coin2);
	}
	if(hsqcin!="")
	{
		if(QFile::exists(hsqcin))
			QFile::remove(hsqcin);
		convertFiles(hsqcfile, hsqcin);
	}

	cafile=cain;
	cafile2=cain2;
	cbcafile=cbin;
	cbcafile2=cbin2;
	cofile=coin;
	cofile2=coin2;
	hsqcfile=hsqcin;
		if(errorQ==false)	
        {
            if(cafile=="")
            {
                cafileS="EMPTY";
            }
            else
            {
                nByte=cafile.toUtf8();
                cafileS=nByte.data();
            }
            if(cbcafile=="")
            {
                cbcafileS="EMPTY";
            }
            else
            {
                nByte=cbcafile.toUtf8();
                cbcafileS=nByte.data();
            }

            if(cofile=="")
            {
                cofileS="EMPTY";
            }
            else
            {
                nByte=cofile.toUtf8();
                cofileS=nByte.data();
            }
            if(cafile2=="")
                cafile2S="EMPTY";
            else
            {
                nByte=cafile2.toUtf8();
                cafile2S=nByte.data();
            }
            if(cbcafile2=="")
                cbcafile2S="EMPTY";
            else
            {
                nByte=cbcafile2.toUtf8();
                cbcafile2S=nByte.data();
            }
            if(cofile2=="")
                cofile2S="EMPTY";
            else
            {
                nByte=cofile2.toUtf8();
                cofile2S=nByte.data();
            }
            nByte=seq.toUtf8();
            seqS=nByte.data();
		
            if (ss=="")
                ssS="EMPTY";
            else
            {
                nByte=ss.toUtf8();
                ssS=nByte.data();
            }
            if(ssS=="EMPTY")
                ssEx=false;
            nByte=filenames.toUtf8();
            filenamesS=nByte.data();
            dev_temp=dev;

            std::string arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg13, arg14, arg15, arg16;
            int arg10, arg11, arg17;
            double arg12;

            arg1=cafileS;
            arg2=cbcafileS;
            arg3=cofileS;
            arg4=cafile2S;
            arg5=cbcafile2S;
            arg6=cofile2S;
            arg7=seqS;
            arg8=ssS;
            arg9=deutS;
            arg10=1;
            arg11=first;
            arg12=dev_temp;
            arg13=filenamesS;
            arg14=arg15=arg16="EMPTY";
            arg17=m1i;
            std::string tempCopy;
            QString c1, c2;
            if(arg1!="EMPTY")
            {
                tempCopy=arg1+".tmp";
               c1= QString::fromUtf8(arg1.c_str());
                c2= QString::fromUtf8(tempCopy.c_str());
                QFile::copy(c1, c2);
                arg1 +=".tmp";
            }
            if(arg2!="EMPTY")
            {
                tempCopy=arg2+".tmp";
                c1= QString::fromUtf8(arg2.c_str());
                c2= QString::fromUtf8(tempCopy.c_str());
                QFile::copy(c1, c2);
                arg2 +=".tmp";
            }
            if(arg3!="EMPTY")
            {
                tempCopy=arg3+".tmp";
                c1= QString::fromUtf8(arg3.c_str());
                c2= QString::fromUtf8(tempCopy.c_str());
                QFile::copy(c1, c2);
                arg3 +=".tmp";
            }
            if(arg4!="EMPTY")
            {
                tempCopy=arg4+".tmp";
                c1= QString::fromUtf8(arg4.c_str());
                c2= QString::fromUtf8(tempCopy.c_str());
                QFile::copy(c1, c2);
                arg4 +=".tmp";
            }
            if(arg5!="EMPTY")
            {
                tempCopy=arg5+".tmp";
                c1= QString::fromUtf8(arg5.c_str());
                c2= QString::fromUtf8(tempCopy.c_str());
                QFile::copy(c1, c2);
                arg5 +=".tmp";
            }
            if(arg6!="EMPTY")
            {
                tempCopy=arg6+".tmp";
                c1= QString::fromUtf8(arg6.c_str());
                c2= QString::fromUtf8(tempCopy.c_str());
                QFile::copy(c1, c2);
                arg6 +=".tmp";
            }
            if(arg7!="EMPTY")
            {
                tempCopy=arg7+".tmp";
                c1= QString::fromUtf8(arg7.c_str());
                c2= QString::fromUtf8(tempCopy.c_str());
                QFile::copy(c1, c2);
                arg7 +=".tmp";
            }
            if(arg8!="EMPTY")
            {
                tempCopy=arg8+".tmp";
                c1= QString::fromUtf8(arg8.c_str());
                c2= QString::fromUtf8(tempCopy.c_str());
                QFile::copy(c1, c2);
                arg8 +=".tmp";
            }
            if(arg14!="EMPTY")
            {
                tempCopy=arg14+".tmp";
                c1= QString::fromUtf8(arg14.c_str());
                c2= QString::fromUtf8(tempCopy.c_str());
                QFile::copy(c1, c2);
                arg14 +=".tmp";
            }
            if(arg15!="EMPTY")
            {
                tempCopy=arg15+".tmp";
                c1= QString::fromUtf8(arg15.c_str());
                c2= QString::fromUtf8(tempCopy.c_str());
               QFile::copy(c1, c2);
                arg15 +=".tmp";
            }
            if(arg16!="EMPTY")
            {
                tempCopy=arg16+".tmp";
                c1= QString::fromUtf8(arg16.c_str());
                c2= QString::fromUtf8(tempCopy.c_str());
                QFile::copy(c1, c2);
                arg16 +=".tmp";
            }
            double dev_temp=arg12;
            int retVal=0;
            while(retVal==0 || retVal==2)
            {
                retVal=compass_analyze(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, dev_temp, arg13, arg14, arg15, arg16, arg17);
                if(retVal==0)
                {
                    dev_temp-=0.01;
                }
                else if(retVal==2)
                {
                    dev_temp+=0.01;
                }
                if(dev_temp >20 )
                {
                    devErr = "Deviation is too high. Check that you have included (i) and (i-1) shifts for at least one of CA, CB or CO.";
                }
                QApplication::processEvents();
            }
            if(arg1!="EMPTY")
                remove(arg1.c_str());
            if(arg2!="EMPTY")
                remove(arg2.c_str());
            if(arg3!="EMPTY")
                remove(arg3.c_str());
            if(arg4!="EMPTY")
                remove(arg4.c_str());
            if(arg5!="EMPTY")
                remove(arg5.c_str());
            if(arg6!="EMPTY")
                remove(arg6.c_str());
            if(arg7!="EMPTY")
                remove(arg7.c_str());
            if(arg8!="EMPTY")
                remove(arg8.c_str());
            if(arg14!="EMPTY")
                remove(arg14.c_str());
            if(arg15!="EMPTY")
                remove(arg15.c_str());
            if(arg16!="EMPTY")
                remove(arg16.c_str());
        }
        if(errorQ==false && devErr=="" && (match23=="4" || match23=="6"))
        {
            dev_temp=dev2;
            std::string arg1b, arg2b, arg3b, arg4b, arg5b, arg6b, arg7b, arg8b, arg9b, arg13b, arg14b, arg15b, arg16b;
            int arg10b, arg11b, arg17b;
            double arg12b;

            arg1b=cafileS;
            arg2b=cbcafileS;
            arg3b=cofileS;
            arg4b=cafile2S;
            arg5b=cbcafile2S;
            arg6b=cofile2S;
            arg7b=seqS;
            arg8b=ssS;
            arg9b=deutS;
            arg10b=2;
            arg11b=first;
            arg12b=dev_temp;
            arg13b=filenamesS;
            arg14b=arg15b=arg16b="EMPTY";
            arg17b=m2i;
            std::string tempCopyb;
            QString c1b, c2b;

            if(arg1b!="EMPTY")
            {
                tempCopyb=arg1b+".tmp2";
                c1b= QString::fromUtf8(arg1b.c_str());
                c2b= QString::fromUtf8(tempCopyb.c_str());
                QFile::copy(c1b, c2b);
                arg1b +=".tmp2";
            }
            if(arg2b!="EMPTY")
            {
                tempCopyb=arg2b+".tmp2";
                c1b= QString::fromUtf8(arg2b.c_str());
                c2b= QString::fromUtf8(tempCopyb.c_str());
                QFile::copy(c1b, c2b);
                arg2b +=".tmp2";
            }
            if(arg3b!="EMPTY")
            {
                tempCopyb=arg3b+".tmp2";
                c1b= QString::fromUtf8(arg3b.c_str());
                c2b= QString::fromUtf8(tempCopyb.c_str());
                QFile::copy(c1b, c2b);
                arg3b +=".tmp2";
            }
            if(arg4b!="EMPTY")
            {
                tempCopyb=arg4b+".tmp2";
                c1b= QString::fromUtf8(arg4b.c_str());
                c2b= QString::fromUtf8(tempCopyb.c_str());
                QFile::copy(c1b, c2b);
                arg4b +=".tmp2";
            }
            if(arg5b!="EMPTY")
            {
                tempCopyb=arg5b+".tmp2";
                c1b= QString::fromUtf8(arg5b.c_str());
                c2b= QString::fromUtf8(tempCopyb.c_str());
                QFile::copy(c1b, c2b);
                arg5b +=".tmp2";
            }
            if(arg6b!="EMPTY")
            {
                tempCopyb=arg6b+".tmp2";
                c1b= QString::fromUtf8(arg6b.c_str());
                c2b= QString::fromUtf8(tempCopyb.c_str());
                QFile::copy(c1b, c2b);
                arg6b +=".tmp2";
            }
            if(arg7b!="EMPTY")
            {
                tempCopyb=arg7b+".tmp2";
                c1b= QString::fromUtf8(arg7b.c_str());
                c2b= QString::fromUtf8(tempCopyb.c_str());
                QFile::copy(c1b, c2b);
                arg7b +=".tmp2";
            }
            if(arg8b!="EMPTY")
            {
                tempCopyb=arg8b+".tmp2";
                c1b= QString::fromUtf8(arg8b.c_str());
                c2b= QString::fromUtf8(tempCopyb.c_str());
                QFile::copy(c1b, c2b);
                arg8b +=".tmp2";
            }
            if(arg14b!="EMPTY")
            {
                tempCopyb=arg14b+".tmp2";
                c1b= QString::fromUtf8(arg14b.c_str());
                c2b= QString::fromUtf8(tempCopyb.c_str());
                QFile::copy(c1b, c2b);
                arg14b +=".tmp2";
            }
            if(arg15b!="EMPTY")
            {
                tempCopyb=arg15b+".tmp2";
                c1b= QString::fromUtf8(arg15b.c_str());
                c2b= QString::fromUtf8(tempCopyb.c_str());
                QFile::copy(c1b, c2b);
                arg15b +=".tmp2";
            }
            if(arg16b!="EMPTY")
            {
                tempCopyb=arg16b+".tmp2";
                c1b= QString::fromUtf8(arg16b.c_str());
                c2b= QString::fromUtf8(tempCopyb.c_str());
                QFile::copy(c1b, c2b);
                arg16b +=".tmp2";
            }
            double dev_temp=arg12b;
            int retVal=0;
            while(retVal==0 || retVal==2)
            {
                retVal=compass_analyzeb(arg1b, arg2b, arg3b, arg4b, arg5b, arg6b, arg7b, arg8b, arg9b, arg10b, arg11b, dev_temp, arg13b, arg14b, arg15b, arg16b, arg17b);
                if(retVal==0)
                {
                    dev_temp-=0.01;
                }
                else if(retVal==2)
                {
                    dev_temp+=0.01;
                }
                if (dev_temp >20 )
                {
                    devErr = "Deviation is too high. Check that you have included (i) and (i-1) shifts for at least one of CA, CB or CO.";
                    break;
                }
                QApplication::processEvents();
             }
            if(arg1b!="EMPTY")
                remove(arg1b.c_str());
            if(arg2b!="EMPTY")
                remove(arg2b.c_str());
            if(arg3b!="EMPTY")
                remove(arg3b.c_str());
            if(arg4b!="EMPTY")
                remove(arg4b.c_str());
            if(arg5b!="EMPTY")
                remove(arg5b.c_str());
            if(arg6b!="EMPTY")
                remove(arg6b.c_str());
            if(arg7b!="EMPTY")
                remove(arg7b.c_str());
            if(arg8b!="EMPTY")
                remove(arg8b.c_str());
            if(arg14b!="EMPTY")
                remove(arg14b.c_str());
            if(arg15b!="EMPTY")
                remove(arg15b.c_str());
            if(arg16b!="EMPTY")
                remove(arg16b.c_str());
        }
        if(devErr=="" && errorQ==false && match23=="6")
        {
            dev_temp=dev3;
            std::string arg1c, arg2c, arg3c, arg4c, arg5c, arg6c, arg7c, arg8c, arg9c, arg13c, arg14c, arg15c, arg16c;
            int arg10c, arg11c, arg17c;
            double arg12c;

            arg1c=cafileS;
            arg2c=cbcafileS;
            arg3c=cofileS;
            arg4c=cafile2S;
            arg5c=cbcafile2S;
            arg6c=cofile2S;
            arg7c=seqS;
            arg8c=ssS;
            arg9c=deutS;
            arg10c=3;
            arg11c=first;
            arg12c=dev_temp;
            arg13c=filenamesS;
            arg14c=arg15c=arg16c="EMPTY";
            arg17c=m3i;

            double dev_temp=arg12c;
            int retVal=0;
            while(retVal==0 || retVal==2)
            {
                retVal=compass_analyzec(arg1c, arg2c, arg3c, arg4c, arg5c, arg6c, arg7c, arg8c, arg9c, arg10c, arg11c, dev_temp, arg13c, arg14c, arg15c, arg16c, arg17c);
                if(retVal==0)
                {
                    dev_temp-=0.01;
                }
                else if(retVal==2)
                {
                    dev_temp+=0.01;
                }
                if (devErr!="" || dev_temp >20 )
                {
                    devErr = "Deviation is too high. Check that you have included (i) and (i-1) shifts for at least one of CA, CB or CO.";
                    break;
                }
                QApplication::processEvents();
            }
        }
        //outputfiler har skapats för alla matcher
            //analyserar outputfiler
        if(devErr=="")
        {
            std::vector< std::string > str;
            str.resize(3,"");
            std::string line;
            str[0]="0";
            std::vector< std::vector< std::string > > fragVec;
            std::vector< std::vector< std::string > > fragVec2;
            std::vector< std::vector< std::string > > fragVec3;
            std::ifstream fragFile;
            std::string fname = outname.toUtf8().data();
            fragFile.open(fname.c_str(), std::ios::in);
            while(getline(fragFile, line))
            {
                str[1]=line;
                std::istringstream iss(line);
                std::string sub, sub2, sub3;
                sub3=sub2=sub="";
                while(iss>>sub)
                {
                    if(sub=="-seq")
                    {
                        str[2]="1"+sub3.substr(3);
                        break;
                    }
                    sub3=sub2;
                    sub2=sub;
                }
                fragVec.push_back(str);
            }
            fragFile.clear();
            fragFile.close();

            if(match23=="4" || match23=="6")
            {
                fname = outnameb.toUtf8().data();
                fragFile.open(fname.c_str(), std::ios::in);
                while(getline(fragFile, line))
                {
                    str[1]=line;
                    std::istringstream iss(line);
                    std::string sub, sub2, sub3;
                    sub3=sub2=sub="";
                    while(iss>>sub)
                    {
                        if(sub=="-seq")
                        {
                            str[2]="2"+sub3.substr(3);
                            break;
                        }
                        sub3=sub2;
                        sub2=sub;
                    }
                    fragVec2.push_back(str);
                }
                fragFile.clear();
                fragFile.close();
            }
            if(match23=="6")
            {
                fname = outnamec.toUtf8().data();
                fragFile.open(fname.c_str(), std::ios::in);
                while(getline(fragFile, line))
                {
                    str[1]=line;
                    std::istringstream iss(line);
                    std::string sub, sub2, sub3;
                    sub3=sub2=sub="";
                    while(iss>>sub)
                    {
                        if(sub=="-seq")
                        {
                            str[2]="3"+sub3.substr(3);
                            break;
                        }
                        sub3=sub2;
                        sub2=sub;
                    }
                    fragVec3.push_back(str);
                }
                fragFile.clear();
                fragFile.close();
            }

            std::vector <std::string> ss_sequence;
            std::string sub_temp;
            std::ifstream sfile;
            if(ss!="EMPTY")
            {
                sfile.open(ssS.c_str(), ios::in);
                while(sfile>>sub_temp)
                    ss_sequence.push_back(sub_temp);
                sfile.clear();
                sfile.close();
            }


            std::vector <std::string> seq_sequence;
            sfile.open(seqS.c_str(), ios::in);
            while(sfile>>sub_temp)
                seq_sequence.push_back(sub_temp);
            sfile.clear();
            sfile.close();

            int total;
            total = fragVec.size()+fragVec2.size()+fragVec3.size();
            //Threaded analysis
            Thread *t1 = new Thread(fragVec, 1, filenamesS, ss_sequence, seq_sequence);
            Thread *t2 = new Thread(fragVec2, 2, filenamesS, ss_sequence, seq_sequence);
            Thread *t3 = new Thread(fragVec3, 3, filenamesS, ss_sequence, seq_sequence);
            extern int p1, p2, p3;
            p1=0;
            p2=0;
            p3=0;
            t1->start();
            t2->start();
            t3->start();
            while(t1->isRunning() || t2->isRunning() || t3->isRunning())
            {
                ui->progressBar->setValue(100*(p1+p2+p3)/total);
                ui->doneBrowser->setText("\tAnalyzing ("+QString::number(p1+p2+p3)+"/"+QString::number(total)+")");
                QApplication::processEvents();
            }
            t1->wait();
            t2->wait();
            t3->wait();

           //End thread
            extern bool abortBool;
            if(abortBool==false)
            {
                sortLists(1, filenamesS);
                htmlfile(filenamesS, 1, ssEx);
                if(fragVec2.size()>0)
                {
                    sortListsb(2, filenamesS);
                    htmlfile2(filenamesS, 2, ssEx);
                }
                if(fragVec3.size()>0)
                {
                    sortListsb(3, filenamesS);
                    htmlfile3(filenamesS, 3, ssEx);
                }
            }          //end match3
        }
        //all analys är klar
        extern bool abortBool;
        if(abortBool)
        {
            ui->progressBar->setValue(0);
            ui->doneBrowser->setText("\tAnalysis is aborted!\n");
        }
        else if (devErr=="")
        {
            ui->progressBar->setValue(100);
            ui->doneBrowser->setText("\tAnalysis is done!\n");
        }
        else
        {
            extern QString FormatError;
            FormatError=devErr;
            QueryFormatError winQFE;
            winQFE.setWindowModality(Qt::ApplicationModal);
            if(winQFE.exec())
                FormatError=devErr;
        }
    }
    else if(dErr=="")
    {
        QueryFormatError winQFE;
        winQFE.setWindowModality(Qt::ApplicationModal);
        if(winQFE.exec())
            dErr="";
    }
	else
	{
		extern QString FormatError;
        FormatError=dErr;
        QueryFormatError winQFE;
        winQFE.setWindowModality(Qt::ApplicationModal);
        if(winQFE.exec())
            FormatError=dErr;
	}
    //abort analysis
    if(cont==false)
    {
        QString cain, cain2, cbin, cbin2, coin, coin2, hsqcin;
        cain = cafile.section("/",-1,-1);
        cain2 = cafile2.section("/",-1,-1);
        cbin = cbcafile.section("/",-1,-1);
        cbin2 = cbcafile2.section("/",-1,-1);
        coin = cofile.section("/",-1,-1);
        coin2 = cofile2.section("/",-1,-1);
        hsqcin = hsqcfile.section("/",-1,-1);
        delFile del;
        del.setList(makeSlashLast(ui->folderLine->text()), makeSlashLast(ui->projectLine->text()), cain, cain2, cbin, cbin2, coin, coin2, hsqcin);

    }
    else
        disconnect(ui->abortButton, SIGNAL(clicked()), this, SLOT(abortAnalysis()));

    ui->abortButton->setDisabled(true);
    connectAll();
    running =false;
    analyzing = false;
}
void Thread::run()
{
    if(match==1)
    {
        for(uint b=0; b<fV.size(); b++)
        {
            extern bool abortBool;
            if (abortBool==true)
                break;
            int counting_times =b;
            ShiftType shifts;
            ParserType parser;
            std::string a[1000];
            int fill=0;
            int wc;
            std::istringstream iss(fV[b][1]);
            std::string sub;
            while(iss>>sub)
            {
                a[fill]=sub;
                fill++;
            }
            wc = fill;
            parser.parse(wc, a, b+1, 0, counting_times, 1, fname, ss, seq);
            CalcScoreType score(parser);
            shifts.setShifts();
            score.calcScore(shifts, wc, a, b+1);
            extern int p1;
            p1=b;
        }
    }
    else if(match==2)
    {
        for(uint b=0; b<fV.size(); b++)
        {
            extern bool abortBool;
            if (abortBool==true)
                break;
            int counting_times =b;
            ShiftTypeb shiftsb;
            ParserTypeb parserb;
            std::string a[1000];
            int fill=0;
            int wc;
            std::istringstream iss(fV[b][1]);
            std::string sub;
            while(iss>>sub)
            {
                a[fill]=sub;
                fill++;
            }
            wc = fill;
            parserb.parse(wc, a, b+1, 0, counting_times, 2, fname, ss, seq);
            CalcScoreTypeb scoreb(parserb);
            shiftsb.setShifts();
            scoreb.calcScore(shiftsb, wc, a, b+1);
            extern int p2;
            p2=b;
        }
    }
    else
    {
        for(uint b=0; b<fV.size(); b++)
        {
            extern bool abortBool;
            if (abortBool==true)
                break;
            int counting_times =b;
            ShiftTypec shiftsc;
            ParserTypec parserc;

            std::string a[1000];
            int fill=0;
            int wc;
            std::istringstream iss(fV[b][1]);
            std::string sub;
            while(iss>>sub)
            {
                a[fill]=sub;
                fill++;
            }
            wc = fill;
            parserc.parse(wc, a, b+1, 0, counting_times, 3, fname, ss, seq);
            CalcScoreTypec scorec(parserc);
            shiftsc.setShifts();
            scorec.calcScore(shiftsc, wc, a, b+1);
            extern int p3;
            p3=b;
        }
    }
}


void CompassQuery::abortAnalysis()
{
    extern int abortInt;
    abortInt++;
    if(abortInt==1)
    {
        disconnect(ui->abortButton, SIGNAL(clicked()), this, SLOT(abortAnalysis()));
        connect(ui->abortButton, SIGNAL(clicked()), this, SLOT(abortAnalysis2()));
        ui->doneBrowser->setText("\tClick again to abort\n");
        for(int i=0; i<5000; i++)
        {
            QApplication::processEvents();
            usleep(1000);
        }
        nullTimer();
    }

}
void CompassQuery::abortAnalysis2()
{
        disconnect(ui->abortButton, SIGNAL(clicked()), this, SLOT(abortAnalysis2()));
        ui->abortButton->setDisabled(true);
        QApplication::processEvents();
        extern bool abortBool;
        abortBool= true;
        ui->doneBrowser->setText("\tAborting analysis!\n");
}
void CompassQuery::nullTimer()
{
    extern int abortInt;
    abortInt = 0;
    extern bool abortBool;
    disconnect(ui->abortButton, SIGNAL(clicked()), this, SLOT(abortAnalysis2()));
    if(abortBool==false)
        connect(ui->abortButton, SIGNAL(clicked()), this, SLOT(abortAnalysis()));
    if(abortBool==false)
        ui->doneBrowser->setText("\tAnalyzing\n");
}
void CompassQuery::convertFiles(QString in, QString out)
{
	int counter = mcountlines(mconvert(in));
	std::ofstream fileO;
	std::ifstream file;
	file.open(mconvert(in).c_str(), std::ios::in);
	fileO.open(mconvert(out).c_str(), std::ios::out);
	std::string line;
	for(int i=0; i<counter; i++)
	{
		getline(file, line);
		fileO<<line<<"\n";
	}
	getline(file, line);
	std::istringstream iss(line);
	std::string sub;
	while(iss>>sub)
		fileO<<sub<<" ";
	file.clear();
	file.close();
	fileO.clear();
	fileO.close();
}
std::string CompassQuery::checkDup(std::string in)
{
	std::vector<std::string> vec;
	std::ifstream file;
	file.open(in.c_str(), std::ios::in);
	std::string line;
	getline(file, line);
	getline(file, line);
	while(getline(file, line))
	{
		std::istringstream iss(line);
		std::string sub;
		iss>>sub;
		vec.push_back(sub);
	}
	file.clear();
	file.close();
	for(unsigned int i=0; i<vec.size(); i++)
		for(unsigned int j=i+1; j<vec.size(); j++)
			if(vec[i]==vec[j])
			{
				return vec[j]+" in "+in+" is a duplicate. Please check your input file.";
			}
	return "";
}

void CompassQuery::on_clearFormButton_clicked()
{
    clear_form();
}

void CompassQuery::on_loadParamButton_clicked()
{
    loadParams();
}

void CompassQuery::on_quit_queryButton_clicked()
{
    QApplication::quit();
}

void CompassQuery::on_query_helpButton_clicked()
{
    if(analyzing) return;
    CompassHelp winCA;
    winCA.setWindowModality(Qt::ApplicationModal);
    if(winCA.exec())
        return;
}
