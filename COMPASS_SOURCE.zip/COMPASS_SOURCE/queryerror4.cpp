#include "queryerror4.h"
#include "ui_queryerror4.h"
#include <cstdlib>
#include "QRect"	
#include "QDesktopWidget"	
#include <fstream>
#include <iostream>
#include "globals.h"

QueryError4::QueryError4(QWidget *parent) :
    QDialog(parent),
	ui(new Ui::QueryError4)
{
	ui->setupUi(this);
	errorSet();
}

QueryError4::~QueryError4()
{
	delete ui;
}
void QueryError4::errorSet()
{
	extern QString invalid;
	ui->errorBrowser4->setText(invalid);
}
void QueryError4::on_closeErrButton2_clicked()
{
    accept();
}
