#ifndef CSEDIT_H
#define CSEDIT_H

#include <QDialog>
#include "globals.h"
#include "iostream"
#include "fstream"
#include "cstdlib"
#include "sstream"
#include "mfunc.h"

namespace Ui {
class CSedit;
}

class CSedit : public QDialog
{
    Q_OBJECT

public:
    explicit CSedit(QWidget *parent = 0);
    ~CSedit();

private:
    Ui::CSedit *ui;
    int curr1, curr2;
    std::vector<std::vector<std::string> > csVec;

private slots:
    void on_cancelButton_clicked();
    void on_defaultButton_clicked();
    void on_saveButton_clicked();
    void setup();
    void validate(QTableWidgetItem * item1);
    void activeCell(int row,int col);
    void on_helpButton_clicked();
    void readChanges(std::string root);
};

#endif // CSEDIT_H
