#include "compasshelp6.h"
#include "ui_compasshelp6.h"
#include <QtWidgets>

CompassHelp6::CompassHelp6(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CompassHelp6)
{
	ui->setupUi(this);
}

CompassHelp6::~CompassHelp6()
{
	delete ui;
}

void CompassHelp6::on_closeButton_clicked()
{
    accept();
}
