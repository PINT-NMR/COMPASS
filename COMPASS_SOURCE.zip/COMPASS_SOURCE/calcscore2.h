#ifndef CALCSCORE2_H
#define CALCSCORE2_H
#include "passdef.h"
#include "globals.h"
#include "compassvec.h"
#include "mfunc.h"

struct ResultType {
    double score;
    int resno;
	string res[MAX_RES];
	string ss[MAX_RES];
};

struct CalcScoreType2
{
    double ca[MAX_RES], cb[MAX_RES], co[MAX_RES], CA[MAX_RES], CB[MAX_RES], CO[MAX_RES];
    CompassVec cadb; CompassVec cbdb; CompassVec codb;
	
	int CHI;			
	int resultNO;
	ResultType top[MAX_TOP];    
    int max_result;
	int counting;				
	int matchno;
	string filenames;
        double deuter;
    double pdeuter;
	vector<string> ss_sequence;	
	vector<string> sequence;
    int firstRes;
	bool ss_exist;
    double tempScore;
   	CalcScoreType2(ParserType2 &parser) 
	{
		for (int i=0; i<MAX_RES; i++) { 
		    ca[i] = CA[i] = parser.ca[i];
		    cb[i] = CB[i] = parser.cb[i];
		    co[i] = CO[i] = parser.co[i];
		}
		firstRes = 1;
		sequence = parser.sequence;
        	deuter = parser.deuter;
		pdeuter= parser.pdeuter;
        	max_result = 20;
        cadb = CompassVec(MAX_RES);
        cbdb = CompassVec(MAX_RES);
        codb = CompassVec(MAX_RES);
		for (int i=0; i<MAX_TOP; i++) {
	        top[i].score = 1.e99;
	        top[i].resno = 1;
			for (int j=0; j<MAX_RES; j++) {
	            top[i].res[j] = "ALA";
			    top[i].ss[j] = "loop";
		    }
		}
	}


    double calcChiSq(const CompassVec &cadb, const CompassVec &cbdb, const CompassVec &codb, int nres, int zeroes, int resno)
	{
        double score = 0.;
        for (int i=0; i<nres; i++) {
		    if (CA[i] > 0.001)
                score += (cadb[i] - CA[i])*(cadb[i] - CA[i]);
		    if (CB[i] > 0.001)
                score += (cbdb[i] - CB[i])*(cbdb[i] - CB[i]);
		    if (CO[i] > 0.001)
                score += (codb[i] - CO[i])*(codb[i] - CO[i]);
		}
		return (10*score/(3*resno-zeroes));
	}


    void calcScore(ShiftType shifts, int wc, char word[][1000], string aa1, string aa2, int row_no) {
		int zeroes=0;
		int size=0;
		if ((ca[0]>0. || cb[0]>0. || co[0]>0.) && (ca[1]>0. || cb[1]>0. || co[1]>0.)) 
		{
		for (int i=0; i<2; i++)
		{
			if(ca[i]==0.)
				zeroes++;
			if(cb[i]==0.)
				zeroes++;
			if(co[i]==0.)
				zeroes++;
		}
			size=2;
			calcScore2resSeq(shifts, wc, word, zeroes, size, row_no, aa1, aa2);
		}
		else if ((ca[0]==0. && cb[0]==0. && co[0]==0.) && (ca[1]>0. || cb[1]>0. || co[1]>0.)) 
		{
			if(ca[1]==0.)
				zeroes++;
			if(cb[1]==0.)
				zeroes++;
			if(co[1]==0.)
				zeroes++;
			zeroes+=3;
			size=2;
			calcScore2resSeq(shifts, wc, word, zeroes, size, row_no, aa1, aa2);
		}
		else if ((ca[0]>0. || cb[0]>0. || co[0]>0.) && (ca[1]==0. && cb[1]==0. && co[1]==0.)) 
		{
			if(ca[0]==0.)
				zeroes++;
			if(cb[0]==0.)
				zeroes++;
			if(co[0]==0.)
				zeroes++;
			zeroes+=3;
			size=2;
			calcScore2resSeq(shifts, wc, word, zeroes, size, row_no, aa1, aa2);
		}
	}
        void calcScore2resSeq(ShiftType &shifts, int wc, char word[][1000], int zeroes, int size, int row_no, string aa1, string aa2)
	{
        if(wc==0 || row_no || word[0][0])
        {}
		for (int i=LOOP; i<=STRAND; i++)
			for (int j=LOOP; j<=STRAND; j++)
                    for (unsigned int m=0; m<sequence.size()-1; m++) {
						if (sequence[m+1]!="PRO"){
	                    getDatabaseShifts(0, shifts.resIdx(aa1.c_str()), i, shifts);
	                    getDatabaseShifts(1, shifts.resIdx(aa2.c_str()), j, shifts);

                        if (deuter > 0.) 
							correctIso(shifts, m, 2);
			if (pdeuter > 0.)
							correctIso_pD(shifts, m, 2);

					    tempScore = calcChiSq(cadb, cbdb, codb, 2, zeroes, size);
						if (tempScore < top[MAX_TOP-1].score) {
                            setResult(top[MAX_TOP-1], tempScore, firstRes, m, i, j);
                            for (int n=MAX_TOP-1; n>0 && top[n].score < top[n-1].score; n--)
                                swap(top[n], top[n-1]);
						}

				}}
		stringstream ss;
		ss << top[0].score;
		extern std::string chiValq;
		chiValq= ss.str();
	}
    void setResult(ResultType &top, double score, int first, int idx, int i, int j)
	{
        top.score = score;
        top.resno = first + idx;
		top.ss[0] =  i==0? "loop" : (i==1)? "helx" : "strd";
		top.ss[1] =  j==0? "loop" : (j==1)? "helx" : "strd";
		for (int xx=0; xx<2; xx++) 
			top.res[xx] = sequence[idx+xx];
	}

    void idx2ss(string &ss, int i)
	{
		ss =  i==0? "loop" : (i==1)? "helx" : "strd";
	}


    void getDatabaseShifts(const int idx, const int resid, int ss, ShiftType &shifts)
	{
		cadb[idx] = ss==LOOP ? shifts.ca_rc[resid] : ss==HELIX ? shifts.ca_helix_ave[resid] : shifts.ca_strand_ave[resid];
		cbdb[idx] = ss==LOOP ? shifts.cb_rc[resid] : ss==HELIX ? shifts.cb_helix_ave[resid] : shifts.cb_strand_ave[resid];
		codb[idx] = ss==LOOP ? shifts.co_rc[resid] : ss==HELIX ? shifts.co_helix_ave[resid] : shifts.co_strand_ave[resid];
	}

    void correctIso(ShiftType &shifts, int first, int noRes)
	{
        for (int i=0; i<noRes; i++)
			shifts.correctIso(shifts.resIdx(sequence[first+i]), CA[i], CB[i], CO[i], ca[i], cb[i], co[i]);
	}
	
    void correctIso_pD(ShiftType &shifts, int first, int noRes)
	{
        for (int i=0; i<noRes; i++)
			shifts.correctIso_pD(shifts.resIdx(sequence[first+i]), CA[i], CB[i], CO[i], ca[i], cb[i], co[i]);
	}
	
	string itoa_sort(int integer)
	{
		string converted;
		stringstream converted_out;
		converted_out << integer;
		converted = converted_out.str();
		return converted;
	}
	string ftoa_sort(double dubs)
	{
		string d_conv;
		stringstream d_conv_out;
		d_conv_out << dubs;
		d_conv = d_conv_out.str();
		return d_conv;
	}
	
};
#endif
