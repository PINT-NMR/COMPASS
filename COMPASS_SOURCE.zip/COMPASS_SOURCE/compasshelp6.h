#ifndef COMPASSHELP6_H
#define COMPASSHELP6_H

#include <QDialog>
namespace Ui
{
    class CompassHelp6;
}

class CompassHelp6 : public QDialog
{
	Q_OBJECT

public:
    CompassHelp6(QWidget *parent = 0);
    ~CompassHelp6();

private:
    Ui::CompassHelp6 *ui;

private slots:
	void on_closeButton_clicked();

};

#endif
