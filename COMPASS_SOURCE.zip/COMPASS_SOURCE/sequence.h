#ifndef SEQUENCE_H
#define SEQUENCE_H
#include "compassvec.h"
	
struct Sequence {

    vector<Char> seq;

	Sequence() {}

	Char& operator[] (Uint n)
	{
		 return seq[n];
	}

	Uint size()
	{
		return seq.size();
	}

	void read(string mySeq)
	{
        ifstream myFile;
	    Char s[MAX_LINE];
	    string s2;

		myFile.open(mySeq.c_str());
		 
		myFile.getline(s, MAX_LINE);

		for (Int i=0; s[i]!='\0'; i++)
			seq.push_back(s[i]);

		myFile.close();
	}
};
#endif
