#ifndef COMPASSINDEX_H
#define COMPASSINDEX_H

#include <QWidget>
#include "compassmanualmode.h"
#include "csedit.h"
#include <QTextDocument>
#include "qcustomplot.h"
#include "warnings.h"
#include <QUrl>
#include <QObject>
#include <QTextObjectInterface>
#include <QPicture>
#include <QVariant>
#include <QPainter>


namespace Ui
{
	class CompassIndex;
}

class CompassIndex : public QWidget
{
	Q_OBJECT

public:
	CompassIndex(QWidget *parent = 0);
	~CompassIndex();
    enum { PlotTextFormat = QTextFormat::UserObject + 3902 };
    enum { PicturePropertyId = 1 };


private:
	Ui::CompassIndex *ui;
	CompassManualMode *winManual;
    CSedit *winEdit;
	Warnings *winWarn;
    QMenuBar *menuBar;
    int idxBox;
    int idxBox2;

private slots:
    void manualMode();
    void displayHelp();
    void iClicked();
    void i1Clicked();
	void rename(int save);
	void ssp();
	void stat(std::string file);
	void DisplayInfo(std::string resno);
	void readfile();
	void readfile_seq(std::string fnam, int resSeq, int noPro);
    void warn();
	void on_overlayButton_clicked();
	void on_openfileButton_clicked();
	void on_deleteButton_clicked();
	void saveIdx();
	void createBak(int bakI);
	std::string checkIdx();
	std::string aa3to1(std::string aa);
	std::string ftoa(double doub);
	double Compensate(std::string cs, std::string resno, std::string seqRead, std::string first, std::string ssp_deut, std::string nucl);
	double Trosy(std::string cs, std::string trosy, std::string nucl);
	void anchorClicked(const QUrl &url);
    void anchorClicked2(const QUrl &url);
    void warn2();
    void hideWarnings();
	void on_undoButton_clicked();
	void setLimits();
	void undoFunc();
    void preview();
	void setMaxFrag();
	void setResbox();
	void on_resButton_clicked();
	void on_resButton_2_clicked();
	bool testchar(char c);
	void setAxis();
	void on_ResetButton_clicked();
	void mouseWheel();
	void mousePress();
	void selectionChanged();
	void addGraph();
	void resetPlot();
    void saveSsp();
    void Preassign();
    void editChemicalShifts();
    void manAssign(std::string peak, int resNO);
    int saveMan();
    void goToMainSig();
    void quitApp();

signals:
    void goToMain();
    void renderManualMode();
};
Q_DECLARE_METATYPE(QPicture)

#endif
