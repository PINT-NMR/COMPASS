#include "compasslabelexample.h"
#include "ui_compasslabelexample.h"
#include <QtWidgets>
#include "QRect"
#include "QDesktopWidget"

CompassLabelExample::CompassLabelExample(QDialog *parent) :
    QDialog(parent),
    ui(new Ui::CompassLabelExample)
{
    ui->setupUi(this);
}

CompassLabelExample::~CompassLabelExample()
{
    delete ui;
}

void CompassLabelExample::on_closeButton_clicked()
{
    accept();
}
