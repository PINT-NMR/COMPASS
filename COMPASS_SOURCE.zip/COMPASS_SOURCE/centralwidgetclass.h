#ifndef CENTRALWIDGETCLASS_H
#define CENTRALWIDGETCLASS_H

#include <QWidget>

namespace Ui {
class centralWidgetClass;
}

class centralWidgetClass : public QWidget
{
    Q_OBJECT

public:
    explicit centralWidgetClass(QWidget *parent = 0);
    ~centralWidgetClass();

private slots:
    void on_gssButton_clicked();
    void on_peak_menuButton_clicked();
    void on_rename_menuButton_clicked();
    void on_convertButton_clicked();
    void on_about_menuButton_clicked();
    void on_quit_menuButton_clicked();

    void on_checkGitHubButton_clicked();

private:
    Ui::centralWidgetClass *ui;

signals:
    void label();
    void analyze();
    void assign();
    void about();
    void convert();
};

#endif // CENTRALWIDGETCLASS_H
