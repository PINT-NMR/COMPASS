#ifndef SHIFTSC_H
#define SHIFTSC_H
#include "compassvec.h"
#include "passdef.h"
#include "compassvec.h"

struct ShiftTypec {

    CompassVec ca_rc, cb_rc, co_rc, ha_rc, hn_rc, n_rc;
    CompassVec ca_strand_ave, cb_strand_ave, co_strand_ave, ha_strand_ave, hn_strand_ave, n_strand_ave;
    CompassVec ca_helix_ave, cb_helix_ave, co_helix_ave, ha_helix_ave, hn_helix_ave, n_helix_ave;
    CompassVec ca_strand_sdev, cb_strand_sdev, co_strand_sdev, ha_strand_sdev, hn_strand_sdev, n_strand_sdev;
    CompassVec ca_helix_sdev, cb_helix_sdev, co_helix_sdev, ha_helix_sdev, hn_helix_sdev, n_helix_sdev;

    string residue[20];

    ShiftTypec() {
        ca_rc =  cb_rc = co_rc = ha_rc = hn_rc = n_rc = CompassVec(20);
        ca_strand_ave = cb_strand_ave = co_strand_ave = ha_strand_ave = hn_strand_ave = n_strand_ave = CompassVec(20);
        ca_helix_ave = cb_helix_ave = co_helix_ave = ha_helix_ave = hn_helix_ave = n_helix_ave = CompassVec(20);
        ca_strand_sdev = cb_strand_sdev = co_strand_sdev = ha_strand_sdev = hn_strand_sdev = n_strand_sdev = CompassVec(20);
        ca_helix_sdev = cb_helix_sdev = co_helix_sdev = ha_helix_sdev = hn_helix_sdev = n_helix_sdev = CompassVec(20);

        residue[0] = "ALA";
        residue[1] = "CYS";
        residue[2] = "ASP";
        residue[3] = "GLU";
        residue[4] = "PHE";
        residue[5] = "GLY";
        residue[6] = "HIS";
        residue[7] = "ILE";
        residue[8] = "LYS";
        residue[9] = "LEU";
        residue[10] = "MET";
        residue[11] = "ASN";
        residue[12] = "PRO";
        residue[13] = "GLN";
        residue[14] = "ARG";
        residue[15] = "SER";
        residue[16] = "THR";
        residue[17] = "VAL";
        residue[18] = "TRP";
        residue[19] = "TYR";
    }

    void setShifts()
    {
        setRC_ca();
        setRC_cb();
        setRC_co();
        setRC_ha();
        setRC_hn();
        setRC_n();

        setSS_ca();
        setSS_cb();
        setSS_co();
        setSS_ha();
        setSS_hn();
        setSS_n();
    }

    void setRC_ca()
    {
        ca_rc[ALA] = 52.84;
        ca_rc[CYS] = 57.53;
        ca_rc[ASP] = 54.18;
        ca_rc[GLU] = 56.87;
        ca_rc[PHE] = 57.98;
        ca_rc[GLY] = 45.51;
        ca_rc[HIS] = 55.86;
        ca_rc[ILE] = 61.03;
        ca_rc[LYS] = 56.69;
        ca_rc[LEU] = 54.92;
        ca_rc[MET] = 55.67;
        ca_rc[ASN] = 53.23;
        ca_rc[PRO] = 63.47;
        ca_rc[GLN] = 56.12;
        ca_rc[ARG] = 56.42;
        ca_rc[SER] = 58.38;
        ca_rc[THR] = 61.64;
        ca_rc[VAL] = 62.06;
        ca_rc[TRP] = 57.78;
        ca_rc[TYR] = 57.97;
    }

    void setRC_cb()
    {
        cb_rc[ALA] = 19.06;
        cb_rc[CYS] = 29.35;
        cb_rc[ASP] = 40.85;
        cb_rc[GLU] = 30.20;
        cb_rc[PHE] = 39.45;
        cb_rc[GLY] = 0.00;
        cb_rc[HIS] = 29.97;
        cb_rc[ILE] = 38.65;
        cb_rc[LEU] = 42.38;
        cb_rc[LYS] = 32.79;
        cb_rc[MET] = 33.36;
        cb_rc[ASN] = 38.55;
        cb_rc[PRO] = 31.94;
        cb_rc[GLN] = 29.14;
        cb_rc[ARG] = 30.66;
        cb_rc[SER] = 64.03;
        cb_rc[THR] = 70.12;
        cb_rc[VAL] = 32.71;
        cb_rc[TRP] = 29.67;
        cb_rc[TYR] = 38.95;
    }

    void setRC_co()
    {
        co_rc[ALA] = 177.67;
        co_rc[CYS] = 174.93;
        co_rc[ASP] = 176.31;
        co_rc[GLU] = 176.43;
        co_rc[PHE] = 175.59;
        co_rc[GLY] = 173.89;
        co_rc[HIS] = 174.83;
        co_rc[ILE] = 175.57;
        co_rc[LYS] = 176.34;
        co_rc[LEU] = 176.89;
        co_rc[MET] = 175.35;
        co_rc[ASN] = 175.08;
        co_rc[PRO] = 176.89;
        co_rc[GLN] = 175.90;
        co_rc[ARG] = 176.02;
        co_rc[SER] = 174.49;
        co_rc[THR] = 174.70;
        co_rc[VAL] = 175.66;
        co_rc[TRP] = 176.15;
        co_rc[TYR] = 175.39;
    }

    void setRC_ha()
    {
        ha_rc[ALA] = 4.26;
        ha_rc[CYS] = 4.65;
        ha_rc[ASP] = 4.60;
        ha_rc[GLU] = 4.28;
        ha_rc[PHE] = 4.54;
        ha_rc[GLY] = 3.96;
        ha_rc[HIS] = 4.53;
        ha_rc[ILE] = 4.15;
        ha_rc[LYS] = 4.26;
        ha_rc[LEU] = 4.36;
        ha_rc[MET] = 4.38;
        ha_rc[ASN] = 4.66;
        ha_rc[PRO] = 4.37;
        ha_rc[GLN] = 4.26;
        ha_rc[ARG] = 4.24;
        ha_rc[SER] = 4.47;
        ha_rc[THR] = 4.45;
        ha_rc[VAL] = 4.12;
        ha_rc[TRP] = 4.55;
        ha_rc[TYR] = 4.52;
    }

    void setRC_hn()
    {
        hn_rc[ALA] = 8.15;
        hn_rc[CYS] = 8.25;
        hn_rc[ASP] = 8.36;
        hn_rc[GLU] = 8.37;
        hn_rc[PHE] = 8.17;
        hn_rc[GLY] = 8.33;
        hn_rc[HIS] = 8.21;
        hn_rc[ILE] = 7.98;
        hn_rc[LYS] = 8.23;
        hn_rc[LEU] = 8.08;
        hn_rc[MET] = 8.18;
        hn_rc[ASN] = 8.40;
        hn_rc[PRO] = 0.00;
        hn_rc[GLN] = 8.23;
        hn_rc[ARG] = 8.25;
        hn_rc[SER] = 8.23;
        hn_rc[THR] = 8.16;
        hn_rc[VAL] = 8.04;
        hn_rc[TRP] = 7.92;
        hn_rc[TYR] = 8.06;
    }

    void setRC_n()
    {
        n_rc[ALA] = 123.61;
        n_rc[CYS] = 117.96;
        n_rc[ASP] = 119.95;
        n_rc[GLU] = 120.43;
        n_rc[PHE] = 119.67;
        n_rc[GLY] = 109.13;
        n_rc[HIS] = 118.72;
        n_rc[ILE] = 120.87;
        n_rc[LYS] = 120.45;
        n_rc[LEU] = 121.48;
        n_rc[MET] = 119.66;
        n_rc[ASN] = 118.22;
        n_rc[PRO] = 000.00;
        n_rc[GLN] = 119.49;
        n_rc[ARG] = 120.42;
        n_rc[SER] = 115.55;
        n_rc[THR] = 113.36;
        n_rc[VAL] = 119.77;
        n_rc[TRP] = 120.16;
        n_rc[TYR] = 119.52;
    }

    void setSS_ca()
    {
        ca_strand_ave[ALA] =      51.53;  ca_strand_sdev[ALA] = 1.48; ca_helix_ave[ALA] =   54.83; ca_helix_sdev[ALA] =  1.05;
        ca_strand_ave[CYS] =      56.88;  ca_strand_sdev[CYS] = 2.02; ca_helix_ave[CYS] =   61.31; ca_helix_sdev[CYS] =  3.50;
        ca_strand_ave[ASP] =      53.87;  ca_strand_sdev[ASP] = 1.64; ca_helix_ave[ASP] =   56.70; ca_helix_sdev[ASP] =  1.61;
        ca_strand_ave[GLU] =      55.52;  ca_strand_sdev[GLU] = 1.67; ca_helix_ave[GLU] =   59.11; ca_helix_sdev[GLU] =  1.16;
        ca_strand_ave[PHE] =      56.65;  ca_strand_sdev[PHE] = 1.59; ca_helix_ave[PHE] =   60.81; ca_helix_sdev[PHE] =  1.90;
        ca_strand_ave[GLY] =      45.22;  ca_strand_sdev[GLY] = 1.17; ca_helix_ave[GLY] =   46.91; ca_helix_sdev[GLY] =  1.10;
        ca_strand_ave[HIS] =      55.09;  ca_strand_sdev[HIS] = 1.78; ca_helix_ave[HIS] =   59.04; ca_helix_sdev[HIS] =  1.74;
        ca_strand_ave[ILE] =      60.05;  ca_strand_sdev[ILE] = 1.57; ca_helix_ave[ILE] =   64.57; ca_helix_sdev[ILE] =  1.74;
        ca_strand_ave[LYS] =      55.40;  ca_strand_sdev[LYS] = 1.34; ca_helix_ave[LYS] =   58.93; ca_helix_sdev[LYS] =  1.44;
        ca_strand_ave[LEU] =      54.08;  ca_strand_sdev[LEU] = 1.31; ca_helix_ave[LEU] =   57.52; ca_helix_sdev[LEU] =  1.23;
        ca_strand_ave[MET] =      54.58;  ca_strand_sdev[MET] = 1.24; ca_helix_ave[MET] =   58.09; ca_helix_sdev[MET] =  1.81;
        ca_strand_ave[ASN] =      52.74;  ca_strand_sdev[ASN] = 1.47; ca_helix_ave[ASN] =   55.45; ca_helix_sdev[ASN] =  1.42;
        ca_strand_ave[PRO] =      62.64;  ca_strand_sdev[PRO] = 1.03; ca_helix_ave[PRO] =   65.49; ca_helix_sdev[PRO] =  1.08;
        ca_strand_ave[GLN] =      54.83;  ca_strand_sdev[GLN] = 1.41; ca_helix_ave[GLN] =   58.47; ca_helix_sdev[GLN] =  1.19;
        ca_strand_ave[ARG] =      55.14;  ca_strand_sdev[ARG] = 1.64; ca_helix_ave[ARG] =   58.93; ca_helix_sdev[ARG] =  1.55;
        ca_strand_ave[SER] =      57.54;  ca_strand_sdev[SER] = 1.40; ca_helix_ave[SER] =   60.88; ca_helix_sdev[SER] =  1.61;
        ca_strand_ave[THR] =      61.06;  ca_strand_sdev[THR] = 1.59; ca_helix_ave[THR] =   65.61; ca_helix_sdev[THR] =  2.39;
        ca_strand_ave[VAL] =      60.83;  ca_strand_sdev[VAL] = 1.64; ca_helix_ave[VAL] =   66.16; ca_helix_sdev[VAL] =  1.55;
        ca_strand_ave[TRP] =      56.41;  ca_strand_sdev[TRP] = 1.87; ca_helix_ave[TRP] =   60.01; ca_helix_sdev[TRP] =  1.77;
        ca_strand_ave[TYR] =      56.83;  ca_strand_sdev[TYR] = 1.71; ca_helix_ave[TYR] =   60.98; ca_helix_sdev[TYR] =  1.76;

    }

    void setSS_cb()
    {
        cb_strand_ave[ALA] = 21.14; cb_strand_sdev[ALA] = 2.05; cb_helix_ave[ALA] = 18.26; cb_helix_sdev[ALA] = 0.88;
        cb_strand_ave[CYS] = 30.16; cb_strand_sdev[CYS] = 1.97; cb_helix_ave[CYS] = 27.75; cb_helix_sdev[CYS] = 2.07;
        cb_strand_ave[ASP] = 42.30; cb_strand_sdev[ASP] = 1.62; cb_helix_ave[ASP] = 40.51; cb_helix_sdev[ASP] = 1.33;
        cb_strand_ave[GLU] = 32.01; cb_strand_sdev[GLU] = 1.98; cb_helix_ave[GLU] = 29.37; cb_helix_sdev[GLU] = 0.88;
        cb_strand_ave[PHE] = 41.54; cb_strand_sdev[PHE] = 1.74; cb_helix_ave[PHE] = 38.78; cb_helix_sdev[PHE] = 1.31;
        cb_strand_ave[GLY] = 00.00; cb_strand_sdev[GLY] = 1.00; cb_helix_ave[GLY] = 00.00; cb_helix_sdev[GLY] = 1.00;
        cb_strand_ave[HIS] = 31.85; cb_strand_sdev[HIS] = 2.22; cb_helix_ave[HIS] = 29.54; cb_helix_sdev[HIS] = 1.46;
        cb_strand_ave[ILE] = 39.86; cb_strand_sdev[ILE] = 1.98; cb_helix_ave[ILE] = 37.60; cb_helix_sdev[ILE] = 1.15;
        cb_strand_ave[LYS] = 34.63; cb_strand_sdev[LYS] = 1.78; cb_helix_ave[LYS] = 32.27; cb_helix_sdev[LYS] = 0.88;
        cb_strand_ave[LEU] = 43.79; cb_strand_sdev[LEU] = 2.00; cb_helix_ave[LEU] = 41.65; cb_helix_sdev[LEU] = 1.05;
        cb_strand_ave[MET] = 35.05; cb_strand_sdev[MET] = 2.29; cb_helix_ave[MET] = 32.27; cb_helix_sdev[MET] = 1.66;
        cb_strand_ave[ASN] = 40.12; cb_strand_sdev[ASN] = 2.07; cb_helix_ave[ASN] = 38.61; cb_helix_sdev[ASN] = 1.31;
        cb_strand_ave[PRO] = 32.27; cb_strand_sdev[PRO] = 1.20; cb_helix_ave[PRO] = 31.46; cb_helix_sdev[PRO] = 0.95;
        cb_strand_ave[GLN] = 31.28; cb_strand_sdev[GLN] = 1.93; cb_helix_ave[GLN] = 28.51; cb_helix_sdev[GLN] = 0.92;
        cb_strand_ave[ARG] = 32.19; cb_strand_sdev[ARG] = 1.80; cb_helix_ave[ARG] = 30.14; cb_helix_sdev[ARG] = 1.14;
        cb_strand_ave[SER] = 65.16; cb_strand_sdev[SER] = 1.51; cb_helix_ave[SER] = 63.08; cb_helix_sdev[SER] = 1.12;
        cb_strand_ave[THR] = 70.75; cb_strand_sdev[THR] = 1.51; cb_helix_ave[THR] = 68.88; cb_helix_sdev[THR] = 1.17;
        cb_strand_ave[VAL] = 33.91; cb_strand_sdev[VAL] = 1.61; cb_helix_ave[VAL] = 31.49; cb_helix_sdev[VAL] = 0.72;
        cb_strand_ave[TRP] = 31.50; cb_strand_sdev[TRP] = 1.70; cb_helix_ave[TRP] = 29.30; cb_helix_sdev[TRP] = 1.40;
        cb_strand_ave[TYR] = 40.97; cb_strand_sdev[TYR] = 1.85; cb_helix_ave[TYR] = 38.25; cb_helix_sdev[TYR] = 1.11;
    }

    void setSS_co()
    {
        co_strand_ave[ALA] = 176.09; co_strand_sdev[ALA] = 1.51; co_helix_ave[ALA] = 179.40; co_helix_sdev[ALA] = 1.32;
        co_strand_ave[CYS] = 173.57; co_strand_sdev[CYS] = 1.64; co_helix_ave[CYS] = 176.16; co_helix_sdev[CYS] = 1.64;
        co_strand_ave[ASP] = 175.54; co_strand_sdev[ASP] = 1.57; co_helix_ave[ASP] = 178.08; co_helix_sdev[ASP] = 1.33;
        co_strand_ave[GLU] = 175.35; co_strand_sdev[GLU] = 1.40; co_helix_ave[GLU] = 178.61; co_helix_sdev[GLU] = 1.21;
        co_strand_ave[PHE] = 174.25; co_strand_sdev[PHE] = 1.63; co_helix_ave[PHE] = 177.13; co_helix_sdev[PHE] = 1.38;
        co_strand_ave[GLY] = 172.55; co_strand_sdev[GLY] = 1.58; co_helix_ave[GLY] = 175.51; co_helix_sdev[GLY] = 1.23;
        co_strand_ave[HIS] = 174.17; co_strand_sdev[HIS] = 1.54; co_helix_ave[HIS] = 176.98; co_helix_sdev[HIS] = 1.29;
        co_strand_ave[ILE] = 174.86; co_strand_sdev[ILE] = 1.39; co_helix_ave[ILE] = 177.72; co_helix_sdev[ILE] = 1.29;
        co_strand_ave[LYS] = 175.31; co_strand_sdev[LYS] = 1.29; co_helix_ave[LYS] = 178.40; co_helix_sdev[LYS] = 1.46;
        co_strand_ave[LEU] = 175.67; co_strand_sdev[LEU] = 1.47; co_helix_ave[LEU] = 178.53; co_helix_sdev[LEU] = 1.30;
        co_strand_ave[MET] = 174.83; co_strand_sdev[MET] = 1.40; co_helix_ave[MET] = 177.95; co_helix_sdev[MET] = 1.12;
        co_strand_ave[ASN] = 174.64; co_strand_sdev[ASN] = 1.65; co_helix_ave[ASN] = 176.91; co_helix_sdev[ASN] = 1.55;
        co_strand_ave[PRO] = 176.18; co_strand_sdev[PRO] = 1.40; co_helix_ave[PRO] = 178.34; co_helix_sdev[PRO] = 1.45;
        co_strand_ave[GLN] = 174.88; co_strand_sdev[GLN] = 1.38; co_helix_ave[GLN] = 177.97; co_helix_sdev[GLN] = 1.29;
        co_strand_ave[ARG] = 175.14; co_strand_sdev[ARG] = 1.36; co_helix_ave[ARG] = 178.26; co_helix_sdev[ARG] = 1.43;
        co_strand_ave[SER] = 173.55; co_strand_sdev[SER] = 1.50; co_helix_ave[SER] = 175.94; co_helix_sdev[SER] = 1.39;
        co_strand_ave[THR] = 173.66; co_strand_sdev[THR] = 1.50; co_helix_ave[THR] = 175.92; co_helix_sdev[THR] = 1.15;
        co_strand_ave[VAL] = 174.80; co_strand_sdev[VAL] = 1.39; co_helix_ave[VAL] = 177.65; co_helix_sdev[VAL] = 1.38;
        co_strand_ave[TRP] = 175.41; co_strand_sdev[TRP] = 1.66; co_helix_ave[TRP] = 178.05; co_helix_sdev[TRP] = 1.57;
        co_strand_ave[TYR] = 174.54; co_strand_sdev[TYR] = 1.45; co_helix_ave[TYR] = 177.36; co_helix_sdev[TYR] = 1.40;
    }

    void setSS_ha()
    {
        ha_strand_ave[ALA] = 4.77; ha_strand_sdev[ALA] = 0.55; ha_helix_ave[ALA] = 4.03; ha_helix_sdev[ALA] = 0.33;
        ha_strand_ave[CYS] = 5.15; ha_strand_sdev[CYS] = 0.51; ha_helix_ave[CYS] = 4.15; ha_helix_sdev[CYS] = 0.67;
        ha_strand_ave[ASP] = 4.94; ha_strand_sdev[ASP] = 0.40; ha_helix_ave[ASP] = 4.43; ha_helix_sdev[ASP] = 0.22;
        ha_strand_ave[GLU] = 4.78; ha_strand_sdev[GLU] = 0.49; ha_helix_ave[GLU] = 4.01; ha_helix_sdev[GLU] = 0.24;
        ha_strand_ave[PHE] = 5.09; ha_strand_sdev[PHE] = 0.46; ha_helix_ave[PHE] = 4.16; ha_helix_sdev[PHE] = 0.46;
        ha_strand_ave[GLY] = 4.20; ha_strand_sdev[GLY] = 0.60; ha_helix_ave[GLY] = 3.81; ha_helix_sdev[GLY] = 0.38;
        ha_strand_ave[HIS] = 5.06; ha_strand_sdev[HIS] = 0.48; ha_helix_ave[HIS] = 4.33; ha_helix_sdev[HIS] = 0.34;
        ha_strand_ave[ILE] = 4.68; ha_strand_sdev[ILE] = 0.48; ha_helix_ave[ILE] = 3.67; ha_helix_sdev[ILE] = 0.33;
        ha_strand_ave[LYS] = 4.69; ha_strand_sdev[LYS] = 0.51; ha_helix_ave[LYS] = 3.99; ha_helix_sdev[LYS] = 0.30;
        ha_strand_ave[LEU] = 4.82; ha_strand_sdev[LEU] = 0.46; ha_helix_ave[LEU] = 4.00; ha_helix_sdev[LEU] = 0.34;
        ha_strand_ave[MET] = 4.96; ha_strand_sdev[MET] = 0.47; ha_helix_ave[MET] = 4.07; ha_helix_sdev[MET] = 0.34;
        ha_strand_ave[ASN] = 5.06; ha_strand_sdev[ASN] = 0.49; ha_helix_ave[ASN] = 4.48; ha_helix_sdev[ASN] = 0.22;
        ha_strand_ave[PRO] = 4.60; ha_strand_sdev[PRO] = 0.50; ha_helix_ave[PRO] = 4.22; ha_helix_sdev[PRO] = 0.29;
        ha_strand_ave[GLN] = 4.80; ha_strand_sdev[GLN] = 0.49; ha_helix_ave[GLN] = 3.99; ha_helix_sdev[GLN] = 0.28;
        ha_strand_ave[ARG] = 4.74; ha_strand_sdev[ARG] = 0.50; ha_helix_ave[ARG] = 3.99; ha_helix_sdev[ARG] = 0.32;
        ha_strand_ave[SER] = 4.91; ha_strand_sdev[SER] = 0.48; ha_helix_ave[SER] = 4.25; ha_helix_sdev[SER] = 0.25;
        ha_strand_ave[THR] = 4.86; ha_strand_sdev[THR] = 0.46; ha_helix_ave[THR] = 4.00; ha_helix_sdev[THR] = 0.34;
        ha_strand_ave[VAL] = 4.60; ha_strand_sdev[VAL] = 0.48; ha_helix_ave[VAL] = 3.58; ha_helix_sdev[VAL] = 0.36;
        ha_strand_ave[TRP] = 5.19; ha_strand_sdev[TRP] = 0.50; ha_helix_ave[TRP] = 4.38; ha_helix_sdev[TRP] = 0.37;
        ha_strand_ave[TYR] = 5.10; ha_strand_sdev[TYR] = 0.54; ha_helix_ave[TYR] = 4.09; ha_helix_sdev[TYR] = 0.39;
    }

    void setSS_hn()
    {
        hn_strand_ave[ALA] = 8.44; hn_strand_sdev[ALA] = 0.76; hn_helix_ave[ALA] = 8.08; hn_helix_sdev[ALA] = 0.52;
        hn_strand_ave[CYS] = 8.80; hn_strand_sdev[CYS] = 0.64; hn_helix_ave[CYS] = 8.20; hn_helix_sdev[CYS] = 0.69;
        hn_strand_ave[ASP] = 8.51; hn_strand_sdev[ASP] = 0.61; hn_helix_ave[ASP] = 8.18; hn_helix_sdev[ASP] = 0.56;
        hn_strand_ave[GLU] = 8.53; hn_strand_sdev[GLU] = 0.62; hn_helix_ave[GLU] = 8.22; hn_helix_sdev[GLU] = 0.62;
        hn_strand_ave[PHE] = 8.75; hn_strand_sdev[PHE] = 0.72; hn_helix_ave[PHE] = 8.18; hn_helix_sdev[PHE] = 0.62;
        hn_strand_ave[GLY] = 8.34; hn_strand_sdev[GLY] = 0.86; hn_helix_ave[GLY] = 8.29; hn_helix_sdev[GLY] = 0.67;
        hn_strand_ave[HIS] = 8.62; hn_strand_sdev[HIS] = 0.74; hn_helix_ave[HIS] = 8.10; hn_helix_sdev[HIS] = 0.56;
        hn_strand_ave[ILE] = 8.68; hn_strand_sdev[ILE] = 0.70; hn_helix_ave[ILE] = 8.02; hn_helix_sdev[ILE] = 0.52;
        hn_strand_ave[LYS] = 8.48; hn_strand_sdev[LYS] = 0.68; hn_helix_ave[LYS] = 7.99; hn_helix_sdev[LYS] = 0.56;
        hn_strand_ave[LEU] = 8.60; hn_strand_sdev[LEU] = 0.71; hn_helix_ave[LEU] = 8.05; hn_helix_sdev[LEU] = 0.54;
        hn_strand_ave[MET] = 8.64; hn_strand_sdev[MET] = 0.67; hn_helix_ave[MET] = 8.09; hn_helix_sdev[MET] = 0.58;
        hn_strand_ave[ASN] = 8.60; hn_strand_sdev[ASN] = 0.64; hn_helix_ave[ASN] = 8.22; hn_helix_sdev[ASN] = 0.58;
        hn_strand_ave[PRO] = 0.00; hn_strand_sdev[PRO] = 1.00; hn_helix_ave[PRO] = 0.00; hn_helix_sdev[PRO] = 1.00;
        hn_strand_ave[GLN] = 8.48; hn_strand_sdev[GLN] = 0.66; hn_helix_ave[GLN] = 8.04; hn_helix_sdev[GLN] = 0.55;
        hn_strand_ave[ARG] = 8.56; hn_strand_sdev[ARG] = 0.64; hn_helix_ave[ARG] = 8.07; hn_helix_sdev[ARG] = 0.55;
        hn_strand_ave[SER] = 8.50; hn_strand_sdev[SER] = 0.67; hn_helix_ave[SER] = 8.14; hn_helix_sdev[SER] = 0.56;
        hn_strand_ave[THR] = 8.51; hn_strand_sdev[THR] = 0.61; hn_helix_ave[THR] = 8.04; hn_helix_sdev[THR] = 0.51;
        hn_strand_ave[VAL] = 8.62; hn_strand_sdev[VAL] = 0.69; hn_helix_ave[VAL] = 8.02; hn_helix_sdev[VAL] = 0.65;
        hn_strand_ave[TRP] = 8.59; hn_strand_sdev[TRP] = 0.83; hn_helix_ave[TRP] = 8.12; hn_helix_sdev[TRP] = 0.74;
        hn_strand_ave[TYR] = 8.68; hn_strand_sdev[TYR] = 0.76; hn_helix_ave[TYR] = 8.07; hn_helix_sdev[TYR] = 0.62;
    }

    void setSS_n()
    {
        n_strand_ave[ALA] = 124.47; n_strand_sdev[ALA] = 4.39; n_helix_ave[ALA] = 121.44; n_helix_sdev[ALA] = 2.37;
        n_strand_ave[CYS] = 121.04; n_strand_sdev[CYS] = 4.53; n_helix_ave[CYS] = 117.68; n_helix_sdev[CYS] = 3.33;
        n_strand_ave[ASP] = 122.17; n_strand_sdev[ASP] = 4.40; n_helix_ave[ASP] = 119.22; n_helix_sdev[ASP] = 2.69;
        n_strand_ave[GLU] = 122.09; n_strand_sdev[GLU] = 3.95; n_helix_ave[GLU] = 119.04; n_helix_sdev[GLU] = 2.82;
        n_strand_ave[PHE] = 121.08; n_strand_sdev[PHE] = 4.45; n_helix_ave[PHE] = 119.16; n_helix_sdev[PHE] = 3.33;
        n_strand_ave[GLY] = 109.32; n_strand_sdev[GLY] = 3.94; n_helix_ave[GLY] = 107.51; n_helix_sdev[GLY] = 2.69;
        n_strand_ave[HIS] = 120.49; n_strand_sdev[HIS] = 4.51; n_helix_ave[HIS] = 117.95; n_helix_sdev[HIS] = 2.63;
        n_strand_ave[ILE] = 122.85; n_strand_sdev[ILE] = 4.63; n_helix_ave[ILE] = 119.71; n_helix_sdev[ILE] = 2.88;
        n_strand_ave[LYS] = 122.21; n_strand_sdev[LYS] = 4.32; n_helix_ave[LYS] = 119.20; n_helix_sdev[LYS] = 2.64;
        n_strand_ave[LEU] = 124.05; n_strand_sdev[LEU] = 4.26; n_helix_ave[LEU] = 119.61; n_helix_sdev[LEU] = 2.73;
        n_strand_ave[MET] = 121.66; n_strand_sdev[MET] = 4.02; n_helix_ave[MET] = 118.18; n_helix_sdev[MET] = 2.75;
        n_strand_ave[ASN] = 121.58; n_strand_sdev[ASN] = 4.35; n_helix_ave[ASN] = 117.30; n_helix_sdev[ASN] = 2.85;
        n_strand_ave[PRO] = 000.00; n_strand_sdev[PRO] = 1.00; n_helix_ave[PRO] = 000.00; n_helix_sdev[PRO] = 1.00;
        n_strand_ave[GLN] = 121.08; n_strand_sdev[GLN] = 4.13; n_helix_ave[GLN] = 118.45; n_helix_sdev[GLN] = 2.84;
        n_strand_ave[ARG] = 122.31; n_strand_sdev[ARG] = 4.25; n_helix_ave[ARG] = 118.90; n_helix_sdev[ARG] = 2.83;
        n_strand_ave[SER] = 116.89; n_strand_sdev[SER] = 4.02; n_helix_ave[SER] = 114.87; n_helix_sdev[SER] = 2.99;
        n_strand_ave[THR] = 116.46; n_strand_sdev[THR] = 5.00; n_helix_ave[THR] = 114.60; n_helix_sdev[THR] = 3.99;
        n_strand_ave[VAL] = 121.90; n_strand_sdev[VAL] = 5.05; n_helix_ave[VAL] = 119.19; n_helix_sdev[VAL] = 3.59;
        n_strand_ave[TRP] = 122.09; n_strand_sdev[TRP] = 5.15; n_helix_ave[TRP] = 119.84; n_helix_sdev[TRP] = 3.11;
        n_strand_ave[TYR] = 121.43; n_strand_sdev[TYR] = 4.78; n_helix_ave[TYR] = 119.17; n_helix_sdev[TYR] = 2.91;
    }

    void  correctIso_pD(const int res, double &ca, double &cb, double &co, double cain, double cbin, double coin)
     {
         if (cain > 0.001)
             ca = cain + ca_pd(res);
         else
             ca = cain;
         if (cbin > 0.001)
             cb = cbin + cb_pd(res);
         else
             cb = cbin;
         if (coin > 0.001)
             co = coin + co_pd(res);
         else
             co = coin;
     }


    double isotopeShiftGly(const int &d1, const int &d2, const int &d3)
    {
        double deltaC1 = -0.39;
        double deltaC2 = -0.13;
        double deltaC3 = -0.07;

        return deltaC1*d1 + deltaC2*d2 + deltaC3*d3;
    }

    double isotopeShift(const int &d1, const int &d2, const int &d3)
    {
        double deltaC1 = -0.29;
        double deltaC2 = -0.13;
        double deltaC3 = -0.07;

        return deltaC1*d1 + deltaC2*d2 + deltaC3*d3;
    }

    void  correctIso(const int res, double &ca, double &cb, double &co, double cain, double cbin, double coin)
    {
        int d1=0, d2=0, d3=0;

        if (cain > 0.001 && res==5) {
            dVectorCA(res, d1, d2, d3);
            ca = cain - isotopeShiftGly(d1, d2, d3);
        }
        else if (cain > 0.001) {
            dVectorCA(res, d1, d2, d3);
            ca = cain - isotopeShift(d1, d2, d3);
        }
        else
            ca = cain;
        if (cbin > 0.001) {
            dVectorCB(res, d1, d2, d3);
            cb = cbin - isotopeShift(d1, d2, d3);
        }
        else
            cb = cbin;
        if (coin > 0.001 && res==5) {
            dVectorCO(res, d1, d2, d3);
            co = coin - isotopeShiftGly(d1, d2, d3);
        }
        else if (coin > 0.001) {
            dVectorCO(res, d1, d2, d3);
            co = coin - isotopeShift(d1, d2, d3);
        }
        else
            co = coin;
    }


   double ca_pd(const int res)
    {
        switch (res) {
            case ALA: return 0.28; break;
            case CYS: return 0.39; break;
            case ASP: return 0.19; break;
            case GLU: return 0.43; break;
            case PHE: return 0.33; break;
            case GLY: return 0.45; break;
            case HIS: return 0.43; break;
            case ILE: return 0.46; break;
            case LYS: return 0.42; break;
            case LEU: return 0.43; break;
            case MET: return 0.46; break;
            case ASN: return 0.28; break;
            case PRO: return 0.30; break;
            case GLN: return 0.42; break;
            case ARG: return 0.40; break;
            case SER: return 0.43; break;
            case THR: return 0.30; break;
            case VAL: return 0.42; break;
            case TRP: return 0.28; break;
            case TYR: return 0.27; break;
        }
        return 0.0;
    }

 double cb_pd(const int res)
    {
        switch (res) {
            case ALA: return 0.78; break;
            case CYS: return 0.00; break;
            case ASP: return 0.42; break;
            case GLU: return 0.88; break;
            case PHE: return 0.71; break;
            case GLY: return 0.00; break;
            case HIS: return 0.91; break;
            case ILE: return 0.90; break;
            case LYS: return 0.83; break;
            case LEU: return 1.10; break;
            case MET: return 0.92; break;
            case ASN: return 0.46; break;
            case PRO: return 0.95; break;
            case GLN: return 0.84; break;
            case ARG: return 0.92; break;
            case SER: return 0.33; break;
            case THR: return 0.37; break;
            case VAL: return 0.91; break;
            case TRP: return 0.41; break;
            case TYR: return 0.63; break;
        }
        return 0.0;
    }

 double co_pd(const int res)
    {
        switch (res) {
            case ALA: return 0.010; break;
            case CYS: return -0.03; break;
            case ASP: return 0.030; break;
            case GLU: return -0.01; break;
            case PHE: return 0.020; break;
            case GLY: return -0.06; break;
            case HIS: return 0.130; break;
            case ILE: return 0.060; break;
            case LYS: return 0.000; break;
            case LEU: return -0.01; break;
            case MET: return -0.03; break;
            case ASN: return 0.010; break;
            case PRO: return -0.02; break;
            case GLN: return 0.040; break;
            case ARG: return 0.020; break;
            case SER: return -0.48; break;
            case THR: return 0.010; break;
            case VAL: return 0.000; break;
            case TRP: return -0.01; break;
            case TYR: return -0.03; break;
        }
        return 0.0;
    }

    void  dVectorCO(const int res, int &d1,  int &d2, int &d3)
    {
        d1 = 0;
        d2 = 1;
        switch (res) {
            case ALA: d3 = 4; break;
            case CYS: d3 = 3; break;
            case ASP: d3 = 3; break;
            case GLU: d3 = 3; break;
            case PHE: d3 = 3; break;
            case GLY: d2 = 2; d3 = 1; break;
            case HIS: d3 = 3; break;
            case ILE: d3 = 2; break;
            case LYS: d3 = 3; break;
            case LEU: d3 = 3; break;
            case MET: d3 = 3; break;
            case ASN: d3 = 3; break;
            case PRO: d3 = 3; break;
            case GLN: d3 = 3; break;
            case ARG: d3 = 3; break;
            case SER: d3 = 3; break;
            case THR: d3 = 2; break;
            case VAL: d3 = 2; break;
            case TRP: d3 = 3; break;
            case TYR: d3 = 3; break;
        }
    }

    void  dVectorCA(const int res, int &d1,  int &d2, int &d3)
    {
        d1 = 1;
        d2 = 2;
        switch (res) {
            case ALA: d2 = 3; d3 = 0; break;
            case CYS: d3 = 0; break;
            case ASP: d3 = 0; break;
            case GLU: d3 = 2; break;
            case PHE: d3 = 0; break;
            case GLY: d1 = 2; d2 = d3 = 0; break;
            case HIS: d3 = 0; break;
            case ILE: d2 = 1; d3 = 5; break;
            case LYS: d3 = 2; break;
            case LEU: d3 = 1; break;
            case MET: d3 = 2; break;
            case ASN: d3 = 0; break;
            case PRO: d3 = 2; break;
            case GLN: d3 = 2; break;
            case ARG: d3 = 2; break;
            case SER: d3 = 0; break;
            case THR: d2 = 1; d3 = 3; break;
            case VAL: d2 = 1; d3 = 6; break;
            case TRP: d2 = 1; d3 = 3; break;
            case TYR: d3 = 0; break;
        }
    }

    void  dVectorCB(const int res, int &d1,  int &d2, int &d3)
    {
        switch (res) {
            case ALA: d1 = 3; d2 = 1; d3 = 0; break;
            case CYS: d1 = 2; d2 = 1; d3 = 0; break;
            case ASP: d1 = 2; d2 = 1; d3 = 0; break;
            case GLU: d1 = 2; d2 = 3; d3 = 0; break;
            case PHE: d1 = 2; d2 = 1; d3 = 0; break;
            case GLY: d1 = 2; d2 = d3 = 0; break;
            case HIS: d1 = 2; d2 = 1; d3 = 0; break;
            case ILE: d1 = 1; d2 = 6; d3 = 3; break;
            case LYS: d1 = 2; d2 = 3; d3 = 2; break;
            case LEU: d1 = 2; d2 = 2; d3 = 6; break;
            case MET: d1 = 2; d2 = 3; d3 = 0; break;
            case ASN: d1 = 2; d2 = 1; d3 = 0; break;
            case PRO: d1 = 2; d2 = 3; d3 = 2; break;
                    case GLN: d1 = 2; d2 = 3; d3 = 0; break;
            case ARG: d1 = 2; d2 = 3; d3 = 2; break;
            case SER: d1 = 2; d2 = 1; d3 = 0; break;
            case THR: d1 = 1; d2 = 4; d3 = 0; break;
            case VAL: d1 = 1; d2 = 7; d3 = 0; break;
            case TRP: d1 = 2; d2 = 1; d3 = 0; break;
            case TYR: d1 = 2; d2 = 1; d3 = 0; break;
        }
    }

    int resIdx(const std::string res) {
        if (res == "ALA") return 0;
        if (res == "CYS") return 1;
        if (res == "ASP") return 2;
        if (res == "GLU") return 3;
        if (res == "PHE") return 4;
        if (res == "GLY") return 5;
        if (res == "HIS") return 6;
        if (res == "ILE") return 7;
        if (res == "LYS") return 8;
        if (res == "LEU") return 9;
        if (res == "MET") return 10;
        if (res == "ASN") return 11;
        if (res == "PRO") return 12;
        if (res == "GLN") return 13;
        if (res == "ARG") return 14;
        if (res == "SER") return 15;
        if (res == "THR") return 16;
        if (res == "VAL") return 17;
        if (res == "TRP") return 18;
        if (res == "TYR") return 19;
        return -1;
    }


    ~ShiftTypec() { }
};
#endif
