#ifndef CONVERTERROR_H
#define CONVERTERROR_H

#include <QDialog>

namespace Ui
{
	class ConvertError;
}

class ConvertError : public QDialog
{
	Q_OBJECT

public:
	ConvertError(QWidget *parent = 0);
	~ConvertError();

private slots:
    void on_closeButton_clicked();

private:
	Ui::ConvertError *ui;

};

#endif
