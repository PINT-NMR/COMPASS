#ifndef COMPASSFUNCTIONS_H
#define COMPASSFUNCTIONS_H
#include <QtWidgets>
#include <cstdlib>


    QString checkProjectName(QString qStr);
    QString makeSlashLast(QString qfolder);
    QString convSlash(QString word);

#endif // COMPASSFUNCTIONS_H
