#ifndef MFUNC_H
#define MFUNC_H
#include <fstream>
#include <cmath>
#include <complex>
#include <iostream>
#include <iomanip>
#include <vector>
#include <limits>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include <cstdlib>
#include <QtWidgets>

void mout(QString str);
void mout(QString str, QString comment);
void mout(QString str, QString str2, QString comment);
void mout(QString str, QString str2,QString str3, QString comment);
void mout(QString str, QString str2,QString str3, QString str4, QString comment);
void mout(QString str, QString str2,QString str3, QString str4, QString str5, QString comment);
void mout(std::string str);
void mout(std::string str, std::string comment);
void mout(std::string str, std::string str2, std::string comment);
void mout(std::string str, std::string str2,std::string str3, std::string comment);
void mout(std::string str, std::string str2,std::string str3, std::string str4, std::string comment);
void mout(std::string str, std::string str2,std::string str3, std::string str4, std::string str5, std::string comment);
void mout(QString str, std::string str2);
void mout(std::string str, QString str2);
void mout(QString str, std::string str2, QString str3);
void mout(QString str, std::string str2, std::string str3);
void mout(std::string str, QString str2, std::string str3);
void mout(std::string str, QString str2, QString str3);
void mout(std::vector<std::string> vec);
void mout(std::vector<int> vec);
void mout(std::vector<double> vec);
void mout(std::vector<QString> vec);
void mout(std::vector< std::vector< std::string > > vec);
void mout(std::vector< std::vector< int > > vec);
void mout(std::vector< std::vector< double > > vec);
QString mconvert(std::string str);
std::string mconvert(QString str);
void mout(const char str1, const char str2, const char str3);
std::string mconvert(double d);
std::string mconvert(int i);
int mcountlines(std::string filename);
#endif // MFUNC_H
