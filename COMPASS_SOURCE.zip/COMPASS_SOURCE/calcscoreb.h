#ifndef CALCSCOREB_H
#define CALCSCOREB_H
#include "passdef.h"
#include "compassvec.h"
#include <iostream>

struct ResultTypeb {
    double score;
    int resno;
    string res[MAX_RES];
    string ss[MAX_RES];
};

struct SortTypeb
{
    string sortLines[32];
    double	sortKey;
};

struct CalcScoreTypeb
{
    double ca[MAX_RES], cb[MAX_RES], co[MAX_RES], CA[MAX_RES], CB[MAX_RES], CO[MAX_RES];
    CompassVec cadb; CompassVec cbdb; CompassVec codb;

    int CHI;
    int resultNO;
    SortTypeb* sorted;
    ResultTypeb top[MAX_TOP];
    int max_result;
    int counting;
    int matchno;
    string filenames;
        double deuter;
    double pdeuter;
    vector<string> ss_sequence;
    vector<string> sequence;
    int firstRes;
    bool ss_exist;
    double tempScore;
    CalcScoreTypeb(ParserTypeb &parser)
    {
        for (int i=0; i<MAX_RES; i++) {
            ca[i] = CA[i] = parser.ca[i];
            cb[i] = CB[i] = parser.cb[i];
            co[i] = CO[i] = parser.co[i];
        }
        resultNO=parser.resultNO;
        sequence = parser.sequence;
        ss_sequence = parser.ss_sequence;
        ss_exist = parser.ss_exist;
        firstRes = parser.first;
        CHI = parser.CHI;
        counting=parser.counting;
        matchno=parser.matchno;
        filenames=parser.filenames;
            deuter = parser.deuter;
        pdeuter= parser.pdeuter;
            max_result = parser.max;
        cadb = CompassVec(MAX_RES);
        cbdb = CompassVec(MAX_RES);
        codb = CompassVec(MAX_RES);
        if(counting==0)
        sorted = new SortTypeb[2];
        for (int i=0; i<MAX_TOP; i++) {
            top[i].score = 1.e99;
            top[i].resno = 1;
            for (int j=0; j<MAX_RES; j++) {
                top[i].res[j] = "ALA";
                top[i].ss[j] = "loop";
            }
        }
    }


    double calcChiSq(const CompassVec &cadb, const CompassVec &cbdb, const CompassVec &codb, int nres, int zeroes, int resno)
    {
        double score = 0.;
        for (int i=0; i<nres; i++) {
            if (CA[i] > 0.001)
                score += (cadb[i] - CA[i])*(cadb[i] - CA[i]);
            if (CB[i] > 0.001)
                score += (cbdb[i] - CB[i])*(cbdb[i] - CB[i]);
            if (CO[i] > 0.001)
                score += (codb[i] - CO[i])*(codb[i] - CO[i]);
        }
        return (10*score/(3*resno-zeroes));
    }


    void calcScore(ShiftTypeb shifts, int wc, string word[1000], int row_no) {
        int zeroes=0;
        int size=0;

    if ((ca[0]>0.||cb[0]>0.||co[0]>0.) && (ca[1]>0.||cb[1]>0.||co[1]>0.) && \
             (ca[2]>0.||cb[2]>0.||co[2]>0.) && (ca[3]>0.||cb[3]>0.||co[3]>0.) && (ca[4]>0.||cb[4]>0.||co[4]>0.) && (ca[5]>0.||cb[5]>0.||co[5]>0.) && (ca[6]>0.||cb[6]>0.||co[6]>0.)  && (ca[7]>0.||cb[7]>0.||co[7]>0.) && (ca[8]>0.||cb[8]>0.||co[8]>0.)  && (ca[9]>0.||cb[9]>0.||co[9]>0.)) {
        for (int i=0; i<10; i++)
        {
            if(ca[i]==0.)
                zeroes++;
            if(cb[i]==0.)
                zeroes++;
            if(co[i]==0.)
                zeroes++;
        }
            size=10;
            if (sequence.size() > 9)
                calcScore10resSeq(shifts, wc, word, zeroes, size, row_no);
            else {
                cerr << "ERROR: You must provide a valid sequence. Aborting." << endl;
                exit(1);
            }
        }

            else if ((ca[0]>0.||cb[0]>0.||co[0]>0.) && (ca[1]>0.||cb[1]>0.||co[1]>0.) && \
             (ca[2]>0.||cb[2]>0.||co[2]>0.) && (ca[3]>0.||cb[3]>0.||co[3]>0.) && (ca[4]>0.||cb[4]>0.||co[4]>0.) && (ca[5]>0.||cb[5]>0.||co[5]>0.) && (ca[6]>0.||cb[6]>0.||co[6]>0.)  && (ca[7]>0.||cb[7]>0.||co[7]>0.) && (ca[8]>0.||cb[8]>0.||co[8]>0.) ) {
        for (int i=0; i<9; i++)
        {
            if(ca[i]==0.)
                zeroes++;
            if(cb[i]==0.)
                zeroes++;
            if(co[i]==0.)
                zeroes++;
        }
            size=9;
            if (sequence.size() > 8)
                calcScore9resSeq(shifts, wc, word, zeroes, size, row_no);
            else {
                cerr << "ERROR: You must provide a valid sequence. Aborting." << endl;
                exit(1);
            }
        }

            else if ((ca[0]>0.||cb[0]>0.||co[0]>0.) && (ca[1]>0.||cb[1]>0.||co[1]>0.) && \
             (ca[2]>0.||cb[2]>0.||co[2]>0.) && (ca[3]>0.||cb[3]>0.||co[3]>0.) && (ca[4]>0.||cb[4]>0.||co[4]>0.) && (ca[5]>0.||cb[5]>0.||co[5]>0.) && (ca[6]>0.||cb[6]>0.||co[6]>0.)  && (ca[7]>0.||cb[7]>0.||co[7]>0.)) {
        for (int i=0; i<8; i++)
        {
            if(ca[i]==0.)
                zeroes++;
            if(cb[i]==0.)
                zeroes++;
            if(co[i]==0.)
                zeroes++;
        }
            size=8;
            if (sequence.size() > 7)
                calcScore8resSeq(shifts, wc, word, zeroes, size, row_no);
            else {
                cerr << "ERROR: You must provide a valid sequence. Aborting." << endl;
                exit(1);
            }
        }

        else if ((ca[0]>0.||cb[0]>0.||co[0]>0.) && (ca[1]>0.||cb[1]>0.||co[1]>0.) && \
             (ca[2]>0.||cb[2]>0.||co[2]>0.) && (ca[3]>0.||cb[3]>0.||co[3]>0.) && (ca[4]>0.||cb[4]>0.||co[4]>0.) && (ca[5]>0.||cb[5]>0.||co[5]>0.) && (ca[6]>0.||cb[6]>0.||co[6]>0.) ) {
        for (int i=0; i<7; i++)
        {
            if(ca[i]==0.)
                zeroes++;
            if(cb[i]==0.)
                zeroes++;
            if(co[i]==0.)
                zeroes++;
        }
            size=7;
            if (sequence.size() > 6)
                calcScore7resSeq(shifts, wc, word, zeroes, size, row_no);
            else {
                cerr << "ERROR: You must provide a valid sequence. Aborting." << endl;
                exit(1);
            }
        }


        else if ((ca[0]>0.||cb[0]>0.||co[0]>0.) && (ca[1]>0.||cb[1]>0.||co[1]>0.) && \
             (ca[2]>0.||cb[2]>0.||co[2]>0.) && (ca[3]>0.||cb[3]>0.||co[3]>0.) && (ca[4]>0.||cb[4]>0.||co[4]>0.) && (ca[5]>0.||cb[5]>0.||co[5]>0.) ) {
        for (int i=0; i<6; i++)
        {
            if(ca[i]==0.)
                zeroes++;
            if(cb[i]==0.)
                zeroes++;
            if(co[i]==0.)
                zeroes++;
        }
            size=6;
            if (sequence.size() > 5)
                calcScore6resSeq(shifts, wc, word, zeroes, size, row_no);
            else {
                cerr << "ERROR: You must provide a valid sequence. Aborting." << endl;
                exit(1);
            }
        }

        else if ((ca[0]>0.||cb[0]>0.||co[0]>0.) && (ca[1]>0.||cb[1]>0.||co[1]>0.) && \
             (ca[2]>0.||cb[2]>0.||co[2]>0.) && (ca[3]>0.||cb[3]>0.||co[3]>0.) && (ca[4]>0.||cb[4]>0.||co[4]>0.)  ) {
        for (int i=0; i<5; i++)
        {
            if(ca[i]==0.)
                zeroes++;
            if(cb[i]==0.)
                zeroes++;
            if(co[i]==0.)
                zeroes++;
        }
            size=5;
            if (sequence.size() > 4)
                calcScore5resSeq(shifts, wc, word, zeroes, size, row_no);
            else {
                cerr << "ERROR: You must provide a valid sequence. Aborting." << endl;
                exit(1);
            }
        }

        else if ((ca[0]>0.||cb[0]>0.||co[0]>0.) && (ca[1]>0.||cb[1]>0.||co[1]>0.) && \
             (ca[2]>0.||cb[2]>0.||co[2]>0.) && (ca[3]>0.||cb[3]>0.||co[3]>0.)) {
        for (int i=0; i<4; i++)
        {
            if(ca[i]==0.)
                zeroes++;
            if(cb[i]==0.)
                zeroes++;
            if(co[i]==0.)
                zeroes++;
        }
            size=4;
            if (sequence.size() > 3)
                calcScore4resSeq(shifts, wc, word, zeroes, size, row_no);
            else {
                cerr << "ERROR: You must provide a valid sequence. Aborting." << endl;
                exit(1);
            }
        }
        else if ((ca[0]>0. || cb[0]>0. || co[0]>0.) && (ca[1]>0. || cb[1]>0. || co[1]>0.) && \
                  (ca[2]>0. || cb[2]>0. || co[2]>0.)) {
        for (int i=0; i<3; i++)
        {
            if(ca[i]==0.)
                zeroes++;
            if(cb[i]==0.)
                zeroes++;
            if(co[i]==0.)
                zeroes++;
        }
            size=3;
            if (sequence.size() > 2)
                calcScore3resSeq(shifts, wc, word, zeroes, size, row_no);
        }
        else if ((ca[0]>0. || cb[0]>0. || co[0]>0.) && (ca[1]>0. || cb[1]>0. || co[1]>0.))
        {
        for (int i=0; i<2; i++)
        {
            if(ca[i]==0.)
                zeroes++;
            if(cb[i]==0.)
                zeroes++;
            if(co[i]==0.)
                zeroes++;
        }
            size=2;
            if (sequence.size() > 1)
                calcScore2resSeq(shifts, wc, word, zeroes, size, row_no);
        }
        else if ((ca[0]==0. && cb[0]==0. && co[0]==0.) && (ca[1]>0. || cb[1]>0. || co[1]>0.))
        {
            if(ca[1]==0.)
                zeroes++;
            if(cb[1]==0.)
                zeroes++;
            if(co[1]==0.)
                zeroes++;
            zeroes+=3;
            size=2;
            if (sequence.size() > 1)
                calcScore2resSeq(shifts, wc, word, zeroes, size, row_no);
        }
        else if ((ca[0]>0. || cb[0]>0. || co[0]>0.) && (ca[1]==0. && cb[1]==0. && co[1]==0.))
        {
            if(ca[0]==0.)
                zeroes++;
            if(cb[0]==0.)
                zeroes++;
            if(co[0]==0.)
                zeroes++;
            zeroes+=3;
            size=2;
            if (sequence.size() > 1)
                calcScore2resSeq(shifts, wc, word, zeroes, size, row_no);
        }
    }

    void calcScore4resSeq(ShiftTypeb &shifts,  int wc, string word[1000], int zeroes, int size, int row_no)
    {
        for (unsigned int m=0; m<sequence.size()-3; m++) {
if(sequence[m+1]!="PRO" && sequence[m+2]!="PRO" && sequence[m+3]!="PRO")
        for (int i=0; i<=STRAND; i++)
            for (int j=0; j<=STRAND; j++)
                for (int k=0; k<=STRAND; k++)
                    for (int l=0; l<=STRAND; l++)
                {
                            getDatabaseShifts(0, shifts.resIdx(sequence[m]), i, shifts);
                            getDatabaseShifts(1, shifts.resIdx(sequence[m+1]), j, shifts);
                            getDatabaseShifts(2, shifts.resIdx(sequence[m+2]), k, shifts);
                            getDatabaseShifts(3, shifts.resIdx(sequence[m+3]), l, shifts);

                            if (deuter > 0.)
                                correctIso(shifts, m, 4);
                if (pdeuter > 0.)
                        correctIso_pD(shifts, m, 4);

                            tempScore = calcChiSq(cadb, cbdb, codb, 4, zeroes, size);
                            if (tempScore < top[MAX_TOP-1].score) {
                                setResult(top[MAX_TOP-1], tempScore, firstRes, m, i, j, k, l);
                                for (int n=MAX_TOP-1; n>0 && top[n].score < top[n-1].score; n--)
                                    swap(top[n], top[n-1]);
                            }
                        }}
        printresult(4, true, wc, word, row_no);
    }


    void calcScore3resSeq(ShiftTypeb &shifts, int wc, string word[1000], int zeroes, int size, int row_no)
    {
        for (unsigned int m=0; m<sequence.size()-2; m++) {
            if (sequence[m+1]!="PRO" && sequence[m+2]!="PRO")
        for (int i=LOOP; i<=STRAND; i++)
            for (int j=LOOP; j<=STRAND; j++)
                for (int k=LOOP; k<=STRAND; k++)
                        {
                        getDatabaseShifts(0, shifts.resIdx(sequence[m]), i, shifts);
                        getDatabaseShifts(1, shifts.resIdx(sequence[m+1]), j, shifts);
                        getDatabaseShifts(2, shifts.resIdx(sequence[m+2]), k, shifts);

                        if (deuter > 0.)
                            correctIso(shifts, m, 3);
            if (pdeuter > 0.)
                            correctIso_pD(shifts, m, 3);

                        tempScore = calcChiSq(cadb, cbdb, codb, 3, zeroes, size);
                        if (tempScore < top[MAX_TOP-1].score) {
                            setResult(top[MAX_TOP-1], tempScore, firstRes, m, i, j, k);
                            for (int n=MAX_TOP-1; n>0 && top[n].score < top[n-1].score; n--)
                                swap(top[n], top[n-1]);
                        }
                }}
        printresult(3, true, wc, word, row_no);
    }
        void calcScore2resSeq(ShiftTypeb &shifts, int wc, string word[1000], int zeroes, int size, int row_no)
    {
            for (unsigned int m=0; m<sequence.size()-1; m++) {
                if (sequence[m+1]!="PRO")
        for (int i=LOOP; i<=STRAND; i++)
            for (int j=LOOP; j<=STRAND; j++){
                        getDatabaseShifts(0, shifts.resIdx(sequence[m]), i, shifts);
                        getDatabaseShifts(1, shifts.resIdx(sequence[m+1]), j, shifts);

                        if (deuter > 0.)
                            correctIso(shifts, m, 2);
            if (pdeuter > 0.)
                            correctIso_pD(shifts, m, 2);

                        tempScore = calcChiSq(cadb, cbdb, codb, 2, zeroes, size);
                        if (tempScore < top[MAX_TOP-1].score) {
                            setResult(top[MAX_TOP-1], tempScore, firstRes, m, i, j);
                            for (int n=MAX_TOP-1; n>0 && top[n].score < top[n-1].score; n--)
                                swap(top[n], top[n-1]);
                        }
                }}
        printresult(2, true, wc, word, row_no);
    }
    void calcScore5resSeq(ShiftTypeb &shifts,  int wc, string word[1000], int zeroes, int size, int row_no)
    {
        for (unsigned int m=0; m<sequence.size()-4; m++) {
    if(sequence[m+1]!="PRO" && sequence[m+2]!="PRO" && sequence[m+3]!="PRO" && sequence[m+4]!="PRO")
        for (int i=0; i<=STRAND; i++)
            for (int j=0; j<=STRAND; j++)
                for (int k=0; k<=STRAND; k++)
                    for (int l=0; l<=STRAND; l++)
                    for (int m2=0; m2<=STRAND; m2++)
                {
                            getDatabaseShifts(0, shifts.resIdx(sequence[m]), i, shifts);
                            getDatabaseShifts(1, shifts.resIdx(sequence[m+1]), j, shifts);
                            getDatabaseShifts(2, shifts.resIdx(sequence[m+2]), k, shifts);
                            getDatabaseShifts(3, shifts.resIdx(sequence[m+3]), l, shifts);
                getDatabaseShifts(4, shifts.resIdx(sequence[m+4]), m2, shifts);


                            if (deuter > 0.)
                                correctIso(shifts, m, 5);
                if (pdeuter > 0.)
                        correctIso_pD(shifts, m, 5);

                            tempScore = calcChiSq(cadb, cbdb, codb, 5, zeroes, size);
                            if (tempScore < top[MAX_TOP-1].score) {
                                setResult(top[MAX_TOP-1], tempScore, firstRes, m, i, j, k, l, m2);
                                for (int n=MAX_TOP-1; n>0 && top[n].score < top[n-1].score; n--)
                                    swap(top[n], top[n-1]);
                            }
                        }}
        printresult(5, true, wc, word, row_no);
    }

    void calcScore6resSeq(ShiftTypeb &shifts,  int wc, string word[1000], int zeroes, int size, int row_no)
    {
        for (unsigned int m=0; m<sequence.size()-5; m++) {
    if(sequence[m+1]!="PRO" && sequence[m+2]!="PRO" && sequence[m+3]!="PRO" && sequence[m+4]!="PRO" && sequence[m+5]!="PRO")
        for (int i=0; i<=STRAND; i++)
            for (int j=0; j<=STRAND; j++)
                for (int k=0; k<=STRAND; k++)
                    for (int l=0; l<=STRAND; l++)
                    for (int m2=0; m2<=STRAND; m2++)
                        for (int n2=0; n2<=STRAND; n2++)
                {
                            getDatabaseShifts(0, shifts.resIdx(sequence[m]), i, shifts);
                            getDatabaseShifts(1, shifts.resIdx(sequence[m+1]), j, shifts);
                            getDatabaseShifts(2, shifts.resIdx(sequence[m+2]), k, shifts);
                            getDatabaseShifts(3, shifts.resIdx(sequence[m+3]), l, shifts);
                getDatabaseShifts(4, shifts.resIdx(sequence[m+4]), m2, shifts);
                getDatabaseShifts(5, shifts.resIdx(sequence[m+5]), n2, shifts);

                            if (deuter > 0.)
                                correctIso(shifts, m, 6);
                if (pdeuter > 0.)
                        correctIso_pD(shifts, m, 6);

                            tempScore = calcChiSq(cadb, cbdb, codb, 6, zeroes, size);
                            if (tempScore < top[MAX_TOP-1].score) {
                                setResult(top[MAX_TOP-1], tempScore, firstRes, m, i, j, k, l, m2, n2);
                                for (int n=MAX_TOP-1; n>0 && top[n].score < top[n-1].score; n--)
                                    swap(top[n], top[n-1]);
                            }
                        }}
        printresult(6, true, wc, word, row_no);
    }

    void calcScore7resSeq(ShiftTypeb &shifts,  int wc, string word[1000], int zeroes, int size, int row_no)
    {
        for (unsigned int m=0; m<sequence.size()-6; m++) {
    if(sequence[m+1]!="PRO" && sequence[m+2]!="PRO" && sequence[m+3]!="PRO" && sequence[m+4]!="PRO" && sequence[m+5]!="PRO" && sequence[m+6]!="PRO")
        for (int i=0; i<=STRAND; i++)
            for (int j=0; j<=STRAND; j++)
                for (int k=0; k<=STRAND; k++)
                    for (int l=0; l<=STRAND; l++)
                    for (int m2=0; m2<=STRAND; m2++)
                        for (int n2=0; n2<=STRAND; n2++)
                            for (int o=0; o<=STRAND; o++)
                {
                            getDatabaseShifts(0, shifts.resIdx(sequence[m]), i, shifts);
                            getDatabaseShifts(1, shifts.resIdx(sequence[m+1]), j, shifts);
                            getDatabaseShifts(2, shifts.resIdx(sequence[m+2]), k, shifts);
                            getDatabaseShifts(3, shifts.resIdx(sequence[m+3]), l, shifts);
                getDatabaseShifts(4, shifts.resIdx(sequence[m+4]), m2, shifts);
                getDatabaseShifts(5, shifts.resIdx(sequence[m+5]), n2, shifts);
                getDatabaseShifts(6, shifts.resIdx(sequence[m+6]), o, shifts);

                            if (deuter > 0.)
                                correctIso(shifts, m, 7);
                if (pdeuter > 0.)
                        correctIso_pD(shifts, m, 7);

                            tempScore = calcChiSq(cadb, cbdb, codb, 7, zeroes, size);
                            if (tempScore < top[MAX_TOP-1].score) {
                                setResult(top[MAX_TOP-1], tempScore, firstRes, m, i, j, k, l, m2, n2, o);
                                for (int n=MAX_TOP-1; n>0 && top[n].score < top[n-1].score; n--)
                                    swap(top[n], top[n-1]);
                            }
                        }}
        printresult(7, true, wc, word, row_no);
    }


    void calcScore8resSeq(ShiftTypeb &shifts,  int wc, string word[1000], int zeroes, int size, int row_no)
    {
        for (unsigned int m=0; m<sequence.size()-7; m++) {
    if(sequence[m+1]!="PRO" && sequence[m+2]!="PRO" && sequence[m+3]!="PRO" && sequence[m+4]!="PRO" && sequence[m+5]!="PRO" && sequence[m+6]!="PRO" && sequence[m+7]!="PRO")
        for (int i=0; i<=STRAND; i++)
            for (int j=0; j<=STRAND; j++)
                for (int k=0; k<=STRAND; k++)
                    for (int l=0; l<=STRAND; l++)
                    for (int m2=0; m2<=STRAND; m2++)
                        for (int n2=0; n2<=STRAND; n2++)
                            for (int o=0; o<=STRAND; o++)
                                for (int p=0; p<=STRAND; p++)
                {
                            getDatabaseShifts(0, shifts.resIdx(sequence[m]), i, shifts);
                            getDatabaseShifts(1, shifts.resIdx(sequence[m+1]), j, shifts);
                            getDatabaseShifts(2, shifts.resIdx(sequence[m+2]), k, shifts);
                            getDatabaseShifts(3, shifts.resIdx(sequence[m+3]), l, shifts);
                getDatabaseShifts(4, shifts.resIdx(sequence[m+4]), m2, shifts);
                getDatabaseShifts(5, shifts.resIdx(sequence[m+5]), n2, shifts);
                getDatabaseShifts(6, shifts.resIdx(sequence[m+6]), o, shifts);
                getDatabaseShifts(7, shifts.resIdx(sequence[m+7]), p, shifts);

                            if (deuter > 0.)
                                correctIso(shifts, m, 8);
                if (pdeuter > 0.)
                        correctIso_pD(shifts, m, 8);

                            tempScore = calcChiSq(cadb, cbdb, codb, 8, zeroes, size);
                            if (tempScore < top[MAX_TOP-1].score) {
                                setResult(top[MAX_TOP-1], tempScore, firstRes, m, i, j, k, l, m2, n2, o, p);
                                for (int n=MAX_TOP-1; n>0 && top[n].score < top[n-1].score; n--)
                                    swap(top[n], top[n-1]);
                            }
                        }}
        printresult(8, true, wc, word, row_no);
    }

    void calcScore9resSeq(ShiftTypeb &shifts,  int wc, string word[1000], int zeroes, int size, int row_no)
    {
        for (unsigned int m=0; m<sequence.size()-8; m++) {
    if(sequence[m+1]!="PRO" && sequence[m+2]!="PRO" && sequence[m+3]!="PRO" && sequence[m+4]!="PRO" && sequence[m+5]!="PRO" && sequence[m+6]!="PRO" && sequence[m+7]!="PRO" && sequence[m+8]!="PRO")
        for (int i=0; i<=STRAND; i++)
            for (int j=0; j<=STRAND; j++)
                for (int k=0; k<=STRAND; k++)
                    for (int l=0; l<=STRAND; l++)
                    for (int m2=0; m2<=STRAND; m2++)
                        for (int n2=0; n2<=STRAND; n2++)
                            for (int o=0; o<=STRAND; o++)
                                for (int p=0; p<=STRAND; p++)
                                    for (int q=0; q<=STRAND; q++)
                {
                            getDatabaseShifts(0, shifts.resIdx(sequence[m]), i, shifts);
                            getDatabaseShifts(1, shifts.resIdx(sequence[m+1]), j, shifts);
                            getDatabaseShifts(2, shifts.resIdx(sequence[m+2]), k, shifts);
                            getDatabaseShifts(3, shifts.resIdx(sequence[m+3]), l, shifts);
                getDatabaseShifts(4, shifts.resIdx(sequence[m+4]), m2, shifts);
                getDatabaseShifts(5, shifts.resIdx(sequence[m+5]), n2, shifts);
                getDatabaseShifts(6, shifts.resIdx(sequence[m+6]), o, shifts);
                getDatabaseShifts(7, shifts.resIdx(sequence[m+7]), p, shifts);
                getDatabaseShifts(8, shifts.resIdx(sequence[m+8]), q, shifts);

                            if (deuter > 0.)
                                correctIso(shifts, m, 9);
                if (pdeuter > 0.)
                        correctIso_pD(shifts, m, 9);

                            tempScore = calcChiSq(cadb, cbdb, codb, 9, zeroes, size);
                            if (tempScore < top[MAX_TOP-1].score) {
                                setResult(top[MAX_TOP-1], tempScore, firstRes, m, i, j, k, l, m2, n2, o, p, q);
                                for (int n=MAX_TOP-1; n>0 && top[n].score < top[n-1].score; n--)
                                    swap(top[n], top[n-1]);
                            }
                        }}
        printresult(9, true, wc, word, row_no);
    }

    void calcScore10resSeq(ShiftTypeb &shifts,  int wc, string word[1000], int zeroes, int size, int row_no)
    {
        for (unsigned int m=0; m<sequence.size()-9; m++) {
    if(sequence[m+1]!="PRO" && sequence[m+2]!="PRO" && sequence[m+3]!="PRO" && sequence[m+4]!="PRO" && sequence[m+5]!="PRO" && sequence[m+6]!="PRO" && sequence[m+7]!="PRO" && sequence[m+8]!="PRO" && sequence[m+9]!="PRO")
        for (int i=0; i<=STRAND; i++)
            for (int j=0; j<=STRAND; j++)
                for (int k=0; k<=STRAND; k++)
                    for (int l=0; l<=STRAND; l++)
                    for (int m2=0; m2<=STRAND; m2++)
                        for (int n2=0; n2<=STRAND; n2++)
                            for (int o=0; o<=STRAND; o++)
                                for (int p=0; p<=STRAND; p++)
                                    for (int q=0; q<=STRAND; q++)
                                        for (int r=0; r<=STRAND; r++)
                {
                            getDatabaseShifts(0, shifts.resIdx(sequence[m]), i, shifts);
                            getDatabaseShifts(1, shifts.resIdx(sequence[m+1]), j, shifts);
                            getDatabaseShifts(2, shifts.resIdx(sequence[m+2]), k, shifts);
                            getDatabaseShifts(3, shifts.resIdx(sequence[m+3]), l, shifts);
                getDatabaseShifts(4, shifts.resIdx(sequence[m+4]), m2, shifts);
                getDatabaseShifts(5, shifts.resIdx(sequence[m+5]), n2, shifts);
                getDatabaseShifts(6, shifts.resIdx(sequence[m+6]), o, shifts);
                getDatabaseShifts(7, shifts.resIdx(sequence[m+7]), p, shifts);
                getDatabaseShifts(8, shifts.resIdx(sequence[m+8]), q, shifts);
                getDatabaseShifts(9, shifts.resIdx(sequence[m+9]), r, shifts);


                            if (deuter > 0.)
                                correctIso(shifts, m, 10);
                if (pdeuter > 0.)
                        correctIso_pD(shifts, m, 10);

                            tempScore = calcChiSq(cadb, cbdb, codb, 10, zeroes, size);
                            if (tempScore < top[MAX_TOP-1].score) {
                                setResult(top[MAX_TOP-1], tempScore, firstRes, m, i, j, k, l, m2, n2, o, p, q, r);
                                for (int n=MAX_TOP-1; n>0 && top[n].score < top[n-1].score; n--)
                                    swap(top[n], top[n-1]);
                            }
                        }}
        printresult(10, true, wc, word, row_no);
    }

    void printresult(const int nresid, const bool seq, int wc, string word[1000], int row_no)
    {
        if (seq)
        {}
        int results = nresid > 1 ? max_result : 20;
        {
                            sorted[1].sortLines[0]="*****\t\t\t\t**************";
                                sorted[1].sortLines[1]="Index\t\t\t\tTOP 20 RESULTS";
                                sorted[1].sortLines[2]="*****\t\t\t\t**************";
                if(ss_exist==true)
                {
                if(nresid==4)
                {
                    sorted[1].sortLines[0]+="\t\t\t\t\t\t\t**************";
                    sorted[1].sortLines[1]+="\t\t\t\t\t\t\tSS correlation";
                    sorted[1].sortLines[2]+="\t\t\t\t\t\t\t**************";
                }
                else if (nresid==2)
                {
                    sorted[1].sortLines[0]+="\t\t\t\t**************";
                    sorted[1].sortLines[1]+="\t\t\t\tSS correlation";
                    sorted[1].sortLines[2]+="\t\t\t\t**************";
                }
                else if (nresid==3)
                {
                    sorted[1].sortLines[0]+="\t\t\t\t\t**************";
                    sorted[1].sortLines[1]+="\t\t\t\t\tSS correlation";
                    sorted[1].sortLines[2]+="\t\t\t\t\t**************";
                }
                else if (nresid==7)
                {
                    sorted[1].sortLines[0]+="\t\t\t\t\t\t\t\t\t\t**************";
                    sorted[1].sortLines[1]+="\t\t\t\t\t\t\t\t\t\tSS correlation";
                    sorted[1].sortLines[2]+="\t\t\t\t\t\t\t\t\t\t**************";
                }
                else if (nresid==8)
                {
                    sorted[1].sortLines[0]+="\t\t\t\t\t\t\t\t\t\t\t\t**************";
                    sorted[1].sortLines[1]+="\t\t\t\t\t\t\t\t\t\t\t\tSS correlation";
                    sorted[1].sortLines[2]+="\t\t\t\t\t\t\t\t\t\t\t\t**************";
                }
                else if (nresid==9)
                {
                    sorted[1].sortLines[0]+="\t\t\t\t\t\t\t\t\t\t\t\t**************";
                    sorted[1].sortLines[1]+="\t\t\t\t\t\t\t\t\t\t\t\tSS correlation";
                    sorted[1].sortLines[2]+="\t\t\t\t\t\t\t\t\t\t\t\t**************";
                }
                else if (nresid==10)
                {
                    sorted[1].sortLines[0]+="\t\t\t\t\t\t\t\t\t\t\t\t\t**************";
                    sorted[1].sortLines[1]+="\t\t\t\t\t\t\t\t\t\t\t\t\tSS correlation";
                    sorted[1].sortLines[2]+="\t\t\t\t\t\t\t\t\t\t\t\t\t**************";
                }
                else if (nresid==6)
                {
                    sorted[1].sortLines[0]+="\t\t\t\t\t\t\t\t\t\t**************";
                    sorted[1].sortLines[1]+="\t\t\t\t\t\t\t\t\t\tSS correlation";
                    sorted[1].sortLines[2]+="\t\t\t\t\t\t\t\t\t\t**************";
                }
                else if (nresid==5)
                {
                    sorted[1].sortLines[0]+="\t\t\t\t\t\t\t\t**************";
                    sorted[1].sortLines[1]+="\t\t\t\t\t\t\t\tSS correlation";
                    sorted[1].sortLines[2]+="\t\t\t\t\t\t\t\t**************";
                }
                }


            for (int i=0; i<results; i++)
            {
                sorted[1].sortLines[3+i] += itoa_sort(matchno*1000+row_no);
                            sorted[1].sortLines[3+i] +=".";
                            sorted[1].sortLines[3+i] += itoa_sort(i+1);
                            sorted[1].sortLines[3+i] +="\t";

            for (int j=0; j<nresid-1; j++)
            {
                sorted[1].sortLines[3+i] += top[i].res[j];
                    sorted[1].sortLines[3+i] += "-";
            }
            sorted[1].sortLines[3+i] += top[i].res[nresid-1];
            sorted[1].sortLines[3+i] += "\t\t";

                        sorted[1].sortLines[3+i] += itoa_sort(top[i].resno);
                    sorted[1].sortLines[3+i] += "-";
                    sorted[1].sortLines[3+i] += itoa_sort(top[i].resno + nresid-1);
                    sorted[1].sortLines[3+i] += "\t\t";
            string ss_array[10];
            string ss_array2[10];


            if(ss_exist==true)
            {
            for (int o=0; o<10; o++){
                ss_array[o]="NULL";
                ss_array2[o]="NULL";}}


            for (int j=0; j<nresid-1; j++)
            {
                sorted[1].sortLines[3+i] += top[i].ss[j];
                sorted[1].sortLines[3+i] +="-";
                if(ss_exist==true)
                ss_array[j]=top[i].ss[j];
            }


            sorted[1].sortLines[3+i] +=top[i].ss[nresid-1];
            sorted[1].sortLines[3+i] +="\t";
            if(nresid==8)
                sorted[1].sortLines[3+i] +="\t";

            sorted[1].sortLines[3+i] += ftoa_sort(top[i].score);
            if (CHI==1)
                sorted[1].sortKey= top[0].score;
            else
                sorted[1].sortKey= top[0].resno;

            if(ss_exist==true && top[i].resno-firstRes+1>=1)
            {
//
//
            ss_array[nresid-1]=top[i].ss[nresid-1];
//
            bool correct_ss=false;
            int p=0;
            for (int m=top[i].resno-firstRes+1; m<top[i].resno-firstRes+1+nresid; m++){
                ss_array2[p]=ss_sequence[m-1];
                p++;}
            int ss_counter=0;
            for (int j=0; j<10; j++){
                if(ss_array2[j]==ss_array[j]){
                    ss_counter++;}}
            if (ss_counter==10)
                correct_ss=true;
            else
                correct_ss=false;

            if(correct_ss==true)
            {
                if(nresid==8 || nresid==9 || nresid==10)
                    sorted[1].sortLines[3+i] +="\tYes";
                else
                    sorted[1].sortLines[3+i] +="\t\tYes";
            }
            }
            }



            sorted[1].sortLines[23] = "#";
            sorted[1].sortLines[24] = "#";
            for(int w=0; w<wc; w++)
            {
                if(word[w]=="#")
                {
                    for(int y=w+1; y<wc;y++)
                    {
                        sorted[1].sortLines[24] += " ";
                        sorted[1].sortLines[24] += word[y];
                    }
                    break;
                }
            }
                    if (nresid == 4) {
                sorted[1].sortLines[25] = "#________________________________________________________________________";

                            sorted[1].sortLines[26] = "#\t\tResidue 1\tResidue 2\tResidue 3\tResidue 4";
                        sorted[1].sortLines[27] = "#| CA |\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[0]);
                        sorted[1].sortLines[27] += "\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[1]);
                        sorted[1].sortLines[27] +="\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[2]);
                            sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[3]);
                            sorted[1].sortLines[28] ="#| CB |\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[0]);
                            sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[1]);
                            sorted[1].sortLines[28] += "\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[2]);
                            sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[3]);
                            sorted[1].sortLines[29] ="#| CO |\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[0]);
                            sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[1]);
                            sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[2]);
                        sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[3]);
                            sorted[1].sortLines[30] ="#________________________________________________________________________";
                    }
        else if (nresid == 3) {
            sorted[1].sortLines[25] = "#________________________________________________________________________";
                    sorted[1].sortLines[26] ="#\t\tResidue 1\tResidue 2\tResidue 3";
                    sorted[1].sortLines[27] ="#| CA |\t\t";
                    sorted[1].sortLines[27] += ftoa_sort(ca[0]);
                    sorted[1].sortLines[27] +="\t\t";
                    sorted[1].sortLines[27] += ftoa_sort(ca[1]);
                    sorted[1].sortLines[27] +="\t\t";
                    sorted[1].sortLines[27] += ftoa_sort(ca[2]);
                    sorted[1].sortLines[28] ="#| CB |\t\t";
                    sorted[1].sortLines[28] += ftoa_sort(cb[0]);
                    sorted[1].sortLines[28] += "\t\t";
                    sorted[1].sortLines[28] += ftoa_sort(cb[1]);
                    sorted[1].sortLines[28] += "\t\t";
                    sorted[1].sortLines[28] += ftoa_sort(cb[2]);
                    sorted[1].sortLines[29] ="#| CO |\t\t";
                    sorted[1].sortLines[29] += ftoa_sort(co[0]);
                    sorted[1].sortLines[29] +="\t\t";
                    sorted[1].sortLines[29] += ftoa_sort(co[1]);
                    sorted[1].sortLines[29] +="\t\t";
                    sorted[1].sortLines[29] += ftoa_sort(co[2]);
                    sorted[1].sortLines[30] ="#________________________________________________________________________";
                }
        else if (nresid == 2) {
            sorted[1].sortLines[25] = "#_________________________________________________________________";
                    sorted[1].sortLines[26] ="#\t\tResidue 1\tResidue 2";
                    sorted[1].sortLines[27] ="#| CA |\t\t";
                    sorted[1].sortLines[27] += ftoa_sort(ca[0]);
                    sorted[1].sortLines[27] +="\t\t";
                    sorted[1].sortLines[27] += ftoa_sort(ca[1]);
                    sorted[1].sortLines[28] ="#| CB |\t\t";
                    sorted[1].sortLines[28] += ftoa_sort(cb[0]);
                    sorted[1].sortLines[28] += "\t\t";
                    sorted[1].sortLines[28] += ftoa_sort(cb[1]);
                    sorted[1].sortLines[29] ="#| CO |\t\t";
                    sorted[1].sortLines[29] += ftoa_sort(co[0]);
                    sorted[1].sortLines[29] +="\t\t";
                    sorted[1].sortLines[29] += ftoa_sort(co[1]);
                    sorted[1].sortLines[30] ="#_________________________________________________________________";
        }
        else if (nresid == 5) {
                sorted[1].sortLines[25] = "#________________________________________________________________________________________";
                            sorted[1].sortLines[26] = "#\t\tResidue 1\tResidue 2\tResidue 3\tResidue 4\tResidue 5";
                        sorted[1].sortLines[27] = "#| CA |\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[0]);
                        sorted[1].sortLines[27] += "\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[1]);
                        sorted[1].sortLines[27] +="\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[2]);
                            sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[3]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[4]);

                            sorted[1].sortLines[28] ="#| CB |\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[0]);
                            sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[1]);
                            sorted[1].sortLines[28] += "\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[2]);
                            sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[3]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[4]);

                            sorted[1].sortLines[29] ="#| CO |\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[0]);
                            sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[1]);
                            sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[2]);
                        sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[3]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[4]);

                            sorted[1].sortLines[30] ="#________________________________________________________________________________________";
                }

            else if (nresid == 6) {
                sorted[1].sortLines[25] = "#________________________________________________________________________________________________________";

                            sorted[1].sortLines[26] = "#\t\tResidue 1\tResidue 2\tResidue 3\tResidue 4\tResidue 5\tResidue 6";
                        sorted[1].sortLines[27] = "#| CA |\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[0]);
                        sorted[1].sortLines[27] += "\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[1]);
                        sorted[1].sortLines[27] +="\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[2]);
                            sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[3]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[4]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[5]);


                            sorted[1].sortLines[28] ="#| CB |\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[0]);
                            sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[1]);
                            sorted[1].sortLines[28] += "\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[2]);
                            sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[3]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[4]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[5]);

                            sorted[1].sortLines[29] ="#| CO |\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[0]);
                            sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[1]);
                            sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[2]);
                        sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[3]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[4]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[5]);

                            sorted[1].sortLines[30] ="#________________________________________________________________________________________________________";
                }
            else if (nresid == 7) {
                sorted[1].sortLines[25] = "#________________________________________________________________________________________________________________________";
                            sorted[1].sortLines[26] = "#\t\tResidue 1\tResidue 2\tResidue 3\tResidue 4\tResidue 5\tResidue 6\tResidue 7";
                        sorted[1].sortLines[27] = "#| CA |\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[0]);
                        sorted[1].sortLines[27] += "\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[1]);
                        sorted[1].sortLines[27] +="\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[2]);
                            sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[3]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[4]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[5]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[6]);


                            sorted[1].sortLines[28] ="#| CB |\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[0]);
                            sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[1]);
                            sorted[1].sortLines[28] += "\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[2]);
                            sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[3]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[4]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[5]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[6]);


                            sorted[1].sortLines[29] ="#| CO |\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[0]);
                            sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[1]);
                            sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[2]);
                        sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[3]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[4]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[5]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[6]);

                            sorted[1].sortLines[30] ="#_________________________________________________________________________________________________________________________";
                }
            else if (nresid == 8) {
                sorted[1].sortLines[25] = "#________________________________________________________________________________________________________________________________________";

                            sorted[1].sortLines[26] = "#\t\tResidue 1\tResidue 2\tResidue 3\tResidue 4\tResidue 5\tResidue 6\tResidue 7\tResidue 8";
                        sorted[1].sortLines[27] = "#| CA |\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[0]);
                        sorted[1].sortLines[27] += "\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[1]);
                        sorted[1].sortLines[27] +="\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[2]);
                            sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[3]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[4]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[5]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[6]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[7]);


                            sorted[1].sortLines[28] ="#| CB |\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[0]);
                            sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[1]);
                            sorted[1].sortLines[28] += "\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[2]);
                            sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[3]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[4]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[5]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[6]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[7]);


                            sorted[1].sortLines[29] ="#| CO |\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[0]);
                            sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[1]);
                            sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[2]);
                        sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[3]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[4]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[5]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[6]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[7]);

                            sorted[1].sortLines[30] ="#_________________________________________________________________________________________________________________________________________";
                }
                else if (nresid == 9) {
                sorted[1].sortLines[25] ="#_________________________________________________________________________________________________________________________________________________________";
                            sorted[1].sortLines[26] = "#\t\tResidue 1\tResidue 2\tResidue 3\tResidue 4\tResidue 5\tResidue 6\tResidue 7\tResidue 8\tResidue 9";
                        sorted[1].sortLines[27] = "#| CA |\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[0]);
                        sorted[1].sortLines[27] += "\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[1]);
                        sorted[1].sortLines[27] +="\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[2]);
                            sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[3]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[4]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[5]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[6]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[7]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[8]);
                            sorted[1].sortLines[28] ="#| CB |\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[0]);
                            sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[1]);
                            sorted[1].sortLines[28] += "\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[2]);
                            sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[3]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[4]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[5]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[6]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[7]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[8]);
                            sorted[1].sortLines[29] ="#| CO |\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[0]);
                            sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[1]);
                            sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[2]);
                        sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[3]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[4]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[5]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[6]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[7]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[8]);
                            sorted[1].sortLines[30] ="#_________________________________________________________________________________________________________________________________________________________";
                }
            else if (nresid == 10) {
                sorted[1].sortLines[25] ="#_________________________________________________________________________________________________________________________________________________________________________";
                            sorted[1].sortLines[26] = "#\t\tResidue 1\tResidue 2\tResidue 3\tResidue 4\tResidue 5\tResidue 6\tResidue 7\tResidue 8\tResidue 9\tResidue 10";
                        sorted[1].sortLines[27] = "#| CA |\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[0]);
                        sorted[1].sortLines[27] += "\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[1]);
                        sorted[1].sortLines[27] +="\t\t";
                        sorted[1].sortLines[27] += ftoa_sort(ca[2]);
                            sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[3]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[4]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[5]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[6]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[7]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[8]);
                sorted[1].sortLines[27] +="\t\t";
                            sorted[1].sortLines[27] += ftoa_sort(ca[9]);
                            sorted[1].sortLines[28] ="#| CB |\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[0]);
                            sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[1]);
                            sorted[1].sortLines[28] += "\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[2]);
                            sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[3]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[4]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[5]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[6]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[7]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[8]);
                sorted[1].sortLines[28] +="\t\t";
                            sorted[1].sortLines[28] += ftoa_sort(cb[9]);

                            sorted[1].sortLines[29] ="#| CO |\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[0]);
                            sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[1]);
                            sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[2]);
                        sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[3]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[4]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[5]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[6]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[7]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[8]);
                sorted[1].sortLines[29] += "\t\t";
                            sorted[1].sortLines[29] += ftoa_sort(co[9]);

                            sorted[1].sortLines[30] ="#_________________________________________________________________________________________________________________________________________________________________________";
                }
        sorted[1].sortLines[31] = itoa_sort(nresid);


}
    printSortedResult();

    for (int te=0; te<32;te++)
        sorted[1].sortLines[te]="";

    }

    void printSortedResult()
    {
    ofstream resultfile2, resultfile3, resultfile4, resultfile5, resultfile6,resultfile7,resultfile8,resultfile9,resultfile10, resultfileC;
    ofstream resultfile2b, resultfile3b, resultfile4b, resultfile5b, resultfile6b,resultfile7b,resultfile8b,resultfile9b,resultfile10b, resultfileCb;
    string filen2, filen3, filen4, filen5, filen6, filen7, filen8, filen9, filen10, filenC;

    filenames+="Analysis/";
    filen2=filenames;
    filen2+="compass_result2_match";
    filen2+=itoa_sort(matchno);
    filen3=filenames;
    filen3+="compass_result3_match";
    filen3+=itoa_sort(matchno);
    filen4=filenames;
    filen4+="compass_result4_match";
    filen4+=itoa_sort(matchno);

    {
    filen5=filenames;
    filen5+="compass_result5_match";
    filen5+=itoa_sort(matchno);
    filen6=filenames;
    filen6+="compass_result6_match";
    filen6+=itoa_sort(matchno);
    filen7=filenames;
    filen7+="compass_result7_match";
    filen7+=itoa_sort(matchno);
    filen8=filenames;
    filen8+="compass_result8_match";
    filen8+=itoa_sort(matchno);
    filen9=filenames;
    filen9+="compass_result9_match";
    filen9+=itoa_sort(matchno);
    filen10=filenames;
    filen10+="compass_result10_match";
    filen10+=itoa_sort(matchno);
    }
    filenC=filenames;
    filenC+="COMPASSresult_match";
    filenC+=itoa_sort(matchno);
    resultfile2.open (filen2.c_str(), ios_base::app);
    resultfile3.open (filen3.c_str(), ios_base::app);
    resultfile4.open (filen4.c_str(), ios_base::app);

    {
    resultfile5.open (filen5.c_str(), ios_base::app);
    resultfile6.open (filen6.c_str(), ios_base::app);
    resultfile7.open (filen7.c_str(), ios_base::app);
    resultfile8.open (filen8.c_str(), ios_base::app);
    resultfile9.open (filen9.c_str(), ios_base::app);
    resultfile10.open (filen10.c_str(), ios_base::app);
    }
    resultfileC.open (filenC.c_str(), ios_base::app);

    for (int j=0; j<31; j++)
    {
        if(sorted[1].sortLines[31]=="2")
            resultfile2<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="3")
            resultfile3<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="4")
            resultfile4<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="5")
            resultfile5<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="6")
            resultfile6<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="7")
            resultfile7<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="8")
            resultfile8<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="9")
            resultfile9<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="10")
            resultfile10<<sorted[1].sortLines[j]<<endl;
        resultfileC<<sorted[1].sortLines[j]<<endl;
    }

    filen2+=".bak";
    filen3+=".bak";
    filen4+=".bak";
    filen5+=".bak";
    filen6+=".bak";
    filen7+=".bak";
    filen8+=".bak";
    filen9+=".bak";
    filen10+=".bak";
    filenC+=".bak";

    resultfile2b.open (filen2.c_str(), ios_base::app);
    resultfile3b.open (filen3.c_str(), ios_base::app);
    resultfile4b.open (filen4.c_str(), ios_base::app);

    {
    resultfile5b.open (filen5.c_str(), ios_base::app);
    resultfile6b.open (filen6.c_str(), ios_base::app);
    resultfile7b.open (filen7.c_str(), ios_base::app);
    resultfile8b.open (filen8.c_str(), ios_base::app);
    resultfile9b.open (filen9.c_str(), ios_base::app);
    resultfile10b.open (filen10.c_str(), ios_base::app);
    }
    resultfileCb.open (filenC.c_str(), ios_base::app);

    for (int j=0; j<31; j++)
    {
        if(sorted[1].sortLines[31]=="2")
            resultfile2b<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="3")
            resultfile3b<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="4")
            resultfile4b<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="5")
            resultfile5b<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="6")
            resultfile6b<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="7")
            resultfile7b<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="8")
            resultfile8b<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="9")
            resultfile9b<<sorted[1].sortLines[j]<<endl;
        if(sorted[1].sortLines[31]=="10")
            resultfile10b<<sorted[1].sortLines[j]<<endl;
        resultfileCb<<sorted[1].sortLines[j]<<endl;
    }
    resultfile2.close();
    resultfile3.close();
    resultfile4.close();

    {
    resultfile5.close();
    resultfile6.close();
    resultfile7.close();
    resultfile8.close();
    resultfile9.close();
    resultfile10.close();
    }
    resultfileC.close();
    resultfile2b.close();
    resultfile3b.close();
    resultfile4b.close();

    {
    resultfile5b.close();
    resultfile6b.close();
    resultfile7b.close();
    resultfile8b.close();
    resultfile9b.close();
    resultfile10b.close();
    }
    resultfileCb.close();
    }


    void setResult(ResultTypeb &top, double score, int first, int idx, int i, int j, int k, int l)
    {
        top.score = score;
        top.resno = first + idx;
        top.ss[0] =  i==0? "loop" : (i==1)? "helx" : "strd";
        top.ss[1] =  j==0? "loop" : (j==1)? "helx" : "strd";
        top.ss[2] =  k==0? "loop" : (k==1)? "helx" : "strd";
        top.ss[3] =  l==0? "loop" : (l==1)? "helx" : "strd";
        for (int xx=0; xx<4; xx++)
            top.res[xx] = sequence[idx+xx];
    }

    void setResult(ResultTypeb &top, double score, int first, int idx, int i, int j, int k)
    {
        top.score = score;
        top.resno = first + idx;
        top.ss[0] =  i==0? "loop" : (i==1)? "helx" : "strd";
        top.ss[1] =  j==0? "loop" : (j==1)? "helx" : "strd";
        top.ss[2] =  k==0? "loop" : (k==1)? "helx" : "strd";
        for (int xx=0; xx<3; xx++)
            top.res[xx] = sequence[idx+xx];
    }
    void setResult(ResultTypeb &top, double score, int first, int idx, int i, int j)
    {
        top.score = score;
        top.resno = first + idx;
        top.ss[0] =  i==0? "loop" : (i==1)? "helx" : "strd";
        top.ss[1] =  j==0? "loop" : (j==1)? "helx" : "strd";
        for (int xx=0; xx<2; xx++)
            top.res[xx] = sequence[idx+xx];
    }

    void setResult(ResultTypeb &top, double score, int first, int idx, int i, int j, int k, int l, int m)
    {
        top.score = score;
        top.resno = first + idx;
        top.ss[0] =  i==0? "loop" : (i==1)? "helx" : "strd";
        top.ss[1] =  j==0? "loop" : (j==1)? "helx" : "strd";
        top.ss[2] =  k==0? "loop" : (k==1)? "helx" : "strd";
        top.ss[3] =  l==0? "loop" : (l==1)? "helx" : "strd";
        top.ss[4] =  m==0? "loop" : (m==1)? "helx" : "strd";
        for (int xx=0; xx<5; xx++)
            top.res[xx] = sequence[idx+xx];
    }

    void setResult(ResultTypeb &top, double score, int first, int idx, int i, int j, int k, int l, int m, int n)
    {
        top.score = score;
        top.resno = first + idx;
        top.ss[0] =  i==0? "loop" : (i==1)? "helx" : "strd";
        top.ss[1] =  j==0? "loop" : (j==1)? "helx" : "strd";
        top.ss[2] =  k==0? "loop" : (k==1)? "helx" : "strd";
        top.ss[3] =  l==0? "loop" : (l==1)? "helx" : "strd";
        top.ss[4] =  m==0? "loop" : (m==1)? "helx" : "strd";
        top.ss[5] =  n==0? "loop" : (n==1)? "helx" : "strd";
        for (int xx=0; xx<6; xx++)
            top.res[xx] = sequence[idx+xx];
    }
    void setResult(ResultTypeb &top, double score, int first, int idx, int i, int j, int k, int l, int m, int n, int o)
    {
        top.score = score;
        top.resno = first + idx;
        top.ss[0] =  i==0? "loop" : (i==1)? "helx" : "strd";
        top.ss[1] =  j==0? "loop" : (j==1)? "helx" : "strd";
        top.ss[2] =  k==0? "loop" : (k==1)? "helx" : "strd";
        top.ss[3] =  l==0? "loop" : (l==1)? "helx" : "strd";
        top.ss[4] =  m==0? "loop" : (m==1)? "helx" : "strd";
        top.ss[5] =  n==0? "loop" : (n==1)? "helx" : "strd";
        top.ss[6] =  o==0? "loop" : (o==1)? "helx" : "strd";
        for (int xx=0; xx<7; xx++)
            top.res[xx] = sequence[idx+xx];
    }
    void setResult(ResultTypeb &top, double score, int first, int idx, int i, int j, int k, int l, int m, int n, int o, int p)
    {
        top.score = score;
        top.resno = first + idx;
        top.ss[0] =  i==0? "loop" : (i==1)? "helx" : "strd";
        top.ss[1] =  j==0? "loop" : (j==1)? "helx" : "strd";
        top.ss[2] =  k==0? "loop" : (k==1)? "helx" : "strd";
        top.ss[3] =  l==0? "loop" : (l==1)? "helx" : "strd";
        top.ss[4] =  m==0? "loop" : (m==1)? "helx" : "strd";
        top.ss[5] =  n==0? "loop" : (n==1)? "helx" : "strd";
        top.ss[6] =  o==0? "loop" : (o==1)? "helx" : "strd";
        top.ss[7] =  p==0? "loop" : (p==1)? "helx" : "strd";
        for (int xx=0; xx<8; xx++)
            top.res[xx] = sequence[idx+xx];
    }
    void setResult(ResultTypeb &top, double score, int first, int idx, int i, int j, int k, int l, int m, int n, int o, int p, int q)
    {
        top.score = score;
        top.resno = first + idx;
        top.ss[0] =  i==0? "loop" : (i==1)? "helx" : "strd";
        top.ss[1] =  j==0? "loop" : (j==1)? "helx" : "strd";
        top.ss[2] =  k==0? "loop" : (k==1)? "helx" : "strd";
        top.ss[3] =  l==0? "loop" : (l==1)? "helx" : "strd";
        top.ss[4] =  m==0? "loop" : (m==1)? "helx" : "strd";
        top.ss[5] =  n==0? "loop" : (n==1)? "helx" : "strd";
        top.ss[6] =  o==0? "loop" : (o==1)? "helx" : "strd";
        top.ss[7] =  p==0? "loop" : (p==1)? "helx" : "strd";
        top.ss[8] =  q==0? "loop" : (q==1)? "helx" : "strd";
        for (int xx=0; xx<9; xx++)
            top.res[xx] = sequence[idx+xx];
    }
    void setResult(ResultTypeb &top, double score, int first, int idx, int i, int j, int k, int l, int m, int n, int o, int p, int q, int r)
    {
        top.score = score;
        top.resno = first + idx;
        top.ss[0] =  i==0? "loop" : (i==1)? "helx" : "strd";
        top.ss[1] =  j==0? "loop" : (j==1)? "helx" : "strd";
        top.ss[2] =  k==0? "loop" : (k==1)? "helx" : "strd";
        top.ss[3] =  l==0? "loop" : (l==1)? "helx" : "strd";
        top.ss[4] =  m==0? "loop" : (m==1)? "helx" : "strd";
        top.ss[5] =  n==0? "loop" : (n==1)? "helx" : "strd";
        top.ss[6] =  o==0? "loop" : (o==1)? "helx" : "strd";
        top.ss[7] =  p==0? "loop" : (p==1)? "helx" : "strd";
        top.ss[8] =  q==0? "loop" : (q==1)? "helx" : "strd";
        top.ss[9] =  r==0? "loop" : (r==1)? "helx" : "strd";
        for (int xx=0; xx<10; xx++)
            top.res[xx] = sequence[idx+xx];
    }
    void idx2ss(string &ss, int i)
    {
        ss =  i==0? "loop" : (i==1)? "helx" : "strd";
    }


    void getDatabaseShifts(const int idx, const int resid, int ss, ShiftTypeb &shifts)
    {
        cadb[idx] = ss==LOOP ? shifts.ca_rc[resid] : ss==HELIX ? shifts.ca_helix_ave[resid] : shifts.ca_strand_ave[resid];
        cbdb[idx] = ss==LOOP ? shifts.cb_rc[resid] : ss==HELIX ? shifts.cb_helix_ave[resid] : shifts.cb_strand_ave[resid];
        codb[idx] = ss==LOOP ? shifts.co_rc[resid] : ss==HELIX ? shifts.co_helix_ave[resid] : shifts.co_strand_ave[resid];
    }

    void correctIso(ShiftTypeb &shifts, int first, int noRes)
    {
        for (int i=0; i<noRes; i++)
            shifts.correctIso(shifts.resIdx(sequence[first+i]), CA[i], CB[i], CO[i], ca[i], cb[i], co[i]);
    }

    void correctIso_pD(ShiftTypeb &shifts, int first, int noRes)
    {
        for (int i=0; i<noRes; i++)
            shifts.correctIso_pD(shifts.resIdx(sequence[first+i]), CA[i], CB[i], CO[i], ca[i], cb[i], co[i]);
    }

    string itoa_sort(int integer)
    {
        string converted;
        stringstream converted_out;
        converted_out << integer;
        converted = converted_out.str();
        return converted;
    }
    string ftoa_sort(double dubs)
    {
        string d_conv;
        stringstream d_conv_out;
        d_conv_out << dubs;
        d_conv = d_conv_out.str();
        return d_conv;
    }

};
#endif
