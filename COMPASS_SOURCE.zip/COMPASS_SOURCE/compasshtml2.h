#ifndef COMPASSHTML2_H
#define COMPASSHTML2_H

#include "compassvec.h"
#include "globals.h"
void compasshtml2();
#endif
