#ifndef QUERYERROR7_H
#define QUERYERROR7_H

#include <QDialog>

namespace Ui
{
	class QueryError7;
}

class QueryError7 : public QDialog
{
	Q_OBJECT

public:
	QueryError7(QWidget *parent = 0);
	~QueryError7();
private:
	Ui::QueryError7 *ui;

private slots:
	void setError();
    void on_closeErrButton6_clicked();
};

#endif
