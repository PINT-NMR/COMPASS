#ifndef COMPASSANALYZE2_H
#define COMPASSANALYZE2_H

#include <fstream>
#include <cmath>
#include <complex>
#include <iostream> 
#include <iomanip>
#include <vector>
#include <limits>
#include <stdlib.h> 
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include "compassvec.h"
#include "generator.h"
void compass_analyze2(string cafile, string cbcafile, string cofile, string cafile2, string cbcafile2, string cofile2, string seq, string ss, string deutS, int match, int first, double dev, string namefiles,string resultfile, string indexfile, string hsqcfile);
#endif
