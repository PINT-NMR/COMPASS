#ifndef COMPASSVEC_H
#define COMPASSVEC_H
#include <fstream>
#include <cmath>
#include <complex>
#include <iostream>
#include <iomanip>
#include <vector>
#include <limits>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
using namespace std;

typedef std::vector<double> CompassVec;

#endif // COMPASSVEC_H
