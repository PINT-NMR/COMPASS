#include "indexerror.h"
#include "ui_indexerror.h"
#include <QtWidgets>
#include <cstdlib>
#include "QRect"	
#include "QDesktopWidget"	
#include <fstream>
#include <iostream>
#include <globals.h>

IndexError::IndexError(QWidget *parent) :
	QMainWindow(parent),
	ui(new Ui::IndexError)
{
	ui->setupUi(this);
	QRect position = frameGeometry();	
	position.moveCenter(QDesktopWidget().availableGeometry().center());
 	move(position.topLeft());
	readerrfile();
}

IndexError::~IndexError()
{
	delete ui;
}

void IndexError::changeEvent(QEvent *e)
{
	QMainWindow::changeEvent(e);
	switch (e->type())
	{
		case QEvent::LanguageChange:
			ui->retranslateUi(this);
			break;
			default:
			break;
	}
}

void IndexError::readerrfile()
{
	extern QString filenames;
	QString fread = filenames;
	fread+="Temp/rename_errors.txt";
	QFile file(fread);
	file.open(QFile::ReadOnly | QFile::Text);
	QTextStream ReadFile(&file);
	ui->errorBrowser->setText(ReadFile.readAll());
}
