#include "compassrename.h"
#include "ui_compassrename.h"
#include <QtWidgets>
#include <cstdlib>
#include "QRect"		
#include "QDesktopWidget"	
#include "globals.h"
#include <fstream>
#include <iostream>
#include <qfiledialog.h>
#include "globals.h"
#include "compassfunctions.h"
#include "QMessageBox"


CompassRename::CompassRename(QWidget *parent) :
    QWidget(parent),
	ui(new Ui::CompassRename)
{
	ui->setupUi(this);
	ui->errorLabel->hide();
}

CompassRename::~CompassRename()
{
	delete ui;
}

void CompassRename::on_menu_renameButton_clicked()
{
    emit goToMain();
}

void CompassRename::on_project_renameButton_clicked()
{
	QString pathPro;
	pathPro = QFileDialog::getOpenFileName(
	this,
	"Choose a .cpro file",
	QString::null,
	tr("COMPASS project files (*.cpro)"));
	if(pathPro!="")
	{
        ui->project_renameLine->setText(convSlash(pathPro));
		extern QString profile;
		profile = pathPro;
	}
}

void CompassRename::on_analyze_renameButton_clicked()
{
    if (ui->project_renameLine->text()!="")
    {
        QString qFile = ui->project_renameLine->text();

        if (QFile::exists(qFile))
        {
            QString proFileOK=proFileCheck(qFile);

            if (proFileOK=="" || proFileOK=="PRE")
            {
                extern bool preassign;
                if(proFileOK=="PRE")
                {
                    QMessageBox::StandardButton dialog;
                    dialog = QMessageBox::warning(this, "COMPASS",
                                 "Do you want COMPASS to pre-assign spin systems according to any existing assignments?\nAssignments can be changed manually later.\nWarning! This process can take several minutes. During this time COMPASS will be unresponsive.",
                                 QMessageBox::Yes | QMessageBox::No);
                    if( dialog == QMessageBox::Yes)
                    {
                        preassign=true;
                        ui->errorLabel->show();
                        ui->errorBrowser->setText("Please wait while COMPASS is pre-assigning spin systems.\nDo not quit COMPASS. This process can take several minutes.");
                    }
                    disablePreassignment(qFile);
                }
                else
                    preassign=false;
                emit renderRename();
            }
            else
            {
                ui->errorLabel->show();
                ui->errorBrowser->setText(proFileOK);
            }
        }
        else
        {
           ui->errorLabel->show();
           ui->errorBrowser->setText("The submitted COMPASS project file does not exist. Please submit an existing file. ");
        }
    }
    else
	{
		ui->errorLabel->show();
        ui->errorBrowser->setText(" Please submit a COMPASS project file. ");
	}

}

void CompassRename::disablePreassignment(QString qFile)
{
    std::string infile=qFile.toUtf8().data();
    std::ifstream file;
    std::string line;
    file.open(infile.c_str(), std::ios::in);
    std::vector<std::string> tmpVec;
    while(getline(file, line))
        tmpVec.push_back(line);
    file.clear();
    file.close();
    QFile::remove(qFile);
    std::ofstream fileo;
    fileo.open(infile.c_str(), std::ios::out);
    for(uint i=0; i<tmpVec.size()-1; i++)
        fileo<<tmpVec[i]<<"\n";
    fileo<<"EMPTY";
    fileo.clear();
    fileo.close();
}
QString CompassRename::proFileCheck(QString qFile)
{
    std::string infile=qFile.toUtf8().data();
    std::ifstream file;
    std::string line;
    QString retstr="";
    file.open(infile.c_str(), std::ios::in);
    int counter=0;
    while(file.good())
    {
        getline(file,line);
        counter++;
    }
    file.clear();
    file.close();
    counter--;

    file.open(infile.c_str(), std::ios::in);

    getline(file,line);
    QString qFile2=QString::fromStdString(line);
    if (QFile::exists(qFile2)==false)
        retstr= "Project directory does not exist or the project file has been moved from its correct place. Please submit a project file with correct parameters.";

    getline(file,line);
    qFile2=QString::fromStdString(line);
        if (qFile2!="EMPTY" && QFile::exists(qFile2)==false)
        {
            retstr= "The file ";
            retstr+=qFile2;
            retstr+=" does not exist.\nPlease submit a project file with correct parameters.";
        }
    getline(file,line);
    qFile2=QString::fromStdString(line);
        if (qFile2!="EMPTY" && QFile::exists(qFile2)==false)
        {
            retstr= "The file ";
            retstr+=qFile2;
            retstr+=" does not exist.\nPlease submit a project file with correct parameters.";
        }

    getline(file,line);
    qFile2=QString::fromStdString(line);
        if (qFile2!="EMPTY" && QFile::exists(qFile2)==false)
        {
            retstr= "The file ";
            retstr+=qFile2;
            retstr+=" does not exist.\nPlease submit a project file with correct parameters.";
        }

    getline(file,line);
    qFile2=QString::fromStdString(line);
        if (qFile2!="EMPTY" && QFile::exists(qFile2)==false)
        {
            retstr= "The file ";
            retstr+=qFile2;
            retstr+=" does not exist.\nPlease submit a project file with correct parameters.";
        }

    getline(file,line);
    int num = line.length();
    for (int i=0;i<num;i++)
        if (!isdigit(line[i]))
            retstr="The project file does not have the correct format. Line 6 should contain the number of the first residue. Please submit a valid project file.";

    getline(file,line);
    qFile2=QString::fromStdString(line);
        if (qFile2!="EMPTY" && QFile::exists(qFile2)==false)
        {
            retstr= "The file ";
            retstr+=qFile2;
            retstr+=" does not exist.\nPlease submit a project file with correct parameters.";
        }

    getline(file,line);
    qFile2=QString::fromStdString(line);
        if (qFile2!="EMPTY" && QFile::exists(qFile2)==false)
        {
            retstr= "The file ";
            retstr+=qFile2;
            retstr+=" does not exist.\nPlease submit a project file with correct parameters.";
        }

    getline(file,line);
    qFile2=QString::fromStdString(line);
        if (qFile2!="EMPTY" && QFile::exists(qFile2)==false)
        {
            retstr= "The file ";
            retstr+=qFile2;
            retstr+=" does not exist.\nPlease submit a project file with correct parameters.";
        }

    getline(file,line);
    qFile2=QString::fromStdString(line);
        if (qFile2!="EMPTY" && QFile::exists(qFile2)==false)
        {
            retstr= "The file ";
            retstr+=qFile2;
            retstr+=" does not exist.\nPlease submit a project file with correct parameters.";
        }

    getline(file,line);
    if (line!="EMPTY" && line!="pD" && line!="D")
      retstr="The project file does not have the correct format.\nPlease submit a valid project file.";

    getline(file,line);
    if (line!="Yes" && line!="No")
        retstr="The project file does not have the correct format. Line 12 should contain 'Yes' (Trosy) or 'No' (no Trosy). Please submit a valid project file.";

    getline(file,line);
    qFile2=QString::fromStdString(line);
        if (qFile2!="EMPTY" && QFile::exists(qFile2)==false)
        {
            retstr= "The file ";
            retstr+=qFile2;
            retstr+=" does not exist.\nPlease submit a project file with correct parameters.";
        }

    getline(file,line);
    if(line=="PRE")
        retstr="PRE";
    file.clear();
    file.close();

    return retstr;
}

void CompassRename::on_quit_renameButton_clicked()
{
    QApplication::quit();
}
