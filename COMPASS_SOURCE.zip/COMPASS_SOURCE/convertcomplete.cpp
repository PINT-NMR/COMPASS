#include "convertcomplete.h"
#include "ui_convertcomplete.h"
#include <QtWidgets>
#include <cstdlib>
#include <fstream>
#include <iostream>

ConvertComplete::ConvertComplete(QWidget *parent) :
    QDialog(parent),
	ui(new Ui::ConvertComplete)
{
	ui->setupUi(this);
}

ConvertComplete::~ConvertComplete()
{
	delete ui;
}

void ConvertComplete::on_closeButton_clicked()
{
    accept();
}
