#include "compassfunctions.h"
#include <iostream>

QString checkProjectName(QString qStr)
{
    std::string str=qStr.toUtf8().data();
    for (unsigned int i=0;i<str.length();i++)
    {
        if (!isdigit(str[i]) && !isalpha(str[i]) && str[i]!='.' && str[i]!='-' && str[i]!='_')
            return "Illegal character in the project name.\nAllowed characters are [A-Z], [a-z], [0-9], '.', '_' and '-'.";
    }
    return "";
}
QString makeSlashLast(QString qfolder)
{
    char lastS;
    std::string tempS = qfolder.toUtf8().data();
    int lengthS = tempS.length();
    lastS = tempS[lengthS-1];
    if(lastS!='/' && lastS!='\\')
        qfolder+="/"; //Windows Version
    return qfolder;
}
QString convSlash(QString word)
{
    std::string w = word.toUtf8().data();
    for(unsigned int i=0;i<w.length();i++)
        if(w[i]=='\\')
            w[i]='/';
    return QString::fromUtf8(w.c_str());
}

