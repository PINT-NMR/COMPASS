#include "compass_analyze2.h"
void compass_analyze2(string cafile, string cbcafile, string cofile, string cafile2, string cbcafile2, string cofile2, string seq, string ss, string deutS, int match, int first, double dev, string namefiles,string resultfile, string indexfile, string hsqcfile)
{
    if(ss=="" && deutS=="" && match==0 && first==0 && dev==0.0 && seq=="")
    {}
    std::ifstream file;
    fstream errors;
    string errors1 = namefiles;
    errors1+="Temp/rename_errors.txt";
    errors.open(errors1.c_str(), ios::out);
    bool errB=false;

    if(indexfile!="EMPTY")
    {
        file.open(indexfile.c_str());
        if(!file.is_open())
        {
            errors<<"Index file not found. Aborting."<<endl<<endl;
            errors.clear();
            errors.close();
            errB=true;
        }
        else
        {
        file.clear();
        file.close();
        }
    }
    if(hsqcfile!="EMPTY")
    {
        file.open(hsqcfile.c_str());
        if(!file.is_open())
        {
            errors<<"HSQC file not found. Aborting."<<endl<<endl;
            errors.clear();
            errors.close();
            errB=true;
        }
        else
        {
        file.clear();
        file.close();
        }
    }
    if(cbcafile!="EMPTY")
        {
                    file.open(cbcafile.c_str());
                if(!file.is_open())
                {
                    errors<<"HNCACB list not found. Aborting."<<endl<<endl;
                    errors.clear();
                    errors.close();
                    errB=true;
                }
                else
                {
                    file.clear();
                    file.close();
                }
        }
            if(cafile!="EMPTY")
            {
                    file.open(cafile.c_str());
                if(!file.is_open())
                {
                    errors<<"HNCA list not found. Aborting."<<endl<<endl;
                    errors.clear();
                    errors.close();
                    errB=true;
                }
                else
                {
                    file.clear();
                    file.close();
                }
            }
            if(cofile!="EMPTY")
            {
                    file.open(cofile.c_str());
                if(!file.is_open())
                {
                    errors<<"HNCACO list not found. Aborting."<<endl<<endl;
                    errors.clear();
                    errors.close();
                    errB=true;
                }
                else
                {
                    file.clear();
                    file.close();
                }
            }
            if(cbcafile2!="EMPTY")
            {
                    file.open(cbcafile2.c_str());
                if(!file.is_open())
                {
                    errors<<"HNCOCACB list not found. Aborting."<<endl<<endl;
                    errors.clear();
                    errors.close();
                    errB=true;
                }
                else
                {
                    file.clear();
                    file.close();
                }
            }
            if(cafile2!="EMPTY")
            {
                    file.open(cafile2.c_str());
                if(!file.is_open())
                {
                    errors<<"HNCOCA list not found. Aborting."<<endl<<endl;
                    errors.clear();
                    errors.close();
                    errB=true;
                }
                else
                {
                    file.clear();
                    file.close();
                }
            }
            if(cofile2!="EMPTY")
            {
                    file.open(cofile2.c_str());
                if(!file.is_open())
                {
                    errors<<"HNCO list not found. Aborting."<<endl<<endl;
                    errors.clear();
                    errors.close();
                    errB=true;
                }
                else
                {
                    file.clear();
                    file.close();
                }
            }
            errors.clear();
            errors.close();
            if(errB==false)
            {
                GeneratorType generator;
                generator.generate(resultfile, indexfile, cafile, cbcafile, cofile, hsqcfile, cafile2, cbcafile2, cofile2, namefiles);
            }

}

