#include "compasshtml2.h"
void compasshtml2()
{
    extern QString profile;
    std::string fname, line, fname2, ifile, idxline, idxArr[3003];
    std::ifstream file, idxfile;
    std::ofstream fileOut;
    int iC=0;
    fname=profile.toStdString();
    file.open(fname.c_str(), std::ios::in);
    getline(file, line);
    file.clear();
    file.close();
    ifile=line+"Analysis/htmlindex.idx";
    std::string checkfile =line+"Analysis/indice.idx";
    std::ifstream checkf;
    checkf.open(checkfile.c_str(), std::ios::in);
    std::string linec;
    getline(checkf, linec);
    checkf.clear();
    checkf.close();
    if(linec=="")
    {
        std::ofstream filecf;
        filecf.open(ifile.c_str(), std::ios::out);
        filecf<<"";
        filecf.clear();
        filecf.close();
    }

    idxfile.open(ifile.c_str(), std::ios::in);
    bool exist=true;
    if(!idxfile.is_open())
        exist=false;
    else
    {
        getline(idxfile,idxline);
        std::istringstream iss(idxline);
        while(iss>>idxArr[iC])
            iC++;
    }
    if(exist==true)
    {
        for(int files=0; files<2; files++)
        {
            for(int match=1; match<4; match++)
            {
                for(int i=2; i<=10; i++)
                {
                    std::string converted, converted2;
                    std::stringstream ss, ss2;
                    ss << i;
                    ss >> converted;
                    ss2 << match;
                    ss2 >> converted2;
                    fname2=line+"Analysis/compass_result"+converted+"_match"+converted2+"_sort";
                    if(files==0)
                        fname2+="CHI_html";
                    else
                        fname2+="_html";
                    file.open(fname2.c_str(), std::ios::in);
                    if(!file.is_open())
                        break;
                    else
                    {
                        int fC=0;
                        std::string lineR;

                        while(file.good())
                        {
                            getline(file, lineR);
                            fC++;
                        }
                        fC--;
                        file.clear();
                        file.close();
                        file.open(fname2.c_str(), std::ios::in);
                        fC/=32;
                        fname2+=".bak";
                        fileOut.open(fname2.c_str(), std::ios::out);
                        std::string temp_rows[32];
                        for(int l=0; l<fC; l++)
                        {
                            for(int k=0; k<32; k++)
                            {
                                getline(file, lineR);
                                temp_rows[k]=lineR;
                            }
                            std::string idx = temp_rows[3].substr(9,4);
                            if(temp_rows[3].substr(0,4)=="<FON")
                                idx=temp_rows[3].substr(49,4);
                            bool write=true;
                            for(int j=0; j<iC; j++)
                            {
                                if(idx==idxArr[j])
                                {
                                    write=false;
                                    break;
                                }
                            }
                            if(write==true)
                                for(int k=0; k<32;k++)
                                    fileOut<<temp_rows[k]<<std::endl;
                        }
                        file.clear();
                        file.close();
                        fileOut.clear();
                        fileOut.close();
                    }
                }
            }
        }
    }
};
