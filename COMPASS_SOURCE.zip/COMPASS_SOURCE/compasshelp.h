#ifndef COMPASSHELP_H
#define COMPASSHELP_H

#include <QDialog>

namespace Ui
{
	class CompassHelp;
}

class CompassHelp : public QDialog
{
	Q_OBJECT

public:
	CompassHelp(QWidget *parent = 0);
	~CompassHelp();


private:
	Ui::CompassHelp *ui;

private slots:
	void on_closehelpButton_clicked();
	void on_cahelpButton_clicked();
};

#endif
