#ifndef COMPASSRENAME_H
#define COMPASSRENAME_H

#include <QWidget>

namespace Ui
{
	class CompassRename;
}

class CompassRename : public QWidget
{
	Q_OBJECT

public:
	CompassRename(QWidget *parent = 0);
	~CompassRename();

private:
	Ui::CompassRename *ui;

private slots:
	void on_menu_renameButton_clicked();
	void on_project_renameButton_clicked();
	void on_analyze_renameButton_clicked();
    QString proFileCheck(QString File);
    void disablePreassignment(QString qFile);

    void on_quit_renameButton_clicked();

signals:
    void goToMain();
    void renderRename();
};

#endif
