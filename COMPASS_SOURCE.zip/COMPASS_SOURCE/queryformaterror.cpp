#include "queryformaterror.h"
#include "ui_queryformaterror.h"
#include <QtWidgets>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include "globals.h"

QueryFormatError::QueryFormatError(QWidget *parent) :
    QDialog(parent),
	ui(new Ui::QueryFormatError)
{
	ui->setupUi(this);
	display();
}
void QueryFormatError::display()
{
	extern QString FormatError;
	ui->formatBrowser->setText(FormatError);
}
QueryFormatError::~QueryFormatError()
{
	delete ui;
}

void QueryFormatError::on_closeErrButton2_clicked()
{
    accept();
}
