#include "ssp.h"
#include <vector>
#include <sstream>
using namespace std;

    int getAa2(string aa)
    {
        int value=0;
        if(aa=="A")
            value=0;
        else if (aa=="C")
            value=1;
        else if (aa=="D")
            value=2;
        else if (aa=="E")
            value=3;
        else if (aa=="F")
            value=4;
        else if (aa=="G")
            value=5;
        else if (aa=="H")
            value=6;
        else if (aa=="I")
            value=7;
        else if (aa=="K")
            value=8;
        else if (aa=="L")
            value=9;
        else if (aa=="M")
            value=10;
        else if (aa=="N")
            value=11;
        else if (aa=="P")
            value=12;
        else if (aa=="Q")
            value=13;
        else if (aa=="R")
            value=14;
        else if (aa=="S")
            value=15;
        else if (aa=="T")
            value=16;
        else if (aa=="V")
            value=17;
        else if (aa=="W")
            value=18;
        else if (aa=="Y")
            value=19;

        return value;
    }

    double refdbCA2(int res)
    {
        double dbCA[20];
        dbCA[0]=52.84; //A
        dbCA[1]=57.53; //C
        dbCA[2]=54.18; //D
        dbCA[3]=56.87; //E
        dbCA[4]=57.98; //F
        dbCA[5]=45.51; //G
        dbCA[6]=55.86; //H
        dbCA[7]=61.03; //I
        dbCA[8]=56.69; //K
        dbCA[9]=54.92; //L
        dbCA[10]=55.67; //M
        dbCA[11]=53.23; //N
        dbCA[12]=63.47; //P
        dbCA[13]=56.12; //Q
        dbCA[14]=56.42; //R
        dbCA[15]=58.38; //S
        dbCA[16]=61.64; //T
        dbCA[17]=62.06; //V
        dbCA[18]=57.78; //W
        dbCA[19]=57.97; //Y

        return dbCA[res];
    }
    double refdbCB2(int res)
    {
        double dbCB[20];
        dbCB[0]=19.06;
        dbCB[1]=29.35;
        dbCB[2]=40.85;
        dbCB[3]=30.20;
        dbCB[4]=39.45;
        dbCB[5]=0.00;
        dbCB[6]=29.97;
        dbCB[7]=38.65;
        dbCB[8]=32.79;
        dbCB[9]=42.38;
        dbCB[10]=33.36;
        dbCB[11]=38.55;
        dbCB[12]=31.94;
        dbCB[13]=29.14;
        dbCB[14]=30.66;
        dbCB[15]=64.03;
        dbCB[16]=70.12;
        dbCB[17]=32.71;
        dbCB[18]=29.67;
        dbCB[19]=38.95;

        return dbCB[res];
    }
    double refdbCO2(int res)
    {
        double dbCO[20];
        dbCO[0]=177.67;
        dbCO[1]=174.93;
        dbCO[2]=176.31;
        dbCO[3]=176.43;
        dbCO[4]=175.59;
        dbCO[5]=173.89;
        dbCO[6]=174.83;
        dbCO[7]=175.57;
        dbCO[8]=176.34;
        dbCO[9]=176.89;
        dbCO[10]=175.35;
        dbCO[11]=175.08;
        dbCO[12]=176.89;
        dbCO[13]=175.90;
        dbCO[14]=176.02;
        dbCO[15]=174.49;
        dbCO[16]=174.70;
        dbCO[17]=175.66;
        dbCO[18]=176.15;
        dbCO[19]=175.39;

        return dbCO[res];
    }
    double refdbHN2(int res)
    {
        double dbHN[20];
        dbHN[0]=8.15;
        dbHN[1]=8.25;
        dbHN[2]=8.36;
        dbHN[3]=8.37;
        dbHN[4]=8.17;
        dbHN[5]=8.33;
        dbHN[6]=8.21;
        dbHN[7]=7.98;
        dbHN[8]=8.23;
        dbHN[9]=8.08;
        dbHN[10]=8.18;
        dbHN[11]=8.40;
        dbHN[12]=0.00;
        dbHN[13]=8.23;
        dbHN[14]=8.25;
        dbHN[15]=8.23;
        dbHN[16]=8.16;
        dbHN[17]=8.04;
        dbHN[18]=7.92;
        dbHN[19]=8.06;

        return dbHN[res];
    }
    double refdbN2(int res)
    {
        double dbN[20];
        dbN[0]=123.61;
        dbN[1]=117.96;
        dbN[2]=119.95;
        dbN[3]=120.43;
        dbN[4]=119.67;
        dbN[5]=109.13;
        dbN[6]=118.72;
        dbN[7]=120.87;
        dbN[8]=120.45;
        dbN[9]=121.48;
        dbN[10]=119.66;
        dbN[11]=118.22;
        dbN[12]=0.00;
        dbN[13]=119.49;
        dbN[14]=120.42;
        dbN[15]=115.55;
        dbN[16]=113.36;
        dbN[17]=119.77;
        dbN[18]=120.16;
        dbN[19]=119.52;

        return dbN[res];
    }
    double refdbSSCA2(int res, int col)
    {
        double dbCA_strand[20], dbCA_strand_sd[20], dbCA_helix[20], dbCA_helix_sd[20];
        dbCA_strand[0]= 51.53;  dbCA_strand_sd[0]= 1.48;  dbCA_helix[0]= 54.83;  dbCA_helix_sd[0]= 1.05;
        dbCA_strand[1]= 56.88;  dbCA_strand_sd[1]= 2.02;  dbCA_helix[1]= 61.31;  dbCA_helix_sd[1]= 3.50;
        dbCA_strand[2]= 53.87;  dbCA_strand_sd[2]= 1.64;  dbCA_helix[2]= 56.70;  dbCA_helix_sd[2]= 1.61;
        dbCA_strand[3]= 55.52;  dbCA_strand_sd[3]= 1.67;  dbCA_helix[3]= 59.11;  dbCA_helix_sd[3]= 1.16;
        dbCA_strand[4]= 56.65;  dbCA_strand_sd[4]= 1.59;  dbCA_helix[4]= 60.81;  dbCA_helix_sd[4]= 1.90;
        dbCA_strand[5]= 45.22;  dbCA_strand_sd[5]= 1.17;  dbCA_helix[5]= 46.91;  dbCA_helix_sd[5]= 1.10;
        dbCA_strand[6]= 55.09;  dbCA_strand_sd[6]= 1.78;  dbCA_helix[6]= 59.04;  dbCA_helix_sd[6]= 1.74;
        dbCA_strand[7]= 60.05;  dbCA_strand_sd[7]= 1.57;  dbCA_helix[7]= 64.57;  dbCA_helix_sd[7]= 1.74;
        dbCA_strand[8]= 55.40;  dbCA_strand_sd[8]= 1.34;  dbCA_helix[8]= 58.93;  dbCA_helix_sd[8]= 1.44;
        dbCA_strand[9]= 54.08;  dbCA_strand_sd[9]= 1.31;  dbCA_helix[9]= 57.52;  dbCA_helix_sd[9]= 1.23;
        dbCA_strand[10]= 54.58;  dbCA_strand_sd[10]= 1.24;  dbCA_helix[10]= 58.09;  dbCA_helix_sd[10]= 1.81;
        dbCA_strand[11]= 52.74;  dbCA_strand_sd[11]= 1.47;  dbCA_helix[11]= 55.45;  dbCA_helix_sd[11]= 1.42;
        dbCA_strand[12]= 62.64;  dbCA_strand_sd[12]= 1.03;  dbCA_helix[12]= 65.49;  dbCA_helix_sd[12]= 1.08;
        dbCA_strand[13]= 54.83;  dbCA_strand_sd[13]= 1.41;  dbCA_helix[13]= 58.47;  dbCA_helix_sd[13]= 1.19;
        dbCA_strand[14]= 55.14;  dbCA_strand_sd[14]= 1.64;  dbCA_helix[14]= 58.93;  dbCA_helix_sd[14]= 1.55;
        dbCA_strand[15]= 57.54;  dbCA_strand_sd[15]= 1.40;  dbCA_helix[15]= 60.88;  dbCA_helix_sd[15]= 1.61;
        dbCA_strand[16]= 61.06;  dbCA_strand_sd[16]= 1.59;  dbCA_helix[16]= 65.61;  dbCA_helix_sd[16]= 2.39;
        dbCA_strand[17]= 60.83;  dbCA_strand_sd[17]= 1.64;  dbCA_helix[17]= 66.16;  dbCA_helix_sd[17]= 1.55;
        dbCA_strand[18]= 56.41;  dbCA_strand_sd[18]= 1.87;  dbCA_helix[18]= 60.01;  dbCA_helix_sd[18]= 1.77;
        dbCA_strand[19]= 56.83;  dbCA_strand_sd[19]= 1.71;  dbCA_helix[19]= 60.98;  dbCA_helix_sd[19]= 1.76;

        if(col==0)
            return dbCA_strand[res];
        else if(col==1)
            return dbCA_strand_sd[res];
        else if(col==2)
            return dbCA_helix[res];
        else
            return dbCA_helix_sd[res];
    }
    double refdbSSCB2(int res, int col)
    {
        double dbCB_strand[20], dbCB_strand_sd[20], dbCB_helix[20], dbCB_helix_sd[20];
        dbCB_strand[0]= 21.14;  dbCB_strand_sd[0]= 2.05;  dbCB_helix[0]= 18.26;  dbCB_helix_sd[0]= 0.88;
        dbCB_strand[1]= 30.16;  dbCB_strand_sd[1]= 1.97;  dbCB_helix[1]= 27.75;  dbCB_helix_sd[1]= 2.07;
        dbCB_strand[2]= 42.30;  dbCB_strand_sd[2]= 1.62;  dbCB_helix[2]= 40.51;  dbCB_helix_sd[2]= 1.33;
        dbCB_strand[3]= 32.01;  dbCB_strand_sd[3]= 1.98;  dbCB_helix[3]= 29.37;  dbCB_helix_sd[3]= 0.88;
        dbCB_strand[4]= 41.54;  dbCB_strand_sd[4]= 1.74;  dbCB_helix[4]= 38.78;  dbCB_helix_sd[4]= 1.31;
        dbCB_strand[5]= 0.00;   dbCB_strand_sd[5]= 1.00;  dbCB_helix[5]= 0.00;   dbCB_helix_sd[5]= 1.00;
        dbCB_strand[6]= 31.85;  dbCB_strand_sd[6]= 2.22;  dbCB_helix[6]= 29.54;  dbCB_helix_sd[6]= 1.46;
        dbCB_strand[7]= 39.86;  dbCB_strand_sd[7]= 1.98;  dbCB_helix[7]= 37.60;  dbCB_helix_sd[7]= 1.15;
        dbCB_strand[8]= 34.63;  dbCB_strand_sd[8]= 1.78;  dbCB_helix[8]= 32.27;  dbCB_helix_sd[8]= 0.88;
        dbCB_strand[9]= 43.79;  dbCB_strand_sd[9]= 2.00;  dbCB_helix[9]= 41.65;  dbCB_helix_sd[9]= 1.05;
        dbCB_strand[10]= 35.05;  dbCB_strand_sd[10]= 2.29;  dbCB_helix[10]= 32.27;  dbCB_helix_sd[10]= 1.66;
        dbCB_strand[11]= 40.12;  dbCB_strand_sd[11]= 2.07;  dbCB_helix[11]= 38.61;  dbCB_helix_sd[11]= 1.31;
        dbCB_strand[12]= 32.27;  dbCB_strand_sd[12]= 1.20;  dbCB_helix[12]= 31.46;  dbCB_helix_sd[12]= 0.95;
        dbCB_strand[13]= 31.28;  dbCB_strand_sd[13]= 1.93;  dbCB_helix[13]= 28.51;  dbCB_helix_sd[13]= 0.92;
        dbCB_strand[14]= 32.19;  dbCB_strand_sd[14]= 1.80;  dbCB_helix[14]= 30.14;  dbCB_helix_sd[14]= 1.14;
        dbCB_strand[15]= 65.16;  dbCB_strand_sd[15]= 1.51;  dbCB_helix[15]= 63.08;  dbCB_helix_sd[15]= 1.12;
        dbCB_strand[16]= 70.75;  dbCB_strand_sd[16]= 1.51;  dbCB_helix[16]= 68.88;  dbCB_helix_sd[16]= 1.17;
        dbCB_strand[17]= 33.91;  dbCB_strand_sd[17]= 1.61;  dbCB_helix[17]= 31.49;  dbCB_helix_sd[17]= 0.72;
        dbCB_strand[18]= 31.50;  dbCB_strand_sd[18]= 1.70;  dbCB_helix[18]= 29.30;  dbCB_helix_sd[18]= 1.40;
        dbCB_strand[19]= 40.97;  dbCB_strand_sd[19]= 1.85;  dbCB_helix[19]= 38.25;  dbCB_helix_sd[19]= 1.11;

        if(col==0)
            return dbCB_strand[res];
        else if(col==1)
            return dbCB_strand_sd[res];
        else if(col==2)
            return dbCB_helix[res];
        else
            return dbCB_helix_sd[res];

    }
    double refdbSSCO2(int res, int col)
    {
        double dbCO_strand[20], dbCO_strand_sd[20], dbCO_helix[20], dbCO_helix_sd[20];
        dbCO_strand[0]= 176.09;  dbCO_strand_sd[0]= 1.51;  dbCO_helix[0]= 179.40;  dbCO_helix_sd[0]= 1.32;
        dbCO_strand[1]= 173.57;  dbCO_strand_sd[1]= 1.64;  dbCO_helix[1]= 176.16;  dbCO_helix_sd[1]= 1.64;
        dbCO_strand[2]= 175.54;  dbCO_strand_sd[2]= 1.57;  dbCO_helix[2]= 178.08;  dbCO_helix_sd[2]= 1.33;
        dbCO_strand[3]= 175.35;  dbCO_strand_sd[3]= 1.40;  dbCO_helix[3]= 178.61;  dbCO_helix_sd[3]= 1.21;
        dbCO_strand[4]= 174.25;  dbCO_strand_sd[4]= 1.63;  dbCO_helix[4]= 177.13;  dbCO_helix_sd[4]= 1.38;
        dbCO_strand[5]= 172.55;  dbCO_strand_sd[5]= 1.58;  dbCO_helix[5]= 175.51;  dbCO_helix_sd[5]= 1.23;
        dbCO_strand[6]= 174.17;  dbCO_strand_sd[6]= 1.54;  dbCO_helix[6]= 176.98;  dbCO_helix_sd[6]= 1.29;
        dbCO_strand[7]= 174.86;  dbCO_strand_sd[7]= 1.39;  dbCO_helix[7]= 177.72;  dbCO_helix_sd[7]= 1.29;
        dbCO_strand[8]= 175.31;  dbCO_strand_sd[8]= 1.29;  dbCO_helix[8]= 178.40;  dbCO_helix_sd[8]= 1.46;
        dbCO_strand[9]= 175.67;  dbCO_strand_sd[9]= 1.47;  dbCO_helix[9]= 178.53;  dbCO_helix_sd[9]= 1.30;
        dbCO_strand[10]= 174.83;  dbCO_strand_sd[10]= 1.40;  dbCO_helix[10]= 177.95;  dbCO_helix_sd[10]= 1.12;
        dbCO_strand[11]= 174.64;  dbCO_strand_sd[11]= 1.65;  dbCO_helix[11]= 176.91;  dbCO_helix_sd[11]= 1.55;
        dbCO_strand[12]= 176.18;  dbCO_strand_sd[12]= 1.40;  dbCO_helix[12]= 178.34;  dbCO_helix_sd[12]= 1.45;
        dbCO_strand[13]= 174.88;  dbCO_strand_sd[13]= 1.38;  dbCO_helix[13]= 177.97;  dbCO_helix_sd[13]= 1.29;
        dbCO_strand[14]= 175.14;  dbCO_strand_sd[14]= 1.36;  dbCO_helix[14]= 178.26;  dbCO_helix_sd[14]= 1.43;
        dbCO_strand[15]= 173.55;  dbCO_strand_sd[15]= 1.50;  dbCO_helix[15]= 175.94;  dbCO_helix_sd[15]= 1.39;
        dbCO_strand[16]= 173.66;  dbCO_strand_sd[16]= 1.50;  dbCO_helix[16]= 175.92;  dbCO_helix_sd[16]= 1.15;
        dbCO_strand[17]= 174.80;  dbCO_strand_sd[17]= 1.39;  dbCO_helix[17]= 177.65;  dbCO_helix_sd[17]= 1.38;
        dbCO_strand[18]= 175.41;  dbCO_strand_sd[18]= 1.66;  dbCO_helix[18]= 178.05;  dbCO_helix_sd[18]= 1.57;
        dbCO_strand[19]= 174.54;  dbCO_strand_sd[19]= 1.45;  dbCO_helix[19]= 177.36;  dbCO_helix_sd[19]= 1.40;

        if(col==0)
            return dbCO_strand[res];
        else if(col==1)
            return dbCO_strand_sd[res];
        else if(col==2)
            return dbCO_helix[res];
        else
            return dbCO_helix_sd[res];
    }
    double refdbSSHN2(int res, int col)
    {
        double dbHN_strand[20], dbHN_strand_sd[20], dbHN_helix[20], dbHN_helix_sd[20];
        dbHN_strand[0]= 8.44;  dbHN_strand_sd[0]= 0.76;  dbHN_helix[0]= 8.08;  dbHN_helix_sd[0]= 0.52;
        dbHN_strand[1]= 8.80;  dbHN_strand_sd[1]= 0.64;  dbHN_helix[1]= 8.20;  dbHN_helix_sd[1]= 0.69;
        dbHN_strand[2]= 8.51;  dbHN_strand_sd[2]= 0.61;  dbHN_helix[2]= 8.18;  dbHN_helix_sd[2]= 0.56;
        dbHN_strand[3]= 8.53;  dbHN_strand_sd[3]= 0.62;  dbHN_helix[3]= 8.22;  dbHN_helix_sd[3]= 0.62;
        dbHN_strand[4]= 8.75;  dbHN_strand_sd[4]= 0.72;  dbHN_helix[4]= 8.18;  dbHN_helix_sd[4]= 0.62;
        dbHN_strand[5]= 8.34;  dbHN_strand_sd[5]= 0.86;  dbHN_helix[5]= 8.29;  dbHN_helix_sd[5]= 0.67;
        dbHN_strand[6]= 8.62;  dbHN_strand_sd[6]= 0.74;  dbHN_helix[6]= 8.10;  dbHN_helix_sd[6]= 0.56;
        dbHN_strand[7]= 8.68;  dbHN_strand_sd[7]= 0.70;  dbHN_helix[7]= 8.02;  dbHN_helix_sd[7]= 0.52;
        dbHN_strand[8]= 8.48;  dbHN_strand_sd[8]= 0.68;  dbHN_helix[8]= 7.99;  dbHN_helix_sd[8]= 0.56;
        dbHN_strand[9]= 8.60;  dbHN_strand_sd[9]= 0.71;  dbHN_helix[9]= 8.05;  dbHN_helix_sd[9]= 0.54;
        dbHN_strand[10]= 8.64;  dbHN_strand_sd[10]= 0.67;  dbHN_helix[10]= 8.09;  dbHN_helix_sd[10]= 0.58;
        dbHN_strand[11]= 8.60;  dbHN_strand_sd[11]= 0.64;  dbHN_helix[11]= 8.22;  dbHN_helix_sd[11]= 0.58;
        dbHN_strand[12]= 0.00;  dbHN_strand_sd[12]= 1.00;  dbHN_helix[12]= 0.00;  dbHN_helix_sd[12]= 1.00;
        dbHN_strand[13]= 8.48;  dbHN_strand_sd[13]= 0.66;  dbHN_helix[13]= 8.04;  dbHN_helix_sd[13]= 0.55;
        dbHN_strand[14]= 8.56;  dbHN_strand_sd[14]= 0.64;  dbHN_helix[14]= 8.07;  dbHN_helix_sd[14]= 0.55;
        dbHN_strand[15]= 8.50;  dbHN_strand_sd[15]= 0.67;  dbHN_helix[15]= 8.14;  dbHN_helix_sd[15]= 0.56;
        dbHN_strand[16]= 8.51;  dbHN_strand_sd[16]= 0.61;  dbHN_helix[16]= 8.04;  dbHN_helix_sd[16]= 0.51;
        dbHN_strand[17]= 8.62;  dbHN_strand_sd[17]= 0.69;  dbHN_helix[17]= 8.02;  dbHN_helix_sd[17]= 0.65;
        dbHN_strand[18]= 8.59;  dbHN_strand_sd[18]= 0.83;  dbHN_helix[18]= 8.12;  dbHN_helix_sd[18]= 0.74;
        dbHN_strand[19]= 8.68;  dbHN_strand_sd[19]= 0.76;  dbHN_helix[19]= 8.07;  dbHN_helix_sd[19]= 0.62;

        if(col==0)
            return dbHN_strand[res];
        else if(col==1)
            return dbHN_strand_sd[res];
        else if(col==2)
            return dbHN_helix[res];
        else
            return dbHN_helix_sd[res];
    }
    double refdbSSN2(int res, int col)
    {
        double dbN_strand[20], dbN_strand_sd[20], dbN_helix[20], dbN_helix_sd[20];
        dbN_strand[0]= 124.47;  dbN_strand_sd[0]= 4.39;  dbN_helix[0]= 121.44;  dbN_helix_sd[0]= 2.37;
        dbN_strand[1]= 121.04;  dbN_strand_sd[1]= 4.53;  dbN_helix[1]= 117.68;  dbN_helix_sd[1]= 3.33;
        dbN_strand[2]= 122.17;  dbN_strand_sd[2]= 4.40;  dbN_helix[2]= 119.22;  dbN_helix_sd[2]= 2.69;
        dbN_strand[3]= 122.09;  dbN_strand_sd[3]= 3.95;  dbN_helix[3]= 119.04;  dbN_helix_sd[3]= 2.82;
        dbN_strand[4]= 121.08;  dbN_strand_sd[4]= 4.45;  dbN_helix[4]= 119.16;  dbN_helix_sd[4]= 3.33;
        dbN_strand[5]= 109.32;  dbN_strand_sd[5]= 3.94;  dbN_helix[5]= 107.51;  dbN_helix_sd[5]= 2.69;
        dbN_strand[6]= 120.49;  dbN_strand_sd[6]= 4.51;  dbN_helix[6]= 117.95;  dbN_helix_sd[6]= 2.63;
        dbN_strand[7]= 122.85;  dbN_strand_sd[7]= 4.63;  dbN_helix[7]= 119.71;  dbN_helix_sd[7]= 2.88;
        dbN_strand[8]= 122.21;  dbN_strand_sd[8]= 4.32;  dbN_helix[8]= 119.20;  dbN_helix_sd[8]= 2.64;
        dbN_strand[9]= 124.05;  dbN_strand_sd[9]= 4.26;  dbN_helix[9]= 119.61;  dbN_helix_sd[9]= 2.73;
        dbN_strand[10]= 121.66;  dbN_strand_sd[10]= 4.02;  dbN_helix[10]= 118.18;  dbN_helix_sd[10]= 2.75;
        dbN_strand[11]= 121.58;  dbN_strand_sd[11]= 4.35;  dbN_helix[11]= 117.30;  dbN_helix_sd[11]= 2.85;
        dbN_strand[12]= 0.00;    dbN_strand_sd[12]= 1.00;  dbN_helix[12]= 0.00;    dbN_helix_sd[12]= 1.00;
        dbN_strand[13]= 121.08;  dbN_strand_sd[13]= 4.13;  dbN_helix[13]= 118.45;  dbN_helix_sd[13]= 2.84;
        dbN_strand[14]= 122.31;  dbN_strand_sd[14]= 4.25;  dbN_helix[14]= 118.90;  dbN_helix_sd[14]= 2.83;
        dbN_strand[15]= 116.89;  dbN_strand_sd[15]= 4.02;  dbN_helix[15]= 114.87;  dbN_helix_sd[15]= 2.99;
        dbN_strand[16]= 116.46;  dbN_strand_sd[16]= 5.00;  dbN_helix[16]= 114.60;  dbN_helix_sd[16]= 3.99;
        dbN_strand[17]= 121.90;  dbN_strand_sd[17]= 5.02;  dbN_helix[17]= 119.19;  dbN_helix_sd[17]= 3.59;
        dbN_strand[18]= 122.09;  dbN_strand_sd[18]= 5.15;  dbN_helix[18]= 119.84;  dbN_helix_sd[18]= 3.11;
        dbN_strand[19]= 121.43;  dbN_strand_sd[19]= 4.78;  dbN_helix[19]= 119.17;  dbN_helix_sd[19]= 2.91;

        if(col==0)
            return dbN_strand[res];
        else if(col==1)
            return dbN_strand_sd[res];
        else if(col==2)
            return dbN_helix[res];
        else
            return dbN_helix_sd[res];
    }

void sspCalc2(string CA, string CB, string CO, string HN, string N, string SEQ, string fname)
{
    ifstream file;
    ofstream fileO;
    string line, sub;
    vector<string> protein_seq;
    string resno_shifts[2500][7]; // 0=resno, 1=aa, 2=ca, 3=cb, 4=co, 5=hn, 6=n
    int protein_size=1, fillCounter=0, CAc=0, CBc=0, COc=0, HNc=0, Nc=0;
    for (int i=0; i<2500; i++)
    {
        for (int j=0; j<7; j++)
            resno_shifts[i][j]="0";
    }
    file.open(SEQ.c_str(), ios::in);
    getline(file, line);
    istringstream iss(line);
    protein_seq.push_back("");
    while (iss >> sub)
    {
        protein_seq.push_back(sub);
        protein_size++;
    }
    file.clear();
    file.close();
    file.open(CA.c_str(), ios::in);
    while(file.good())
    {
        getline(file, line);
        CAc++;
    }
    CAc--;
    file.clear();
    file.close();
    file.open(CA.c_str(), ios::in);
    for (int i=0; i<CAc; i++)
    {
        getline(file, line);
        istringstream iss(line);
        iss >> sub;
        resno_shifts[fillCounter][0]=sub;
        iss >> sub;
        resno_shifts[fillCounter][2]=sub;
        fillCounter++;
    }
    file.clear();
    file.close();
    file.open(CB.c_str(), ios::in);
    while(file.good())
    {
        getline(file, line);
        CBc++;
    }
    CBc--;
    file.clear();
    file.close();
    file.open(CB.c_str(), ios::in);
    std::string subI;
    for(int j=0; j<CBc; j++)
    {
        getline(file, line);
        istringstream iss(line);
        iss >> sub;
        subI=sub;
        iss >> sub;
        for(int i=0; i<fillCounter; i++)
            if(resno_shifts[i][0]==subI)
            {
                resno_shifts[i][3]=sub;
                break;
            }
            else if(i==fillCounter-1)
            {
                resno_shifts[fillCounter][0]=subI;
                resno_shifts[fillCounter][3]=sub;
                fillCounter++;
            }
        if(fillCounter==0)
        {
            resno_shifts[fillCounter][0]=subI;
            resno_shifts[fillCounter][3]=sub;
            fillCounter++;
        }
    }
    file.clear();
    file.close();
    file.open(CO.c_str(), ios::in);
    while(file.good())
    {
        getline(file, line);
        COc++;
    }
    COc--;
    file.clear();
    file.close();
    file.open(CO.c_str(), ios::in);
    for(int j=0; j<COc; j++)
    {
        getline(file, line);
        istringstream iss(line);
        iss >> sub;
        subI=sub;
        iss >> sub;
        for(int i=0; i<fillCounter; i++)
            if(resno_shifts[i][0]==subI)
            {
                resno_shifts[i][4]=sub;
                break;
            }
            else if(i==fillCounter-1)
            {
                resno_shifts[fillCounter][0]=subI;
                resno_shifts[fillCounter][4]=sub;
                fillCounter++;
            }
        if(fillCounter==0)
        {
            resno_shifts[fillCounter][0]=subI;
            resno_shifts[fillCounter][4]=sub;
            fillCounter++;
        }
    }
    file.clear();
    file.close();
    file.open(HN.c_str(), ios::in);
    while(file.good())
    {
        getline(file, line);
        HNc++;
    }
    HNc--;
    file.clear();
    file.close();
    file.open(HN.c_str(), ios::in);
    for(int j=0; j<HNc; j++)
    {
        getline(file, line);
        istringstream iss(line);
        iss >> sub;
        subI=sub;
        iss >> sub;
        for(int i=0; i<fillCounter; i++)
            if(resno_shifts[i][0]==subI)
            {
                resno_shifts[i][5]=sub;
                break;
            }
            else if(i==fillCounter-1)
            {
                resno_shifts[fillCounter][0]=subI;
                resno_shifts[fillCounter][5]=sub;
                fillCounter++;
            }
    }
    file.clear();
    file.close();
    file.open(N.c_str(), ios::in);
    while(file.good())
    {
        getline(file, line);
        Nc++;
    }
    Nc--;
    file.clear();
    file.close();
    file.open(N.c_str(), ios::in);
    for(int j=0; j<Nc; j++)
    {
        getline(file, line);
        istringstream iss(line);
        iss >> sub;
        subI=sub;
        iss >> sub;
        for(int i=0; i<fillCounter; i++)
            if(resno_shifts[i][0]==subI)
            {
                resno_shifts[i][6]=sub;
                break;
            }
            else if(i==fillCounter-1)
            {
                resno_shifts[fillCounter][0]=subI;
                resno_shifts[fillCounter][6]=sub;
                fillCounter++;
            }
    }
    file.clear();
    file.close();
    fileO.open(fname.c_str(), ios::out);
    std::vector<double> strand_sum, helix_sum, strand_total, helix_total;
    strand_sum.resize(fillCounter, 0.0);
    helix_sum.resize(fillCounter, 0.0);
    strand_total.resize(fillCounter, 0.0);
    helix_total.resize(fillCounter, 0.0);
    for(int i=0; i<fillCounter; i++)
        resno_shifts[i][1]=protein_seq[atoi(resno_shifts[i][0].c_str())];
    for (int j=0; j<fillCounter; j++)
    {
	    for(int k=j+1; k<fillCounter;k++)
	    {
		   if(atoi(resno_shifts[j][0].c_str())>atoi(resno_shifts[k][0].c_str()))
		   {
			   std::string swapper[7];
			   for(int l=0; l<7;l++)
			   {
				   swapper[l]=resno_shifts[j][l];
				   resno_shifts[j][l]=resno_shifts[k][l];
				   resno_shifts[k][l]=swapper[l]; 
			   }					   
		   }
	    }
    }
    for (int j=2; j<7; j++)
        for(int i=0; i<fillCounter; i++)
        {
            if (resno_shifts[i][j]=="0" || resno_shifts[i][1]=="P" || resno_shifts[i][1]=="X")
                continue;
            double strand,helix,strand_weight,helix_weight, strand_dif, helix_dif, strand_percent, helix_percent;
            strand=helix=strand_weight=helix_weight= strand_dif= helix_dif= strand_percent= helix_percent=0.0;

            if (j==2)
            {
                strand = refdbSSCA2(getAa2(resno_shifts[i][1]),0)-refdbCA2(getAa2(resno_shifts[i][1]));
                helix = refdbSSCA2(getAa2(resno_shifts[i][1]),2)-refdbCA2(getAa2(resno_shifts[i][1]));
                if (strand*helix>0.0)
                    continue;
                strand_weight = abs(strand/refdbSSCA2(getAa2(resno_shifts[i][1]),1));
                helix_weight = abs(helix/refdbSSCA2(getAa2(resno_shifts[i][1]),3));
                strand_dif =  atof(resno_shifts[i][j].c_str())-refdbCA2(getAa2(resno_shifts[i][1]));
                helix_dif =  atof(resno_shifts[i][j].c_str())-refdbCA2(getAa2(resno_shifts[i][1]));
            }
            if (j==3)
            {
                strand = refdbSSCB2(getAa2(resno_shifts[i][1]),0)-refdbCB2(getAa2(resno_shifts[i][1]));
                helix = refdbSSCB2(getAa2(resno_shifts[i][1]),2)-refdbCB2(getAa2(resno_shifts[i][1]));
                if (strand*helix>0.0)
                    continue;
                strand_weight = abs(strand/refdbSSCB2(getAa2(resno_shifts[i][1]),1));
                helix_weight = abs(helix/refdbSSCB2(getAa2(resno_shifts[i][1]),3));
                strand_dif =  atof(resno_shifts[i][j].c_str())-refdbCB2(getAa2(resno_shifts[i][1]));
                helix_dif =  atof(resno_shifts[i][j].c_str())-refdbCB2(getAa2(resno_shifts[i][1]));
            }
            if (j==4)
            {
                strand = refdbSSCO2(getAa2(resno_shifts[i][1]),0)-refdbCO2(getAa2(resno_shifts[i][1]));
                helix = refdbSSCO2(getAa2(resno_shifts[i][1]),2)-refdbCO2(getAa2(resno_shifts[i][1]));
                if (strand*helix>0.0)
                    continue;
                strand_weight = abs(strand/refdbSSCO2(getAa2(resno_shifts[i][1]),1));
                helix_weight = abs(helix/refdbSSCO2(getAa2(resno_shifts[i][1]),3));
                strand_dif =  atof(resno_shifts[i][j].c_str())-refdbCO2(getAa2(resno_shifts[i][1]));
                helix_dif =  atof(resno_shifts[i][j].c_str())-refdbCO2(getAa2(resno_shifts[i][1]));
            }
            if (j==5)
            {
                strand = refdbSSHN2(getAa2(resno_shifts[i][1]),0)-refdbHN2(getAa2(resno_shifts[i][1]));
                helix = refdbSSHN2(getAa2(resno_shifts[i][1]),2)-refdbHN2(getAa2(resno_shifts[i][1]));
                if (strand*helix>0.0)
                    continue;
                strand_weight = abs(strand/refdbSSHN2(getAa2(resno_shifts[i][1]),1));
                helix_weight = abs(helix/refdbSSHN2(getAa2(resno_shifts[i][1]),3));
                strand_dif =  atof(resno_shifts[i][j].c_str())-refdbHN2(getAa2(resno_shifts[i][1]));
                helix_dif =  atof(resno_shifts[i][j].c_str())-refdbHN2(getAa2(resno_shifts[i][1]));
            }
            if (j==6)
            {
                strand = refdbSSN2(getAa2(resno_shifts[i][1]),0)-refdbN2(getAa2(resno_shifts[i][1]));
                helix = refdbSSN2(getAa2(resno_shifts[i][1]),2)-refdbN2(getAa2(resno_shifts[i][1]));
                if (strand*helix>0.0)
                    continue;
                strand_weight = abs(strand/refdbSSN2(getAa2(resno_shifts[i][1]),1));
                helix_weight = abs(helix/refdbSSN2(getAa2(resno_shifts[i][1]),3));
                strand_dif =  atof(resno_shifts[i][j].c_str())-refdbN2(getAa2(resno_shifts[i][1]));
                helix_dif =  atof(resno_shifts[i][j].c_str())-refdbN2(getAa2(resno_shifts[i][1]));
            }
            strand_percent= strand_dif/strand;
            helix_percent= helix_dif/helix;
            if (strand_percent> 1.2)
                strand_percent= 1.2;
            else if (strand_percent< 0.0)
                strand_percent=0.0;
            if (helix_percent> 1.2)
                helix_percent= 1.2;
            else if (helix_percent< 0.0)
                helix_percent=0.0;
            strand_sum[i] += strand_percent * strand_weight;
            helix_sum[i] += helix_percent * helix_weight;
            if(strand_percent>0)
                strand_total[i] += strand_weight;
            if(helix_percent>0)
                helix_total[i] += helix_weight;
        }
    int first_res, last_res;
    first_res = last_res =-1;
    vector<double> score;
    score.resize(fillCounter, 0.0);
    for(int i=0; i<fillCounter; i++)
    {
        if(!(helix_total[i] + strand_total[i])>0)
            continue;
        score[i] = (helix_sum[i]-strand_sum[i])/(helix_total[i]+strand_total[i]);
        if(first_res==-1)
            first_res=atoi(resno_shifts[i][0].c_str());
        else if (atoi(resno_shifts[i][0].c_str())<first_res)
            first_res=atoi(resno_shifts[i][0].c_str());
        if(last_res==-1)
            last_res=atoi(resno_shifts[i][0].c_str());
        else if (atoi(resno_shifts[i][0].c_str())>last_res)
            last_res=atoi(resno_shifts[i][0].c_str());
    }
    for(int i=0; i<fillCounter; i++)
    {
        int res = atoi(resno_shifts[i][0].c_str());
        double b = 0.0;
        double sum = 0.0;
        for(int j=i-2; j<i+3;j++)
        {
            if(j<0 || j>=fillCounter)
                continue;
            int res2 = atoi(resno_shifts[j][0].c_str());
            if(i-j!=res-res2)
                continue;
            if(j>=0 && j<fillCounter)
            {
                b+= strand_total[j] + helix_total[j];
                sum += score[j] * (strand_total[j]+helix_total[j]);
            }
        }
        if(b!=0.0)
            sum=sum/b;
        fileO<<resno_shifts[i][0]<<"\t"<<sum<<"\n";
    }
fileO.clear();
fileO.close();
};

