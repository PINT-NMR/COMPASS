#ifndef SSP_H
#define SSP_H
#include <fstream>
#include <cmath>
#include <iostream> 
#include <stdlib.h> 
#include <string.h>

using namespace std;
int getAa(string aa);
double refdbCA(int res);
double refdbCB(int res);
double refdbCO(int res);
double refdbHN(int res);
double refdbN(int res);
double refdbSSCA(int res, int col);
double refdbSSCB(int res, int col);
double refdbSSCO(int res, int col);
double refdbSSHN(int res, int col);
double refdbSSN(int res, int col);
void sspCalc(string CA, string CB, string CO, string HN, string N, string SEQ, string fname);
#endif
