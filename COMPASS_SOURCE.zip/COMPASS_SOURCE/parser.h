#include "compassvec.h"
#include "passdef.h"



struct ParserType
{
    std::string seqFile;
    std::vector<std::string> sequence;
    int first;
    double deuter;
    double pdeuter;
	int resultNO;	
    int max;
	int counting;
	int matchno;
    std::string filenames;
	int CHI;
    std::string ssFile;
    std::vector<std::string> ss_sequence;
	bool ss_exist;

    double ca[MAX_RES], cb[MAX_RES], co[MAX_RES];
	
    ParserType() {
		   for (int i=0; i<MAX_RES; i++)
               ca[i] = cb[i] = co[i] = 0.0;
		   seqFile = "";
		   ssFile = "";
		   first = 1;
		   deuter = 0.0;
		   pdeuter = 0.0;
		   max = DEFAULT_TOP;
		   resultNO=0;
		   CHI=0;	
	}

    void parse(int argc, string argv[1000], int resultnumber, int sort_by, int counting_times, int match, std::string namefile, std::vector<std::string> ss_seq, std::vector<std::string> s)
	{
		counting= counting_times;
		matchno=match;
		filenames=namefile;
		CHI = sort_by;
		resultNO = resultnumber;
		ss_exist = false;

		for (int i=0; i<MAX_RES; i++)
            ca[i] = cb[i] = co[i] = 0.0;

		if (argc < 3) {
				help(); 
			}

        for (int i = 0; i<argc;) {
            if (argv[i]=="-ca1") {
                ca[0] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-ca2") {
                ca[1] = atof(argv[i+1].c_str());
				i += 2;
		                continue;
			}
            if (argv[i]=="-ca3") {
                ca[2] = atof(argv[i+1].c_str());
				i += 2;
		                continue;
			}
            if (argv[i]=="-ca4") {
                ca[3] = atof(argv[i+1].c_str());
				i += 2;
                		continue;
			}
            if (argv[i]=="-ca5") {
                ca[4] = atof(argv[i+1].c_str());
				i += 2;
                		continue;
			}
            if (argv[i]=="-ca6") {
                ca[5] = atof(argv[i+1].c_str());
				i += 2;
                		continue;
			}
            if (argv[i]=="-ca7") {
                ca[6] = atof(argv[i+1].c_str());
				i += 2;
                		continue;
			}
            if (argv[i]=="-ca8") {
                ca[7] = atof(argv[i+1].c_str());
				i += 2;
                		continue;
			}
            if (argv[i]=="-ca9") {
                ca[8] = atof(argv[i+1].c_str());
				i += 2;
                		continue;
			}
            if (argv[i]=="-ca10") {
                ca[9] = atof(argv[i+1].c_str());
				i += 2;
                		continue;
			}

            if (argv[i]=="-cb1") {
                cb[0] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-cb2") {
                cb[1] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-cb3") {
                cb[2] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-cb4") {
                cb[3] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-cb5") {
                cb[4] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-cb6") {
                cb[5] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-cb7") {
                cb[6] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-cb8") {
                cb[7] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-cb9") {
                cb[8] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-cb10") {
                cb[9] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-co1") {
                co[0] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-co2") {
                co[1] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-co3") {
                co[2] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-co4") {
                co[3] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-co5") {
                co[4] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-co6") {
                co[5] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-co7") {
                co[6] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-co8") {
                co[7] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-co9") {
                co[8] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-co10") {
                co[9] = atof(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-seq") {
				seqFile = argv[i+1];
				i += 2;
				sequence=s;
				continue;
			}
            if (argv[i]=="-first") {
                first = atoi(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-D") {
				deuter = 1.0;
				i++;
				continue;
			}
            if (argv[i]=="-pD") {
				pdeuter = 1.0;
				i++;
				continue;
			}
            if (argv[i]=="-max") {
                max = atoi(argv[i+1].c_str());
				i += 2;
				continue;
			}
            if (argv[i]=="-ss") {
				ssFile= argv[i+1];
				i += 2;
				ss_sequence = ss_seq;
				ss_exist=true;
				continue;
			}
			else {
				i++;
			}
		}
    }

    void line2words(char *u, std::vector<std::string> &word)
    {
	
            #define IS_PUNC(c) ((c) == ' ' || (c) == '\t')
            #define IS_END(c) ((c) == '\0' || (c) == '\n')
			word.resize(0);
    	    while (!IS_END(*u)) {
                int jj=0;
    			char t[MAX_LINE];
                std::string tt;
                while (IS_PUNC(*u))  
					u++;
				if (IS_END(*u))
					return;
	    	    while (!IS_PUNC(*u) && !IS_END(*u)) {
	    			t[jj++] = *(u++);
				}
	    	    t[jj] = '\0';
	    		word.push_back(t);
	    	}
    		#undef IS_PUNC
    		#undef IS_END
    }

    void toUpper(std::string &s)
	{
        for (unsigned int i=0; i<s.size(); i++)
			s[i] = toupper(s[i]);
	}

    void help()
	{
      	exit(1);
    }

};
