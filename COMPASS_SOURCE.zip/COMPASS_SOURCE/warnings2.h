#ifndef WARNINGS2_H
#define WARNINGS2_H

#include <QMainWindow>

namespace Ui
{
	class Warnings2;
}

class Warnings2 : public QMainWindow
{
	Q_OBJECT

public:
	Warnings2(QWidget *parent = 0);
	~Warnings2();

protected:
	void changeEvent(QEvent *e);

private:
	Ui::Warnings2 *ui;

private slots:
	void on_buttonBox_accepted();
};

#endif
