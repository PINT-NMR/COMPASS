#ifndef COMPASSABOUT_H
#define COMPASSABOUT_H

#include <QWidget>

namespace Ui{
	class CompassAbout;
}

class CompassAbout : public QWidget
{
	Q_OBJECT

public:
    explicit CompassAbout(QWidget *parent = 0);
	~CompassAbout();

private:
	Ui::CompassAbout *ui;

private slots:
    void on_close_aboutButton_2_clicked();

signals:
    void goToMain();
};

#endif //COMPASSABOUT_H
