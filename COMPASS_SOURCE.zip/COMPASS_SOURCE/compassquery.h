#ifndef COMPASSQUERY_H
#define COMPASSQUERY_H

#include <QWidget>
#include <QTimer>
#include <cmath>
#include <iomanip>
#include <vector>
#include <limits>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include "compassvec.h"
#include "shifts.h"
#include "parser.h"
#include "calcscore.h"
#include "shiftsb.h"
#include "shiftsc.h"
#include "parserb.h"
#include "parserc.h"
#include "calcscoreb.h"
#include "calcscorec.h"
#include "htmlfile3.h"
#include "htmlfile2.h"
#include "htmlfile.h"
#include "QThread"

namespace Ui
{
	class CompassQuery;
}

class CompassQuery : public QWidget
{
    	Q_OBJECT

public:
	CompassQuery(QWidget *parent = 0);
	~CompassQuery();
private:
    Ui::CompassQuery *ui;
    bool analyzing;
signals:
    void finished();
    void goToMain();

private slots:
    void abortAnalysis();
    void abortAnalysis2();
    void nullTimer();
    void analysis();
    void convertFiles(QString in, QString out);
    std::string checkDup(std::string in);
	void getDir();
    void on_menu_queryButton_clicked();
    void on_folderButton_clicked();
	void on_caButton_clicked();
	void on_cbcaButton_clicked();
	void on_coButton_clicked();
	void on_caButton_2_clicked();
	void on_cbcaButton_2_clicked();
	void on_coButton_2_clicked();
	void on_hsqcButton_clicked();
	void on_seqButton_clicked();
	void on_ssButton_clicked();
	void on_analyzeButton_clicked();
    void loadParams();
	void loadParam(QString path);
    void saveParam();
    void setParam();
    void connectLines();
    void clear_form();
    QString format_check(std::string cafile, std::string cafile2, std::string cbcafile, std::string cbcafile2, std::string cofile, std::string cofile2, std::string hsqcfile, std::string seq, std::string ss);
    QString File_Format_Check3D(std::string infile, std::string Ctype, std::string Ftype);
    QString File_Format_Check2D(std::string infile);
    void disconnectAll();
    void connectAll();
    void on_clearFormButton_clicked();
    void on_loadParamButton_clicked();
    void on_quit_queryButton_clicked();
    void on_query_helpButton_clicked();
};

class Thread : public QThread
{
public:
    explicit Thread(std::vector< std::vector< std::string > > fragVec, int m, std::string filenamesS, std::vector <std::string> ss_sequence, std::vector <std::string> seq_sequence) : fV(fragVec), match(m), fname(filenamesS), ss(ss_sequence), seq(seq_sequence) {}
    void run();

private:
    std::vector< std::vector< std::string > > fV;
    int match;
    std::string fname;
    std::vector< std::string > ss, seq;
};

 
#endif
