#ifndef QUERYERROR3_H
#define QUERYERROR3_H

#include <QMainWindow>

namespace Ui
{
	class QueryError3;
}

class QueryError3 : public QMainWindow
{
	Q_OBJECT

public:
	QueryError3(QWidget *parent = 0);
	~QueryError3();

protected:
	void changeEvent(QEvent *e);

private:
	Ui::QueryError3 *ui;
};

#endif
