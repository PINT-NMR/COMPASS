#ifndef QUERYFORMATERROR_H
#define QUERYFORMATERROR_H

#include <QDialog>

namespace Ui
{
	class QueryFormatError;
}

class QueryFormatError : public QDialog
{
	Q_OBJECT

public:
	QueryFormatError(QWidget *parent = 0);
	~QueryFormatError();


private:
	Ui::QueryFormatError *ui;

private slots:
	void display();
    void on_closeErrButton2_clicked();
};

#endif
