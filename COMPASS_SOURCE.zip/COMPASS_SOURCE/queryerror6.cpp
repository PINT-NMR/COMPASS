#include "queryerror6.h"
#include "ui_queryerror6.h"
#include <QtWidgets>
#include <cstdlib>

#include <fstream>
#include <iostream>

QueryError6::QueryError6(QWidget *parent) :
    QDialog(parent),
	ui(new Ui::QueryError6)
{
	ui->setupUi(this);
}

QueryError6::~QueryError6()
{
	delete ui;
}

void QueryError6::on_closeErrButton6_clicked()
{
    accept();
}
