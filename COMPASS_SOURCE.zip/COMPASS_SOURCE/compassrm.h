#ifndef COMPASSRM_H
#define COMPASSRM_H
#include <QtWidgets>
#include "QFile"
#include "mfunc.h"

struct delFile
{
    QString list[317];
	void setList(QString dir, QString project, QString hnca, QString hnca2, QString hncb, QString hncb2, QString hnco, QString hnco2, QString hsqc)
	{
        dir+=project;
        list[307]=dir % "Project_Files/" % hnca;
        list[308]=dir % "Project_Files/" % hnca2;
        list[309]=dir % "Project_Files/" % hncb;
        list[310]=dir % "Project_Files/" % hncb2;
        list[311]=dir % "Project_Files/" % hnco;
        list[312]=dir % "Project_Files/" % hnco2;
        list[313]=dir % "Project_Files/" % hsqc;
        list[314]=dir % "Analysis/csedit";
        list[315]=dir % "Analysis/findresult.txt";
        list[316]=dir % "Analysis/findresult2.txt";

        list[0]=dir % "Project_Files/parameters.cpar";
        list[1]=dir % "Project_Files/"% mconvert(mconvert(project).substr(0,mconvert(project).length()-1)) %".cpro";
        list[2]=dir % "Temp/rename_errors.txt1";
        list[3]=dir % "Temp/rename_errors.txt2";
        list[4]=dir % "Temp/rename_errors.txt3";

        list[5]=dir % "Results/" % hnca % ".compass";
        list[6]=dir % "Results/" % hnca2 % ".compass";
        list[7]=dir % "Results/" % hncb % ".compass";
        list[8]=dir % "Results/" % hncb2 % ".compass";
        list[9]=dir % "Results/" % hnco % ".compass";
        list[10]=dir % "Results/" % hnco2 % ".compass";
        list[11]=dir % "Results/SSP_plot.txt";
        list[12]=dir % "Analysis/compass_result2_match1";
        list[13]=dir % "Analysis/compass_result3_match1";
        list[14]=dir % "Analysis/compass_result4_match1";
        list[15]=dir % "Analysis/compass_result5_match1";
        list[16]=dir % "Analysis/compass_result6_match1";
        list[17]=dir % "Analysis/compass_result7_match1";
        list[18]=dir % "Analysis/compass_result8_match1";
        list[19]=dir % "Analysis/compass_result9_match1";
        list[20]=dir % "Analysis/compass_result10_match1";
		
        list[21]=dir % "Analysis/compass_result2_match2";
        list[22]=dir % "Analysis/compass_result3_match2";
        list[23]=dir % "Analysis/compass_result4_match2";
        list[24]=dir % "Analysis/compass_result5_match2";
        list[25]=dir % "Analysis/compass_result6_match2";
        list[26]=dir % "Analysis/compass_result7_match2";
        list[27]=dir % "Analysis/compass_result8_match2";
        list[28]=dir % "Analysis/compass_result9_match2";
        list[29]=dir % "Analysis/compass_result10_match2";

        list[30]=dir % "Analysis/compass_result2_match3";
        list[31]=dir % "Analysis/compass_result3_match3";
        list[32]=dir % "Analysis/compass_result4_match3";
        list[33]=dir % "Analysis/compass_result5_match3";
        list[34]=dir % "Analysis/compass_result6_match3";
        list[35]=dir % "Analysis/compass_result7_match3";
        list[36]=dir % "Analysis/compass_result8_match3";
        list[37]=dir % "Analysis/compass_result9_match3";
        list[38]=dir % "Analysis/compass_result10_match3";

        list[39]=dir % "Analysis/compass_result2_match1.bak";
        list[40]=dir % "Analysis/compass_result3_match1.bak";
        list[41]=dir % "Analysis/compass_result4_match1.bak";
        list[42]=dir % "Analysis/compass_result5_match1.bak";
        list[43]=dir % "Analysis/compass_result6_match1.bak";
        list[44]=dir % "Analysis/compass_result7_match1.bak";
        list[45]=dir % "Analysis/compass_result8_match1.bak";
        list[46]=dir % "Analysis/compass_result9_match1.bak";
        list[47]=dir % "Analysis/compass_result10_match1.bak";
		
        list[48]=dir % "Analysis/compass_result2_match2.bak";
        list[49]=dir % "Analysis/compass_result3_match2.bak";
        list[50]=dir % "Analysis/compass_result4_match2.bak";
        list[51]=dir % "Analysis/compass_result5_match2.bak";
        list[52]=dir % "Analysis/compass_result6_match2.bak";
        list[53]=dir % "Analysis/compass_result7_match2.bak";
        list[54]=dir % "Analysis/compass_result8_match2.bak";
        list[55]=dir % "Analysis/compass_result9_match2.bak";
        list[56]=dir % "Analysis/compass_result10_match2.bak";

        list[57]=dir % "Analysis/compass_result2_match3.bak";
        list[58]=dir % "Analysis/compass_result3_match3.bak";
        list[59]=dir % "Analysis/compass_result4_match3.bak";
        list[60]=dir % "Analysis/compass_result5_match3.bak";
        list[61]=dir % "Analysis/compass_result6_match3.bak";
        list[62]=dir % "Analysis/compass_result7_match3.bak";
        list[63]=dir % "Analysis/compass_result8_match3.bak";
        list[64]=dir % "Analysis/compass_result9_match3.bak";
        list[65]=dir % "Analysis/compass_result10_match3.bak";

        list[66]=dir % "Analysis/compass_result2_match1_sort";
        list[67]=dir % "Analysis/compass_result3_match1_sort";
        list[68]=dir % "Analysis/compass_result4_match1_sort";
        list[69]=dir % "Analysis/compass_result5_match1_sort";
        list[70]=dir % "Analysis/compass_result6_match1_sort";
        list[71]=dir % "Analysis/compass_result7_match1_sort";
        list[72]=dir % "Analysis/compass_result8_match1_sort";
        list[73]=dir % "Analysis/compass_result9_match1_sort";
        list[74]=dir % "Analysis/compass_result10_match1_sort";

        list[75]=dir % "Analysis/compass_result2_match2_sort";
        list[76]=dir % "Analysis/compass_result3_match2_sort";
        list[77]=dir % "Analysis/compass_result4_match2_sort";
        list[78]=dir % "Analysis/compass_result5_match2_sort";
        list[79]=dir % "Analysis/compass_result6_match2_sort";
        list[80]=dir % "Analysis/compass_result7_match2_sort";
        list[81]=dir % "Analysis/compass_result8_match2_sort";
        list[82]=dir % "Analysis/compass_result9_match2_sort";
        list[83]=dir % "Analysis/compass_result10_match2_sort";

        list[84]=dir % "Analysis/compass_result2_match3_sort";
        list[85]=dir % "Analysis/compass_result3_match3_sort";
        list[86]=dir % "Analysis/compass_result4_match3_sort";
        list[87]=dir % "Analysis/compass_result5_match3_sort";
        list[88]=dir % "Analysis/compass_result6_match3_sort";
        list[89]=dir % "Analysis/compass_result7_match3_sort";
        list[90]=dir % "Analysis/compass_result8_match3_sort";
        list[91]=dir % "Analysis/compass_result9_match3_sort";
        list[92]=dir % "Analysis/compass_result10_match3_sort";
		
        list[93]=dir % "Analysis/compass_result2_match1_sort.bak";
        list[94]=dir % "Analysis/compass_result3_match1_sort.bak";
        list[95]=dir % "Analysis/compass_result4_match1_sort.bak";
        list[96]=dir % "Analysis/compass_result5_match1_sort.bak";
        list[97]=dir % "Analysis/compass_result6_match1_sort.bak";
        list[98]=dir % "Analysis/compass_result7_match1_sort.bak";
        list[99]=dir % "Analysis/compass_result8_match1_sort.bak";
        list[100]=dir % "Analysis/compass_result9_match1_sort.bak";
        list[101]=dir % "Analysis/compass_result10_match1_sort.bak";

        list[102]=dir % "Analysis/compass_result2_match2_sort.bak";
        list[103]=dir % "Analysis/compass_result3_match2_sort.bak";
        list[104]=dir % "Analysis/compass_result4_match2_sort.bak";
        list[105]=dir % "Analysis/compass_result5_match2_sort.bak";
        list[106]=dir % "Analysis/compass_result6_match2_sort.bak";
        list[107]=dir % "Analysis/compass_result7_match2_sort.bak";
        list[108]=dir % "Analysis/compass_result8_match2_sort.bak";
        list[109]=dir % "Analysis/compass_result9_match2_sort.bak";
        list[110]=dir % "Analysis/compass_result10_match2_sort.bak";

        list[111]=dir % "Analysis/compass_result2_match3_sort.bak";
        list[112]=dir % "Analysis/compass_result3_match3_sort.bak";
        list[113]=dir % "Analysis/compass_result4_match3_sort.bak";
        list[114]=dir % "Analysis/compass_result5_match3_sort.bak";
        list[115]=dir % "Analysis/compass_result6_match3_sort.bak";
        list[116]=dir % "Analysis/compass_result7_match3_sort.bak";
        list[117]=dir % "Analysis/compass_result8_match3_sort.bak";
        list[118]=dir % "Analysis/compass_result9_match3_sort.bak";
        list[119]=dir % "Analysis/compass_result10_match3_sort.bak";
		
        list[120]=dir % "Analysis/compass_result2_match1_sortCHI";
        list[121]=dir % "Analysis/compass_result3_match1_sortCHI";
        list[122]=dir % "Analysis/compass_result4_match1_sortCHI";
        list[123]=dir % "Analysis/compass_result5_match1_sortCHI";
        list[124]=dir % "Analysis/compass_result6_match1_sortCHI";
        list[125]=dir % "Analysis/compass_result7_match1_sortCHI";
        list[126]=dir % "Analysis/compass_result8_match1_sortCHI";
        list[127]=dir % "Analysis/compass_result9_match1_sortCHI";
        list[128]=dir % "Analysis/compass_result10_match1_sortCHI";

        list[129]=dir % "Analysis/compass_result2_match2_sortCHI";
        list[130]=dir % "Analysis/compass_result3_match2_sortCHI";
        list[131]=dir % "Analysis/compass_result4_match2_sortCHI";
        list[132]=dir % "Analysis/compass_result5_match2_sortCHI";
        list[133]=dir % "Analysis/compass_result6_match2_sortCHI";
        list[134]=dir % "Analysis/compass_result7_match2_sortCHI";
        list[135]=dir % "Analysis/compass_result8_match2_sortCHI";
        list[136]=dir % "Analysis/compass_result9_match2_sortCHI";
        list[137]=dir % "Analysis/compass_result10_match2_sortCHI";

        list[138]=dir % "Analysis/compass_result2_match3_sortCHI";
        list[139]=dir % "Analysis/compass_result3_match3_sortCHI";
        list[140]=dir % "Analysis/compass_result4_match3_sortCHI";
        list[141]=dir % "Analysis/compass_result5_match3_sortCHI";
        list[142]=dir % "Analysis/compass_result6_match3_sortCHI";
        list[143]=dir % "Analysis/compass_result7_match3_sortCHI";
        list[144]=dir % "Analysis/compass_result8_match3_sortCHI";
        list[145]=dir % "Analysis/compass_result9_match3_sortCHI";
        list[146]=dir % "Analysis/compass_result10_match3_sortCHI";
	
        list[147]=dir % "Analysis/compass_result2_match1_sortCHI.bak";
        list[148]=dir % "Analysis/compass_result3_match1_sortCHI.bak";
        list[149]=dir % "Analysis/compass_result4_match1_sortCHI.bak";
        list[150]=dir % "Analysis/compass_result5_match1_sortCHI.bak";
        list[151]=dir % "Analysis/compass_result6_match1_sortCHI.bak";
        list[152]=dir % "Analysis/compass_result7_match1_sortCHI.bak";
        list[153]=dir % "Analysis/compass_result8_match1_sortCHI.bak";
        list[154]=dir % "Analysis/compass_result9_match1_sortCHI.bak";
        list[155]=dir % "Analysis/compass_result10_match1_sortCHI.bak";

        list[156]=dir % "Analysis/compass_result2_match2_sortCHI.bak";
        list[157]=dir % "Analysis/compass_result3_match2_sortCHI.bak";
        list[158]=dir % "Analysis/compass_result4_match2_sortCHI.bak";
        list[159]=dir % "Analysis/compass_result5_match2_sortCHI.bak";
        list[160]=dir % "Analysis/compass_result6_match2_sortCHI.bak";
        list[161]=dir % "Analysis/compass_result7_match2_sortCHI.bak";
        list[162]=dir % "Analysis/compass_result8_match2_sortCHI.bak";
        list[163]=dir % "Analysis/compass_result9_match2_sortCHI.bak";
        list[164]=dir % "Analysis/compass_result10_match2_sortCHI.bak";

        list[165]=dir % "Analysis/compass_result2_match3_sortCHI.bak";
        list[166]=dir % "Analysis/compass_result3_match3_sortCHI.bak";
        list[167]=dir % "Analysis/compass_result4_match3_sortCHI.bak";
        list[168]=dir % "Analysis/compass_result5_match3_sortCHI.bak";
        list[169]=dir % "Analysis/compass_result6_match3_sortCHI.bak";
        list[170]=dir % "Analysis/compass_result7_match3_sortCHI.bak";
        list[171]=dir % "Analysis/compass_result8_match3_sortCHI.bak";
        list[172]=dir % "Analysis/compass_result9_match3_sortCHI.bak";
        list[173]=dir % "Analysis/compass_result10_match3_sortCHI.bak";

        list[174]=dir % "Analysis/compass_result2_match1_sortCHI_html";
        list[175]=dir % "Analysis/compass_result3_match1_sortCHI_html";
        list[176]=dir % "Analysis/compass_result4_match1_sortCHI_html";
        list[177]=dir % "Analysis/compass_result5_match1_sortCHI_html";
        list[178]=dir % "Analysis/compass_result6_match1_sortCHI_html";
        list[179]=dir % "Analysis/compass_result7_match1_sortCHI_html";
        list[180]=dir % "Analysis/compass_result8_match1_sortCHI_html";
        list[181]=dir % "Analysis/compass_result9_match1_sortCHI_html";
        list[182]=dir % "Analysis/compass_result10_match1_sortCHI_html";

        list[183]=dir % "Analysis/compass_result2_match2_sortCHI_html";
        list[184]=dir % "Analysis/compass_result3_match2_sortCHI_html";
        list[185]=dir % "Analysis/compass_result4_match2_sortCHI_html";
        list[186]=dir % "Analysis/compass_result5_match2_sortCHI_html";
        list[187]=dir % "Analysis/compass_result6_match2_sortCHI_html";
        list[188]=dir % "Analysis/compass_result7_match2_sortCHI_html";
        list[189]=dir % "Analysis/compass_result8_match2_sortCHI_html";
        list[190]=dir % "Analysis/compass_result9_match2_sortCHI_html";
        list[191]=dir % "Analysis/compass_result10_match2_sortCHI_html";

        list[192]=dir % "Analysis/compass_result2_match3_sortCHI_html";
        list[193]=dir % "Analysis/compass_result3_match3_sortCHI_html";
        list[194]=dir % "Analysis/compass_result4_match3_sortCHI_html";
        list[195]=dir % "Analysis/compass_result5_match3_sortCHI_html";
        list[196]=dir % "Analysis/compass_result6_match3_sortCHI_html";
        list[197]=dir % "Analysis/compass_result7_match3_sortCHI_html";
        list[198]=dir % "Analysis/compass_result8_match3_sortCHI_html";
        list[199]=dir % "Analysis/compass_result9_match3_sortCHI_html";
        list[200]=dir % "Analysis/compass_result10_match3_sortCHI_html";
		
        list[201]=dir % "Analysis/compass_result2_match1_sortCHI_html.bak";
        list[202]=dir % "Analysis/compass_result3_match1_sortCHI_html.bak";
        list[203]=dir % "Analysis/compass_result4_match1_sortCHI_html.bak";
        list[204]=dir % "Analysis/compass_result5_match1_sortCHI_html.bak";
        list[205]=dir % "Analysis/compass_result6_match1_sortCHI_html.bak";
        list[206]=dir % "Analysis/compass_result7_match1_sortCHI_html.bak";
        list[207]=dir % "Analysis/compass_result8_match1_sortCHI_html.bak";
        list[208]=dir % "Analysis/compass_result9_match1_sortCHI_html.bak";
        list[209]=dir % "Analysis/compass_result10_match1_sortCHI_html.bak";

        list[210]=dir % "Analysis/compass_result2_match2_sortCHI_html.bak";
        list[211]=dir % "Analysis/compass_result3_match2_sortCHI_html.bak";
        list[212]=dir % "Analysis/compass_result4_match2_sortCHI_html.bak";
        list[213]=dir % "Analysis/compass_result5_match2_sortCHI_html.bak";
        list[214]=dir % "Analysis/compass_result6_match2_sortCHI_html.bak";
        list[215]=dir % "Analysis/compass_result7_match2_sortCHI_html.bak";
        list[216]=dir % "Analysis/compass_result8_match2_sortCHI_html.bak";
        list[217]=dir % "Analysis/compass_result9_match2_sortCHI_html.bak";
        list[218]=dir % "Analysis/compass_result10_match2_sortCHI_html.bak";

        list[219]=dir % "Analysis/compass_result2_match3_sortCHI_html.bak";
        list[220]=dir % "Analysis/compass_result3_match3_sortCHI_html.bak";
        list[221]=dir % "Analysis/compass_result4_match3_sortCHI_html.bak";
        list[222]=dir % "Analysis/compass_result5_match3_sortCHI_html.bak";
        list[223]=dir % "Analysis/compass_result6_match3_sortCHI_html.bak";
        list[224]=dir % "Analysis/compass_result7_match3_sortCHI_html.bak";
        list[225]=dir % "Analysis/compass_result8_match3_sortCHI_html.bak";
        list[226]=dir % "Analysis/compass_result9_match3_sortCHI_html.bak";
        list[227]=dir % "Analysis/compass_result10_match3_sortCHI_html.bak";
		
        list[228]=dir % "Analysis/compass_result2_match1_sort_html.bak";
        list[229]=dir % "Analysis/compass_result3_match1_sort_html.bak";
        list[230]=dir % "Analysis/compass_result4_match1_sort_html.bak";
        list[231]=dir % "Analysis/compass_result5_match1_sort_html.bak";
        list[232]=dir % "Analysis/compass_result6_match1_sort_html.bak";
        list[233]=dir % "Analysis/compass_result7_match1_sort_html.bak";
        list[234]=dir % "Analysis/compass_result8_match1_sort_html.bak";
        list[235]=dir % "Analysis/compass_result9_match1_sort_html.bak";
        list[236]=dir % "Analysis/compass_result10_match1_sort_html.bak";

        list[237]=dir % "Analysis/compass_result2_match2_sort_html.bak";
        list[238]=dir % "Analysis/compass_result3_match2_sort_html.bak";
        list[239]=dir % "Analysis/compass_result4_match2_sort_html.bak";
        list[240]=dir % "Analysis/compass_result5_match2_sort_html.bak";
        list[241]=dir % "Analysis/compass_result6_match2_sort_html.bak";
        list[242]=dir % "Analysis/compass_result7_match2_sort_html.bak";
        list[243]=dir % "Analysis/compass_result8_match2_sort_html.bak";
        list[244]=dir % "Analysis/compass_result9_match2_sort_html.bak";
        list[245]=dir % "Analysis/compass_result10_match2_sort_html.bak";

        list[246]=dir % "Analysis/compass_result2_match3_sort_html.bak";
        list[247]=dir % "Analysis/compass_result3_match3_sort_html.bak";
        list[248]=dir % "Analysis/compass_result4_match3_sort_html.bak";
        list[249]=dir % "Analysis/compass_result5_match3_sort_html.bak";
        list[250]=dir % "Analysis/compass_result6_match3_sort_html.bak";
        list[251]=dir % "Analysis/compass_result7_match3_sort_html.bak";
        list[252]=dir % "Analysis/compass_result8_match3_sort_html.bak";
        list[253]=dir % "Analysis/compass_result9_match3_sort_html.bak";
        list[254]=dir % "Analysis/compass_result10_match3_sort_html.bak";
		
        list[255]=dir % "Analysis/compass_result2_match1_sort_html";
        list[256]=dir % "Analysis/compass_result3_match1_sort_html";
        list[257]=dir % "Analysis/compass_result4_match1_sort_html";
        list[258]=dir % "Analysis/compass_result5_match1_sort_html";
        list[259]=dir % "Analysis/compass_result6_match1_sort_html";
        list[260]=dir % "Analysis/compass_result7_match1_sort_html";
        list[261]=dir % "Analysis/compass_result8_match1_sort_html";
        list[262]=dir % "Analysis/compass_result9_match1_sort_html";
        list[263]=dir % "Analysis/compass_result10_match1_sort_html";

        list[264]=dir % "Analysis/compass_result2_match2_sort_html";
        list[265]=dir % "Analysis/compass_result3_match2_sort_html";
        list[266]=dir % "Analysis/compass_result4_match2_sort_html";
        list[267]=dir % "Analysis/compass_result5_match2_sort_html";
        list[268]=dir % "Analysis/compass_result6_match2_sort_html";
        list[269]=dir % "Analysis/compass_result7_match2_sort_html";
        list[270]=dir % "Analysis/compass_result8_match2_sort_html";
        list[271]=dir % "Analysis/compass_result9_match2_sort_html";
        list[272]=dir % "Analysis/compass_result10_match2_sort_html";

        list[273]=dir % "Analysis/compass_result2_match3_sort_html";
        list[274]=dir % "Analysis/compass_result3_match3_sort_html";
        list[275]=dir % "Analysis/compass_result4_match3_sort_html";
        list[276]=dir % "Analysis/compass_result5_match3_sort_html";
        list[277]=dir % "Analysis/compass_result6_match3_sort_html";
        list[278]=dir % "Analysis/compass_result7_match3_sort_html";
        list[279]=dir % "Analysis/compass_result8_match3_sort_html";
        list[280]=dir % "Analysis/compass_result9_match3_sort_html";
        list[281]=dir % "Analysis/compass_result10_match3_sort_html";

        list[282]=dir % "Analysis/COMPASSresult_match1";
        list[283]=dir % "Analysis/COMPASSresult_match1.bak";
        list[284]=dir % "Analysis/COMPASSresult_match2";
        list[285]=dir % "Analysis/COMPASSresult_match2.bak";
        list[286]=dir % "Analysis/COMPASSresult_match3";
        list[287]=dir % "Analysis/COMPASSresult_match3.bak";
		
        list[288]=dir % "Analysis/manualmode";
        list[289]=dir % "Analysis/manualmode.bak";
        list[290]=dir % "Analysis/htmlindex.idx";
        list[291]=dir % "Analysis/indice.idx";
        list[292]=dir % "Analysis/inSSP.ssp";
        list[293]=dir % "Analysis/seqfile.seq";
        list[294]=dir % "Analysis/seqfile.seq2";
        list[295]=dir % "Analysis/SetMaxFrag.txt1";
        list[296]=dir % "Analysis/SetMaxFrag.txt2";
        list[297]=dir % "Analysis/SetMaxFrag.txt3";
        list[298]=dir % "Analysis/sspSeq.s";
        list[299]=dir % "Analysis/sspSeq.s2";
        list[300]=dir % "Analysis/statistics.txt";
        list[301]=dir % "Analysis/warnings.txt";
		
        list[302]=dir % "Analysis/hn.hn";
        list[303]=dir % "Analysis/n.n";
        list[304]=dir % "Analysis/ca.ca";
        list[305]=dir % "Analysis/cb.cb";
        list[306]=dir % "Analysis/co.co";

        delList(list);
	}
    void delList(QString list[317])
	{
        for(int i = 0; i<317; i++)
		{
            QFile file(list[i]);
            if(file.exists())
                QFile::remove(list[i]);
		}
	}
};
#endif
