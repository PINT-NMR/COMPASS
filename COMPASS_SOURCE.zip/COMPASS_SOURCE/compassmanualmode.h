#ifndef COMPASSMANUALMODE_H
#define COMPASSMANUALMODE_H

#include <QWidget>
#include <QUrl>
#include "compasshelp4.h"
#include "warnings2.h"
#include "passdef.h"
#include "compassvec.h"
#include "parser2.h"
#include "shifts.h"
#include <QTextDocument>
#include "qcustomplot.h"
#include <QUrl>
#include <QObject>
#include <QTextObjectInterface>
#include <QPicture>
#include <QVariant>
#include <QPainter>

namespace Ui
{
	class CompassManualMode;
}
class CompassManualMode : public QWidget
{
	Q_OBJECT

public:
	CompassManualMode(QWidget *parent = 0);
	~CompassManualMode();

private:
	Ui::CompassManualMode *ui;
    Warnings2 *winWarn2;
    QMenuBar *menuBar;

private slots:
    void compassMode();
    void quitApp();
	void anchorClicked(const QUrl &url);
    void displayHelp();
	void setResbox();
	void on_overlayButton_clicked();
	void on_deleteButton_clicked();
	void on_calculateButton_clicked();
	void DisplayInfo(std::string resno);
	std::string aa3to1(std::string aa);
	void stat(std::string file);
	void rename(int save);
	std::string ftoa(double doub);
	void ssp();
	double Compensate(std::string cs, std::string resno, std::string seqRead, std::string first, std::string ssp_deut, std::string nucl);
	double Trosy(std::string cs, std::string trosy, std::string nucl);
	int saveIdx();
	void undoFunc();
	void on_undoButton_clicked();
    void on_previewButton_clicked();
    void warn2();
    void warn();
    void hideWarnings();
    void editChemicalShifts();
	void readfile();
	void readfile_seq(std::string fnam, int resSeq, int noPro);
    void createBak(int bakI);
	void setAxis();
	void on_ResetButton_clicked();
	void mouseWheel();
	void mousePress();
	void selectionChanged();
	void addGraph();
	void resetPlot();
    void saveSsp();
    void goToMainSig();

signals:
    void renderCompassMode();
    void goToMain();
};
#endif
