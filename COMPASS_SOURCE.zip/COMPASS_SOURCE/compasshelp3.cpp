#include "compasshelp3.h"
#include "ui_compasshelp3.h"
#include <QtWidgets>
#include "QRect"		
#include "QDesktopWidget"

CompassHelp3::CompassHelp3(QWidget *parent) :
    QDialog(parent),
	ui(new Ui::CompassHelp3)
{
	ui->setupUi(this);
}

CompassHelp3::~CompassHelp3()
{
	delete ui;
}

void CompassHelp3::on_closeButton_clicked()
{
    accept();
}
