#ifndef QUERYERROR6_H
#define QUERYERROR6_H

#include <QDialog>

namespace Ui
{
	class QueryError6;
}

class QueryError6 : public QDialog
{
	Q_OBJECT

public:
	QueryError6(QWidget *parent = 0);
	~QueryError6();


private slots:
    void on_closeErrButton6_clicked();

private:
	Ui::QueryError6 *ui;

};

#endif
